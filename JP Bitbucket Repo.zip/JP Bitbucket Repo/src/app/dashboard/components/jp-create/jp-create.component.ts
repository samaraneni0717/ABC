import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'jp-create',
  templateUrl: './jp-create.component.html',
  styleUrls: ['./jp-create.component.scss']
})
export class JpCreateComponent implements OnInit {
  jpForm: FormGroup;
  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.jpForm = this.fb.group({
      jobCode: ['', [Validators.required, Validators.maxLength(50)]],
      jobTitle: ['', [Validators.required, Validators.email]]
    });
  }
}
