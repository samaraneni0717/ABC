import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { JpCreateComponent } from '../../components/jp-create/jp-create.component';

@Component({
  selector: 'jp-shell',
  templateUrl: './jp-shell.component.html',
  styleUrls: ['./jp-shell.component.scss']
})
export class JpShellComponent implements OnInit {
  showCreate = false;
  constructor(private dialog: MatDialog) {}

  ngOnInit() {}

  openDialog(): void {
    this.showCreate = true;
    const dialogRef = this.dialog.open(JpCreateComponent, {
      width: '850px'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.showCreate = false;
    });
  }
}
