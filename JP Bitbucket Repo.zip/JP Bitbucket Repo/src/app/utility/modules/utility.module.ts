import { NgModule } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { SharedModule } from 'src/app/shared/modules/shared.module';
import { SlideinComponent } from '../slidein/slidein.component';

@NgModule({
  imports: [SharedModule],
  declarations: [NavbarComponent, SlideinComponent],
  exports: [NavbarComponent, SlideinComponent]
  // entryComponents: [SlideinComponent]
})
export class UtilityModule {}
