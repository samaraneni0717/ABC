import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';

@Component({
  selector: 'jp-slidein',
  templateUrl: './slidein.component.html',
  styleUrls: ['./slidein.component.scss'],
  animations: [
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(20%)' })),
      transition('void => *', [
        style({ transform: 'translateX(100%)' }),
        animate(1000)
      ]),
      transition('* => void', [
        animate(1000, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class SlideinComponent {}
