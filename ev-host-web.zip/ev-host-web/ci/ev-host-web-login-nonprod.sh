#!/bin/bash -x

fly -t dt-smart-breaker sync
fly -t dt-smart-breaker login \
--team-name smart-breaker \
--username smart-breaker \
--concourse-url http://ccdt.duke-energy.com
