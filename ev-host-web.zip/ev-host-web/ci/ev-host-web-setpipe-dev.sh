#!/bin/bash -x

fly -t dt-smart-breaker sync
fly -t dt-smart-breaker set-pipeline \
--pipeline build-ev-host-web-dev \
-c ev-host-web-pipeline.yml \
--load-vars-from "ev-host-web-parms-dev.yml" \
--load-vars-from "ev-host-web-parms-common.yml"

fly -t dt-smart-breaker hide-pipeline --pipeline build-ev-host-web-dev
set +x
echo " "
echo "fly -t dt-smart-breaker expose-pipeline --pipeline build-ev-host-web-dev"
echo "fly -t dt-smart-breaker destroy-pipeline --pipeline build-ev-host-web-dev"
