#!/bin/bash -x

fly -t cust-smart-breaker sync
fly -t cust-smart-breaker set-pipeline \
--pipeline build-ev-host-web-qa \
-c ev-host-web-pipeline-qa.yml \
--load-vars-from "ev-host-web-parms-qa.yml" \
--load-vars-from "ev-host-web-parms-common.yml"

fly -t cust-smart-breaker expose-pipeline --pipeline build-ev-host-web-qa
set +x
echo " "
echo "fly -t cust-smart-breaker hide-pipeline --pipeline build-ev-host-web-qa"
echo "fly -t cust-smart-breaker destroy-pipeline --pipeline build-ev-host-web-qa"
