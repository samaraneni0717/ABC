#!/bin/bash -x

fly -t dt-smart-breaker sync
fly -t dt-smart-breaker set-pipeline \
--pipeline build-ev-host-web-sandbox \
-c ev-host-web-pipeline.yml \
--load-vars-from "ev-host-web-parms-sandbox.yml" \
--load-vars-from "ev-host-web-parms-common.yml"

fly -t dt-smart-breaker hide-pipeline --pipeline build-ev-host-web-sandbox
set +x
echo " "
echo "fly -t dt-smart-breaker expose-pipeline --pipeline build-ev-host-web-sandbox"
echo "fly -t dt-smart-breaker destroy-pipeline --pipeline build-ev-host-web-sandbox"
