#!/bin/bash -x

fly -t cust-smart-breaker sync
fly -t cust-smart-breaker login \
--team-name smart-breaker \
--username smart-breaker \
--concourse-url http://ccprodcust.duke-energy.com
