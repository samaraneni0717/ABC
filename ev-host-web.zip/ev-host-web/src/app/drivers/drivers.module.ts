import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { DriversTableComponent } from './components/drivers-table/drivers-table.component';
import { DriversComponent } from './containers/ev-drivers/drivers.component';

// NgRx
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { driversReducer } from './state/drivers.reducer';
import { DriverEffects } from './state/drivers.effect';
import { DriverEditComponent } from './components/driver-edit/driver-edit.component';
import { DriverModalComponent } from './components/driver-modal/driver-modal.component';
import { DriversSharedService } from './drivers-shared.service';

@NgModule({
    imports: [SharedModule,
        StoreModule.forFeature('drivers', driversReducer),
        EffectsModule.forFeature([DriverEffects])],
    declarations: [DriversTableComponent, DriversComponent, DriverEditComponent, DriverModalComponent],
    providers: [DriversSharedService]
})
export class DriversModule {

}
