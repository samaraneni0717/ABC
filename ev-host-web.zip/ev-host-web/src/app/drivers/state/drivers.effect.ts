import {Injectable} from '@angular/core';

import { Action } from '@ngrx/store';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';

import { DataAccess } from '../data-access.service';
import * as driversActions from './drivers.actions';

@Injectable()
export class DriverEffects {

    constructor( private actions$: Actions, private dataService: DataAccess) {    }

    @Effect()
    getDrivers$: Observable<Action> = this.actions$
        .ofType(driversActions.DriversActionTypes.GetDrivers)
        .switchMap(() => this.dataService.getDrivers()
        .map(data => new driversActions.GetDriversSuccess(data))); // action automatically dispatched to store with data

    @Effect()
    createDriver$: Observable<Action> = this.actions$
        .ofType(driversActions.DriversActionTypes.CreateDriver)
        .switchMap(() => this.dataService.createDriver())
        .map (() => new driversActions.CreateDriverSuccess());
    // To Do
    // 1) Catch error
    // 2) Check if the ID of the newly created one doesn't exist then update the state with the new one

}
