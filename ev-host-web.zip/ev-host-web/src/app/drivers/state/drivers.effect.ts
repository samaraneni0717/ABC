import { Injectable } from '@angular/core';

import { Action, Store } from '@ngrx/store';
import { Actions, Effect } from '@ngrx/effects';
import { Observable } from 'rxjs/Observable';

import { DataAccess } from '../data-access.service';
import * as driversActions from './drivers.actions';

import { map, switchMap, mergeMap, catchError } from 'rxjs/operators';

import * as fromRoot from './../../state/app.state';

@Injectable()
export class DriverEffects {

    constructor(private actions$: Actions, private dataService: DataAccess, private store: Store<fromRoot.AppState>) { }

    @Effect()
    createDriver$: Observable<Action> = this.actions$
        .ofType(driversActions.DriversActionTypes.CreateDriver)
        .switchMap(() => this.dataService.createDriver())
        .map(() => new driversActions.CreateDriverSuccess());
    // To Do
    // 1) Catch error
    // 2) Check if the ID of the newly created one doesn't exist then update the state with the new one

    @Effect()
    editDriver$: Observable<Action> = this.actions$
        .ofType(driversActions.DriversActionTypes.EditDriver)
        .pipe(
            switchMap((action: driversActions.EditDriver) => {
                this.store.dispatch(new driversActions.StartSpinner());
                return this.dataService.editDriver(action.payload)
                    .pipe(
                        mergeMap((data: any) => {
                            return [
                                new driversActions.EditDriverSuccess(data),
                                new driversActions.StopSpinner()
                            ];
                        }),
                        catchError((error) => {
                            console.log('get drivers call failed', error);
                            return [
                                new driversActions.StopSpinner()
                            ];
                        })
                    );
            })
        );


    @Effect()
    getDrivers$: Observable<Action> = this.actions$
        .ofType(driversActions.DriversActionTypes.GetDrivers)
        .pipe(
            switchMap(() => {
                this.store.dispatch(new driversActions.StartSpinner());
                return this.dataService.getDrivers()
                    .pipe(
                        mergeMap((data: any) => {
                            return [
                                new driversActions.GetDriversSuccess(data),
                                new driversActions.StopSpinner()
                            ];
                        }),
                        catchError((error) => {
                            console.log('get drivers call failed', error);
                            return [
                                new driversActions.StopSpinner()
                            ];
                        })
                    );
            })
        );
}
