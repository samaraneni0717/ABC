import { createSelector, createFeatureSelector } from '@ngrx/store';
import * as fromDrivers from './drivers.reducer';


// Selector  functions
const getDriverFeatureState = createFeatureSelector <fromDrivers.DriversState>('drivers');

export const getDrivers = createSelector (
    getDriverFeatureState,
    state => state.drivers
);

// export const createDriver = createSelector (
//     getDriverFeatureState
//     // state => state.
//
