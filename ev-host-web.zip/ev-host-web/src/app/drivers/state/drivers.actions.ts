import { Action } from '@ngrx/store';
import { IDriver } from '../model/i-driver.interface';

export enum DriversActionTypes {
    GetDrivers = '[Drivers] GetDrivers',
    GetDriversSuccess = '[Drivers] GetDriversSuccess',
    CreateDriver = '[Drivers] CreateDriver',
    CreateDriverSuccess = '[Drivers] CreateDriverSuccess'
}
// Action Creators
export class GetDrivers implements Action {

    readonly type = DriversActionTypes.GetDrivers;
}

export class GetDriversSuccess implements Action {

    readonly type = DriversActionTypes.GetDriversSuccess;
    constructor (public payload: IDriver[]) { }
}

export class CreateDriver implements Action {
    readonly type = DriversActionTypes.CreateDriver;
    constructor (public payload: any) { }  // TO DO: Make payLoad strongly typed
}

export class CreateDriverSuccess implements Action {
    readonly type = DriversActionTypes.CreateDriverSuccess;
}
// Union the valid types

export type DriverActions = GetDrivers | GetDriversSuccess | CreateDriver;
