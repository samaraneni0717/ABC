import { Action } from '@ngrx/store';
import { IDriver } from '../model/i-driver.interface';
import { Drivers } from '../model/drivers';

export enum DriversActionTypes {
    StartSpinner  = '[Drivers] StartSpinner',
    StopSpinner = '[Drivers] StopSpinner',
    GetDrivers = '[Drivers] GetDrivers',
    GetDriversSuccess = '[Drivers] GetDriversSuccess',
    CreateDriver = '[Drivers] CreateDriver',
    CreateDriverSuccess = '[Drivers] CreateDriverSuccess',
    EditDriver = '[Drivers] EditDriver',
    EditDriverSuccess = '[Drivers] EditDriverSuccess'
}
// Action Creators
export class GetDrivers implements Action {

    readonly type = DriversActionTypes.GetDrivers;
}

export class GetDriversSuccess implements Action {

    readonly type = DriversActionTypes.GetDriversSuccess;
    constructor(public payload: Drivers[]) { }
}

export class CreateDriver implements Action {
    readonly type = DriversActionTypes.CreateDriver;
    constructor(public payload: any) { }  // TO DO: Make payLoad strongly typed
}

export class CreateDriverSuccess implements Action {
    readonly type = DriversActionTypes.CreateDriverSuccess;
}

export class EditDriver implements Action {
    readonly type = DriversActionTypes.EditDriver;
    constructor(public payload: number) { }
}

export class EditDriverSuccess implements Action {
    readonly type = DriversActionTypes.EditDriverSuccess;
    constructor(public payload: any) { }
}

export class StartSpinner implements Action {
    readonly type = DriversActionTypes.StartSpinner;
}

export class StopSpinner implements Action {
    readonly type = DriversActionTypes.StopSpinner;
}
// Union the valid types

export type DriverActions = GetDrivers | GetDriversSuccess
| CreateDriver | EditDriver | EditDriverSuccess | StartSpinner | StopSpinner;
