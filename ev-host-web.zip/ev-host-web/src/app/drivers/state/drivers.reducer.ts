import { IDriver} from '../model/i-driver.interface';
import { DriverActions, DriversActionTypes } from './drivers.actions';

// state for this feature (Drivers)
export interface  DriversState {
    drivers: IDriver[];
}

const initialState: DriversState = {
    drivers: []
};

export function driversReducer(state = initialState, action: DriverActions): DriversState {

        switch (action.type) {

            case DriversActionTypes.GetDriversSuccess:

                return {
                    ...state,
                    drivers: action.payload
                };

            default:

                return state;
        }
    }
