import { IDriver } from '../model/i-driver.interface';
import { DriverActions, DriversActionTypes } from './drivers.actions';
import { Drivers } from '../model/drivers';

// state for this feature (Drivers)
export interface DriversState {
    drivers: Drivers[];
    driverInfo: IDriver;
    isLoading: boolean;
}

const initialState: DriversState = {
    drivers: [],
    driverInfo: null,
    isLoading: true
};

export function driversReducer(state = initialState, action: DriverActions): DriversState {

    switch (action.type) {

        case DriversActionTypes.GetDriversSuccess:

            return {
                ...state,
                drivers: action.payload
            };

        case DriversActionTypes.EditDriverSuccess:
            return {
                ...state,
                driverInfo: action.payload
            };

        case DriversActionTypes.StartSpinner:
            return {
                ...state,
                isLoading: true
            };

        case DriversActionTypes.StopSpinner:
            return {
                ...state,
                isLoading: false
            };
        default:

            return state;
    }
}
