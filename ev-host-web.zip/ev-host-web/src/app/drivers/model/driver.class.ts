

export class Driver {

    constructor(public firstName: string, public lastName: string, public email: string, public carMake: string, public lastSession: string, public lastCharger: string) { }

}






