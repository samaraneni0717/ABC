export interface IDriver {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  carMake: string;
  carModel: string;
  carYear: 2017;
  dateAdded: string;
  city: string;
  zipcode: string;
  lastSession: string;
  accountNumber: number;
  lastCharger: string;
  address1: string;
  address2: string;
  phoneNumber: string;
  minutesUsed: number;
  state: string;


}
