export interface IDriver {

    firstName: string;
    lastName: string;
    email: string;
    carMake: string;
    lastSession: string;
    lastCharger: string;


  }
