export const validationMessages = {
    firstName: {
        required: 'First name is required.',
        maxlength: 'First name cannot exceed 50 characters.'
    },
    lastName: {
        required: 'Last name is required.',
        maxlength: 'Last name cannot exceed 50 characters.'
    },
    email: {
        required: 'Email is required.',
        email: 'Email is invalid.'
    },
    address1: {
        required: 'Address is required.'
    },
    city: {
        required: 'City is required.'
    },
    zipcode: {
        required: 'Zipcode is required.',
        pattern: 'Zipcode is invalid.'
    },

    phoneNumber: {
        required: 'Phone number is required.',
        pattern: 'Phone number is invalid.'
    },
    state: {
        required: 'State is required.'
    },

    carModel: {
        required: 'CarModel is required.'
    },

    carMake: {
        required: 'CarMake is required.'
    }

};
