import { IDriver } from './i-driver.interface';

export interface AppState {

    drivers: Array<IDriver>;


}
