import { Component, OnInit, ChangeDetectionStrategy} from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import * as fromRoot from '../../../state/app.state';
import * as driversActions from '../../state/drivers.actions';
import * as fromDrivers from '../../state';
import { Drivers } from '../../model/drivers';

@Component({
  selector: 'ev-drivers',
  templateUrl: './drivers.component.html',
  styleUrls: ['./drivers.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DriversComponent implements OnInit {


  drivers$: Observable<Drivers[]>;
  isDriverscreenLoading$: Observable<boolean>;
  showModal = false;
  showAlert = false;
  triggerModal = 0;
  typeOfAlert = 'error'; // TO DO: Need to updated with the API response

  constructor(private store: Store<fromRoot.AppState>) { }

  ngOnInit() {


    // dispatch api call to the backend
    this.store.dispatch(new driversActions.GetDrivers());

    // retrieve the value from the store and assigning to this.drivers
    // to pass to drivers presentation component.
    this.drivers$ = this.store.select(fromDrivers.getDrivers);

    this.isDriverscreenLoading$ = this.store.select(fromDrivers.isSpinnerLoading);
  }


  inviteDriver() {
    this.triggerModal++;
    this.showModal = true;
  }

  saveDriver(driver: any) {
    this.showModal = false;
    this.store.dispatch(new driversActions.CreateDriver(driver));
   // this.showAlert = true;
  }

  handleAlert() {
    this.showAlert = false;
  }
}
