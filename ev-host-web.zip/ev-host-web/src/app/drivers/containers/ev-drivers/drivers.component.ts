import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';

import * as fromRoot from '../../../state/app.state';
import * as driversActions from '../../state/drivers.actions';
import * as fromDrivers from '../../state';
import { IDriver } from '../../model/i-driver.interface';
import { DriversSharedService } from '../../drivers-shared.service';

@Component({
  selector: 'ev-drivers',
  templateUrl: './drivers.component.html',
  styleUrls: ['./drivers.component.scss']
})
export class DriversComponent implements OnInit {


  drivers$: Observable<IDriver[]>;
  showModal = false;

  constructor(public store: Store<fromRoot.AppState>, public driversSharedService: DriversSharedService) { }

  ngOnInit() {

    // dispatch api call to the backend
    this.store.dispatch(new driversActions.GetDrivers());

    // retrieve the value from the store and assigning to this.drivers
    // to pass to drivers presentation component.
    this.drivers$ = this.store.select(fromDrivers.getDrivers);
  }


  inviteDriver() {
    this.showModal = true;
    this.driversSharedService.openModal();
  }

  saveDriver(driver: any) {
    this.store.dispatch(new driversActions.CreateDriver(driver));
  }
}
