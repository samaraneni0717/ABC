import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../state/app.state';
import * as driversActions from '../../state/drivers.actions';
import { Observable } from 'rxjs/Observable';
import * as fromDrivers from '../../state';

@Component({
    templateUrl: './driver-shell.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DriverShellComponent implements OnInit {

    driverInfo$: Observable<any>;
    modalCalled = 0;
    showModal = false;
    ignoreChanges = 0;
    isEditScreenLoading$: Observable<boolean>;
    constructor(private route: ActivatedRoute, private store: Store<fromRoot.AppState>) { }
    ngOnInit() {
        const param = this.route.snapshot.params['id'];
        console.log(param);
        this.store.dispatch(new driversActions.EditDriver(param));

        // get the driverInfo
        this.driverInfo$ = this.store.select(fromDrivers.editDriver);
        this.driverInfo$.subscribe((data) => {console.log('the values are', data); });
        this.isEditScreenLoading$ = this.store.select(fromDrivers.isSpinnerLoading);
    }
    openModal() {
        this.showModal = true;
        this.modalCalled++;
    }

    emitFromConfirm() {
        this.ignoreChanges++;
    }
}
