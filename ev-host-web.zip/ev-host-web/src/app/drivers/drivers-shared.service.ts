import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class DriversSharedService {

    private showDriverModalSource = new BehaviorSubject<boolean>(false);

    public showDriverModal$ = this.showDriverModalSource.asObservable();

    public openModal() {
        this.showDriverModalSource.next(true);
    }

}
