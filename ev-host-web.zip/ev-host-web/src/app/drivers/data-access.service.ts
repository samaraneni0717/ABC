import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';

// RXJS

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/empty';


// Classes

import { PendingRequest } from './model/pending-request.class';


//  Services

import { Drivers } from './model/drivers';
import { Login } from '../login/login.service';




@Injectable()
export class DataAccess {

    private queue: Array<PendingRequest> = new Array<PendingRequest>();

    constructor(private http: HttpClient, private loginService: Login) { }

    /* **************************************
    //***** HTTP REQUEST QUEUE METHODS *****
    //**************************************/

    private submit(pr: PendingRequest) {

        if (pr.method === 'GET') {
            this.http.get<any>(pr.url, { headers: pr.headers, params: pr.params })
                .catch(err => {

                    switch (err.status) {

                        case 401: {

                            return this.handle401ErrorRefresh(pr.url, pr.method, pr.headers, pr.params);

                        }
                        case 500: {

                            return this.handle500Error();

                        }
                        default: {

                            return this.handleOtherError();

                        }

                    }

                })
                .subscribe(res => {

                    pr.subject.next(res);
                    this.queue.shift();
                    this.submitNextRequest();

                });

        }

    }

    private submitNextRequest() {

        if (this.queue.length > 0) { this.submit(this.queue[0]); }

    }

    private addRequest(url: string, method: string, headers: HttpHeaders, params?: HttpParams, payload?: any) {

        const sub = new Subject<any>();

        const req = new PendingRequest(url, method, headers, sub, params, payload);

        this.queue.push(req);

        if (this.queue.length === 1) { this.submitNextRequest(); }

        return sub;

    }

    // ******* INVITE A DRIVER ****/
    createDriver(): Observable<any> {
        console.log('Saved the driver');
        return of('test');
    }

    // ******* EDIT A DRIVER ****/

    editDriver(id: number): Observable<any> {
        return of({
            id: '1234',
            firstName: 'Cindy',
            lastName: 'Greatdriver',
            email: 'cindy@letspretendthisisanemailaddress.org',
            carMake: 'Tesla',
            carModel: 'S3',
            carYear: 2017,
            dateAdded: 'Sept 01, 2018',
            city: 'Charlotte',
            zipcode: '28260',
            accountNumber: 202002002,
            address1: '1911 arbr v dr',
            address2: 'near shell gas',
            phoneNumber: '9888877766',
            minutesUsed: 223,
            state: 'North Carolina'

        });
    }

    /*******************************************
    //***** APPLICATION REQUESTS FOR DATA *******
    //*******************************************/

    getDrivers(): Observable<Drivers[]> {

        return of([

            {
                id: '1234',
                firstName: 'Cindy',
                lastName: 'Greatdriver',
                email: 'cindy@letspretendthisisanemailaddress.org',
                carMake: 'Nissan',
                lastSession: '07/01/18 11:18 AM',
                lastCharger: 'Charger 1'

            },
            {
                id: '1234',
                firstName: 'Greg',
                lastName: 'Gooddriver',
                email: 'greg@letspretendthisisanemailaddress.org',
                carMake: 'Ford',
                lastSession: '04/06/18 01:33 PM',
                lastCharger: 'Charger 5'

            },
            {
                id: '1234',
                firstName: 'Doug',
                lastName: 'Decentdriver',
                email: 'doug@letspretendthisisanemailaddress.org',
                carMake: 'Ford',
                lastSession: '05/22/18 07:18 PM',
                lastCharger: 'Charger 3'

            },
            {
                id: '1234',
                firstName: 'Larry',
                lastName: 'Letsnottalkaboutitdriver',
                email: 'larry@letspretendthisisanemailaddress.org',
                carMake: 'FastCar',
                lastSession: '03/17/18 04:22 PM',
                lastCharger: 'Charger 2'

            },
            {
                id: '1234',
                firstName: 'Gary',
                lastName: 'Greatdriver',
                email: 'gary@letspretendthisisanemailaddress.org',
                carMake: 'Nissan',
                lastSession: '04/01/18 11:15 AM',
                lastCharger: 'Charger 3'

            },
            {
                id: '1234',
                firstName: 'Sue',
                lastName: 'Gooddriver',
                email: 'sue@letspretendthisisanemailaddress.org',
                carMake: 'Toyota',
                lastSession: '04/07/18 01:32 PM',
                lastCharger: 'Charger 5'

            },
            {
                id: '1234',
                firstName: 'Michael',
                lastName: 'Decentdriver',
                email: 'michael@letspretendthisisanemailaddress.org',
                carMake: 'Toyota',
                lastSession: '05/25/18 07:16 PM',
                lastCharger: 'Charger 2'

            },
            {
                id: '1234',
                firstName: 'Lauren',
                lastName: 'Letsnottalkaboutitdriver',
                email: 'lauren@letspretendthisisanemailaddress.org',
                carMake: 'FastCar',
                lastSession: '03/14/18 04:21 PM',
                lastCharger: 'Charger 4'

            },
            {
                id: '1234',
                firstName: 'Judy',
                lastName: 'Greatdriver',
                email: 'judy@letspretendthisisanemailaddress.org',
                carMake: 'Nissan',
                lastSession: '07/03/18 11:19 AM',
                lastCharger: 'Charger 2'

            },
            {
                id: '1234',
                firstName: 'Stan',
                lastName: 'Gooddriver',
                email: 'stan@letspretendthisisanemailaddress.org',
                carMake: 'Ford',
                lastSession: '04/04/18 01:32 PM',
                lastCharger: 'Charger 4'

            },
            {
                id: '1234',
                firstName: 'Emily',
                lastName: 'Decentdriver',
                email: 'emily@letspretendthisisanemailaddress.org',
                carMake: 'Ford',
                lastSession: '05/20/18 07:17 PM',
                lastCharger: 'Charger 3'

            },
            {
                id: '1234',
                firstName: 'Linda',
                lastName: 'Letsnottalkaboutitdriver',
                email: 'linda@letspretendthisisanemailaddress.org',
                carMake: 'FastCar',
                lastSession: '03/25/18 04:21 PM',
                lastCharger: 'Charger 2'

            },
            {
                id: '2345',
                firstName: 'Bill',
                lastName: 'Greatdriver',
                email: 'bill@letspretendthisisanemailaddress.org',
                carMake: 'Nissan',
                lastSession: '07/09/18 11:19 AM',
                lastCharger: 'Charger 1'

            },
            {
                id: '678999',
                firstName: 'Dan',
                lastName: 'Gooddriver',
                email: 'dan@letspretendthisisanemailaddress.org',
                carMake: 'Nissan',
                lastSession: '04/01/18 01:31 PM',
                lastCharger: 'Charger 2'

            },
            {
                id: '278936',
                firstName: 'Cynthia',
                lastName: 'Decentdriver',
                email: 'cynthia@letspretendthisisanemailaddress.org',
                carMake: 'Chevrolet',
                lastSession: '05/17/18 07:22 PM',
                lastCharger: 'Charger 2'

            },
            {
                id: '9897',
                firstName: 'Lenny',
                lastName: 'Letsnottalkaboutitdriver',
                email: 'lenny@letspretendthisisanemailaddress.org',
                carMake: 'FastCar',
                lastSession: '03/15/18 04:33 PM',
                lastCharger: 'Charger 4'

            }

        ]);

    }

    // getBreakers(): Observable<Devices> {

    //     let token = JSON.parse(sessionStorage.getItem("user")).access_token;
    //     let environment = JSON.parse(sessionStorage.getItem("env"));

    //     let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

    //     let brUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/devices/summary`;
    //     let brHeaders: HttpHeaders = new HttpHeaders();

    //     brHeaders = brHeaders.append('Content-Type', 'application/json');
    //     brHeaders = brHeaders.append('Authorization',`Bearer ${token}`);

    //     let brParams: HttpParams = new HttpParams();

    //     return this.addRequest(brUrl, 'GET', brHeaders, brParams).switchMap(brks => {

    //         let breakers = new Array<BreakerImpl>();

    //         for(let i=0; i<brks.length; i++){

    //             let breaker = new BreakerImpl();

    //             breaker.breakerID = brks[i].hardwareDeviceId;
    //             breaker.breakerType = brks[i].breakerType;
    //             breaker.cloudAgentId = brks[i].cloudAgentId;
    //             breaker.commissionedDate = brks[i].commissionedDate;
    //             breaker.deviceName = brks[i].name;
    //             breaker.group = brks[i].group;
    //             breaker.id = brks[i].id;
    //             breaker.lastUpdate = brks[i].lastUpdate;
    //             breaker.location = brks[i].location;
    //             breaker.loadType = brks[i].loadType;
    //             breaker.recentUsage = brks[i].recentUsage;
    //             breaker.status = brks[i].status;

    //             breakers[i] = breaker;

    //         }

    //         return Observable.of({devices: breakers});

    //     });

    // }



    /************************************
    //***** ERROR HANDLING METHODS *******
    //************************************/

    handle401ErrorRefresh(url: string, method: string, header: HttpHeaders, params?: HttpParams, payload?: any): Observable<any> {

        const errorObservable: Observable<Array<any>> = of(new Array<any>());

        return errorObservable
            .switchMap((empty) => {

                return this.removeRefreshToken();

            }).switchMap((refTok) => {

                return this.loginService.refresh(refTok);

            }).switchMap((refRes) => {

                if (refRes === true) {

                    const newToken: string = JSON.parse(sessionStorage.getItem('user')).access_token;

                    // SET HEADERS IN ALL PENDING REQUESTS TO USE NEW TOKEN INSTEAD OF OLD TOKEN
                    this.queue.forEach(pr => {

                        pr.headers = new HttpHeaders();
                        pr.headers = pr.headers.append('Content-Type', 'application/json');
                        pr.headers = pr.headers.append('Authorization', `Bearer ${newToken}`);
                    });

                    // HEADERS BEING PASSED IN BECAUSE WE MAY NEED SOME INFO BUT REBUILD HEADERS HERE DUE TO NEW TOKEN
                    header = null;
                    header = new HttpHeaders();
                    header = header.append('Content-Type', 'application/json');
                    header = header.append('Authorization', `Bearer ${newToken}`);

                    if (method === 'GET') {
                        return this.http.get<any>(url, { headers: header, params: params })
                            .catch(err => {

                                return this.handleError(err);

                            });
                    } else if (method === 'PUT') {
                        return this.http.put<any>(url, payload, { headers: header, params: params })
                            .catch(err => {

                                return this.handleError(err);

                            });

                    }

                } else {

                    this.loginService.redirect();
                    return Observable.empty<any>();

                }

            });

    }

    removeRefreshToken(): Observable<string> {

        const refreshToken: string = JSON.parse(sessionStorage.getItem('user')).refresh_token;
        const rt: Observable<string> = of(refreshToken);

        sessionStorage.removeItem('user');
        return rt;
    }

    handleError<T>(err: HttpErrorResponse): Observable<T> {

        switch (err.status) {

            case 401: {

                return this.handle401Error();

            }
            case 500: {

                return this.handle500Error();

            }
            default: {

                return this.handleOtherError();

            }

        }
    }

    handle401Error<T>(): Observable<T> {

        this.loginService.redirect();
        return Observable.empty<T>();

    }

    handle500Error<T>(): Observable<T> {

        // THIS METHOD IS A TEMPORARY PLACEHOLDER ... CURRENTLY ONLY HAVE HANDLER FOR 401 ERROR WITH REFRESH
        return Observable.empty<T>();

    }

    handleOtherError<T>(): Observable<T> {

        // THIS METHOD IS A TEMPORARY PLACEHOLDER ... CURRENTLY ONLY HAVE HANDLER FOR 401 ERROR WITH REFRESH
        return Observable.empty<T>();

    }



}
