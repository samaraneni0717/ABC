import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { Driver } from '../../model/driver.class';
import { IDriver } from '../../model/i-driver.interface';


@Component({
  selector: 'ev-drivers-table',
  templateUrl: './drivers-table.component.html',
  styleUrls: ['./drivers-table.component.scss']
})
export class DriversTableComponent implements OnInit {


  @Input() drivers: IDriver[];

  // Sorting Properties

  nameSortDirection = '';
  nameShowImage = 'ascending';
  nameCurrentState = 'ascending';

  emailSortDirection = '';
  emailShowImage = '';
  emailCurrentState = 'ascending';

  carSortDirection = '';
  carShowImage = '';
  carCurrentState = 'ascending';

  lastSessionSortDirection = '';
  lastSessionShowImage = '';
  lastSessionCurrentState = 'ascending';

  lastChargerSortDirection = '';
  lastChargerShowImage = '';
  lastChargerCurrentState = 'ascending';

  lastSortClick = 'name';


  // Pagination Properties

  totalRows = 0;
  firstRowNum = 1;
  lastRowNum = 0;
  showRows = 10;
  driverPages: Array<Array<Driver>> = new Array<Array<Driver>>(); // drivers in multiple arrays corresponding to pages
  selectedDriverPage: Array<Driver>;
  currentDriverPagesIndex: number;

  constructor() { }

  ngOnInit() {

    // Sorting

    this.sortDriversByName();

    // Pagination

    this.processPagination();


  }



  processPagination() {

    this.totalRows = this.drivers.length;
    this.firstRowNum = 1;
    this.lastRowNum = (this.totalRows < this.showRows) ? this.totalRows : this.showRows;
    this.showRows = 10; // this will come from UI input
    this.currentDriverPagesIndex = 0;


    let currentPageBreakPoint = this.showRows;


    this.driverPages[this.currentDriverPagesIndex] = new Array<Driver>();

    this.drivers.forEach((drv, idx) => {

      if ((idx + 1) > currentPageBreakPoint) {


        this.currentDriverPagesIndex = this.currentDriverPagesIndex + 1;
        this.driverPages[this.currentDriverPagesIndex] = new Array<Driver>();
        currentPageBreakPoint = currentPageBreakPoint + this.showRows;

      }

      this.driverPages[this.currentDriverPagesIndex].push(drv);

    });

    this.currentDriverPagesIndex = 0; // set back to zero after processing
    this.selectedDriverPage = this.driverPages[this.currentDriverPagesIndex];

  }

  exportBilling() {



  }

  inviteDriver() {

    console.log('invite driver clicked');


  }

  headerClick(location: string) {

    this[this.lastSortClick + 'ShowImage'] = '';

    switch (location) {

      case 'name':

        if (this.nameCurrentState === 'ascending') {

          this.nameCurrentState = 'descending';
          this.nameShowImage = 'descending';

        } else {

          this.nameCurrentState = 'ascending';
          this.nameShowImage = 'ascending';

        }

        this.sortDriversByName();
        this.lastSortClick = 'name';
        break;


      case 'email':

        if (this.emailCurrentState === 'ascending') {

          this.emailCurrentState = 'descending';
          this.emailShowImage = 'descending';

        } else {

          this.emailCurrentState = 'ascending';
          this.emailShowImage = 'ascending';

        }

        this.sortDriversByEmail();
        this.lastSortClick = 'email';
        break;


      case 'car':

        if (this.carCurrentState === 'ascending') {

          this.carCurrentState = 'descending';
          this.carShowImage = 'descending';

        } else {

          this.carCurrentState = 'ascending';
          this.carShowImage = 'ascending';

        }

        this.sortDriversByCar();
        this.lastSortClick = 'car';
        break;


      case 'lastSession':

        if (this.lastSessionCurrentState === 'ascending') {

          this.lastSessionCurrentState = 'descending';
          this.lastSessionShowImage = 'descending';

        } else {

          this.lastSessionCurrentState = 'ascending';
          this.lastSessionShowImage = 'ascending';

        }

        this.sortDriversByLastSession();
        this.lastSortClick = 'lastSession';
        break;

      case 'lastCharger':

        if (this.lastChargerCurrentState === 'ascending') {

          this.lastChargerCurrentState = 'descending';
          this.lastChargerShowImage = 'descending';

        } else {

          this.lastChargerCurrentState = 'ascending';
          this.lastChargerShowImage = 'ascending';

        }

        this.sortDriversByLastCharger();
        this.lastSortClick = 'lastCharger';
        break;


      default:

        break;

    }

  }


  mouseEnter(location: string) {



    switch (location) {

      case 'name':

        this.nameShowImage = this.nameCurrentState;
        break;

      case 'email':

        this.emailShowImage = this.emailCurrentState;
        break;

      case 'car':

        this.carShowImage = this.carCurrentState;
        break;

      case 'lastSession':

        this.lastSessionShowImage = this.lastSessionCurrentState;
        break;

      case 'lastCharger':

        this.lastChargerShowImage = this.lastChargerCurrentState;
        break;

      default:

        break;


    }

  }

  mouseLeave(location: string) {

    switch (location) {

      case 'name':

        if (!(this.lastSortClick === 'name')) { this.nameShowImage = ''; }
        break;

      case 'email':

        if (!(this.lastSortClick === 'email')) { this.emailShowImage = ''; }
        break;

      case 'car':

        if (!(this.lastSortClick === 'car')) { this.carShowImage = ''; }
        break;

      case 'lastSession':

        if (!(this.lastSortClick === 'lastSession')) { this.lastSessionShowImage = ''; }
        break;

      case 'lastCharger':

        if (!(this.lastSortClick === 'lastCharger')) { this.lastChargerShowImage = ''; }
        break;

      default:

        break;

    }

  }

  sortDriversByName() {

    if (this.nameCurrentState === 'ascending') {

      this.drivers.sort((a, b) => a.lastName < b.lastName ? -1 : 1);

    } else {

      this.drivers.sort((a, b) => a.lastName > b.lastName ? -1 : 1);

    }

    this.processPagination();

  }

  sortDriversByEmail() {

    if (this.emailCurrentState === 'ascending') {

      this.drivers.sort((a, b) => a.email < b.email ? -1 : 1);

    } else {

      this.drivers.sort((a, b) => a.email > b.email ? -1 : 1);

    }

    this.processPagination();

  }

  sortDriversByCar() {

    if (this.carCurrentState === 'ascending') {

      this.drivers.sort((a, b) => a.carMake < b.carMake ? -1 : 1);

    } else {

      this.drivers.sort((a, b) => a.carMake > b.carMake ? -1 : 1);

    }

    this.processPagination();

  }

  sortDriversByLastSession() {

    if (this.lastSessionCurrentState === 'ascending') {

      this.drivers.sort((a, b) => a.lastSession < b.lastSession ? -1 : 1);

    } else {

      this.drivers.sort((a, b) => a.lastSession > b.lastSession ? -1 : 1);

    }

    this.processPagination();

  }

  sortDriversByLastCharger() {

    if (this.lastChargerCurrentState === 'ascending') {

      this.drivers.sort((a, b) => a.lastCharger < b.lastCharger ? -1 : 1);

    } else {

      this.drivers.sort((a, b) => a.lastCharger > b.lastCharger ? -1 : 1);

    }

    this.processPagination();

  }

  pageForward() {
    const currentIdx = ++this.currentDriverPagesIndex;
    // Return when reach the end of the list
    if (!this.driverPages[currentIdx]) {
      --this.currentDriverPagesIndex;
      return;
    }

    this.selectedDriverPage = this.driverPages[currentIdx];
    if (!this.selectedDriverPage) { return; }

    let rowCount = 0;

    this.driverPages.forEach((p, i) => {

      if (i < this.currentDriverPagesIndex) {

        rowCount = rowCount + p.length;

      }

    });

    this.firstRowNum = rowCount + 1;

    this.lastRowNum = rowCount + this.driverPages[this.currentDriverPagesIndex].length;

  }

  pageBack() {
    const idx = --this.currentDriverPagesIndex;
    if (!this.driverPages[idx]) {
      ++this.currentDriverPagesIndex;
      return;
    }
    this.selectedDriverPage = this.driverPages[idx];

    let rowCount = 0;

    this.driverPages.forEach((p, i) => {

      if (i < this.currentDriverPagesIndex) {

        rowCount = rowCount + p.length;

      }

    });

    this.firstRowNum = rowCount + 1;

    this.lastRowNum = rowCount + this.driverPages[this.currentDriverPagesIndex].length;

  }


  openDriver() {
    // console.log("Opening driver");

  }

}
