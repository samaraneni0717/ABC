import {
    Component, OnInit, ViewEncapsulation,
    Renderer2, Output, EventEmitter, Input, OnChanges
} from '@angular/core';
import * as M from 'materialize-css/dist/js/materialize';
import { FormBuilder, FormGroup, Validators, FormControlName, AbstractControl } from '@angular/forms';
import { GenericValidator } from '../../../shared/generic-validator';
import { validationMessages } from '../../model/validation-messages';


@Component({
    selector: `ev-driver-modal`,
    templateUrl: './driver-modal.component.html',
    styleUrls: ['./driver-modal.component.scss'],
    encapsulation: ViewEncapsulation.None

})
export class DriverModalComponent implements OnInit, OnChanges {


    driverForm: FormGroup;
    // Use with the generic validation message class
    displayMessage: { [key: string]: string } = {};
    private validationMessages: { [key: string]: { [key: string]: string } };
    private genericValidator: GenericValidator;
    PHONE_NUMBER_PATTERN = '^(1\s?)?((\([0-9]{3}\))|[0-9]{3})[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$';
    ZIP_CODE_PATTERN = '^\d{5}(?:[-\s]\d{4})?$';
    @Output() create = new EventEmitter<any>();
    @Input() modalTriggered;
    modalInstance: any;

    // handle confirm box
    showConfirmBox = false;
    confirmBoxCalled = 0;


    constructor(private fb: FormBuilder, private renderer: Renderer2) {
        // Defines all of the validation messages for the form.
        // These could instead be retrieved from a file or database.
        this.validationMessages = validationMessages;
    }


    ngOnInit(): void {

        this.driverForm = this.fb.group({
            firstName: ['', [Validators.required,
            Validators.maxLength(50)]],
            email: ['', [Validators.required, Validators.email]],
            address1: ['', Validators.required],
            city: ['', Validators.required],
            zipcode: ['', [Validators.required, Validators.pattern(/^[0-9]{5}(?:-[0-9]{4})?$/)]],
            lastName: ['', [Validators.required,
            Validators.maxLength(50)]],
            phoneNumber: ['', [Validators.required, Validators.pattern(this.PHONE_NUMBER_PATTERN)]],
            address2: [''],
            emailText: [''],
            state: ['', Validators.required]


        });

        // Define an instance of the validator for use with this form,
        // passing in this form's set of validation messages.
        this.genericValidator = new GenericValidator(this.validationMessages);

    }

    ngOnChanges() {
        this.openModal();
    }

    // Also validate on blur
    // Helpful if the user tabs through required fields
    blur(): void {
        this.displayMessage = this.genericValidator.processMessages(this.driverForm);
        if (this.displayMessage.email && this.displayMessage.email.indexOf('required') !== -1) {
            this.displayMessage.email = 'Email is required.';

        }
        if (this.displayMessage.state && this.displayMessage.state.length > 0) {
            const elem = document.getElementsByClassName('select-dropdown')[0];
            this.renderer.addClass(elem, 'highlight-dropdown');
        } else if (!this.displayMessage.state) {
            const elem = document.getElementsByClassName('select-dropdown')[0];
            this.renderer.removeClass(elem, 'highlight-dropdown');
        }
    }

    openModal() {
        if (!this.modalInstance) {
            const options = { dismissible: false };
            const modalElem = document.getElementById('evModal');
            M.Modal.init(modalElem, options);
            this.modalInstance = M.Modal.getInstance(modalElem);

        }
        this.modalInstance.open();
        const dDownElem = document.querySelectorAll('select');
         M.FormSelect.init(dDownElem);
    }

    inviteDriver() {
        if (this.driverForm.dirty && this.driverForm.valid) {
            const d = this.driverForm.value;
            this.modalInstance.close();
            this.create.emit(d);
        }
    }
    // TO DO: Set FormControls to Pristine to get rid of 'valid' css on the fields
    setFormPristine() {
        if (this.displayMessage) {
            this.displayMessage = {};
        }
        if (this.driverForm) {
            this.driverForm.reset();
        }
    }


    modalClose() {
        if (this.driverForm.touched && this.driverForm.dirty) {
            this.showConfirmBox = true;
            this.confirmBoxCalled++;
        } else {
            this.clearModalInstance();
        }
    }


    // upon clicking 'YES' on confirmBox clears the modalInstance and the formModel
    emitFromConfirm() {
        this.clearModalInstance();
        this.setFormPristine();

    }

    clearModalInstance() {
        this.modalInstance.close();
        this.modalInstance.destroy();
        this.modalInstance = null;
    }

}
