import { Component, OnInit, ViewChildren, ElementRef, ViewEncapsulation,
    Renderer2, Output, EventEmitter, OnDestroy } from '@angular/core';
import * as M from 'materialize-css/dist/js/materialize';
import { DriversSharedService } from '../../drivers-shared.service';
import { FormBuilder, FormGroup, Validators, FormControlName } from '@angular/forms';
import { GenericValidator } from '../../../shared/generic-validator';


@Component({
    selector: `ev-driver-modal`,
    templateUrl: './driver-modal.component.html',
    styleUrls: ['./driver-modal.component.scss'],
    encapsulation: ViewEncapsulation.None

})
export class DriverModalComponent implements OnInit, OnDestroy {


    driverForm: FormGroup;
    // Use with the generic validation message class
    displayMessage: { [key: string]: string } = {};
    private validationMessages: { [key: string]: { [key: string]: string } };
    private genericValidator: GenericValidator;
    PHONE_NUMBER_PATTERN = '^(1\s?)?((\([0-9]{3}\))|[0-9]{3})[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$';
    ZIP_CODE_PATTERN = '^\d{5}(?:[-\s]\d{4})?$';
    @Output() create = new EventEmitter<any>();
    modalInstance: any;

    @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];

    constructor(public driverSharedService: DriversSharedService, public fb: FormBuilder, private renderer: Renderer2) {
        // Defines all of the validation messages for the form.
        // These could instead be retrieved from a file or database.
        this.validationMessages = {
            firstName: {
                required: 'First name is required.',
                minlength: 'First name must be at least 3 character.',
                maxlength: 'First name cannot exceed 50 characters.'
            },
            lastName: {
                required: 'Last name is required.',
                minlength: 'Last name must be at least 3 character.',
                maxlength: 'Last name cannot exceed 50 characters.'
            },
            email: {
                required: 'Email is required.',
                email: 'Email is invalid.'
            },
            address1: {
                required: 'Address is required.'
            },
            city: {
                required: 'City is required.'
            },
            zipcode: {
                required: 'Zipcode is required.',
                pattern: 'Zipcode is invalid.'
            },

            phone: {
                required: 'Phone number is required.',
                pattern: 'Phone number is invalid.'
            },
            state: {
                required: 'State is required.'
            }

        };
    }


    ngOnInit(): void {
        this.driverSharedService.showDriverModal$.subscribe(value => {
            if (value) {
                this.openModal();
            }
        });

        this.driverForm = this.fb.group({
            firstName: ['', [Validators.required,
            Validators.minLength(3),
            Validators.maxLength(50)]],
            email: ['', [Validators.required, Validators.email]],
            address1: ['', Validators.required],
            city: ['', Validators.required],
            zipcode: ['', [Validators.required, Validators.pattern(/^\d{5}(?:[-\s]\d{4})?$/)]],
            lastName: ['', [Validators.required,
            Validators.minLength(3),
            Validators.maxLength(50)]],
            phone: ['', [Validators.required, Validators.pattern(this.PHONE_NUMBER_PATTERN)]],
            address2: [''],
            emailText: [''],
            state: ['', Validators.required]


        });

        // Define an instance of the validator for use with this form,
        // passing in this form's set of validation messages.
        this.genericValidator = new GenericValidator(this.validationMessages);

    }


    // Also validate on blur
    // Helpful if the user tabs through required fields
    blur(): void {
        this.displayMessage = this.genericValidator.processMessages(this.driverForm);
        if (this.displayMessage.email && this.displayMessage.email.indexOf('required') !== -1) {
            this.displayMessage.email = 'Email is required.';

        }
        if (this.displayMessage.state) {
            const elem = document.getElementsByClassName('select-dropdown')[0];
            this.renderer.addClass(elem, 'highlight-dropdown');
        } else if (this.displayMessage.state && this.displayMessage.state.length > 0) {
            const elem = document.getElementsByClassName('select-dropdown')[0];
            this.renderer.removeClass(elem, 'highlight-dropdown');
        }
    }

    openModal() {
        const modalElem = document.getElementById('evModal');
        M.Modal.init(modalElem);
        this.modalInstance = M.Modal.getInstance(modalElem);
        this.modalInstance.open();

        const dDownElem = document.querySelectorAll('select');
        const dDownInstance = M.FormSelect.init(dDownElem);
    }

    inviteDriver() {
        console.log('the form values are', this.driverForm);
        if (this.driverForm.dirty && this.driverForm.valid) {
            const d = this.driverForm.value;
            this.create.emit(d);
        }
    }

    ngOnDestroy() {
        this.modalInstance.destory();
    }

}
