import { Component, AfterViewInit, OnInit } from '@angular/core';
import * as M from 'materialize-css';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'ev-edit-driver',
    templateUrl: './driver-edit.component.html',
    styleUrls: ['./driver-edit.component.scss']
})
export class DriverEditComponent implements AfterViewInit, OnInit {

    public chargingStations = [{ name: 'charger1' }, { name: 'charger2' }, { name: 'charger346' }, { name: 'charger8239' }];

    driverEditForm: FormGroup;

    PHONE_NUMBER_PATTERN = '^(1\s?)?((\([0-9]{3}\))|[0-9]{3})[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$';
    constructor(private fb: FormBuilder) { }

    ngOnInit(): void {
        this.driverEditForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
            phone: ['', [Validators.required, Validators.pattern(this.PHONE_NUMBER_PATTERN)]],
            carMake: ['', Validators.required],
            carModel: ['', Validators.required],
            carYear: [''],
            dateAdded: [''],
            minutesUsed: [''],
            address1: ['', Validators.required],
            address2: [''],
            city: ['', Validators.required],
            zipcode: ['', [Validators.required, Validators.pattern(/^\d{5}(?:[-\s]\d{4})?$/)]],
            accountNumber: ['', Validators.required]
        });
    }

    ngAfterViewInit(): void {
        const elems = document.querySelectorAll('select');
        const instances = M.FormSelect.init(elems);

        const elems2 = document.querySelectorAll('.datepicker');
        const instances2 = M.Datepicker.init(elems2);
    }

    blur() {

    }

}
