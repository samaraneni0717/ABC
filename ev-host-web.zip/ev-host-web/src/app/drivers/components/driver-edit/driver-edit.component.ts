import { Component, AfterViewInit, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import * as M from 'materialize-css';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IDriver } from '../../model/i-driver.interface';
import { GenericValidator } from '../../../shared/generic-validator';
import { validationMessages } from '../../model/validation-messages';


@Component({
    selector: 'ev-edit-driver',
    templateUrl: './driver-edit.component.html',
    styleUrls: ['./driver-edit.component.scss']
})
export class DriverEditComponent implements AfterViewInit, OnInit, OnChanges {

    public chargingStations = [{ name: 'charger1', checked: true },
    { name: 'charger2', checked: true }, { name: 'charger346', checked: true },
    { name: 'charger8239', checked: true }];

    driverEditForm: FormGroup;
    isReadonlyView = true;
    checkBoxValue = true; //////////////////////////////////////////

    // To handle Modal
    modalCalled = 0;

    @Input() driverInfo: IDriver;
    @Output() formChanged = new EventEmitter<void>();

    @Input() ignoreChanges;

    // Use with the generic validation message class
    displayMessage: { [key: string]: string } = {};
    private validationMessages: { [key: string]: { [key: string]: string } };
    private genericValidator: GenericValidator;
    PHONE_NUMBER_PATTERN = '^(1\s?)?((\([0-9]{3}\))|[0-9]{3})[\s\-]?[\0-9]{3}[\s\-]?[0-9]{4}$';
    ZIP_CODE_PATTERN = '^\d{5}(?:[-\s]\d{4})?$';
    constructor(private fb: FormBuilder) {
        // Defines all of the validation messages for the form.
        // These could instead be retrieved from a file or database.
        this.validationMessages = validationMessages;
    }

    ngOnInit(): void {
        // Define an instance of the validator for use with this form,
        // passing in this form's set of validation messages.
        this.genericValidator = new GenericValidator(this.validationMessages);
    }

    ngAfterViewInit(): void {
        const elems = document.querySelectorAll('select');
        M.FormSelect.init(elems);

        const elems2 = document.querySelectorAll('.datepicker');
        M.Datepicker.init(elems2);
    }

    ngOnChanges(changes: SimpleChanges) {
        // patch form with value from the store
        if (!this.driverEditForm) {
            this.initializeForm();
        }
        if (changes.driverInfo) {
            this.displayDriver();
        } else if (changes.ignoreChanges) {
            this.driverEditForm.reset();
            this.displayDriver();
            this.isReadonlyView = true;
        }

    }

    initializeForm() {
        this.driverEditForm = this.fb.group({
            email: ['', [Validators.required, Validators.email]],
            phoneNumber: ['', [Validators.required, Validators.pattern(this.PHONE_NUMBER_PATTERN)]],
            carMake: ['', Validators.required],
            carModel: ['', Validators.required],
            carYear: [''],
            dateAdded: [''],
            minutesUsed: [''],
            address1: ['', Validators.required],
            address2: [''],
            city: ['', Validators.required],
            zipcode: ['', [Validators.required, Validators.pattern(/^\d{5}(?:[-\s]\d{4})?$/)]],
            accountNumber: ['', Validators.required],
            state: ['', Validators.required]
        });
    }

    displayDriver() {

        if (this.driverInfo && this.driverEditForm) {
            this.driverEditForm.patchValue({
                firstName: this.driverInfo.firstName,
                lastName: this.driverInfo.lastName,
                email: this.driverInfo.email,
                city: this.driverInfo.city,
                address1: this.driverInfo.address1,
                address2: this.driverInfo.address2,
                zipcode: this.driverInfo.zipcode,
                phoneNumber: this.driverInfo.phoneNumber,
                carMake: this.driverInfo.carMake,
                carModel: this.driverInfo.carModel,
                carYear: this.driverInfo.carYear,
                minutesUsed: this.driverInfo.minutesUsed,
                dateAdded: this.driverInfo.dateAdded,
                accountNumber: this.driverInfo.accountNumber,
                state: this.driverInfo.state

            });
        }

    }

    emitEvent() {
        this.modalCalled++;
        if (this.driverEditForm.dirty && this.driverEditForm.touched) {
            this.formChanged.emit();
        } else {
            this.isReadonlyView = true;
        }
    }

    checkOrUncheckAll(event) {
        this.chargingStations.forEach(x => x.checked = event);
    }

    checkOrUncheckSingleBoxes (event) {
        if (!event) {
            this.checkBoxValue = false; // unchecking the main box
        } else { // when event is true
           const val = this.chargingStations.some(x => x.checked === !event);
           if (!val) {
            this.checkBoxValue = true;
           }
        }
    }

    // Also validate on blur
    // Helpful if the user tabs through required fields
    blur(): void {
        this.displayMessage = this.genericValidator.processMessages(this.driverEditForm);
        if (this.displayMessage.email && this.displayMessage.email.indexOf('required') !== -1) {
            this.displayMessage.email = 'Email is required.';

        }
    }

}
