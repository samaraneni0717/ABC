import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
// import * as M from 'materialize-css';

export type alertType = 'success' | 'error';

@Component({
    selector: `ev-alert`,
    templateUrl: './alert.component.html',
    styles: [` .ev-close-btn {
        float: right;
    }
    .ev-close-btn:hover{
        cursor:pointer;
    }
    .ev-card-success {
        background-color: rgb(0, 133, 63) ;
    }
    .ev-card-error {
        background-color: #9D2235;
    }
    .ev-icon {
        float:left;
        padding-right: 10px;
    }
   `]
})
export class AlertComponent implements OnChanges {
    @Input() type: alertType = 'success';
    @Output() close = new EventEmitter();
    iconType = '';

    constructor() { }

    ngOnChanges() {
        if (this.type === 'success') {
            this.iconType = 'check_circle';
        } else if (this.type === 'error') {
            this.iconType = 'error_outline';
        }
    }
    handleClose() {
        this.close.emit();
    }

}
