import { Component, OnChanges, Input, Output, EventEmitter} from '@angular/core';
import * as M from 'materialize-css';


@Component({
    selector: `ev-confirm-box`,
    templateUrl: './confirm-box.component.html',
    styles: [`.ev-box-link {margin:10px;}`]
})
export class ConfirmBoxComponent implements OnChanges {
    constructor() { }
    confirmInstance: any;
    @Input() modalCalled: number; // to open modal whenever it's invoked from the host
    @Output() confirmYes = new EventEmitter();

    ngOnChanges() {
        if (!this.confirmInstance) {
            const elem = document.getElementById('evConfirmBox');
            const options = {dismissible: false};
            M.Modal.init(elem, options);
            this.confirmInstance = M.Modal.getInstance(elem);
        }
        this.confirmInstance.open();
    }
    // perform required step in the host component by looking at the output event emitted upon clicking 'YES'
    emitFromConfirm() {
        this.confirmInstance.close();
        this.confirmYes.emit();
    }
    // Handling  click 'NO'
    dismissModal() {
        if (this.confirmInstance) {
            this.confirmInstance.close();
        }
    }
}
