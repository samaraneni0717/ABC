import {Component, Input} from '@angular/core';

@Component({
    selector: `ev-spinner`,
    templateUrl: './spinner.component.html'
})
export class SpinnerComponent {

    @Input() showSpinner;

}
