import { Component, Input, OnChanges, Output, EventEmitter } from '@angular/core';

export type TableOrder = 'asc' | 'desc' | 'none';

export interface TableHeader {
    label: string;
    sort?: boolean;
    order?: TableOrder;

}

export interface TableCell {
    value: string | number;
}

export type TableRow = TableCell[];

@Component({
    selector: `ev-table`,
    templateUrl: './table.component.html',
    styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnChanges {

    @Input() headers: TableHeader[];
    @Input() dataset: TableRow[];
    @Input() colIndxClickable: number = null;
    @Output() columnEdited = new EventEmitter<void>();

    ngOnChanges() {
        if (this.dataset) {
            console.log('Headers:', this.headers);
            console.log('Dataset:', this.dataset);
        }
    }
    sort(colIdx: number) {
        const head = this.headers[colIdx];

        this.headers.forEach(_head => {
            if (_head !== head) {
                _head.order = 'none';
            }
        });

        this.dataset.sort((rowA, rowB) => {
            const a = rowA[colIdx];
            const b = rowB[colIdx];

            if (head.order === 'none' || head.order === 'desc') {
                if (typeof a === 'number' && typeof b === 'number') {
                    return a - b;
                }

                return String(a).localeCompare(String(b));
            }

            if (typeof a === 'number' && typeof b === 'number') {
                return b - a;
            }

            return String(b).localeCompare(String(a));
        });

        head.order = head.order === 'none' || head.order === 'desc' ? 'asc' : 'desc';
        // this.currentPage = 1;
        // this.tableSort.emit({ index: colIdx, order: head.order });
    }

    columnClicked() {

        this.columnEdited.emit();
    }
}
