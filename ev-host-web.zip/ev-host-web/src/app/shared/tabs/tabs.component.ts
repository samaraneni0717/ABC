import { Component, Input, Output, EventEmitter, ContentChildren, QueryList, AfterContentInit, HostBinding } from '@angular/core';

@Component({
    selector: `ev-tab`,
    template: `
    <section class="tab-container" [ngClass]="active ? 'tab-visible' : 'tab-hidden'">
    <ng-content></ng-content>
  </section>    `
})
export class TabComponent {
    @Input() label: string;
    @Input() selected = false;
    @Output() click: EventEmitter<string> = new EventEmitter();

    constructor() { }

    emitSelection(label: string): void {
        this.click.emit(label);
    }
}



@Component({
    selector: `ev-tabs`,
    template: `
    <div class="breaker-panel-body tabs">
    <section class="tab-group-container total-energy-tabs">
    <div class="panel-tabs" aria-label="Tab Container">
     <div class='tab-group total-energy'>
      <button *ngFor="let tab of tabs; let idx = index;" type="button" [ngClass]="tab.selected ? 'tab-group-tab selected' : 'tab-group-tab'"
        (click)="switchTab(idx)" aria-label="Clickable Tab">
        {{tab.label}}
      </button>
      </div>
    </div>
    <ng-content></ng-content>
  </section>
  </div>`,
    styleUrls: ['./tabs1.component.scss']
})
export class TabsComponent implements AfterContentInit {
    @ContentChildren(TabComponent) tabs: QueryList<TabComponent>;

    ngAfterContentInit() {
      //  setTimeout(() => {
            if (this.hasSelectedTabs()) {
                const selectdIndex = this.tabs.toArray().findIndex(tab => tab.selected);
                this.switchTab(selectdIndex);
            } else {
                this.switchTab(0);
            }
      //  });
    }

    hasSelectedTabs() {
        return this.tabs.toArray().some(tab => tab.selected);
    }

    switchTab(idx: number) {
        this.tabs.forEach((tab, _idx) => {
            tab.selected = _idx === idx;
            if (_idx === idx) {
                tab.emitSelection(tab.label);
            }
        });
    }
}
