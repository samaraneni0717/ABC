import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ConfirmBoxComponent } from './confirm-box/confirm-box.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { AlertComponent } from './alert/alert.component';
import { TableComponent } from './table/table.component';
import { TabsComponent, TabComponent } from './tabs/tabs.component';
import { PaginatorComponent } from './paginator/paginator.component';


@NgModule({
    imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
    declarations: [ConfirmBoxComponent, SpinnerComponent, AlertComponent, TableComponent,
        TabsComponent, TabComponent, PaginatorComponent],
    exports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule,
        ConfirmBoxComponent, SpinnerComponent, AlertComponent, TableComponent,
        TabsComponent, TabComponent, PaginatorComponent],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class SharedModule { }
