import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

import * as M from 'materialize-css/dist/js/materialize';

@Component({
  selector: 'ev-nav',
  templateUrl: './ev-nav.component.html',
  styleUrls: ['./ev-nav.component.scss']
})
export class EvNavComponent implements OnInit, AfterViewInit {

  @ViewChild('mainNav') mNav: ElementRef;

  constructor() { }

  ngOnInit() {

  }

  ngAfterViewInit() {

    const tabs = new M.Tabs(this.mNav.nativeElement, {});

    document.addEventListener('DOMContentLoaded', function() {
      const elems = document.querySelectorAll('.sidenav');
      const instances = M.Sidenav.init(elems);
    });

  }

}

