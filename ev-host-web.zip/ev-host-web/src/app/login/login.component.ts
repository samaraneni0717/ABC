import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { Login } from './login.service';
import { EnvironmentVariables } from '../shared/services/envionment.service';
import { ISubscription } from 'rxjs/Subscription';

import { tap } from 'rxjs/operators/tap';

@Component({
    selector: 'ev-login',
    templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit, OnDestroy {

    initialCode: string;
    envConfig: any = JSON.parse(sessionStorage.getItem('env'));

    queryParamsSubscription: ISubscription;
    envVarsSubscription: ISubscription;
    loginStatusSubscription: ISubscription;

    @Output() userLoggedInEvent = new EventEmitter<boolean>();

    constructor(private activatedRoute: ActivatedRoute, private router: Router,
         private loginService: Login, private env: EnvironmentVariables) {  }

    ngOnInit() {

        this.queryParamsSubscription =
        this.activatedRoute.queryParams.subscribe((params: Params) => { this.initialCode = params['code']; });

        if (this.initialCode === undefined && this.envConfig == null || this.envConfig === undefined) {
            // First call from user so redirect to remote login page
            this.envVarsSubscription = this.env.getEnvVars().subscribe(items => {
                sessionStorage.setItem('env', JSON.stringify(items));
                this.loginService.redirect();
            });

        } else {
            // User has been redirected to this page so we now have a code

            this.loginService.process(this.initialCode)
                .pipe(tap(() => {

                    this.loginStatusSubscription = this.loginService.userLoginStatus().subscribe(ls => {

                        if (ls === true) {

                            this.userLoggedInEvent.emit(true);
                            this.router.navigate(['drivers']);
                        } else {

                            this.loginService.redirect();

                        }

                    });

                })).subscribe();

        }

    }

    ngOnDestroy() {

        this.queryParamsSubscription.unsubscribe();

        if (this.envVarsSubscription != null) { this.envVarsSubscription.unsubscribe(); }

        this.loginStatusSubscription.unsubscribe();

    }


}
