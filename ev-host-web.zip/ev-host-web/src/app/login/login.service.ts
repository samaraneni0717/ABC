import { Injectable } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import { of } from 'rxjs/observable/of';

import { EnvironmentVariables } from '../shared/services/envionment.service';

import { ISubscription } from 'rxjs/Subscription';

@Injectable()
export class Login implements OnDestroy {

    initialRedirectUrl: string;
    envConfig: any = JSON.parse(sessionStorage.getItem('env'));
    responseFromApigeePost: Response;

    envVarsSubscription: ISubscription;

    constructor(private http: HttpClient, private env: EnvironmentVariables) { }

    ngOnDestroy() {
        this.envVarsSubscription.unsubscribe();
    }

    redirect() {

        if (this.envConfig === undefined || this.envConfig == null) {

            this.envVarsSubscription = this.env.getEnvVars().subscribe(items => {

                sessionStorage.setItem('env', JSON.stringify(items));

              const envConfig = JSON.parse(sessionStorage.getItem('env'));
              const remoteUrl = envConfig.remoteUrl;
              const remoteKey = envConfig.remoteKey;
              const redirectUrl = envConfig.redirectUrl;

              // tslint:disable-next-line:max-line-length
              this.initialRedirectUrl = `${remoteUrl}/login?response_type=code&client_id=${remoteKey}&redirect_uri=${redirectUrl}&state=STATE&scope=openid`;
              return window.location.replace(this.initialRedirectUrl);

            });

        }  else {

            const remoteUrl = this.envConfig.remoteUrl;
            const remoteKey = this.envConfig.remoteKey;
            const redirectUrl = this.envConfig.redirectUrl;

            // tslint:disable-next-line:max-line-length
            this.initialRedirectUrl = `${remoteUrl}/login?response_type=code&client_id=${remoteKey}&redirect_uri=${redirectUrl}&state=STATE&scope=openid`;
            return window.location.replace(this.initialRedirectUrl);
        }

    }

    process(iniCode: string): Observable<void> {

        if (this.envConfig !== undefined || this.envConfig != null) {

            let emptyHeaders: HttpHeaders = new HttpHeaders();

            const remoteHeaders: HttpHeaders = this.buildHeadersForPostToRemote(emptyHeaders, this.envConfig);

            let body = `code=${iniCode}&grant_type=authorization_code&redirect_uri=${this.envConfig.redirectUrl}&scope=openid`;

            return this.http.post(`${this.envConfig.remoteUrl}/oauth2/token`, body, { headers: remoteHeaders })
                .switchMap(r => {

                    emptyHeaders = new HttpHeaders();

                    const apigeeHeaders = this.buildHeadersForPostToApigee(emptyHeaders, this.envConfig);

                    body = 'grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=' + r['id_token'];

                    return this.http.post(`${this.envConfig.apigeeUrl}/ulms/oauth2/v1/token`, body, { headers: apigeeHeaders })
                    .map(data => {
                        return sessionStorage.setItem('user', JSON.stringify(data));
                    });

                });
        }

    }


    refresh(rt: string): Observable<boolean> {

        let result: Observable<boolean> = of(false);

        const emptyHeaders = new HttpHeaders();

        const apigeeHeaders = this.buildHeadersForPostToApigee(emptyHeaders, this.envConfig);

        const body: string = 'grant_type=refresh_token' + '&refresh_token=' + rt;

        return this.http.post(`${this.envConfig.apigeeUrl}/ulms/oauth2/v1/token`, body, { headers: apigeeHeaders })
            .switchMap(data => {

                sessionStorage.setItem('user', JSON.stringify(data));
                return of(true);
            });
            // .catch((err) => {

            //     return result = of(false);

            // });

    }


    buildHeadersForPostToRemote(h: HttpHeaders, config: any): HttpHeaders {

        h = h.append('Authorization', 'Basic ' + btoa(config.remoteKey + ':' + config.remoteSecret));
        h = h.append('content-type', 'application/x-www-form-urlencoded');
        return h;
    }

    buildHeadersForPostToApigee(h: HttpHeaders, config: any): HttpHeaders {

        h = h.append('Authorization', 'Basic ' + btoa(config.apigeeKey + ':' + config.apigeeSecret));
        h = h.append('content-type', 'application/x-www-form-urlencoded');
        return h;
    }


    userLoginStatus(): Observable<boolean> {

        let token: string;
        let env: string;

        try {
            env = JSON.parse(sessionStorage.getItem('env'));
            token = JSON.parse(sessionStorage.getItem('user')).access_token;
        } catch {

            return of(false);

        }

        if (token !== undefined && token != null && token.length >= 10 && env != null && env !== undefined) {
            return of(true);

        } else {

            return of(false);
        }

    }

    logout(): void {

        sessionStorage.removeItem('user');
        sessionStorage.removeItem('env');
        window.location.reload();

    }

}
