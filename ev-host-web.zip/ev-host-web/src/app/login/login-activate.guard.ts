import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';


import { Login as LoginService } from './login.service';

@Injectable()
export class LoginActivateGuard implements CanActivate {

  constructor(private loginService: LoginService) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    return this.loginService.userLoginStatus()
      .switchMap(ls => {
        if (ls === true) {
          return of(true);
        } else {

          this.loginService.redirect();
          return of(false);
        }

      });

  }

}

