import { AppComponent } from './app.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

// NGRX Effects
import { EffectsModule } from '@ngrx/effects';
import { DriverEffects } from './drivers/state/drivers.effect';

// NGRX Store
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';


// Container Components
import { LoginComponent } from './login/login.component';


// Guards
import { LoginActivateGuard } from './login/login-activate.guard';

// Pipes and Custom Pipes

import { DatePipe } from '@angular/common';
import { DecimalPipe } from '@angular/common';

// Services
import { DataAccess } from './drivers/data-access.service';
import { EnvironmentVariables } from './shared/services/envionment.service';
import { Login } from './login/login.service';
import { EvNavComponent } from './navbar/ev-nav.component';
import { environment } from '../environments/environment';
import { AuthService } from './shared/services/auth.service';

// Feature Modules
import { DriversModule } from './drivers/drivers.module';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    EvNavComponent
  ],

  imports: [
    AppRoutingModule,
    BrowserModule,
    DriversModule,
    HttpClientModule,
    StoreModule.forRoot({ }),
    EffectsModule.forRoot([ ]),
    // Helps in tooling when used with REDUX extension on chrome
    StoreDevtoolsModule.instrument({
      name: 'EV HOST APP DEV TOOLS',
      maxAge: 25, // Amount of actions to be retained in the chrome devTools with the oldest being removed once the age is reached
      logOnly: environment.production // when set to true disables all features like time travel debugging excluding logging
    })

  ],
  providers: [
    DataAccess,
    AuthService,
    DatePipe,
    DecimalPipe,
    Login,
    LoginActivateGuard,
    EnvironmentVariables
  ],
  schemas: [NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule {}

