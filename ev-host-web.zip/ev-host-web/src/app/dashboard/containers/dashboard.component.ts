import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromDashboard from '../state';
import * as dashboardActions from '../state/dashboard.actions';
import { Observable } from 'rxjs/Observable';

@Component({
    templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit, AfterViewInit {

    dailyEnergy$: Observable<any>;
    weeklyEnergy$: Observable<any>;
    monthlyEnergy$: Observable<any>;

    constructor(private store: Store<fromDashboard.State>) { }
    headers = [{ label: 'CHARGER NAME', sort: 'true', order: 'none' },
    { label: 'STATUS', sort: 'true', order: 'none' },
    { label: 'LAST UPDATE', sort: 'true', order: 'none' },
    { label: 'DURATION OF CURRENT SESSION', sort: 'true', order: 'none' },
    { label: 'ENERGY OF CURRENT SESSION', sort: 'true', order: 'none' },
    { label: 'MOST RECENT DRIVER', sort: 'true', order: 'none' },
    { label: 'CHARGER UTILIZATION', sort: 'true', order: 'none' }
    ];

    data = [['Charger1', 'Charging', '07/01/18', '02:18hrs',
        '14kWH', 'Sai', '16%'], ['Charger2', 'NotCharging', '08/01/18', '03:18hrs',
        '14kWH', 'SaiAmar', '19%'], ['Charger3', 'Charging', '09/01/18', '04:18hrs',
        '14kWH', 'TryonSt', '17%'],
    [], [], [], []];

    ngOnInit(): void {
        const dDownElem = document.querySelectorAll('select');
        M.FormSelect.init(dDownElem);
        this.store.dispatch(new dashboardActions.GetDashboardGraphValues());
        this.dailyEnergy$ = this.store.select(fromDashboard.getDailyUsage);
    }

    ngAfterViewInit() {
        const elems = document.querySelectorAll('.datepicker');
        M.Datepicker.init(elems);
    }

}
