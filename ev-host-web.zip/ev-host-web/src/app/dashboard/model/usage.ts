import { Energy } from './energy';

export interface Usage {
    time: {};
    intervalStart: string;
    intervalEnd: string;
    energy: Energy;
}
