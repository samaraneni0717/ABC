import { Energy } from './energy';

export interface ChartPoint {

    intervalStart: string;
    intervalEnd: string;
    energy: Energy;

}
