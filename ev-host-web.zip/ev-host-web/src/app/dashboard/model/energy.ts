export interface Energy {
    amount: number;
    unit: string;
}
