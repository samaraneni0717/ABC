import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { ChartPoint } from '../model/chartpoint';

@Injectable()
export class DashboardDataService {

    getUsageInfo(): Observable<ChartPoint[]> {
        return of([{
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-09-30T16:00:00Z",
            intervalEnd: '2018-09-30T23:44:53Z',
            energy: {
                amount: 3.255953693888889,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-09-30T23:44:53Z",
            intervalEnd: "2018-10-01T23:45:12Z",
            energy: {
                amount: 16.251217535000002,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-01T23:45:12Z",
            intervalEnd: "2018-10-02T23:45:04Z",
            energy: {
                amount: 18.776325083888892,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-02T23:45:04Z",
            intervalEnd: "2018-10-03T23:45:21Z",
            energy: {
                amount: 27.959631083333335,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-03T23:45:21Z",
            intervalEnd: "2018-10-04T23:45:12Z",
            energy: {
                amount: 24.669153850833332,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-04T23:45:12Z",
            intervalEnd: "2018-10-05T23:45:06Z",
            energy: {
                amount: 11.745479518611113,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-05T23:45:06Z",
            intervalEnd: "2018-10-06T23:45:31Z",
            energy: {
                amount: 7.965688567499999,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-06T23:45:31Z",
            intervalEnd: "2018-10-07T23:45:27Z",
            energy: {
                amount: 10.227097161944446,
                unit: 'kwh'
            }
        },
        {
            time: "2018-09-30T23:44:53Z",
            intervalStart: "2018-10-07T23:45:27Z",
            intervalEnd: "2018-10-08T16:20:21Z",
            energy: {
                amount: 9.146652250555555,
                unit: 'kwh'
            }
        }]);
    }
}
