import * as fromRoot from '../../state/app.state';
import * as fromDashboard from './dashboard.reducer';
import { createFeatureSelector, createSelector } from '@ngrx/store';
// Extends the app state to include the Dashboard feature.
// This is required because dashboard is lazy loaded.
// So the reference to DashboardState cannot be added to app.state.ts directly.
export interface State extends fromRoot.AppState {
    dailyUsage: fromDashboard.DashboardState;
}

const getDashboardFeatureState = createFeatureSelector<fromDashboard.DashboardState>('dashboard');

export const getDailyUsage = createSelector(
    getDashboardFeatureState,
    state => state.dailyUsage
);
