import { Usage } from '../model/usage';
import { DashboardActions, DashboardActionTypes } from './dashboard.actions';
import { ChartPoint } from '../model/chartpoint';

export interface DashboardState {
    dailyUsage: ChartPoint[];

}
const initialState: DashboardState = {
    dailyUsage: []
};

export function DashboardReducer(state = initialState, action: DashboardActions): DashboardState {

    switch (action.type) {
        case DashboardActionTypes.GetDashboardGraphValuesSuccess:
        let usageValues: any;
            if (action.payload) {
                console.log('The payload of response', action.payload);
                usageValues = action.payload.map(item => {
                    return {
                        intervalStart: item.intervalStart,
                        intervalEnd: item.intervalEnd,
                        amount: item.energy.amount
                    };
                });


            }
            return {
                ...state,
                dailyUsage: usageValues
            };

        default:
            return state;
    }
}
