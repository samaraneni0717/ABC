import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { DashboardDataService } from '../services/dashboard-data.service';
import { Observable } from 'rxjs/Observable';
import * as dashboardActions from './dashboard.actions';
import { Action } from '@ngrx/store';


@Injectable()
export class DashboardEffects {
    constructor(private actions$: Actions, private dashboardDataService: DashboardDataService) { }

    @Effect()
    getGraphValues$: Observable<Action> = this.actions$
        .ofType(dashboardActions.DashboardActionTypes.GetDailyEnergyValues)
        .switchMap(() => this.dashboardDataService.getUsageInfo())
        .map((data) =>
             new dashboardActions.GetDailyEnergyValuesSuccess(data)
        );
}
