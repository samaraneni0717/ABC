
import {Action} from '@ngrx/store';
import { ChartPoint } from '../model/chartpoint';
export enum DashboardActionTypes {
    GetDailyEnergyValues = '[Dashboard] GetDashboardGraphValues',
    GetDailyEnergyValuesSuccess = '[Dashboard] GetDashboardGraphValuesSuccess'
}

export class GetDailyEnergyValues implements Action {
    readonly type = DashboardActionTypes.GetDailyEnergyValues;
}

export class GetDailyEnergyValuesSuccess implements Action {
    readonly type = DashboardActionTypes.GetDailyEnergyValuesSuccess;
    constructor(public payload: ChartPoint[]) {}
}

export type DashboardActions = GetDailyEnergyValues | GetDailyEnergyValuesSuccess;
