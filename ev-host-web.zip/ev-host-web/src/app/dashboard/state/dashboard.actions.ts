
import {Action} from '@ngrx/store';
import { ChartPoint } from '../model/chartpoint';
export enum DashboardActionTypes {
    GetDashboardGraphValues = '[Dashboard] GetDashboardGraphValues',
    GetDashboardGraphValuesSuccess = '[Dashboard] GetDashboardGraphValuesSuccess'
}

export class GetDashboardGraphValues implements Action {
    readonly type = DashboardActionTypes.GetDashboardGraphValues;
}

export class GetDashboardGraphValuesSuccess implements Action {
    readonly type = DashboardActionTypes.GetDashboardGraphValuesSuccess;
    constructor(public payload: ChartPoint[]) {}
}

export type DashboardActions = GetDashboardGraphValues | GetDashboardGraphValuesSuccess;
