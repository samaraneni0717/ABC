import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './containers/dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { DashboardGridFilterComponent } from './components/dashboard-grid-filter/dashboard-grid-filter.component';
import { StoreModule } from '@ngrx/store';
import { DashboardReducer } from './state/dashboard.reducer';
import { EffectsModule } from '@ngrx/effects';
import { DashboardDataService } from './services/dashboard-data.service';
import { DashboardEffects } from './state/dashboard.effects';
import { DashboardGraphComponent } from './components/dashboard-graph/dashboard-graph.component';

const dashBoardRoutes: Routes = [{ path: '', component: DashboardComponent }];

@NgModule({
    imports: [RouterModule.forChild(dashBoardRoutes), SharedModule,
    StoreModule.forFeature('dashboard', DashboardReducer),
    EffectsModule.forFeature([DashboardEffects])],
    declarations: [DashboardComponent, DashboardGridFilterComponent, DashboardGraphComponent],
    providers: [DashboardDataService]
})
export class DashboardModule {

}
