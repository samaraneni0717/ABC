import { Component, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import * as Chartist from 'chartist';
import 'chartist-plugin-tooltips';


@Component({
    selector: `ev-dashboard-graph`,
    templateUrl: './dashboard-graph.component.html',
    styleUrls: ['./dashboard-graph.component.scss']
})
export class DashboardGraphComponent implements OnChanges {
    // Inputs from the Dashboard Container
    @Input() dailyUsage: any;
    @Output() tabSelection = new EventEmitter<string>();
    isDaySelected = false;

    dailyDates = [];
    dailyValues = [];

    weeklyDates = [];
    weeklyValues = [];

    monthlyDates = [];
    monthlyValues = [];

    ngOnChanges() {
        if (this.dailyUsage.values) {
            this.isDaySelected = true;
            this.dailyDates = [];
            this.dailyValues = [];
            // For getting the dates and values pulled out of the data
            this.getDatesAndValues(this.dailyUsage, 'daily');
            //  this.dailyLoading = true;

            const chartist = new Chartist.Bar('.day-view',
                {
                    labels: this.dailyDates,
                    series: [this.dailyValues]
                },
                {
                    seriesBarDistance: 10,
                   axisX: {
                       offset: 50
                   },
                    axisY: {
                        offset: 80,
                        labelInterpolationFnc: function(value) {
                            console.log('The y-axis values', value);
                            return value + 'kWh';
                        },
                        scaleMinSpace: 30, // This reflects the Y-Axis labels 
                        onlyInteger: true
                    },
                    plugins: [
                        Chartist.plugins.tooltip(),
                    ]
                }
            );
        }

    }

    getDatesAndValues(array, interval) {
        if (array) {
            array.forEach((value, index) => {

                if (interval === 'daily') {
                    const month = new Date(value.intervalEnd).getMonth() + 1;
                    const day = new Date(value.intervalEnd).getUTCDate();

                    this.dailyDates.indexOf(`${month}/${day}`) === -1 ? this.dailyDates.push(`${month}/${day}`) : null;
                    this.dailyValues.length < this.dailyUsage.length ? this.dailyValues.push(value.amount.toFixed(3)) : null;

                }
            });
        }

    }
    tabClick(label) {
        this.tabSelection.emit(label);
    }
}
