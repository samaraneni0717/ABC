import { Component } from '@angular/core';
import * as M from 'materialize-css';

@Component({
    selector: `ev-dashboard-grid-filter`,
    templateUrl: './dashboard-grid-filter.component.html'
})
export class DashboardGridFilterComponent {

    showFilters = true;

    toggleFilters() {
        this.showFilters =  !this.showFilters;
        // const dDownElem = document.querySelectorAll('select');
        // M.FormSelect.init(dDownElem);
        // console.log('inside filter comp', dDownElem);
    }

}
