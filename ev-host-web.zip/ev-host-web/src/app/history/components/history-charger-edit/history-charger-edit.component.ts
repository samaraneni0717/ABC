import { Component } from '@angular/core';

@Component({
    templateUrl: './history-charger-edit.component.html',
    selector: 'ev-history-charger-edit'
})
export class HistoryChargerEditComponent {

    // Mock data for Table
    headers = [{ label: 'DATE/TIME', sort: 'true', order: 'none' },
    { label: 'EV DRIVER', sort: 'true', order: 'none' },
    { label: 'CAR', sort: 'true', order: 'none' },
    { label: 'DURATION', sort: 'true', order: 'none' },
    ];

    data = [['Charger1', 'SAI AMAR', 'TESLA', '02:18hrs'],
    ['Charger2', 'MNK', 'NISSAN', '02:18hrs']];

}
