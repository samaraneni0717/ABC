import { Component } from '@angular/core';

@Component({
    selector: `ev-history-table`,
    templateUrl: './history-table.component.html'
})
export class HistoryTableComponent {

}
