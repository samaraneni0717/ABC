import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { HistoryComponent } from './containers/history.component';
import { Routes, RouterModule } from '@angular/router';
import { HistoryTableComponent } from './components/history-table/history-table.component';
import { HistoryChargerEditComponent } from './components/history-charger-edit/history-charger-edit.component';

const historyRoutes: Routes = [{ path: '', component: HistoryComponent },
{ path: ':id', component: HistoryChargerEditComponent }];

@NgModule({
    imports: [SharedModule, RouterModule.forChild(historyRoutes)],
    declarations: [HistoryComponent, HistoryTableComponent, HistoryChargerEditComponent]
})
export class HistoryModule {

}
