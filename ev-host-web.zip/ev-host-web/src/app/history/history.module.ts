import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { HistoryComponent } from './containers/history.component';
import { Routes, RouterModule } from '@angular/router';
import { HistoryTableComponent } from './components/history-table.component';

const historyRoutes: Routes = [ {path: '', component: HistoryComponent}];

@NgModule({
    imports: [SharedModule, RouterModule.forChild(historyRoutes)],
    declarations: [HistoryComponent, HistoryTableComponent]
})
export class HistoryModule {

}
