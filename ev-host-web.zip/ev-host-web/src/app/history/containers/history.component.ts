import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
templateUrl: './history.component.html'
})
export class HistoryComponent {

    constructor ( private router: Router) {}
    headers = [{ label: 'CHARGER NAME', sort: 'true', order: 'none' },
    { label: 'EV DRIVER', sort: 'true', order: 'none' },
    { label: 'CAR', sort: 'true', order: 'none' },
    { label: 'DURATION', sort: 'true', order: 'none' },
    { label: 'SESSION START', sort: 'true', order: 'none' },
    { label: 'SESSION END', sort: 'true', order: 'none' },
    { label: 'KWH CONSUMED', sort: 'true', order: 'none' }
    ];

    data = [['Charger1', 'SAI AMAR', 'TESLA', '02:18hrs',
    '06/30/2018 2:30PM', '06/30/2018 3:00PM', '16KWH'], ['Charger2', 'MNK', 'NISSAN', '02:18hrs',
    '07/20/2018 2:30PM', '07/20/2018 3:00PM', '16KWH'], [], []];
    firstRowNum = 1;
    lastRowNum = 2; // To Do: Update based on the response from the backend
    totalRows = 2;

    editCharger() {
        this.router.navigateByUrl('/history/2');
    }
}
