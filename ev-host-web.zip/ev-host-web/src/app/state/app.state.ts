import { DriversState } from '../drivers/state/drivers.reducer';

// Representation of the entire ApplicationState
export interface AppState {
    drivers: DriversState;
}
