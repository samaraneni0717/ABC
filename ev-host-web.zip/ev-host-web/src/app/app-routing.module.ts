import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { DriversComponent } from './drivers/containers/ev-drivers/drivers.component';
import { LoginActivateGuard } from './login/login-activate.guard';
import { DriverEditComponent } from './drivers/components/driver-edit/driver-edit.component';


const routes: Routes = [

  { path: '', redirectTo: 'drivers', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'drivers', component: DriversComponent, canActivate: [LoginActivateGuard]},
  { path: 'driver-edit', component: DriverEditComponent},

  // Catch all will be redirected to login
  { path: '**', redirectTo: 'login', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
