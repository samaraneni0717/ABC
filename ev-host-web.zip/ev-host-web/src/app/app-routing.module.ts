import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { DriversComponent } from './drivers/containers/ev-drivers/drivers.component';
import { LoginActivateGuard } from './login/login-activate.guard';
import { DriverShellComponent } from './drivers/containers/ev-driver-shell/driver-shell.component';

const routes: Routes = [

  { path: '', redirectTo: 'drivers', pathMatch: 'full' }, // makes the drivers route as initial match
  { path: 'login', component: LoginComponent },

  {
    path: 'drivers', component: DriversComponent

  },
  { path: 'drivers/:id', component: DriverShellComponent},

  { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule'},

  { path: 'history', loadChildren: './history/history.module#HistoryModule'},

  // Catch all will be redirected to login
  { path: '**', redirectTo: 'login', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
