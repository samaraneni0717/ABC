export const environment = {
    production: false,
    environmentApi: 'app/config',
};
