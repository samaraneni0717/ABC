const fs = require('fs');
const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ProgressPlugin = require('webpack/lib/ProgressPlugin');
const CircularDependencyPlugin = require('circular-dependency-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const rxPaths = require('rxjs/_esm5/path-mapping');
const autoprefixer = require('autoprefixer');
const postcssUrl = require('postcss-url');
const cssnano = require('cssnano');
const customProperties = require('postcss-custom-properties');

const { NamedModulesPlugin, NoEmitOnErrorsPlugin, SourceMapDevToolPlugin, EnvironmentPlugin, HashedModuleIdsPlugin, ProvidePlugin } = require('webpack');
const { NamedLazyChunksWebpackPlugin, BaseHrefWebpackPlugin, SuppressExtractedTextChunksWebpackPlugin, GlobCopyWebpackPlugin } = require('@angular/cli/plugins/webpack');
const { CommonsChunkPlugin, ModuleConcatenationPlugin } = require('webpack').optimize;
const { LicenseWebpackPlugin } = require('license-webpack-plugin');
const { PurifyPlugin } = require('@angular-devkit/build-optimizer');
const { AngularCompilerPlugin } = require('@ngtools/webpack');
const PortalPatchPlugin = require('./plugins/webpack-portal-patch-plugin');
const AngularPatchPlugin = require('./plugins/webpack-angular-patch-plugin');
const PortalWrapperPlugin = require('./plugins/webpack-portal-wrapper-plugin').PortalWrapperPlugin;
const PortalWrapperTemplateBuilder = require('./plugins/webpack-portal-wrapper-plugin').PortalWrapperTemplateBuilder;
const LazyModulePlugin = require('./plugins/webpack-lazy-module-plugin').LazyModulePlugin;
const SourcemapsBannerPlugin = require('./plugins/webpack-sourcemaps-banner-plugin');
const pkg = require('./package.json');
const nodeModules = path.join(process.cwd(), 'node_modules');
const realNodeModules = fs.realpathSync(nodeModules);
const genDirNodeModules = path.join(process.cwd(), 'src', '$$_gendir', 'node_modules');
const entryPoints = ["inline", "polyfills", "sw-register", "styles", "vendor", "main"];
const minimizeCss = true;
const baseHref = "";
const deployUrl = "";
const fileName = `${pkg.name}-${pkg.version}`;
const bundleName = fileName + '.';
const options = require('./build.options');
const devServerSetup = require('./mock-server/setup');

const postcssPlugins = function () {
    // safe settings based on: https://github.com/ben-eb/cssnano/issues/358#issuecomment-283696193
    const importantCommentRe = /@preserve|@license|[@#]\s*source(?:Mapping)?URL|^!/i;
    const minimizeOptions = {
        autoprefixer: false,
        safe: true,
        mergeLonghand: false,
        discardComments: { remove: (comment) => !importantCommentRe.test(comment) }
    };
    return [
        postcssUrl({
            url: (URL) => {
                const { url } = URL;
                // Only convert root relative URLs, which CSS-Loader won't process into require().
                if (!url.startsWith('/') || url.startsWith('//')) {
                    return URL.url;
                }
                if (deployUrl.match(/:\/\//)) {
                    // If deployUrl contains a scheme, ignore baseHref use deployUrl as is.
                    return `${deployUrl.replace(/\/$/, '')}${url}`;
                }
                else if (baseHref.match(/:\/\//)) {
                    // If baseHref contains a scheme, include it as is.
                    return baseHref.replace(/\/$/, '') +
                        `/${deployUrl}/${url}`.replace(/\/\/+/g, '/');
                }
                else {
                    // Join together base-href, deploy-url and the original URL.
                    // Also dedupe multiple slashes into single ones.
                    return `/${baseHref}/${deployUrl}/${url}`.replace(/\/\/+/g, '/');
                }
            }
        }),
        autoprefixer(),
        customProperties({ preserve: true })
    ].concat(minimizeCss ? [cssnano(minimizeOptions)] : []);
};


module.exports = function (env) {
    let defaultEnv = { portal: false, prod: false, root: '/', sourceMaps: true };

    if (!env) {
        env = Object.assign(defaultEnv, options);
    } else {
        env = Object.assign(defaultEnv, options, env);
    }

    let envType = '';

    if (env.portal) { //these exclude zonejs
        envType = (env.prod) ? 'portal-prod' : 'portal-dev';
    } else {
        envType = (env.prod) ? 'prod' : 'dev'
    }

    let environmentFile = `environments/environment.${envType}.ts`;
    let stylesFile = (env.portal) ? 'src/styles-portal.scss' : 'src/styles.scss';

    let isDev = !env.prod;
    let isLocal = env.local;
    let useSourcemaps = env.sourceMaps;
    let publicPath = env.root;

    console.log('env', JSON.stringify(env, null, 4));
    console.log('Using env:\t', environmentFile);
    console.log('Using styles:\t', stylesFile);

    const prefix = fs.readFileSync(path.join(__dirname, 'wrapper-prefix.txt'), { encoding: 'utf8' });
    const suffix = fs.readFileSync(path.join(__dirname, 'wrapper-suffix.txt'), { encoding: 'utf8' });

    // check root tag in app.component to ensure it matches value in build.options
    const appComponent = fs.readFileSync(path.join(__dirname, 'src', 'app', 'app.component.ts'), { encoding: 'utf8' });
    const tester = new RegExp('selector:\\s*\'' + options.rootTag + '\'', 'g');
    const matches = tester.test(appComponent);

    if (!matches) {
        throw new Error(`The root tag specified in your app.component.ts file does not match the value in 
        your build.options.js file. They must match in order for the application to bootstrap correctly.`);
    }

    if (env.prod && options.rootTag !== `app-${pkg.name}-root`) {
        throw new Error(`You must change the rootTag in your build options to a unique value for your application. 
        Consider making it match you application name from package.json (ex. app-${pkg.name}-root)`);
    }

    let rules = [
        {
            "test": /\.html$/,
            "loader": "raw-loader"
        },
        {
            "test": /\.(eot|svg|cur)$/,
            "loader": "file-loader",
            "options": {
                "name": "[name].[hash:20].[ext]",
                "limit": 10000
            }
        },
        {
            "test": /\.(jpg|png|webp|gif|otf|ttf|woff|woff2|ani)$/,
            "loader": "url-loader",
            "options": {
                "name": "[name].[hash:20].[ext]",
                "limit": 10000
            }
        },
        {
            "exclude": [
                path.join(process.cwd(), stylesFile)
            ],
            "test": /\.scss$|\.sass$/,
            "use": [
                "exports-loader?module.exports.toString()",
                {
                    "loader": "css-loader",
                    "options": {
                        "sourceMap": useSourcemaps,
                        "importLoaders": 1
                    }
                },
                {
                    "loader": "postcss-loader",
                    "options": {
                        "ident": "postcss",
                        "plugins": postcssPlugins,
                        "sourceMap": useSourcemaps
                    }
                },
                {
                    "loader": "sass-loader",
                    "options": {
                        "sourceMap": useSourcemaps,
                        "precision": 8,
                        "includePaths": []
                    }
                }
            ]
        },
        {
            "include": [
                path.join(process.cwd(), stylesFile)
            ],
            "test": /\.scss$|\.sass$/,
            "use": [
                "style-loader",
                {
                    "loader": "css-loader",
                    "options": {
                        "sourceMap": false,
                        "importLoaders": 1
                    }
                },
                {
                    "loader": "postcss-loader",
                    "options": {
                        "ident": "postcss",
                        "plugins": postcssPlugins,
                        "sourceMap": false
                    }
                },
                {
                    "loader": "sass-loader",
                    "options": {
                        "sourceMap": false,
                        "precision": 8,
                        "includePaths": []
                    }
                }
            ]
        }
    ];

    let plugins = [
        new ProvidePlugin({
            'window.JSZip': path.resolve(__dirname,'node_modules/jszip/dist/jszip.min.js'),
            'JSZip': path.resolve(__dirname, 'node_modules/jszip/dist/jszip.min.js')
        }),
        new NoEmitOnErrorsPlugin(),
        new CopyWebpackPlugin([
            {
                "context": "src",
                "to": "",
                "from": {
                    "glob": "assets/**/*",
                    "dot": true
                }
            },
            {
                "context": "src",
                "to": "",
                "from": {
                    "glob": "favicon.ico",
                    "dot": true
                }
            }
        ], {
                "ignore": [
                    ".gitkeep",
                    "**/.DS_Store",
                    "**/Thumbs.db"
                ],
                "debug": "warning"
            }),
        new ProgressPlugin(),
        new CircularDependencyPlugin({
            "exclude": /(\\|\/)node_modules(\\|\/)/,
            "failOnError": false
        }),

        new HtmlWebpackPlugin({
            "template": "./src/index.ejs",
            "filename": "./index.html",
            "hash": false,
            "inject": false,
            "compile": true,
            "favicon": false,
            "minify": false,
            "cache": true,
            "showErrors": true,
            "chunks": ["main"],
            "excludeChunks": [],
            "title": "ADP",
            "xhtml": true,
            "chunksSortMode": function sort(left, right) {
                let leftIndex = entryPoints.indexOf(left.names[0]);
                let rightindex = entryPoints.indexOf(right.names[0]);
                if (leftIndex > rightindex) {
                    return 1;
                }
                else if (leftIndex < rightindex) {
                    return -1;
                }
                else {
                    return 0;
                }
            },
            "isDev": isDev,
            "isLocal": isLocal,
            "isPortal": env.portal,
            "rootTag": options.rootTag,
            "appPrefix": options.appPrefix
        }),
        new BaseHrefWebpackPlugin({}),
        new AngularPatchPlugin({
            bundle: bundleName + 'main.bundle',
            portal: env.portal
        })
    ];

    let prodRules = [
        {
            "test": /(?:\.ngfactory\.js|\.ngstyle\.js|\.ts)$/,
            "use": [
                {
                    "loader": "@angular-devkit/build-optimizer/webpack-loader",
                    "options": {
                        "sourceMap": useSourcemaps
                    }
                },
                "@ngtools/webpack"
            ]
        }
    ];
    let devRules = [
        {
            "test": /\.ts$/,
            "loader": "@ngtools/webpack"
        }
    ];


    let prodPlugins = [
        new SuppressExtractedTextChunksWebpackPlugin(),
        new EnvironmentPlugin({
            "NODE_ENV": isDev ? "development" : "production"
        }),
        new HashedModuleIdsPlugin({
            "hashFunction": "md5",
            "hashDigest": "base64",
            "hashDigestLength": 4
        }),
        new ModuleConcatenationPlugin({}),
        new UglifyJsPlugin({
            "test": /\.js$/i,
            "extractComments": false,
            "sourceMap": useSourcemaps,
            "cache": false,
            "parallel": false,
            "uglifyOptions": {
                "output": {
                    "ascii_only": true,
                    "comments": false
                },
                "ecma": 5,
                "warnings": false,
                "ie8": false,
                "mangle": true,
                "compress": {
                    "pure_getters": true,
                    "passes": 3
                }
            }
        }),
        new LicenseWebpackPlugin({
            "licenseFilenames": [
                "LICENSE",
                "LICENSE.md",
                "LICENSE.txt",
                "license",
                "license.md",
                "license.txt"
            ],
            "perChunkOutput": false,
            "outputTemplate": "./node_modules/license-webpack-plugin/output.template.ejs",
            "outputFilename": "3rdpartylicenses.txt",
            "suppressErrors": true,
            "includePackagesWithoutLicense": false,
            "abortOnUnacceptableLicense": false,
            "addBanner": false,
            "bannerTemplate": "/*! 3rd party license information is available at <%- filename %> */",
            "includedChunks": [],
            "excludedChunks": [],
            "additionalPackages": [],
            "pattern": /^(MIT|ISC|BSD.*)$/
        }),
        new PurifyPlugin(),
        new AngularCompilerPlugin({
            "mainPath": "main.ts",
            "platform": 0,
            "hostReplacementPaths": {
                "environments/environment.dev.ts": environmentFile
            },
            "sourceMap": useSourcemaps,
            "tsConfigPath": path.join(process.cwd(), "src/tsconfig.app.json"),
            "compilerOptions": {},
            "skipCodeGeneration": false
        })
    ];

    let devPlugins = [
        new NamedLazyChunksWebpackPlugin(),
        new NamedModulesPlugin({}),
        new AngularCompilerPlugin({
            "mainPath": "main.ts",
            "platform": 0,
            "hostReplacementPaths": {
                "environments/environment.dev.ts": environmentFile
            },
            "sourceMap": true,
            "tsConfigPath": "src/tsconfig.app.json",
            "skipCodeGeneration": true,
            "compilerOptions": {}
        })
    ];

    let output = {
        "path": path.join(process.cwd(), "dist"),
        "filename": fileName + ".[name].bundle.js",
        "chunkFilename": "[id].[chunkhash:20].chunk.js",
        "crossOriginLoading": false,
        "publicPath": publicPath
    };


    let entries = {
        "main": [
            "./src/polyfills.ts",
            "./src/zone.ts",
            "./src/main.ts",
            "./" + stylesFile
        ]
    };

    if (env.portal) {
        console.log('Stripping out zone for portal');
        entries.main.splice(entries.main.indexOf('./src/zone.ts'), 1);
    }

    plugins = isDev ? plugins.concat(devPlugins) : plugins.concat(prodPlugins);
    rules = isDev ? rules.concat(devRules) : rules.concat(prodRules);
    // let output = isDev ? devOutput : prodOutput;
    // let entries =  isDev ? devEntries : prodEntries;

    if (useSourcemaps) {
        plugins.push(new SourceMapDevToolPlugin({
            "filename": "[file].map[query]",
            "moduleFilenameTemplate": "[resource-path]",
            "fallbackModuleFilenameTemplate": "[resource-path]?[hash]",
            "sourceRoot": "webpack:///"
        }));
    }

    if (env.portal) {
        plugins.push(new GlobCopyWebpackPlugin({
            "patterns": [
                "zone.min.js"
            ],
            "globOptions": {
                "cwd": path.join(process.cwd(), "node_modules/zone.js/dist"),
                "dot": true,
                "ignore": "**/.gitkeep"
            }
        }));


        let context = {
            buildOptions: options,
            pkg: pkg,
            beforeContent: prefix,
            afterContent: suffix,
            isDev: !env.prod,
            isPortal: env.portal,
            isLocal: env.local
        };
        plugins = plugins.concat([
            new PortalPatchPlugin({
                bundle: bundleName + 'main.bundle'
            }),
            new PortalWrapperPlugin(context),
            // plugin for handling lazy module loading in the portal
            new LazyModulePlugin({
                rootTag: options.rootTag
            }),
            new SourcemapsBannerPlugin({
                "entries": [{
                    "bundle": bundleName + 'main.bundle',
                    "prefix": new PortalWrapperTemplateBuilder(context).getPrefixContent()
                }]
            })
        ]);
    }

    return {
        "resolve": {
            "extensions": [
                ".ts",
                ".js",
                ".json"
            ],
            "modules": [
                "./node_modules",
                "./node_modules"
            ],
            "symlinks": true,
            "alias": rxPaths(),
            "mainFields": [
                "browser",
                "module",
                "main"
            ]
        },
        "resolveLoader": {
            "modules": [
                "./node_modules",
                "./node_modules"
            ],
            "alias": rxPaths()
        },
        "entry": entries,
        "output": output,
        "module": {
            "rules": rules
        },
        "plugins": plugins,
        "node": {
            "fs": "empty",
            "global": true,
            "crypto": "empty",
            "tls": "empty",
            "net": "empty",
            "process": true,
            "module": false,
            "clearImmediate": false,
            "setImmediate": false
        },
        "devServer": {
            "setup": devServerSetup,
            "proxy": options.proxy,
             "historyApiFallback": false       
        }
    };
};