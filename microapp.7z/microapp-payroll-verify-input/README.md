# Microapp-payroll-verify-input

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.0.0-beta.32.3. 

## READ THIS FIRST

### Setup

1. You will need to make sure you have NodeJS 6+ installed. 
2. Run `npm install -g yarn`
4. Run `yarn install` 

## Development server
Run `npm run start` for a dev server. Navigate to `http://localhost:8081/`. The app will automatically reload 
if you change any of the source files.

When running locally you will likely want to be able to make REST calls successfully. There are two 
options for how to do this:

1. Provide a mock backend that returns JSON like the real backend
2. Proxy requests to the existing real backend.

Both of these options are supported.

### Mock Backend

When running locally, you may want to intercept requests you make from your Angular app and return some json, 
either from a static file or dynamically generated. This can all be controlled via ExpressJS routes (Don't confuse 
these with Angular Routes) configured in your mock-backend.

#### Static file loading

Static files can be loaded from the `mock-server/json` folder. By default, the mock-server is already setup to 
intercept requests to `http://localhost:8081/api/:endpoint`. The mock server will attempt to load the json file 
whose name matches the `endpoint` path paramter. For example, a request made to `http://localhost:8081/api/foo` 
will attempt to load the file at `./mock-server/json/foo.json` and return it. 

You may however, want to do something to the contents of the json file before returning it to the server. You 
have complete control over what the mock-backend returns by configuring your backend routes in the 
`mock-backend/setup.js` file. For example, lets say you want to update a property of that json file with the 
current date before sending it to the client when a request is made for a certain file. Here is how you would do it:

In the setup.js file:

```javascript
    // Intercept GET requests for the dateTest file and add a currentTimestamp property to it
    app.get(API_ROOT + '/dateTest', (req, res) => {
        // This will return the file path for the requested json from which utils will read.
        let fileLocation = getJsonFilePath(req, 'dateTest.json'); 
        // use the utils modules to read a file and send the data back to the front-end
        utils.readFileAndSend(fileLocation, req, res, (data)=> {
            // this 'postParse' function allows you to modify the data that was read from the json file before sending it
            data.currentTimestamp = new Date().getTime();
        });
    });

```
Now all requests to `/api/dateTest` will return a json with a `currentTimestamp` property.

In the same way that we added the current timestamp, you can also add or change data based on the other data 
in the request. The `req` property is an ExpressJS request object. From it you can read the query parameters, 
path parameters, form post, etc. See [the Express API Docs](https://expressjs.com/en/4x/api.html#req) for more info.

##### Different scenarios
Sometimes you may have the need to test different scenarios from the front end to simulate the real backend. 
For example, you want requests for `/api/team` to return a small list of people for one user and large list for 
another. Rather than changing the urls on the front end or manually changing the files to simulate it, you can 
create folders in the `mock-backend/json` directory for each scenario.

For example, you may have two scenarios. We'll call them 'small-team' and 'big-team'. Both of those needs to 
support requests for the `/api/team` REST call. To support that, you would create the following:

* `mock-server/json/small-team/team.json` - This would include the JSON for a small team
* `mock-server/json/big-team/team.json` - This would include the JSON for a big team

Then, when running your application you can control which of these files you get by setting the 'scenario' 
request header to either 'small-team' or 'big-team'. A handy Chrome extension for setting this is 
[ModHeader](https://chrome.google.com/webstore/detail/modheader/idgpnmonknjnojddfkpgkljpfnnfcklj?hl=en) 

#### Dynamically Generated

As you might expect, inside your route configuration, you don't you have to read a file and send it back. 
You can also just responsd with your own JS object, which will be converted to JSON automatically.

For example

```javascript
    // Intercept requests to /api/foo and just return some dynamically generated JSON
    app.get(API_ROOT + '/foo', (req, res) => {
       res.json({success: 'true'});
    });
```

### Proxy Backend

If you have a real backend, you may want the API requests to just get passed through to the real thing. 
In this case, you can specify the proxy settings in the `build.options.js` file. Specifying the `PROXY_URL` 
constant will result in requests to `/api` getting passed through to that URL instead of being handled locally. 
The proxy configuration is based around the webpack-dev-server proxy configuration. See 
the [API Docs](https://webpack.js.org/configuration/dev-server/#devserver-proxy) for more info.


## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use 
`ng generate directive|pipe|service|class|module name-of-thing`. See [the cli docs](http://cli.angular.io).

## Build

Run `npm run build` to build the project. This kicks off the webpack build. The build artifacts will be stored in the `dist/` directory. 

## Packaging for Portal 

There are four different packaging options. In all cases, the dist folder will have an `index.html` file 
and a `PACKAGE_NAME-PACKAGE_VERSION.js` file where PACKAGE_NAME and PACKAGE_VERSION are the values from 
your package.json file. That javascript file is all of your application code and all of it's dependencies 
(except zone.js - see below) rolled into one file and wrapped in a closure to make running in the portal work correctly.

 `npm run package` to generate a prod package for standalone use.
 `npm run package-dev` to generate a dev package for standalone use. This is just an alias for `npm run build`  

 Portal builds do not bundle zone.js since that should only be loaded once. If you get errors saying that angular requires zone.js
 then you must not have added it into the page. See below.
 
 Also, the portal builds use a `styles-portal.scss` file (instead of `styles.scss`) which should not import 
 the font scss files (proxima-nova, fontawesome, adp-icon-font) as they should be already loaded in the portal. 
 
 `npm run package-portal` to generate a prod package for standalone use.
 `npm run package-portal-dev` to generate a dev package for portal use.  
  
 When generating the packaged files, you may want to adjust the path from which the html loads it's JS file 
 (and font files). You can pass the application root via a command line argument:
 ```
 npm run package -- --env.root=/myWar/
 ```
 Note that you need to include that extra set of -- in there because the env.root needs to be passed 
 through to the `package` npm script.
 
 ### Zone JS Polyfill
 When running in the portal you must add zonejs manually as it can't be bundled inside the concatenated JS file. 
 When you run the package tasks, `zone.min.js` will be placed in the dist folder next to your application's JS. 
 You can add it as a script tag in your html above your JS. If using the revit portal you can use this:
 
 ````
 require(["dojo/aspect", "dojo/ready","dojo/dom","dojo/_base/lang", "dojo/topic", "dijit/registry", 
 	         "revit/app/RevolutionLight","dojo/query","dojo/aspect","revit/form/Button",
 	         "revit/MenuItem","dojox/highlight/languages/pygments/html", "dojo/dom-class", "dojo/dom-construct",
 	         "/ng/zone.min.js"], function(...) {
 	          ...
````

You just need to make sure tha the zone.min.js file is accessible at runtime.

### CoreJS Polyfill
To support older versions of IE <= 11, you should include the core-js shim in your application. You can do this
the same was as the zone js polyfill. The `shim.js` file will also be placed in your dist directory when you run
a package task.


## Running unit tests

Run `npm run test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `npm run e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
Before running the tests make sure you are serving the app via `npm run start`.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the 
[Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
