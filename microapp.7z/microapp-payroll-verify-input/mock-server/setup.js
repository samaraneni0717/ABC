
/**
 * Created by mckeowr on 3/9/17.
 */

const utils = require('./file-util');
const options = require('../build.options');
const path = require('path');

const API_ROOT = options.apiRoot;

function getJsonFilePath(req, fileName) {

    let folderPath = [process.cwd(), 'mock-server', 'json'];

    // To support different scenarios, you may store different versions of JSON files in different directories
    // and switch between them based on a header.

    let scenario = req.get('scenario'); // get the 'scenario' from the request header

    // For example, setting the scenario header of the request to 'foo', would cause the JSON files
    // to be loaded out of the mock-server/json/foo

    if (scenario) {
          folderPath.push(scenario);
    }

    folderPath.push(fileName);

    // console.log(folderPath);
    // console.log(path.join.apply(null, folderPath));
    return path.join.apply(null, folderPath);
}

// You can mock your api calls here. The app argument is an express application
let setup = function(app) {

    /* You can respond to specific requests and return whatever data you want as shown here.

        app.get(API_ROOT + '/foo', (req, res) => {

           res.json({success: 'true'});
        });

    */
    app.use('/output', (req, res) => {
        setTimeout(() => {
            let fileLocation;
            if(req.query.miniTilesOnly){
                fileLocation = getJsonFilePath(req, 'outputPhase2.json');
            } 
            else if (req.query.donutsOnly) {
                fileLocation = getJsonFilePath(req, 'outputPhase2.json');
            } 
            else {
                fileLocation = getJsonFilePath(req, 'output.json');
            }
            utils.readFileAndSend(fileLocation, req, res);

        }, 2000)   
    });

    app.use('/paydatabatches', (req, res) => {
        setTimeout(() => {
            let fileLocation = getJsonFilePath(req, 'paydatabatches.json');
            utils.readFileAndSend(fileLocation, req, res);
        }, 2000)
    });

    app.use('/benefitgroups', (req, res) => {
        setTimeout(() => {
            let fileLocation = getJsonFilePath(req, 'benefitGroups.json');
            utils.readFileAndSend(fileLocation, req, res);
        }, 1000)
    });

    app.use('/procpaygroups', (req, res) => {
        setTimeout(() => {
            let fileLocation = getJsonFilePath(req, 'processingPayGroups.json');
            utils.readFileAndSend(fileLocation, req, res);
        }, 1000)
        //res.sendStatus(500);
    });

    app.use('/permissions', (req, res) => {
        setTimeout(() => {
            let fileLocation = getJsonFilePath(req, `/security/access.json`);
            utils.readFileAndSend(fileLocation, req, res);
        }, 1000)
    });

    app.use('/details', (req, res) => {
        if (req.query.code === 'ITC') {

            let fileLocation = getJsonFilePath(req, 'needs-review-data/InvalidTaxCodes.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 0)

        } else if (req.query.code === 'MTC') {

            let fileLocation = getJsonFilePath(req, 'needs-review-data/MissingTaxCodes.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 2000)

        } else if (req.query.code === 'NHC') {

            let fileLocation = getJsonFilePath(req, 'needs-review-data/UnassignedNewHires.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 2000)
        } else if (req.query.code === 'TER') {

            let fileLocation = getJsonFilePath(req, 'payroll-inputs-data/terminations.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 2000)
        }  else if (req.query.code === 'PDP') {
            let fileLocation = getJsonFilePath(req, 'payroll-inputs-data/paydataentry.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 2000)
        } else if (req.query.code === 'MCP') {
            let fileLocation = getJsonFilePath(req, 'payroll-inputs-data/manualchecks.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 2000)
        } else if (req.query.code === 'TWM') {
            let fileLocation = getJsonFilePath(req, 'needs-review-data/pendingTaxChanges.json');
            setTimeout(() => {
                utils.readFileAndSend(fileLocation, req, res);
            }, 2000)
        }

    });

};

module.exports = setup;