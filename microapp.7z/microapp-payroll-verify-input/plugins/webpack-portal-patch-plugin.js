/**
 * Created by mckeowr on 3/8/17.
 */
var RawSource = require('webpack-sources').RawSource;

/**
 * This plugin is specifically for ensuring that any references to _container_ in the generated code
 * are switched to _kontainer_ because _container_ will automatically get replaced in the portal with something like:
 *  dojo.byId('appContainer') even if it is a JS variable.
 * @constructor
 */
class PortalPatchPlugin {
    constructor(options) {
        this.bundleName = options.bundle + '.js'
    }

    apply(compiler) {
        compiler.plugin("emit", (compilation, callback) => {

            let bundleFile = this.bundleName;
            var JS = compilation.assets[bundleFile].source();

            // Any _container_ is magically broken in the portal... ugh! So we change it to a k... for kool!
            JS = JS.replace(/_container_/g, '_kontainer_');
            JS = JS.replace(/_container_/g, '_kontainer_');

            // apply the patched JS code
            compilation.assets[bundleFile] = new RawSource(JS);

            callback();
        });
    }
}

module.exports = PortalPatchPlugin;