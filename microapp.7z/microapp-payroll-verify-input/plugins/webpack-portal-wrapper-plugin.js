const fs = require('fs');
const path = require('path');
const Handlebars = require('handlebars');

var ConcatSource;
try {
  ConcatSource = require("webpack-core/lib/ConcatSource");
} catch (e) {
  ConcatSource = require("webpack-sources").ConcatSource;
}


class PortalWrapperTemplateBuilder {
  constructor(options) {
    const pkg = options.pkg || {};
    const buildOptions = options.buildOptions || {};
    const beforeTemplateText = options.beforeContent || '';
    const afterTemplateText = options.afterContent || '';

    const context = {
      pkg: pkg,
      buildOptions: buildOptions,
      isPortal: options.isPortal || true,
      isDev: options.isDev || false,
      isLocal: options.isLocal
    };

    const beforeTemplate = Handlebars.compile(beforeTemplateText);
    const afterTemplate = Handlebars.compile(afterTemplateText);

    this.beforeContent = beforeTemplate(context);
    this.afterContent = afterTemplate(context);
  }

  getPrefixContent() {
    return this.beforeContent;
  }

  getSuffixContent() {
    return this.afterContent;
  }
}

/**
 * wraps the generated code with the prefix and suffixed needed to isolate the app in the portal
 * @constructor
 */
class PortalWrapperPlugin {
  constructor(options) {

    const builder = new PortalWrapperTemplateBuilder(options);

    this.beforeContent = builder.getPrefixContent();
    this.afterContent = builder.getSuffixContent();

  }

  apply(compiler) {
    compiler.plugin("emit", (compilation, callback) => {

      const chunkAsset = compilation.chunks.find((chunk) => chunk.name === 'main');
      const distChunk = chunkAsset.files[0];
      const source = compilation.assets[distChunk].source();
      //trim off the sourcemap so we can stick it at the end
      const sourceMap = source.substring(source.lastIndexOf('\n'));
      compilation.assets[distChunk].source = () => {
        return source.substr(0, source.lastIndexOf('\n'));
      };

      // apply the before/after
      compilation.assets[distChunk] = new ConcatSource(this.beforeContent, compilation.assets[distChunk], this.afterContent, sourceMap);

      callback();
    });

  }

}

module.exports = {
  PortalWrapperPlugin: PortalWrapperPlugin,
  PortalWrapperTemplateBuilder: PortalWrapperTemplateBuilder
}
