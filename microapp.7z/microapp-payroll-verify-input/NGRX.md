# Using ngrx
NgRx is a [Redux](http://redux.js.org/) inspired framework built around RxJS specifically for Angular v2+. 
RxJS is a javascript implementation of [ReactiveX](http://reactivex.io/) used heavily in Angular v2+
that uses asynchronous observable streams. Take a look at the [documentation for RxJS](https://github.com/ReactiveX/rxjs). 
Once you have a grasp of RxJS, it will be easier to understand how NgRX uses it to implement a Redux-like application.

The gist of it is that the state of an application can be fairly complex on the front end. This architecture
simplifies it greatly. The Redux documentation sums it up nicely. 

>The whole state of your app is stored in an object tree inside a single store.
>The only way to change the state tree is to emit an action, an object describing what happened.
>To specify how the actions transform the state tree, you write pure reducers.

To change the state, you must dispatch actions which will be applied via reducers (pure functions) that take
the action (which can have a payload) and the existing state. Reducers return a new state that is the result of
applying the changes described in the action. The state can be observed from anywhere in your application to 
be notified of specific changes made to the state. 

### Example 
This starter app already has an example built in. The files you will be interested in are:
* `src/app/ngrx/store/ui.store.ts` - This is probably the simplest possible example of a store. It exposes a state object
that has a single property called `isLoading`.
* `src/app/ngrx/store/index.ts` - This is the aggregate store that pulls together more specific stores required by your application.
In this example, it isn't really necessary since there is only one store but as the application grows, you will likely 
have many stores dealing with specific parts of your application.
* `src/app/ngrx/ngrx.module.ts` - This is all the ngrx related stuff in its own module. It doesn't need to be like this. Usually
 you would add the `StoreModule.provideStore()` in the root module of your application. In this file the `StoreModule` is 
used to provide the store that can then be injected throughout your application.
* `src/app/ngrx/demo/demo.component.ts|html` - This is where we demonstrate how to select from the store and use the data
in the view to output the value and show a busy indicator while loading is true.
* `src/app/ngrx/demo/demo.service.ts` - This has an example of how you dispatch an action indicating when the state must change. 
This isn't the only way to cause changes to the state. The `@ngrx/effects` library is another option (which is not demoed in 
 this application).
* `src/app/app.component.html`- The root component in this example just shows the `app-ngrx-demo` component in it's view.
* `src/app/app.module.ts` - Just importring ngrx demo module so we can use it.
 
You can delete the `app/ngrx/demo` directory once you are familiar with how it works.
 
As the documentation from Redux says, all changes to the applications state are handled in exactly the same way. 
1. Something dispatches an action
2. Reducer handles the action and creates a new state
3. Observers are notified
 
In this simple example, that flow is achieved like so:

1. Clicking the "Load Something" button makes a call to the `DemoService.loadSomething()` method. 
2. That method dispatches an START_LOADING action. 
3. The reducer in the `ui.store.ts` file handles that action and creates a new
ui state with the `isLoading` property set to true. 
4. The service then simulates a backend call with a timeout. 
5. Because, the state has changed, anything subscribing to Observables created from will be notified. In this case, the DemoCompenent subscribed to
 the states isLoading property and as a result gets notified that it changed. (There is a second way as shown in the DemoCompenent. 
 See "using the async pipe" below.
6. The handler for the subscription gets called with the new value which is stored in the DemoCompenent's `isLoading` property.
7. The view is updated do to the changed property.
8. When the async call returns (simulated by the timeout), a STOP_LOADING action is dispatched by the service.
9. The same process applies and a new state is created, observables subscribers are notified and the view is updated.


#### Using the async pipe
Sometimes you component doesn't need to do much with the data it is getting from the state itself. Instead it is passing it on to
other components or displaying it in the view. Rather than having the component class subscribe select a portion of the state, 
subscribe to the observable, and then respond by storing the resulting data as a property, you may just want to select a portion
of the state and store a reference to the Observable it returns. The data that it represents can then be accessing in your view
using the `async` pipe.

The `DemoCompenent` shows an example of this by selecting from the state and storing the Observable in it's `isLoading$`. 
The $ is a convention to indicate that a property is an Observable. It is not required. The view uses the `async` pipe 
to output the value that it will eventually emit.

```
{{isLoading$ | async}}
```
   

### Not Sold on NgNX?
We strongly suggest that you take a look at the [documentation](https://github.com/ngrx/store) 
and [official example application](https://github.com/ngrx/example-app) and use this approach. It greatly simplifies complex
applications (though may seem like overkill for an example as simple as the one above). It also is very easy to test as
the side effects of an action are easily tested due to the simplicity of reducers.

However, if you don't want or need to use NgRX in your application you don't have to use this approach. In fact, there
are other libraries for implementing the Redux pattern in Angular. If you want to remove the sample code from this
starter app, you will just need to delete the `src/app/ngrx` directory and all the references to its use. You can find those 
references by searching src directory for any files that include the string `NGRX_DEMO:`. Lastly, you can delete the four
dependencies from your package.json file: @ngrx/core, @ngrx/store, reselect and ngrx-store-freeze.

