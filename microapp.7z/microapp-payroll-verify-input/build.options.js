const proxy_urls = {
  DIT: 'http://microapi-payroll-verify-input.1.vantage.dit.paascloud.oneadp.com/',
  FIT: 'http://microapi-payroll-verify-input.1.vantage.fit.paascloud.oneadp.com/',
  LOCAL: 'http://localhost:9095/'
}

const proxy = proxy_urls.DIT;

// Build environment configuration
// The intent here is to expose the most commonly modify configuration options. You can of course, edit the
// webpack.config.js file but hopefully you won't have to

// These can also be passed in via command line args such as --env.portal=true
// NOTE: the npm run package* scripts automatically pass portal and prod variables for you. Changing them here
// would only impact the npm run package-dev and npm run start commands

// When running locally with npm run start, you may want to intercept the api calls and pass to either
// a real backend or a locally running mock server (see mock-server.js). This is the url to that server.
// Any requests to it, such as "http://localhost:9000/api" will be routed to that server
// You can change the api root here as well.
const API_ROOT = '/smicro/microapp-payroll-verify-input/1/vantage';

const PROXY_URL = proxy; // <!-- url to actual backend

// For more configuration options that can be specified in this proxyConfig object, see
// https://webpack.js.org/configuration/dev-server/#devserver-proxy
let proxyConfig = {};

if (PROXY_URL) {
  proxyConfig[API_ROOT] = PROXY_URL;
}

proxyConfig['/smicro/microapi-payroll-verify-input/1/vantage/**'] = {
  target: proxy,
  changeOrigin: true,
  //pathRewrite: {'^/microapi' : '/vantage/microapi'},
  pathRewrite: function (path, req) {
    let newPath;
    if (path.indexOf('/verifyinput/dashboard') > -1) {
      newPath = '/verifyinput/dashboard' + path.replace('/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/dashboard', '');
    }

    else if (path.indexOf('/verifyinput/details') > -1) {
      newPath = '/verifyinput/details' + path.replace('/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/details', '');
    }

    else if (path.indexOf('/verifyinput/paydatabatches') > -1) {
      newPath = '/verifyinput/paydatabatches' + path.replace('/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/paydatabatches', '');
    }
    else if (path.indexOf('/verifyinput/employeedetails') > -1) {
      newPath = '/verifyinput/employeedetails' + path.replace('/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/employeedetails', '');
    }
    else if (path.indexOf('/verifyinput/exportdetails') > -1) {
      newPath = '/verifyinput/exportdetails' + path.replace('/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/exportdetails', '');
    }
    else if (path.indexOf('/verifyinput/accessflags') > -1) {
      newPath = '/verifyinput/accessflags' + path.replace('/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/accessflags', '');
    }

    console.log('VerifyInput: \t' + newPath);

    return newPath;
  },
  headers: {
    host: proxy
    //"APPID":"HRIIPortal",
    //"AssociateOID":"G3EYJYBC613RRHX9",
    //"ISISessionID": "1B5E55B27632D912AB108ABB280A8C40=",
    //"orgOID":"G3J4YCQKC4E7AAYH"
  },
  logLevel: 'debug'

}


let config = {
  // this is the public path of the application. If the application is going into a
  // WAR called app.war, your would use
  //  root: '/app/'
  // When you run: npm run start
  //    this will automatically be set to '/' so that the webpack dev server works correctly
  root: "",

  //v-------- Used when running via npm run start only
  // see the proxyConfig defined above
  proxy: proxyConfig,

  // the url relative to the portal where the JS files will be loaded from
  // NOTE: the string $$ROLE_PREFIX is a genesis specific placeholder
  // that will automatically resolve to either 'micro' or 'smicro' depending
  // on the users role.
  appPrefix: '/smicro/microapp-payroll-verify-input/1/vantage',

  // This must match the selector of your app.component
  // YOU MUST CHANGE THIS TO SOMETHING SPECIFIC
  rootTag: "app-microapp-payroll-verify-input-root",

  // you need this for IE unless the portal starts including it
  includePromisePolyfill: true,

  // objects on the window that may be overwritten by dependencies in our application
  // There are defaults built into the wrapper such as Highcharts and libphonenumber,
  // but you can add more here
  windowObjectsToCache: ['wijmo', 'JSZip'],

  // Some window objects need to still be accessible using just the name, such as: libphonenumber (included by default)
  // Adding other items will make them available as local variables inside the closure that surrounds
  // the application.
  windowObjectsToMakeLocal: ['Highcharts', 'wijmo', 'JSZip'],

  apiRoot: API_ROOT
};



module.exports = config;