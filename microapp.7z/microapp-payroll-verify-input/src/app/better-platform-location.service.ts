/**
 * Created by mckeowr on 8/25/17.
 */
import { Inject, Injectable } from '@angular/core';
import { ɵBrowserPlatformLocation as BrowserPlatformLocation, ɵgetDOM as getDOM } from '@angular/platform-browser';

import { DOCUMENT, LocationChangeListener } from '@angular/common';

/**
 * This is a temporary workaround to prevent a memory leak caused by hashChange and popState event
 * listeners not being removed when the application is destroyed.
 * This is a bit of a hack because we are relying on two private imports to do this
 */
@Injectable()
export class BetterPlatformBrowserLocationService extends BrowserPlatformLocation {

    hashChangeListeners: LocationChangeListener[] = [];
    popStateListeners: LocationChangeListener[] = [];

    /* istanbul ignore next */
    constructor(@Inject(DOCUMENT) private doc: any) {
        super(doc);
    }

    /**
     * Override the onPopState method and store a reference to the listener
     * so we can remove it later
     * @param fn
     */
    /* istanbul ignore next */
    onPopState(fn: LocationChangeListener): void {
        this.popStateListeners.push(fn);
        super.onPopState(fn);
    };

    /**
     * Override the onHashChange method and store a reference to the listener
     * so we can remove it later
     * @param fn
     */
    /* istanbul ignore next */
    onHashChange(fn: LocationChangeListener): void {
        this.hashChangeListeners.push(fn);
        super.onHashChange(fn);
    };

    /**
     * This method needs to be called manually. Just implementing OnDestroy doesn't work
     * as the ngOnDestroy method doesn't get called when the application is destroyed.
     * To make this work, you should use this class instead of the normal BrowserPlatformLocation in your
     * app module's providers:
     *
     *  {provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService}
     *
     * Then, inject this into your AppComponent and in it's ngOnDestroy method
     * call this services onDestroy method manually{

        constructor(private platformLocation: PlatformLocation) { }

        ngOnDestroy() {
            // You'll need to cast this to BetterPlatformBrowserLocationService in order to reference
            // this method
            (<BetterPlatformBrowserLocationService> this.platformLocation).onDestroy();
        }
     */
    /* istanbul ignore next */
    onDestroy() {

        this.hashChangeListeners.forEach((fn: LocationChangeListener) => {
            getDOM().getGlobalEventTarget(this.doc, 'window').removeEventListener('hashchange', fn, false);
        });

        this.hashChangeListeners = [];

        this.popStateListeners.forEach((fn: LocationChangeListener) => {
            getDOM().getGlobalEventTarget(this.doc, 'window').removeEventListener('popstate', fn, false);
        });

        this.popStateListeners = [];
    }
}