import { reducers, metaReducers } from './../../store/index';
import { StoreModule } from '@ngrx/store';
import { ClickOutDirective } from './../proc-group-dropdown/directives/click-out.directive';
import { headerData } from './../../store/reducer/app.reducer';
import { CheckboxModule } from '@synerg/components';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { ProcGroupDropdownComponent } from '../proc-group-dropdown/proc-group-dropdown.component';
import { InputFocusDirective } from '../proc-group-dropdown/directives/input-focus.directive';
import { PreScrollDirective } from '../proc-group-dropdown/directives/pre-scroll.directive';
import { FormsModule } from '@angular/forms';
import { SearchFilter } from '../proc-group-dropdown/filters/search-filter.pipe';
import { SearchHighlight } from '../proc-group-dropdown/filters/search-highlight.pipe';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CheckboxModule, FormsModule, StoreModule.forRoot(reducers, { metaReducers })],
      declarations: [
        HeaderComponent, 
        ClickOutDirective,
        ProcGroupDropdownComponent,
        InputFocusDirective,
        PreScrollDirective,
        SearchFilter,
        SearchHighlight
      ],
   
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    component.headerData = {
      type: 'Pay Group',
      payGroup: {
        payrollGroupCode: 'KZ1',
        payrollYear: '2017',
        payrollWeekNumber: '42',
        payrollRunNumber: '1'
      },
      processingGroupName: '',
      description: 'Kaizen &K Other Wkly  PG',
      quarter: '4',
      payDate: '',
      periodStartDate1: '',
      periodEndDate1: '',
      periodStartDate2: '',
      periodEndDate2: '',
      benefitsDeductionReady: ''
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have header data', () => {
    expect(component.headerData.type).toBe('Pay Group');
  });

});
