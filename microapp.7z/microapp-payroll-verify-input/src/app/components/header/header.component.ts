import { Observable } from 'rxjs/Observable';
import { Header } from '../../model/header.interface';
import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../store/index';
import * as AppActions from '../../store/actions/app.actions';

declare var dijit: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderComponent implements OnInit {
  isProcGroupDropdownReady$: Observable<boolean>;
  isProcGroupDropdownError$: Observable<boolean>;
  isPermissionCallError$: Observable<boolean>;
  session$: Observable<object>;
  constructor(private store: Store<fromRoot.State>) {
    
  }
  ngOnInit() {
    this.isProcGroupDropdownReady$ = this.store.select(fromRoot.app_isProcGroupDropdownReady);
    this.isProcGroupDropdownError$ = this.store.select(fromRoot.app_isProcGroupDropdownError);
    this.isPermissionCallError$ = this.store.select(fromRoot.app_isPermissionCallError);
    this.session$ = this.store.select(fromRoot.app_getSessionData);
  }

  @Input()
  headerData: Header;
    /* istanbul ignore next */
    showHelp() {
         if (dijit) {
            const resourceId = dijit.byId('portlet').get('resourceId') || '';
            const helpComponentId = 'inputDashboard';
            dijit.byId('portlet').setHelpResourceId(resourceId, helpComponentId);
            dijit.byId('portlet').helpButton.onClick();
        }
    }

}
