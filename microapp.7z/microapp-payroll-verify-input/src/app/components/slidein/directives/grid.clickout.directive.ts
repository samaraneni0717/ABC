import {
    Directive,
    HostListener,
    Input,
    Output,
    EventEmitter
  } from "@angular/core";
  
  @Directive({
    selector: '[gridClickOut]'
  })
  export class GridClickOutDirective {
  
    @Input('gridClickOut') isOpen: boolean;
    @Input('timerInProgress') timerInProgress: any;
    @Output() output: EventEmitter<boolean> = new EventEmitter();
    setTimer: any;
  
    constructor() { }
  
    @HostListener('click') onClick() {
      if (this.isOpen && !this.timerInProgress) {
        this.setTimer = setTimeout(() => {
          this.output.emit(null);
        }, 3000);
        this.output.emit(this.setTimer);
      }
    }
  }
  
  