import { paygroup } from './../../store/reducer/app.reducer';
import { APP_ACTIONS } from './../../store/actions/app.actions';
import { TableGrid } from './../../model/table-grid.interface';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, HostBinding, ViewChild, OnDestroy } from '@angular/core';
import { VanSlideinService, SLIDE_IN_ANIMATIONS, VanModalModel, VanActiveModal, VanModalOptions} from '@van-genesis/van-genesis';
import * as Constants from '../../constants/constants';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../store/index';
import * as AppActions from '../../store/actions/app.actions';


import { FlexGrid } from 'wijmo/wijmo.grid'; 
import * as wjcCore from 'wijmo/wijmo';
import * as wjcGrid from 'wijmo/wijmo.grid';
import * as wjcGridXlsx from 'wijmo/wijmo.grid.xlsx';
//import * as wjcGridFilter from 'wijmo/wijmo.grid.filter';
import * as wjSheet from 'wijmo/wijmo.grid.sheet';

declare var dijit: any;
@Component({
    selector: 'app-slidein',
    templateUrl: './slidein.component.html',
    styleUrls: ['./slidein.component.scss'],
    animations: SLIDE_IN_ANIMATIONS
})
export class SlideinComponent implements OnInit, OnDestroy {
    @HostBinding('@destroyAnimation') destroyAnimation = true;
    @HostBinding('class.vdl-slide-in-mount') isSlidein = true;

    isGridLoading$: Observable<boolean>;
    headers: any;
    paygroup: string;
    sessionData: object;
    data: wjcCore.CollectionView;
    columnsAvailable: wjcCore.CollectionView;
    columns: wjcCore.CollectionView;
    @ViewChild('flex') flex: wjcGrid.FlexGrid;
    // @ViewChild('filter') filter: wjcGridFilter.FlexGridFilter;
    hidden: any ;
    hidden_dataset: any;
    hidden_headers: any;
    exportExcelStart$: Observable<boolean>;
    exportExcelComplete$: Observable<boolean>;
    exportExcelError$: Observable<boolean>;
    dataSubscription: any;
    miniTileCode: any;
    clearTimer: any;
    /* istanbul ignore next */
    constructor(public model: VanModalModel,
                private activeModal: VanActiveModal,
                public options: VanModalOptions,
                private slideinService: VanSlideinService,
                private store: Store<fromRoot.State>) {
    }
    /* istanbul ignore next */
    dismiss() {
        let alertContainer = document.getElementById('alertContainer');
        if(alertContainer){
            alertContainer.parentNode.removeChild(alertContainer);
        }
        this.activeModal.dismiss('Slide-in was dismissed via "Back"');
    }

    resetProgressBarStatus(timer: any){
        this.clearTimer = timer;
        if(this.clearTimer == null){
            this.store.dispatch(new AppActions.EXPORT_EXCEL_RESET());
        }
    }

     /* istanbul ignore next */
    ngOnInit() {
        this.exportExcelStart$ = this.store.select(fromRoot.app_exportExcelStart);
        this.exportExcelComplete$ =this.store.select(fromRoot.app_exportExcelComplete);
        this.exportExcelError$ =this.store.select(fromRoot.app_exportExcelError);
        
        this.store.select(fromRoot.app_getPayGroup).subscribe( (paygroup) => {
            this.paygroup = paygroup;
        });
        this.store.select(fromRoot.app_getSessionData).subscribe( (sessionData) => {
            this.sessionData = sessionData;
        });
        
        this.isGridLoading$ = this.store.select(fromRoot.app_getIsGridLoading);

        this.dataSubscription = this.store.select(fromRoot.app_getSlideInData).subscribe( (data:any) => {
            if(data) {
                this.miniTileCode = data.code;
                this.headers = data.headers;
                // for( let j = 0; j < 1; j++){
                //     for( let i = 0; i < data.tableData.length; i++){
                //         this.dataset.push(data.tableData[i])
                //     }
                // }
                // build list of columns available
                let fields = new wjcCore.ObservableArray();
                for (let key in data.tableData[0]) {
                    fields.push(key);
                }
                fields.forEach( (field, i) => {
                    fields[i] = {
                        'binding': field,
                        'header': this.headers[i],
                        'align': this.getAlignment(field),
                        'visible': this.isVisible(field),
                        //  'columnHeaderTemplate': this.getCellTemplate(fields[i]),
                        'width': this.getColumnWidth(field),
                        'enableBatchId': Constants.Details[data.code].enableBatchId
                    }  
                });
               
                this.columns = new wjcCore.CollectionView(fields);
                this.data = new wjcCore.CollectionView(data.tableData);

             let sortByName = new wjcCore.SortDescription('name', true);
             this.data.sortDescriptions.push(sortByName);
             this.data.moveCurrentToPosition(-1);  
            }
        });
       
    }
    /* istanbul ignore next */
    isPendingNewHire(row : any){
         if (this.miniTileCode == 'UNH' && (row.employeeType == '' || row.location == '')) {
             return true;
         } 
         return false;
    }
    /* istanbul ignore next */
    sortingColumn = function (sender, data) {
        data.sortComparer = null;
        data.currentPosition = -1;
        if(Constants.RightAlignmentFields.indexOf(sender.panel.columns[sender.col].binding) > -1) {
            data.sortComparer = function(a, b){
                return a-b;
             }  
        };
    } 
     /* istanbul ignore next */
    initialized(sender: wjcGrid.FlexGrid, event: any) {
        // this.filter.filterChanging.addHandler(function (s, e) {
        //     s.grid.itemsSource.currentPosition  = -1;
        // });
        // this.filter.filterChanged.addHandler(function () {
        //     console.log('filter changed');
        // });
        // this.filter.filterApplied.addHandler(function () {
        //     console.log('filter applied');
        // });
    }
    /* istanbul ignore next */
    getAlignment(column: any) {
        return (Constants.RightAlignmentFields.indexOf(column) > -1) ? 'right' : 'left';
     }
    /* istanbul ignore next */
    isVisible(column: any) {
        return ((column == 'employeeRecordNumber')|| (column == 'batchType'))? false : true;
    }
    /* istanbul ignore next */
    getCellTemplate(column: any) {
        //return  column =='name' ? NameCellTemplateComponent : CellTemplateComponent;     
    }
    /* istanbul ignore next */
    getColumnWidth(column: any) {
        return column =='name' ? 300 : '*';
    }
    /* istanbul ignore next */
    openModal(item: any){
        const params: any = {
            name: item.name,
            size: 'lg',
            type: 'default',
            componentId: 'employeedetails',
            paygroup: this.paygroup,
            employeeId: item.employeeId,
            fileNumber: item.fileNumber,
            employeeRecordNumber:  item.employeeRecordNumber
        };
        this.store.dispatch(new AppActions.OPEN_MODAL(params));
    }
    /* istanbul ignore next */
    getDateAndTime(){ 
        function pad2(n) { 
            return n < 10 ? '0' + n : n; 
        }
        let date = new Date();
        return date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + '_'+ 
                pad2(date.getHours()) + pad2(date.getMinutes()) + pad2(date.getSeconds());
    }

    /* istanbul ignore next */
    exportToExcel() {  
        if(this.clearTimer)  {
            clearTimeout(this.clearTimer);
            this.clearTimer = null;
        }

        this.store.dispatch(new AppActions.EXPORT_EXCEL_START());
        setTimeout(() => {
            wjcGridXlsx.FlexGridXlsxConverter.saveAsync(this.flex, {
                includeColumnHeaders: true,
                includeCellStyles: false,
                includeColumns: (column) => {
                    return column.binding !== 'employeeRecordNumber';
                },
                formatItem: null
            }, this.paygroup + '_' + this.model.title + '_' + this.getDateAndTime(),
                // filename
                (base64) => { // onSaved 
                    this.store.dispatch(new AppActions.EXPORT_EXCEL_COMPLETE());
                },
                (reason) => { // onError
                    this.store.dispatch(new AppActions.EXPORT_EXCEL_ERROR());
                });
        }); 
    }

    /* istanbul ignore next */
    exportAll(){

        const finalPayload = { paygroup: 'ZE1', code: 'ITC'};

        //  this.AppService.getDetails(finalPayload).subscribe( (data: any) => {
        //     this.hidden_dataset = buildTableData(data.data.exportDetails || [], 'ITC', true);
        //  }
        

        //  );

         // this.hidden_headers  = [...data.headers, ...Constants.HiddenHeaders]
       
      


        this.store.select(fromRoot.app_getSlideInData).subscribe( (data:any) => {
            if(data) {
                this.hidden_dataset = [];
                this.hidden_headers = [];
                this.headers = data.headers;
                this.hidden_dataset = data.hiddenData;
// console.log('data.tableData', data.tableData);
// console.log('data.hiddenData', data.hiddenData);

            // data.tableData.forEach( (obj, i) => {
            //  let newobj = Object.assign({}, obj, data.hiddenData[i]);
            //     this.hidden_dataset.push(newobj);
            // });

          //  this.hidden_headers  = [...data.headers, ...Constants.HiddenHeaders]


           
                // for( let j = 0; j < 5000; j++){
                //     for( let i = 0; i < data.hiddenData.length; i++){
                //         this.hidden_dataset.push(data.hiddenData[i]);
                //     }
                // }

            //  this.data = new wjcCore.CollectionView(this.hidden_dataset);
            //  this.data.sortDescriptions.push(sortByName);

            //  let sortByName = new wjcCore.SortDescription('name', true);
            //  this.data.sortDescriptions.push(sortByName);
            //  this.data.moveCurrentToPosition(-1);
              
 
            //     // build list of columns available
            //     const item = this.dataset[0];
            //     console.log('item', item);
            //     let fields = new wjcCore.ObservableArray();
            //     for (let key in item) {
            //         fields.push(key);
            //     }

            //     for (var i = 0; i < fields.length; i++) {
            //         fields[i] = {
            //             'binding':  fields[i], 
            //             'header' : this.headers[i],
            //             'align': this.getAlignment(fields[i]),
            //             'visible': this.isVisible(fields[i]),
            //           //  'columnHeaderTemplate': this.getCellTemplate(fields[i]),
            //             'width': this.getColumnWidth(fields[i])}        
            //     }
            //     this.columns = new wjcCore.CollectionView(fields);
          }});

    
        


        if(!this.hidden){
            this.hidden =new wjcGrid.FlexGrid('#hiddenGrid')
        }

       let new_cv = new wjcCore.CollectionView(this.hidden_dataset);
       this.hidden.itemsSource = new_cv;
        for (let i=0; i< this.hidden_headers.length; i++){
            this.hidden.columns[i]._hdr =this.hidden_headers[i];
        }

        // wjcGridXlsx.FlexGridXlsxConverter.saveAsync(this.hidden, {
        //     includeColumnHeaders: true,
        //     includeCellStyles: false,
        //     includeColumns: function(column) {
        //             return column.binding !== 'employeeRecordNumber';
        //          },
              
        //     formatItem:  null
        //   }, this.paygroup +' FlexGrid_Hidden.xlsx');

          
          this.hidden.itemsSource = [];
    }

    routeToBatch(item) {

        this.navigateTo({}, 'Pay Data Entry', '/payroll/hrii/payroll/admin/paydataentry/routingToBatch.faces?payGroup='+encodeURIComponent(this.paygroup)+'&batchId='+encodeURIComponent(item.batchId)+'&type='+item.batchType, 'pracPayDataEntry');
    }
    /* istanbul ignore next */
    showHelp() {
        if (dijit) {
            const resourceId = dijit.byId('portlet').get('resourceId') || '';
            const helpComponentId = this.model.componentId;
            dijit.byId('portlet').setHelpResourceId(resourceId, helpComponentId);
            dijit.byId('portlet').helpButton.onClick();
        }
    }

    navigateTo(sessionItem, name: string, url: string, resourceId: string) {
        if(dijit) {
            //sessionStorage.setItem('vi_details', JSON.stringify(sessionItem));
            const appContainer = dijit.byId('appContainer');
            sessionStorage.setItem('verifyInputData', JSON.stringify(this.sessionData));
            appContainer.gotoSimplePortlet(name, url, resourceId);
        } else {
            console.log('dijit is not defined');
        }
    }
    /* istanbul ignore next */
    ngOnDestroy(){
        this.dataSubscription.unsubscribe();
    }
}
