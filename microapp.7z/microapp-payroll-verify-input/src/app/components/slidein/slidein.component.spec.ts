import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { reducers, metaReducers } from './../../store/index';
import { Store, StoreModule } from '@ngrx/store';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlideinComponent } from './slidein.component';
import { BusyIndicatorModule } from '@synerg/components';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { VanModalOptions, VanSlideinService, VanModalService, VanModalModel, VanActiveModal  } from '@van-genesis/van-genesis';
import * as fromRoot from '../../store/index';
import * as AppActions from '../../store/actions/app.actions';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { WjGridFilterModule } from 'wijmo/wijmo.angular2.grid.filter';
import { WjCoreModule } from 'wijmo/wijmo.angular2.core';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';
import { WjChartModule } from 'wijmo/wijmo.angular2.chart';

describe('SlideinComponent', () => {
  let component: SlideinComponent;
  let fixture: ComponentFixture<SlideinComponent>;
  let slideInService: VanSlideinService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SlideinComponent], 
      imports: [
        BusyIndicatorModule, 
        StoreModule.forRoot(reducers, { metaReducers }),
        BrowserAnimationsModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        VanModalModel, 
        VanActiveModal, 
        WjGridModule,
        WjGridFilterModule,
        WjCoreModule,
        WjInputModule,
        WjChartModule,
        {
          provide: VanModalOptions,
          useValue: {
            closable: true,
            closeOnClickOutside: false,
            type: 'default',
            size: 'xl',
            createBackdrop: true
          }
        },
        VanSlideinService,
        VanModalService
      ]
    })
    .compileComponents();
  }));
  const testData = {
    data: {
      timeStamp: '2018-01-02 20:13:57.000764',
      referenceCode: 'D5734351C79440A489C62DE7EEABB2C5',
      data: {
        details: [
          {
            name: 'Allen,Ethan',
            employeeId: '221588',
            fileNumber: '221588',
            employeeRecordNumber: 0,
            status: 'A',
            paygroup: 'KZ2',
            location: 'CA002',
            locationDescr: 'CA - Los Angeles',
            employeeType: 'H',
            employeeTypeDescr: 'Hourly',
            regTemp: 'R',
            regTempDescr: 'Reg',
            fullPartTime: 'F',
            fullPartTimeDescr: 'FT',
            fileNumberStatus: 'I'
          }
        ],
        resultCount: 6,
        startRowNum: 1,
        endRowNum: 6
      },
      messages: [],
      wfRefData: {
        wfProcessInstanceId: null,
        wfRedirectResourceId: null,
        wfAllowEdits: true
      }
    },
    code: 'MTC'
  };
  beforeEach(() => {
    fixture = TestBed.createComponent(SlideinComponent);
    component = fixture.componentInstance;
    component.model = {
      title: 'title',
      instruction: 'instruction'
    }
    component.headers = [''];
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });

  // it('should dismiss', () => {
  //   spyOn(component, 'dismiss');
  //   fixture.nativeElement.querySelector('button').click();
  //   expect(component.dismiss).toHaveBeenCalled();
  // });

  // it('should get slide in data from the store', () => {
  //   const store = TestBed.get(Store);
  //   store.dispatch(new AppActions.SET_SLIDE_IN_DATA(testData));
  //   spyOn(store,'dispatch').and.callThrough();
  //   expect(component.dataset.length).toBeGreaterThan(0);
  //   // component.dataset[0][0].outputs.click();
  // });

});
