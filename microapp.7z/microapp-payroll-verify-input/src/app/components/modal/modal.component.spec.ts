import { Store, StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './../../store/index';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalComponent } from './modal.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { VanActiveModal, VanModalModel, VanModalOptions, VanModalService } from '@van-genesis/van-genesis';
import * as fromRoot from '../../store/index';
import { By } from '@angular/platform-browser';
describe('ModalComponent', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        StoreModule.forRoot(reducers, { metaReducers })
      ],
      providers: [
        VanModalModel,
        VanActiveModal,
        {
          provide: VanModalOptions,
          useValue: {
            closable: true,
            closeOnClickOutside: false,
            type: 'default',
            size: 'xl',
            createBackdrop: true
          }
        },
        VanModalService
      ]
    })
    .compileComponents();
  }));
  describe('component id !== paydatabatches', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(ModalComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should close', () => {
      spyOn(component.activeModal, 'close');
      component.close();
      expect(component.activeModal.close).toHaveBeenCalled();
    });

  });

  describe('component id == paydatabatches', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(ModalComponent);
      component = fixture.componentInstance;
      component.model.componentId = 'paydatabatches';
      fixture.detectChanges();
    });
    it('modal component id === paydatabatches', () => {
      expect(component.ispaydatabatches).toBeTruthy();
    });
  });

 

});
