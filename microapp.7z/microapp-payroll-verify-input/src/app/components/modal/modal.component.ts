import { Component, OnInit, HostBinding, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { MODAL_ANIMATIONS, VanActiveModal, VanModalModel, VanModalOptions , VanModalService} from '@van-genesis/van-genesis';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../store/index';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
  animations: [MODAL_ANIMATIONS]
})
export class ModalComponent implements OnInit {
  isModalLoading$: Observable<boolean>;
  headers: any;
  data$: Observable<any>;
  title: string;
  size:string;
  type: string;
  ispaydatabatches: boolean;

  constructor(public activeModal: VanActiveModal, public model: VanModalModel, private options: VanModalOptions,
  private service: VanModalService, private store: Store<fromRoot.State>) { 
  }

  close(){
    this.activeModal.close();
    console.log('closed!');
  }

  ngOnInit() {
    this.title = this.model.name;
    this.size = this.model.size;
    this.type = this.model.type;
    if(this.model.componentId == 'paydatabatches'){
        this.ispaydatabatches = true;
    } else {
      this.ispaydatabatches = false;
      this.isModalLoading$ = this.store.select(fromRoot.app_getIsModalLoading);
      this.data$ = this.store.select(fromRoot.app_getModalData);
    }
  }
}
