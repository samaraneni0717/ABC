import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { InputFocusDirective } from './input-focus.directive';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  template: `<input type="text" inputFocus>`
})
class TestInputFocusComponent implements AfterViewInit {
  ngAfterViewInit(){};
}

describe('Directive: InputFocus', () => {

  let component: TestInputFocusComponent;
  let fixture: ComponentFixture<TestInputFocusComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestInputFocusComponent, InputFocusDirective]
    });
    fixture = TestBed.createComponent(TestInputFocusComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    spyOn(inputEl.nativeElement, 'focus');
    component.ngAfterViewInit();
    fixture.detectChanges();

  });

  it('input should gain focus', () => {
    expect(inputEl.nativeElement.focus).toHaveBeenCalled();
  });

});