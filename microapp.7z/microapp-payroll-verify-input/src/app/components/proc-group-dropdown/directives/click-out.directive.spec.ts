import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";
import { ClickOutDirective } from './click-out.directive';

@Component({
  template: `
  <div id="outside">Outside</div>
  <div id="container" [clickOut]="closed" (output)="toggleDropdown($event)">Dropdown</div>
  `
})
class TestClickOutComponent {
  closed = false;
  toggleDropdown(e){
    this.closed = e;
  }
}

describe('Directive: ClickOut', () => {

  let component: TestClickOutComponent;
  let fixture: ComponentFixture<TestClickOutComponent>;
  let container: DebugElement;
  let outside: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestClickOutComponent, ClickOutDirective]
    });
    fixture = TestBed.createComponent(TestClickOutComponent);
    component = fixture.componentInstance;
    container = fixture.debugElement.query(By.css('#container'));
    outside = fixture.debugElement.query(By.css('#outside'));
  });

  it('should set closed to true', () => {
    outside.nativeElement.click();
    fixture.detectChanges();
    expect(component.closed).toEqual(true);
  });

  it('closed should remain set to false', () => {
    container.nativeElement.click();
    fixture.detectChanges();
    expect(component.closed).toEqual(false);
  });

});