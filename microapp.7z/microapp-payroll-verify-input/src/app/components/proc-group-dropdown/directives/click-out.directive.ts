import { 
  Directive, 
  ElementRef, 
  HostListener,
  Input, 
  Output,
  EventEmitter} from "@angular/core";

@Directive({
  selector: '[clickOut]'
})
export class ClickOutDirective {

  constructor(
    private elemRef: ElementRef) {}

  @Input('clickOut') closed: boolean;
  @Output() output: EventEmitter<boolean> = new EventEmitter();

  @HostListener('document:click', ['$event'])
  clickedOutside(event: any) {
    if (!this.elemRef.nativeElement.contains(event.target) && !this.closed) {
      this.output.emit(true);
    }
  }

}