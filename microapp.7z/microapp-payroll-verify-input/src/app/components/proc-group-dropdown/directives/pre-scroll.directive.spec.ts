import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, DebugElement, AfterViewInit } from "@angular/core";
import { By } from "@angular/platform-browser";
import { PreScrollDirective } from './pre-scroll.directive';

@Component({
  template: `
  <div id="container" preScroll>
    <div class="selected">KZ2</div>
  </div>
  `,
  styles: ['#container { height: 10px; }','div { height: 100px; }']
})
class TestPreScrollComponent implements AfterViewInit{
  ngAfterViewInit(){}
}

describe('Directive: PreScroll', () => {

  let component: TestPreScrollComponent;
  let fixture: ComponentFixture<TestPreScrollComponent>;
  let container: DebugElement;
  let directive: PreScrollDirective;
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestPreScrollComponent, PreScrollDirective]
    });
    fixture = TestBed.createComponent(TestPreScrollComponent);
    component = fixture.componentInstance;
    container = fixture.debugElement.query(By.css('#container'));
    
  });

  it('should scroll to the correct Element', () => {
    component.ngAfterViewInit();
    fixture.detectChanges();
    expect(container.nativeElement.scrollTop).toEqual(0);
  });

  it('should calculate and scroll when key navigation is present', () => {
    component.ngAfterViewInit();
    container.triggerEventHandler('window:keyup', { key: 'ArrowDown' });
    fixture.detectChanges();
    expect(container.nativeElement.scrollTop).toEqual(0);
  });

});