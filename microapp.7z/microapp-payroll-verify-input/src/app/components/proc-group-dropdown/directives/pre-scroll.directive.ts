import {
  Directive,
  ElementRef,
  HostListener,
  AfterViewInit
} from "@angular/core";

@Directive({
  selector: '[preScroll]'
})
export class PreScrollDirective implements AfterViewInit {

  constructor(
    private elemRef: ElementRef) { }

  @HostListener('window:keyup', ['$event'])
  /* istanbul ignore next */
  scrollKeyNav(event: KeyboardEvent){
    if(event.keyCode === 40 || event.keyCode === 38){
      this.calculateAndScroll();
    }
  }
  ngAfterViewInit(){
    this.calculateAndScroll();
  }
  calculateAndScroll(){
    const container = this.elemRef.nativeElement;
    const payGroups = container.children;
    const selected: any = Array.from(payGroups).filter((pg: any) => {
      return pg.className.indexOf('selected') !== -1;
    });
   
    const posY = selected[0].offsetTop + selected[0].clientHeight;
    container.scrollTop = posY - container.offsetHeight;
  }
}