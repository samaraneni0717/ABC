import {
  Directive,
  ElementRef,
  AfterViewInit
} from "@angular/core";

@Directive({
  selector: '[inputFocus]'
})
export class InputFocusDirective implements AfterViewInit {

  constructor(
    private elemRef: ElementRef) { }

  ngAfterViewInit() {
    this.elemRef.nativeElement.focus();
  }

}