import { SearchFilter } from './filters/search-filter.pipe';
import { InputFocusDirective } from './directives/input-focus.directive';
import { ClickOutDirective } from './directives/click-out.directive';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcGroupDropdownComponent } from './proc-group-dropdown.component';
import { SearchHighlight } from './filters/search-highlight.pipe';
import { FormsModule } from '@angular/forms';
import { AppModule } from '../../app.module';
import { StoreModule, Store } from '@ngrx/store';
import { reducers, metaReducers } from '../../store';
import * as fromRoot from '../../store/index';
import * as AppActions from '../../store/actions/app.actions';

describe('ProcGroupDropdownComponent', () => {
  let component: ProcGroupDropdownComponent;
  let fixture: ComponentFixture<ProcGroupDropdownComponent>;
  let store: Store<fromRoot.State>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        ProcGroupDropdownComponent,
        ClickOutDirective,
        InputFocusDirective,
        SearchFilter,
        SearchHighlight
      ],
      providers: [SearchFilter, SearchHighlight],
      imports: [FormsModule,
        [StoreModule.forRoot(reducers, { metaReducers })]]
    })
    .compileComponents();
  }));
  const data = { "searchCount": 1, "payCycleProcessingList": [{ "name": "PLGRP", "type": "G", "payCycleGroups": 
      [
        { "paygroup": "ZE5", "description": "Laxmi Weekly Paygrou", "payCycleProcessingItems": [{ "year": "2018", "weekNumber": "04", "payrollNumber": "1", "quarter": "1", "payDate1": "2018-01-26 00:00:00.0", "periodStartDate1": "2017-10-07 00:00:00.0", "periodEndDate1": "2017-10-15 00:00:00.0", "periodStartDate2": "2017-10-07 00:00:00.0", "periodEndDate2": "2017-10-16 00:00:00.0", "benefitRunDate1": "2017-10-16 00:00:00.0", "benefitsProcessed": "Y", "days": "8", "inputDate": "2017-10-16 00:00:00.0", "company": "MCF", "payFrequency": "1", "cycleStatus": "1", "quickViewPayroll": "N", "psn": "1", "deductionGroups": "B" }] }, 
        { "paygroup": "ZE2", "description": "Laxmi Weekly Paygrou", "payCycleProcessingItems": [{ "year": "2018", "weekNumber": "04", "payrollNumber": "1", "quarter": "1", "payDate1": "2018-01-26 00:00:00.0", "periodStartDate1": "2017-10-07 00:00:00.0", "periodEndDate1": "2017-10-15 00:00:00.0", "periodStartDate2": "2017-10-07 00:00:00.0", "periodEndDate2": "2017-10-16 00:00:00.0", "benefitRunDate1": "2017-10-16 00:00:00.0", "benefitsProcessed": "Y", "days": "8", "inputDate": "2017-10-16 00:00:00.0", "company": "MCF", "payFrequency": "1", "cycleStatus": "1", "quickViewPayroll": "N", "psn": "1", "deductionGroups": "B" }] }, 
      ] 
    }] 
  };
  const payGroup = { 
    processingGroupName: 'PLGRP', 
    payGroup: { 
      payrollGroupCode: 'ZE5', 
      payrollYear: '2018', 
      payrollWeekNumber: '04', 
      payrollRunNumber: '1'
    }
  }
  beforeEach(() => {

    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
    /*
      set processing groups in store - 
        the action gets dispatched from the app component and it gets set in app effects
    */
    store.dispatch(new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS(data));
    /*
      set pay group in store - 
        the action gets dispatched from the app component 
        Sets selected paygroup from session storage or first available if entering from proc group then unsubscribes itself.
        Navigation handles paygroup changes after.
    */
    store.dispatch(new AppActions.SET_PAYGROUP(payGroup));
    
    fixture = TestBed.createComponent(ProcGroupDropdownComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();

  });

  it('should create and have data', () => {    
    store.select(fromRoot.app_getProcessingPayGroups).subscribe( (paygroups) => {
      expect(paygroups).toBeTruthy();
      expect(component).toBeTruthy();
    })
  });
  
  it('hoverSelection', () => {
    const pg = { payGroup: 'ZE2' };
    component.hoverSelection(pg);
    expect(component.selected).toBe(pg);
  });

  describe('toggleDropdown', () => {

    it('!event', () => {
      component.searchString = 'ZE5';
      component.toggleDropdown();
      expect(component.searchString).toBe('');
      expect(component.closed).toBeFalsy();
    });

    it('event', () => {
      component.toggleDropdown(true);
      expect(component.closed).toBeTruthy();
    });

  });

  let next = { "paygroup": "ZE2", "description": "Laxmi Weekly Paygrou", "payCycleProcessingItems": [{ "year": "2018", "weekNumber": "04", "payrollNumber": "1", "quarter": "1", "payDate1": "2018-01-26 00:00:00.0", "periodStartDate1": "2017-10-07 00:00:00.0", "periodEndDate1": "2017-10-15 00:00:00.0", "periodStartDate2": "2017-10-07 00:00:00.0", "periodEndDate2": "2017-10-16 00:00:00.0", "benefitRunDate1": "2017-10-16 00:00:00.0", "benefitsProcessed": "Y", "days": "8", "inputDate": "2017-10-16 00:00:00.0", "company": "MCF", "payFrequency": "1", "cycleStatus": "1", "quickViewPayroll": "N", "psn": "1", "deductionGroups": "B" }] };

  it('setCurrentPayGroup', () => {
    component.setCurrentPayGroup(next);
    expect(component.selected).toBe(next);
  });

  describe('iterate', () => {

    it('found', () => {
      component.currentPayGroup = payGroup;
      component.iterate(1);
      expect(component.selected.payGroup.payrollGroupCode).toBe(next.paygroup);
    });

    it('!found', () => {
      component.iterate(1);
      expect(component.forwardArrowDisabled).toBeTruthy();
    });

  });
  
  describe('setArrowDisabled', () => {

    it('only one paygroup', () => {
      component.payGroups = [{}];
      component.setArrowDisabled();
      expect(component.forwardArrowDisabled && component.backArrowDisabled).toBeTruthy();
    });

    it('back arrow disabled', () => {
      component.currentPayGroup = component.payGroups[0];
      component.setArrowDisabled();
      expect(component.backArrowDisabled).toBeTruthy();
    });

    it('forward arrow disabled', () => {
      component.currentPayGroup = component.payGroups[1];
      component.setArrowDisabled();
      expect(component.forwardArrowDisabled).toBeTruthy();
    });

  });

  describe('setSelected', () => {

    it('set selected during search', () => {
      component.searchString = 'ZE5';
      component.setSelectedDuringSearch();
      expect(component.selected).toBe(component.payGroups[1]);
    });

  });

  describe('keyNav', () => {

    it('40 Arrow Down', () => {
      component.searchString = 'ZE2';
      let e = {keyCode: 40};
      component.keyNav(e);
      expect(component.selected).toBe(component.payGroups[0]);
    });

    it('38 Arrow Up', () => {
      component.selected = component.payGroups[1];
      let e = { keyCode: 38 };
      component.keyNav(e);
      expect(component.selected).toBe(component.payGroups[0]);
    });

    it('13 Enter', () => {
      component.searchString = 'Z';
      component.selected = component.payGroups[0];
      let e = { keyCode: 13 };
      component.keyNav(e);
      expect(component.selected).toBe(component.payGroups[0]);
    });
    
  });

});
