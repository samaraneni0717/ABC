import { AppComponent } from './../../app.component';
import { SearchFilter } from './filters/search-filter.pipe';
import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../store/index';
import * as AppActions from '../../store/actions/app.actions';
import * as PayDataActions from '../../features/paydata-batches/store/actions/paydata-batches.actions';
import * as Constants from '../../constants/constants';
declare var Highcharts: any;

@Component({
  selector: 'app-proc-group-dropdown',
  templateUrl: './proc-group-dropdown.component.html',
  styleUrls: ['./proc-group-dropdown.component.scss'],
  providers: [SearchFilter]
})
export class ProcGroupDropdownComponent implements OnInit {
  forwardArrowDisabled: boolean;
  backArrowDisabled: boolean;
  payGroups: any;
  closed = true;
  selected: any;
  currentPayGroup: any;
  searchString: String;
  filteredList: any;

  constructor(
    private searchFilter: SearchFilter,
    private store: Store<fromRoot.State>
  ) { 
    
  }
  
  ngOnInit() {
    //getting groups from the store
    this.store.select(fromRoot.app_getProcessingPayGroups).subscribe( (data) => {
      this.payGroups = data.list;
    });
    //setting the currently selected group
    this.store.select(fromRoot.app_getPayGroup).subscribe((currentPayGroup: any) => {
      this.currentPayGroup = this.payGroups.filter( (pg: any) => pg.payGroup.payrollGroupCode === currentPayGroup)[0];
    });
    this.setArrowDisabled();
  }

  hoverSelection(payGroup: object){
    this.selected = payGroup;
  }

  toggleDropdown($event?: any){
    this.searchString = '';
    if($event){
      this.closed = $event;
    } else {
      this.closed = !this.closed;
    }
    this.selected = this.currentPayGroup; 
  }

  setCurrentPayGroup(payGroup: any){
    this.currentPayGroup = payGroup;
    this.toggleDropdown();
    this.setArrowDisabled();
    this.searchString = '';
    
    this.makeVerifyOutputCall(payGroup);
  }

  iterate(direction: number){
    const index = this.payGroups.indexOf(this.currentPayGroup) + direction;
    if (this.payGroups[index]) {
      this.setCurrentPayGroup(this.payGroups[index]);
    }
    this.setArrowDisabled();
  }

  resetArrows(){
    this.backArrowDisabled = false;
    this.forwardArrowDisabled = false;
  }

  setArrowDisabled(){

    this.resetArrows();
    if (this.payGroups.length === 1){
      this.backArrowDisabled = true;
      this.forwardArrowDisabled = true;
    }
    else if (this.payGroups.indexOf(this.currentPayGroup) === 0){
      this.backArrowDisabled = true;
    }
    else if (this.payGroups.indexOf(this.currentPayGroup) === (this.payGroups.length - 1)) {
      this.forwardArrowDisabled = true;
    } 
  }

  setSelectedDuringSearch(){
    this.selected = this.searchFilter.transform(this.payGroups, this.searchString)[0];
  }

  keyNav(e: any){
    const filteredGroups = this.searchFilter.transform(this.payGroups, this.searchString)
    const index = filteredGroups.indexOf(this.selected);
    switch(e.keyCode){
      case 40:
        /* istanbul ignore else */
        if(index < filteredGroups.length - 1 ){
          this.selected = filteredGroups[index + 1];
        }
        break;
      case 38:
        /* istanbul ignore else */
        if (index > 0) {
          this.selected = filteredGroups[index - 1];
        }
        break;
      case 13:
        /* istanbul ignore else */
        if(filteredGroups.length > 0){
          this.setCurrentPayGroup(this.selected);
        }
        break;
    }
  }

  makeVerifyOutputCall(payGroup: any){
    this.store.dispatch(new AppActions.RESET_STATE());
    this.store.dispatch(new PayDataActions.RESET_STATE());
    Highcharts.charts = [];
    this.store.dispatch(new AppActions.LOAD_PAYGROUP(Object.assign({}, payGroup)))
  }

}
