import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter',
  pure: true
})
export class SearchFilter implements PipeTransform {
  
  transform(payGroups: any[], searchString: any): any {

    if(!searchString){
      return payGroups;
    }
    searchString = searchString.toLowerCase();
    return payGroups.filter( pg => {
      return pg.payGroup.payrollGroupCode.toLowerCase().includes(searchString);
    });

  }
  
}