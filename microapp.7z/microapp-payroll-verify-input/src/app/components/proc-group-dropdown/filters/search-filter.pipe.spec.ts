import { SearchFilter } from './search-filter.pipe';

describe('Pipe: SearchFilter', () => {
  let pipe: SearchFilter;
  const payGroups = [
    {
      payGroup: {
        payrollGroupCode: 'KZ1'
      }
    }, {
      payGroup: {
        payrollGroupCode: 'GD2'
      }
    }, {
      payGroup: {
        payrollGroupCode: 'BL3'
      }
    }

  ]
  beforeEach(() => {
    pipe = new SearchFilter();
  });

  it('should return the filtered paygroup', () => {
    let filteredResults = pipe.transform(payGroups, 'KZ1');
    expect(filteredResults).toEqual([{payGroup: {payrollGroupCode: 'KZ1'}}]);
  });

  it('should return paygroups if no search string is provided', () => {
    let filteredResults = pipe.transform(payGroups, null);
    expect(filteredResults).toEqual(payGroups);
  });
 
});