import { SearchHighlight} from './search-highlight.pipe';

describe('Pipe: SearchHighlight', () => {
  let pipe: SearchHighlight;

  beforeEach(() => {
    pipe = new SearchHighlight();
  });

  it('should return a span containing the pattern that is matched to the input', () => {
    let filteredResult = pipe.transform('KZ1', 'K');
    expect(filteredResult).toEqual('<span class="match">K</span>Z1');
  });

});