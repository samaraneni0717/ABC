import { Pipe, PipeTransform, Input } from '@angular/core';

@Pipe({
  name: 'searchHighlight',
  pure: true
})
export class SearchHighlight implements PipeTransform {

  transform(input: any, filter: any): any {
      return input.replace(new RegExp(filter, 'gi'),
        '<span class="match">$&</span>');
  }

}