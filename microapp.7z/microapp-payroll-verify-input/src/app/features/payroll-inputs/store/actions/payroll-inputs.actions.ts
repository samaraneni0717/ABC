import { Action } from '@ngrx/store';

export const PAYROLL_INPUTS_ACTIONS = {
  
    
}
