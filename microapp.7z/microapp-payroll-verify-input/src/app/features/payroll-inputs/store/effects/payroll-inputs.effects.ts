import { AppService } from './../../../../services/app.service';
import { Action } from '@ngrx/store';
import { Effect, Actions, toPayload } from "@ngrx/effects";
import { Injectable } from "@angular/core";

@Injectable()
export class PayrollInputsEffects {
  
  constructor(
    private action$: Actions,
    private appService: AppService
  ) { }
  

}