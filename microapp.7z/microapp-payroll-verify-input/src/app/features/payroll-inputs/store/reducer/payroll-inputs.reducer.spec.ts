import { reducer } from './payroll-inputs.reducer';
import * as fromPayrollInputs from './payroll-inputs.reducer';

describe('Payroll Inputs reducer', () => {

  describe('default state', () => {
    it('should return default state', () => {
      const action = {} as any;
      const result = reducer(undefined, action);
      expect(result).toEqual(fromPayrollInputs.initialState);
    });
  });
});