import { DonutComponent } from './donut/donut.component';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { PayrollInputsRootComponent } from './payroll-inputs-root.component';
import { StoreModule, Store } from '@ngrx/store';
import { reducers, metaReducers } from './../../store/index';
import { ChartModule, BusyIndicatorComponent } from '@synerg/components';
import * as fromRoot from '../../store/index';

// describe('PayrollInputsRootComponent', () => {
//   let component: PayrollInputsRootComponent;
//   let fixture: ComponentFixture<PayrollInputsRootComponent>;
//   let store: Store<fromRoot.State>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PayrollInputsRootComponent, DonutComponent, BusyIndicatorComponent ],
//       imports: [ StoreModule.forRoot(reducers, { metaReducers }), ChartModule ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     store = TestBed.get(Store);
//     fixture = TestBed.createComponent(PayrollInputsRootComponent);
//     component = fixture.componentInstance;
//     spyOn(store, 'dispatch');
//     component.openSlideIn('TER');
//     fixture.detectChanges();
    
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should dispatch to the store', () => {
//     expect(store.dispatch).toHaveBeenCalled();
//   });

// });
