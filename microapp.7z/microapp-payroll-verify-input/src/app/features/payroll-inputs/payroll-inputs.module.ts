import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartModule } from '@synerg/components/chart';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { PayrollInputsRootComponent } from './payroll-inputs-root.component';
import { DonutComponent } from './donut/donut.component';

@NgModule({
  imports: [
    CommonModule,
    ChartModule,
    BusyIndicatorModule
  ],
  declarations: [
    PayrollInputsRootComponent,
    DonutComponent
  ],
  exports: [
    PayrollInputsRootComponent
  ],
  providers: [

  ]
})
export class PayrollInputsModule { }
