import { outputData } from './../../../store/reducer/app.reducer';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { DonutComponent } from './donut.component';
import { StoreModule, Store } from '@ngrx/store';
import { reducers, metaReducers } from './../../../store/index';
import { ChartModule } from '@synerg/components';
import * as fromRoot from '../../../store/index';
describe('DonutComponent', () => {
  let component: DonutComponent;
  let fixture: ComponentFixture<DonutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonutComponent ],
      imports: [ StoreModule.forRoot(reducers, { metaReducers }), ChartModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonutComponent);
    component = fixture.componentInstance
    component.outputData = {
      name: 'Workforce Changes',
      code: 'WFC',
      colors: [
        '#70032d',
        '#a40541',
        '#e70a5b',
        '#fd6fa5',
        '#ffa4cc'
      ],
      links: [
        {
          name: 'Terminations',
          code: 'TER',
          count: 4,
          status: 'R'
        }
      ],
      count: 4,
      data: [
        {
          name: 'Terminations',
          y: 4,
          code: 'TER'
        }
      ]
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should dispatch to the store', inject([Store], (store: Store<fromRoot.State>) => {
    spyOn(store, 'dispatch');
    component.openSlideIn('TER');
    expect(store.dispatch).toHaveBeenCalled();
  }));

  it('disable', () => {
    component.openSlideIn('TER');
    component.outputData.data[0].disabled = true;
    component.ngOnInit();
  });
});
