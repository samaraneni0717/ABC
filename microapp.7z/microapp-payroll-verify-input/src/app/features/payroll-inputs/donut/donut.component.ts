import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../store/index';
import * as AppActions from '../../../store/actions/app.actions';


@Component({
  selector: 'app-donut',
  templateUrl: './donut.component.html',
  styleUrls: ['./donut.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DonutComponent implements OnInit {
  
  chartData: any;
  paygroup: string;

  @Input()
  outputData:any;

  openSlideIn(code:string) {
    const params:any = {
      paygroup: this.paygroup,
      code: code,
      section: 'donuts'
    }
    this.store.dispatch(new AppActions.OPEN_SLIDE_IN(params));
  }
  
  constructor(private store: Store<fromRoot.State>) {
  }

  ngOnInit() {
    this.store.select(fromRoot.app_getPayGroup).subscribe( (paygroup) => {
      this.paygroup = paygroup;
    });
    const disabled = this.outputData.data[0].disabled;
    const self = this;
    this.chartData = {
      chart: {
        height: 400,
        plotBackgroundColor: null,
        plotBorderWidth: 0,
        plotShadow: false,
        type: 'pie',
        events: {
            load: function () {

                for (let i=0; i < this.series[0].data.length; i++) {
                    /* istanbul ignore else */
                    if (!disabled && !this.series[0].data[i].disableClick) {
                        this.series[0].data[i].graphic.attr({
                            cursor: 'pointer'
                        });
                    }
                }
            }
        }
        },
      colors: this.setColors(),
      credits: false,
      tooltip: {
        enabled: false
      },
      title: {
        verticalAlign: 'middle',
        text:'',
        floating: false,
        style: {
          color: '#000',
          fontWeight: '300',
          fontSize: '16px',
          display:'inline',
          transform: 'translateY(-25px)',
          '-webkit-transform': 'translateY(-25px)'
        }
      },
      plotOptions: {
        pie: {
          dataLabels: {
            enabled: false,
            formatter: /* istanbul ignore next */ function() {
              return this.y;
            },
            distance: -50,
            style: {
              fontWeight: 'bold',
              color: 'white'
            }
          },
        startAngle: -90,
        center: ['50%', '50%'],
        innerSize: '65%',
        size:'200px',
          point: {
            events: {
              mouseOver: /* istanbul ignore next */ function () {
                if(!this.disabled) {
                  if((this.y).toString().length > 6 || ((this.code === 'OTP' || this.code === 'OTH' || this.code === 'REG') && (this.y).toString().length > 4 && this.y.toString().indexOf('.') === -1)) {
                      this.series.chart.setTitle({
                          text: this.name + '<br>' + '<span style=\"font-size:20px\">' + this.count
                      });
                  } else {
                      this.series.chart.setTitle({
                          text: this.name + '<br>' + '<span style=\"font-size:28px\">' + this.count
                      });
                  }
                  /* For IE & EDGE */
                  (function () {
                    let text = document.getElementsByTagName('text');
                    if (text[0]) {
                      let transform = getComputedStyle(text[0]).getPropertyValue('transform');
                      text[0].setAttribute('transform', transform); 
                    }
                  })();
                }
               
              },
              mouseOut: /* istanbul ignore next */ function () {
                if(!this.disabled){
                  this.series.chart.setTitle({
                    text: ''
                  });
                }
              },
              click: /* istanbul ignore next */ function () {
                if (!this.disabled && !this.disableClick) {
                  self.openSlideIn(this.code);
                }
              }
            }
          }
        }
      },
      series: [{
        type: 'pie',
        name: 'Payroll Inputs',
        data: this.outputData.data.filter(section => section.count != 0),
        states: {
          hover: {
            enabled: disabled ? false : true,
          }
        }
      }]
    }
  }




 setColors(){
    let colors = [];
    this.outputData.data.forEach((obj, i) => {
      if(obj.count != 0){
        colors.push(this.outputData.colors[i]);
      }
      
    });
return colors;
}

}
