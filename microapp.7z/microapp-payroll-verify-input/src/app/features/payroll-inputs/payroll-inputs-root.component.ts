import {Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import {Observable} from 'rxjs/Observable';

import {Store} from '@ngrx/store';
import * as fromRoot from '../../store/index';
import * as AppActions from "../../store/actions/app.actions";

@Component({
    selector: 'app-payroll-inputs-root',
    templateUrl: './payroll-inputs-root.component.html',
    styleUrls: ['./payroll-inputs-root.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PayrollInputsRootComponent implements OnInit {

    outputData$: Observable<any>;
    donuts: any;
    paygroup: any;

    constructor(private store: Store<fromRoot.State>) {
    }

    ngOnInit() {
        this.outputData$ = this.store.select(fromRoot.app_getOutputData);
        this.store.select(fromRoot.app_getPayGroup).subscribe((paygroup) => {
            this.paygroup = paygroup;
        });
    }

    openSlideIn(code: string) {

        const params: any = {
            paygroup: this.paygroup,
            code: code,
            section: 'donuts'
        }
        this.store.dispatch(new AppActions.OPEN_SLIDE_IN(params));

    }
    /* istanbul ignore next */
    trackDonuts(index: number, donut: any) {
        return donut.name;
    }


}
