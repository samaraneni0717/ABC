import { Store, StoreModule } from '@ngrx/store';
import { metaReducers, reducers } from './../../store/index';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaydataBatchesRootComponent } from './paydata-batches-root.component';
import { TableModule, BusyIndicatorComponent } from '@synerg/components';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import * as PaydataActions from './store/actions/paydata-batches.actions';
import * as fromRoot from '../../store/index';

import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { WjGridFilterModule } from 'wijmo/wijmo.angular2.grid.filter';
import { WjCoreModule } from 'wijmo/wijmo.angular2.core';
import { WjChartModule } from 'wijmo/wijmo.angular2.chart';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

// describe('PaydataBatchesRootComponent', () => {
//   let component: PaydataBatchesRootComponent;
//   let fixture: ComponentFixture<PaydataBatchesRootComponent>;
//   let store: Store<fromRoot.State>
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       providers: [],
//       declarations: [ PaydataBatchesRootComponent, BusyIndicatorComponent ],
//       imports: [
//         TableModule,
//         StoreModule.forRoot(reducers, { metaReducers }),
//         BrowserAnimationsModule
//       ],
//       schemas: [CUSTOM_ELEMENTS_SCHEMA]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PaydataBatchesRootComponent);
//     component = fixture.componentInstance;
//     store = TestBed.get(Store);
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('if data is empty array', () => {
//     store.dispatch(new PaydataActions.SUCCESS_GET_PAYDATA_BATCHES({data: []}));
//     spyOn(store,'dispatch').and.callThrough();
//     store.select(fromRoot.paydataBatches_getPaydataBatchesData).subscribe( (data) => {
//       expect(data).toEqual([]);
//     });
//   });

//   it('if data exists', () => {
//     store.dispatch(new PaydataActions.SUCCESS_GET_PAYDATA_BATCHES(
//       {
//         data: [{ paygroup: "BL6", batchId: "JHGJ", restrictAccess: "N", status: "In Balance", retainBatch: "0" }]
//       }
//     ));
//     spyOn(store,'dispatch').and.callThrough();
//     store.select(fromRoot.paydataBatches_getPaydataBatchesData).subscribe((data) => {
//       expect(data[0]).toEqual({ batchId: "JHGJ", restrict: "No", status: "In Balance", retain: "No" });
//     });
//   });

// });
