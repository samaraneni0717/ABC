import { reducer } from './paydata-batches.reducer';
import * as fromApp from './paydata-batches.reducer';

// describe('PayDataAppReducer', () => {

//     it('default state', () => {
//         const action = {} as any;
//         const result = reducer(undefined, action);
//         expect(result).toEqual(fromApp.initialState);
//     });

//     describe('PAYDATA_BATCHES:SUCCESS_GET_PAYDATA_BATCHES', () => {
//         it('data', () => {
//             const payload = {
//                 data: [{ batchId: 1, status: 'test', restrictAccess: 'N', retainBatch: '0' }]
//             };
//             const action = { type: 'PAYDATA_BATCHES:SUCCESS_GET_PAYDATA_BATCHES', payload: payload };
//             const result = reducer(fromApp.initialState, action);
//             expect(result.paydataBatches[0]).toEqual({ batchId: 1, status: 'test', restrict: 'No', retain: 'No' });
//         });

//         it('restrict/retain', () => {
//             const payload = {
//                 data: [{ batchId: 1, status: 'test', restrictAccess: 'Y', retainBatch: '1' }]
//             };
//             const action = { type: 'PAYDATA_BATCHES:SUCCESS_GET_PAYDATA_BATCHES', payload: payload };
//             const result = reducer(fromApp.initialState, action);
//             expect(result.paydataBatches[0]).toEqual({ batchId: 1, status: 'test', restrict: 'Yes', retain: 'Yes' });
//         });

//         it('!data', () => {
//             const action = { type: 'PAYDATA_BATCHES:SUCCESS_GET_PAYDATA_BATCHES', payload: undefined }
//             const result = reducer(fromApp.initialState, action);
//             expect(result.paydataBatches).toEqual(undefined);
//         });
//     });

//     it('PAYDATA_BATCHES:RESET_STATE', () => {
//         const action = { type: 'PAYDATA_BATCHES:RESET_STATE'};
//         const result = reducer(fromApp.initialState, action);
//         expect(result).toEqual(fromApp.initialState);
//     }); 

//     it('PAYDATA_BATCHES:STOP_LOADING', () => {
//         const action = { type: 'PAYDATA_BATCHES:STOP_LOADING' };
//         const result = reducer(fromApp.initialState, action);
//         expect(result.isBatchesGridLoading).toBeFalsy();
//     }); 

//     it('exports', () => {
//         for (let key in fromApp) {
//             if (key !== 'reducer' && key !== 'newState') {
//                 let prop = fromApp[key];
//                 if (typeof prop !== 'object') {
//                     prop(fromApp.initialState);
//                 }
//             }
//         }
//     });

// });