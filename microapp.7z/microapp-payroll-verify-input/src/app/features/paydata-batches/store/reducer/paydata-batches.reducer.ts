import { PAYDATA_BATCHES_ACTIONS } from './../actions/paydata-batches.actions';
import { ActionWithPayload } from '../../../../model/action-with-payload.interface';

export interface State {
  paydataBatches: any;
  isBatchesGridLoading: boolean;
  isError: boolean;
  hasData: boolean;
}

export const initialState: State = {
    paydataBatches : null,
    isBatchesGridLoading: true,
    isError: false,
    hasData: false
}

export const newState = (state: State, newData: any) => Object.assign( {}, state, newData);

export function reducer(state = initialState, action: ActionWithPayload) {

  switch (action.type) {
      case PAYDATA_BATCHES_ACTIONS.SUCCESS_GET_PAYDATA_BATCHES:
          let pdeBatches = [];
          if (action.payload.data) {

              pdeBatches = action.payload.data.map((batch: any) => {
                return {
                    batchId: batch.batchId,
                    status: batch.status,
                    restrict: batch.restrictAccess === 'N' ? 'No' : 'Yes',
                    retain: batch.retainBatch === '0' ? 'No' : 'Yes'
                };
              });
          } 
          return newState(state, {paydataBatches: pdeBatches, isBatchesGridLoading: false});

      case PAYDATA_BATCHES_ACTIONS.RESET_STATE:
          return newState(state, initialState); 
          
      case PAYDATA_BATCHES_ACTIONS.STOP_LOADING:
          return newState(state, { isBatchesGridLoading: false }); 

      default:
      return state;

  }
}

export const paydataBatches = ((state: State) => state.paydataBatches);
export const isBatchesGridLoading = ((state: State) => state.isBatchesGridLoading);
export const isError = ((state: State) => state.isError);
export const hasData = ((state: State) => state.hasData);

