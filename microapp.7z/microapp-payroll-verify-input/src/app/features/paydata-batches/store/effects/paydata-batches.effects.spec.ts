import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Actions } from '@ngrx/effects';

import { hot, cold } from 'jasmine-marbles';
import { Observable } from 'rxjs/Observable';
import { empty } from 'rxjs/observable/empty';
import { of } from 'rxjs/observable/of';

import { AppService } from '../../../../services/app.service';
import * as fromEffects from './paydata-batches.effects';
import * as PDActions from '../actions/paydata-batches.actions';
import * as AppActions from '../../../../store/actions/app.actions';

export class TestActions extends Actions {
  constructor() {
    super(empty());
  }

  set stream(source: Observable<any>) {
    this.source = source;
  }
}

export function getActions() {
  return new TestActions();
}

// describe('PDB Effects', () => {
//   let actions$: TestActions;
//   let service: AppService;
//   let effects: fromEffects.PaydataBatchesEffects;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         HttpClientTestingModule
//       ],
//       declarations: [],
//       providers: [
//         AppService,
//         fromEffects.PaydataBatchesEffects,
//         { provide: Actions, useFactory: getActions },
//       ],
//     });
//     actions$ = TestBed.get(Actions);
//     effects = TestBed.get(fromEffects.PaydataBatchesEffects);
//     service = TestBed.get(AppService);
    
//   });

  // describe('getPaydataBatches$', () => {
  //   it('success', () => {
  //     spyOn(service, 'getPaydataBatches').and.returnValue(of({ data: 'data' }));
  //     const action = new PDActions.START_GET_PAYDATA_BATCHES(null);
  //     const success = new PDActions.SUCCESS_GET_PAYDATA_BATCHES({data: 'data'});
  //     const stop_loading = new PDActions.STOP_LOADING();
  //     const has_access = new AppActions.HAS_ACCESS(true);

  //     actions$.stream = hot('-a', { a: action });
  //     const expected = cold('-(bcd)', { b: has_access, c: success, d: stop_loading  });
  //     expect(effects.getPaydataBatches$).toBeObservable(expected);
  //   });

  //   it('failed call', () => {
  //     spyOn(service, 'getPaydataBatches').and.returnValue(Observable.throw(Error) );
  //     const action = new PDActions.START_GET_PAYDATA_BATCHES(null);
  //     const stop_loading = new PDActions.STOP_LOADING();
  //     const failed = new AppActions.PAY_DATA_CALL_FAILED();

  //     actions$.stream = hot('-a', { a: action });
  //     const expected = cold('-(bc)', { b: failed, c: stop_loading });
  //     expect(effects.getPaydataBatches$).toBeObservable(expected);
  //   });

  //   it('no access', () => {
  //     spyOn(service, 'getPaydataBatches').and.returnValue(of({errorCode: 102}));
  //     const action = new PDActions.START_GET_PAYDATA_BATCHES(null);
  //     const stop_loading = new PDActions.STOP_LOADING();
  //     const has_access = new AppActions.HAS_ACCESS(false);

  //     actions$.stream = hot('-a', { a: action });
  //     const expected = cold('-(bc)', { b: has_access, c: stop_loading });
  //     expect(effects.getPaydataBatches$).toBeObservable(expected);
  //   });

  // });

// });


