import { AppService } from './../../../../services/app.service';
import { Effect, Actions, toPayload } from "@ngrx/effects";
import { Injectable } from "@angular/core";
import * as PaydataAppActions from './../../../../features/paydata-batches/store/actions/paydata-batches.actions';
import { map, switchMap, mergeMap, catchError} from 'rxjs/operators';

@Injectable()
export class PaydataBatchesEffects {
  
  constructor(
    private action$: Actions,
    private appService: AppService
  ) { }

    @Effect() getPaydataBatches$ = this.action$
        .ofType(PaydataAppActions.PAYDATA_BATCHES_ACTIONS.START_GET_PAYDATA_BATCHES)
        .pipe(
            map(toPayload),
            switchMap((payload) => {
                return this.appService.getPaydataBatches(payload)
                    .pipe(
                        mergeMap((data: any) => {
                            return [
                                new PaydataAppActions.SUCCESS_GET_PAYDATA_BATCHES(data),
                                new PaydataAppActions.STOP_LOADING()
                            ];
                        }),
                        catchError((error) => {
                            console.log('paydata batches call failed -----> ', error);
                            return [
                                new PaydataAppActions.STOP_LOADING()
                            ];
                        })
                    )   
            })
        )
        
}
