import { Action } from '@ngrx/store';
import {OutputParams} from "../../../../model/output-params.interface";

export const PAYDATA_BATCHES_ACTIONS = {
    START_GET_PAYDATA_BATCHES: 'PAYDATA_BATCHES:START_GET_PAYDATA_BATCHES',
    SUCCESS_GET_PAYDATA_BATCHES: 'PAYDATA_BATCHES:SUCCESS_GET_PAYDATA_BATCHES',
    RESET_STATE: 'PAYDATA_BATCHES:RESET_STATE',
    STOP_LOADING: 'PAYDATA_BATCHES:STOP_LOADING'
}

export class START_GET_PAYDATA_BATCHES implements Action {
    readonly type = PAYDATA_BATCHES_ACTIONS.START_GET_PAYDATA_BATCHES;
    constructor(public payload: OutputParams) {}
}

export class SUCCESS_GET_PAYDATA_BATCHES implements Action {
    readonly type = PAYDATA_BATCHES_ACTIONS.SUCCESS_GET_PAYDATA_BATCHES;
    constructor(public payload: any) {}
}

export class RESET_STATE implements Action {
    readonly type = PAYDATA_BATCHES_ACTIONS.RESET_STATE;
}

export class STOP_LOADING implements Action {
    readonly type = PAYDATA_BATCHES_ACTIONS.STOP_LOADING;
}
