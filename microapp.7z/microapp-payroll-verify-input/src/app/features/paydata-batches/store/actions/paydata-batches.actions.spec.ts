import * as PDActions from './paydata-batches.actions';

describe('pay data actions', () => {
  it('verify actions', () => {
    for (let key in PDActions.PAYDATA_BATCHES_ACTIONS) {
      let action = new PDActions[key]();
      expect(action.type).toEqual(PDActions.PAYDATA_BATCHES_ACTIONS[key]);
    }
  });
  
});