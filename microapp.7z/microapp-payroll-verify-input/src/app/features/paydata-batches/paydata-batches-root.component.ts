import { Component, OnInit, Input, OnDestroy, ViewChild } from '@angular/core';
import {Store} from "@ngrx/store";
import * as fromRoot from "../../store";
import { Observable } from 'rxjs/Observable';
import * as PayDataActions from './store/actions/paydata-batches.actions';

import * as wjcCore from 'wijmo/wijmo';
import * as wjcGrid from 'wijmo/wijmo.grid';
//import * as wjcGridFilter from 'wijmo/wijmo.grid.filter';

declare var dijit: any;

@Component({
  selector: 'app-paydata-batches-root',
  templateUrl: './paydata-batches-root.component.html',
  styleUrls: ['./paydata-batches-root.component.scss']
})
export class PaydataBatchesRootComponent implements OnInit, OnDestroy {

    headers: any;
    data: wjcCore.CollectionView;
    columnsAvailable: wjcCore.CollectionView;
    columns: wjcCore.CollectionView;
    @ViewChild('pdeFlex') pdeFlex: wjcGrid.FlexGrid;
    //@ViewChild('filter') filter: wjcGridFilter.FlexGridFilter;
    isBatchesGridLoading$: Observable<any>;
    paygroup: string;
    hasAccess$: Observable<any>;
    storeSubscription$: any;
    batchesSubscription$: any;

    constructor(
        private store: Store<fromRoot.State>
    ) {
    }

    ngOnInit() {
        let grid: any = document.getElementsByTagName('wj-flex-grid')[0];
        this.isBatchesGridLoading$ = this.store.select(fromRoot.paydataBatches_getIsBatchesGridLoading);
        this.store.select(fromRoot.app_getPayGroup).subscribe( (paygroup) => {
            this.paygroup = paygroup;
        });
        this.hasAccess$ = this.store.select(fromRoot.app_hasAccess);

        this.batchesSubscription$ = this.store.select(fromRoot.paydataBatches_getPaydataBatchesData).subscribe((data: any) => {
           
            if (data && data.length < 1) {
                grid.style.height = '75px';
            }

            this.headers = {
                batchId: 'Batch ID',
                status: 'Status',
                restrict: 'Restrict',
                retain: 'Retain'
            };

            let fields = new wjcCore.ObservableArray();
            for (let key in this.headers) {
                fields.push(key);
            }

            fields.forEach((field, i) => {
                fields[i] = {
                    'binding': field,
                    'header': this.headers[field],
                    'align': 'left',
                    'visible': true
                }
            });

            this.columns = new wjcCore.CollectionView(fields);
            this.data = new wjcCore.CollectionView(data);
            this.data.sortDescriptions.push(new wjcCore.SortDescription('batchId', true));
            this.data.moveCurrentToPosition(-1);

        });
        
        
    }

    /* istanbul ignore next */
    sortingColumn(event: any, data: any) {
        data.currentPosition = -1;
    } 

    /* istanbul ignore next */
    initialized(sender: wjcGrid.FlexGrid, event: any) {
        // this.filter.filterChanging.addHandler(function (s, e) {
        //     s.grid.itemsSource.currentPosition  = -1;
        // });
    }

    /* istanbul ignore next */
    goToPayDataEntry() {
        if (dijit) {
            const appContainer = dijit.byId('appContainer');
            appContainer.gotoSimplePortlet('Pay Data Entry', '/payroll/hrii/payroll/admin/paydataentry/payGroupList.faces');
            }
    }

    ngOnDestroy(){
        //cleaning up observable subscription
        /* istanbul ignore else */
        if(this.batchesSubscription$){
            this.batchesSubscription$.unsubscribe();
        }
    }


}


// Commenting the code until we figure out solution to go to batch details page
                /*this.dataset = this.dataset.map((row: any) => {
                        row[0] = {
                            component: LinkTemplateComponent,
                            inputs: { label: row[0].value },
                            outputs: {
                                click: ($event: Event) => {
                                    $event.stopPropagation();
                                    console.log('test verified');
                                    if(dijit) {
                                        const payData = {payGroup: this.paygroup, batchId: row[0].inputs.label};
                                        sessionStorage.setItem('verifyInput_payDataEntry', JSON.stringify(payData));

                                        //dijit.byId('verifyInputSlideIn').onCancel();
                                        const appContainer = dijit.byId('appContainer');
                                        appContainer.gotoSimplePortlet('Pay Data Entry', '/payroll/hrii/payroll/admin/paydataentry/payGroupList.faces');
                                    console.log('code updated');
                                    }
                                    //this.store.dispatch()

                            //         const params: any = {
                            //             name: 'Pay Data Batches',
                            //             componentId: 'paydatabatches',
                            //             size : 'md',
                            //             type : 'warning',
                            //             paygroup: 'GD2',
                            //             employeeId:'800838',
                            //             fileNumber: '400838'
                            //           };
                            //    this.store.dispatch(new AppActions.OPEN_MODAL(params));
                                }
                            }
                        };
                    return row;
                });*/