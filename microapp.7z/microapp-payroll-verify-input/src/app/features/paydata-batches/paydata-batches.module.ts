import { AppService } from './../../services/app.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaydataBatchesRootComponent } from './paydata-batches-root.component';
import { TableModule, BusyIndicatorModule } from '@synerg/components';
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { WjGridFilterModule } from 'wijmo/wijmo.angular2.grid.filter';
import { WjCoreModule } from 'wijmo/wijmo.angular2.core';

@NgModule({
  imports: [
    CommonModule,
    TableModule,
    BusyIndicatorModule,
    WjGridModule,
    WjGridFilterModule,
    WjCoreModule
  ],
  declarations: [
    PaydataBatchesRootComponent
  ],
  exports: [
    PaydataBatchesRootComponent
  ],
  providers: [
    AppService
  ]
})
export class PaydataBatchesModule { }
