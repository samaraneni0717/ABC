import { DetailParams } from './../../../model/detail-params.interface';
import { MiniTile } from './../../../model/mini-tile.interface';
import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../store/index';
import * as AppActions from '../../../store/actions/app.actions';

@Component({
  selector: 'app-mini-tile',
  templateUrl: './mini-tile.component.html',
  styleUrls: ['./mini-tile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MiniTileComponent implements OnInit {
  paygroup: string;
  constructor(
    private store: Store<fromRoot.State>
  ) {}

  ngOnInit() {
    this.store.select(fromRoot.app_getPayGroup).subscribe( (paygroup) => {
      this.paygroup = paygroup;
    });
  }

  openSlideIn(tile:any){
    const params: DetailParams = {
      paygroup: this.paygroup,
      code: tile.code,
      section: 'MiniTile'
    }
    this.store.dispatch(new AppActions.OPEN_SLIDE_IN(params));
  }

  trackTile(index, tile) {
    return (!tile.status && !tile.errorCode) ? undefined : tile;
  }
  
  @Input()
  miniTiles: Array<MiniTile>;

}