import { reducers, metaReducers } from './../../../store/index';
import { BusyIndicatorComponent, PopoverComponent, PopoverModule, BusyIndicatorModule } from '@synerg/components';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { MiniTileComponent } from './mini-tile.component';
import { StoreModule, Store } from '@ngrx/store';
import * as fromRoot from '../../../store/index';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('MiniTileComponent', () => {
  let component: MiniTileComponent;
  let fixture: ComponentFixture<MiniTileComponent>;
  let store: Store<fromRoot.State>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot(reducers, { metaReducers }), BusyIndicatorModule, PopoverModule],
      declarations: [ MiniTileComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiniTileComponent);
    component = fixture.componentInstance;
    store = TestBed.get(Store);
    component.miniTiles = [{
      code: 'ITC',
      count: 1,
      status: 'R'
    }];
    spyOn(store, 'dispatch');
    component.openSlideIn('ITC');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should dispatch to the store w/ track Tile returning tile', () => {
    expect(store.dispatch).toHaveBeenCalled();
  });

  it('should dispatch to the store w/ track Tile returning undefined', () => {
    component.trackTile(0, '');
    expect(store.dispatch).toHaveBeenCalled();
  });

});
