import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../store/index';

@Component({
  selector: 'app-needs-review-root',
  templateUrl: './needs-review-root.component.html',
  styleUrls: ['./needs-review-root.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NeedsReviewRootComponent implements OnInit {

  outputData$: Observable<any>;
  constructor(
    private store: Store<fromRoot.State>
  ) {}
  
  ngOnInit() {
    this.outputData$ = this.store.select(fromRoot.app_getOutputData);
  }

}
