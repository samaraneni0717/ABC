import { BusyIndicatorModule, PopoverModule} from '@synerg/components';
import { AppService } from './../../services/app.service';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NeedsReviewRootComponent } from './needs-review-root.component';
import { MiniTileComponent } from './mini-tile/mini-tile.component';

@NgModule({
  imports: [
    CommonModule,
    BusyIndicatorModule,
    PopoverModule
  ],
  declarations: [
    NeedsReviewRootComponent,
    MiniTileComponent
  ],
  exports: [
    NeedsReviewRootComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    AppService
  ]
})
export class NeedsReviewModule { }
