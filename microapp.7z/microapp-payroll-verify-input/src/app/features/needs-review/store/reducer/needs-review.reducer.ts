import { NEEDS_REVIEW_ACTIONS } from '../actions/needs-review.actions'
import { ActionWithPayload } from '../../../../model/action-with-payload.interface';

export interface State {
  
}

export const initialState: State = {
 
}
/* istanbul ignore next */
export const newState = (state: State, newData: any) => Object.assign( {}, state, newData);

export function reducer(state = initialState, action: ActionWithPayload) {

  switch(action.type) {
    
    default:
      return state;

  }
}
