import { metaReducers, reducers } from './../../store/index';
import { MiniTileComponent } from './mini-tile/mini-tile.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NeedsReviewRootComponent } from './needs-review-root.component';
import { BusyIndicatorComponent, PopoverComponent, BusyIndicatorModule, PopoverModule } from '@synerg/components';
import { Store, StoreModule } from '@ngrx/store';
import * as fromRoot from '../../store/index'
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('NeedsReviewRootComponent', () => {
  let component: NeedsReviewRootComponent;
  let fixture: ComponentFixture<NeedsReviewRootComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot(reducers, { metaReducers }), BusyIndicatorModule, PopoverModule],
      declarations: [ NeedsReviewRootComponent, MiniTileComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NeedsReviewRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('outputData should be available', () => {
    component.outputData$.subscribe( (data) => {
      expect(data).toBeDefined();
    });
  });

});
