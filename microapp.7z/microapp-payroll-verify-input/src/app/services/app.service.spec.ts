import { of } from 'rxjs/observable/of';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpParams, HttpRequest } from '@angular/common/http';
import { TestBed, inject, async, getTestBed } from '@angular/core/testing';
import { AppService, endpoints } from './app.service';

// describe('AppService', () => {

//   let service: AppService;
//   let httpMock: HttpTestingController;
//   let injector: TestBed;
//   let http: HttpClient;
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule],
//       providers: [AppService]
//     });
//     injector = getTestBed();
//     service = injector.get(AppService);
//     httpMock = injector.get(HttpTestingController);
//     http = injector.get(HttpClient);
//     const testData = [
//       { test: 'testData' }
//     ];
//     spyOn(http, 'get').and.returnValue(of(testData));
//   });
  
//   it('toHttpParams', () => {
//     let params = service.toHttpParams({test: 'test param'});
//     expect(params.toString()).toBe('test=test%20param');
//   });

//   it('verifyOutput', () => {
//     service.getVerifyOutput({paygroup: 'KZ2'}).subscribe( (data) => {
//       expect(data).toBeDefined();
//     });
//     const request = httpMock.match(req => req.method === 'GET' && req.url === endpoints.verifyOutput);
//   });

//   it('getDetails', () => {
//     service.getDetails({ paygroup: 'KZ2' }).subscribe((data) => {
//       expect(data).toBeDefined();
//     });
//     const request = httpMock.match(req => req.method === 'GET' && req.url === endpoints.details);
//   });

//   it('getPaydataBatches', () => {
//     service.getPaydataBatches({ paygroup: 'KZ2' }).subscribe((data) => {
//       expect(data).toBeDefined();
//     });
//     const request = httpMock.match(req => req.method === 'GET' && req.url === endpoints.paydataBatches);
//   });

//   it('employeeDetails', () => {
//     service.getEmployeeDetails({ paygroup: 'KZ2' }).subscribe((data) => {
//       expect(data).toBeDefined();
//     });
//     const request = httpMock.match(req => req.method === 'GET' && req.url === endpoints.employeedetails);
//   });

//   it('benefitGroups', () => {
//     service.getBenefitGroups({ company: 'NET', paygroup: 'KZ2' }).subscribe((data) => {
//       expect(data).toBeDefined();
//     });
//     const request = httpMock.match(req => req.method === 'GET' && req.url === endpoints.benefitGroups);
//   });

//   it('processingPayGroups', () => {
//     service.getProcessingPayGroups({procGroup: 'Test'}).subscribe((data) => {
//       expect(data).toBeDefined();
//     });
//     const request = httpMock.match(req => req.method === 'GET' && req.url === endpoints.processingPayGroups);
//   });

// });
