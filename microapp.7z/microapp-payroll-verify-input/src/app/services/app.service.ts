import { OutputParams } from './../model/output-params.interface';
import { ProcGroupParams } from './../model/proc-group-params.interface';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

export const endpoints = {
  verifyOutput: '/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/dashboard',
  details: '/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/details',
  exportdetails: '/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/exportdetails',
  paydataBatches: '/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/paydatabatches',
  employeedetails:'/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/employeedetails',
  benefitGroups: '/payroll/controller/companyControl/payroll/v1/pay-group',
  processingPayGroups: '/payrolldashboard/hrcore/payroll/v1/payroll-dashboard/payroll-groups',
  permissions: '/smicro/microapi-payroll-verify-input/1/vantage/verifyinput/accessflags',
  mockProcessingPayGroups: '/procpaygroups',
  mockBenefitGroups: '/benefitgroups',
  mockOutput: '/output',
  mockDetails: '/details',
  mockpaydataBatches: '/paydatabatches',
  mockPermissions: '/permissions'
} 

let httpHeaders = new HttpHeaders();
httpHeaders = httpHeaders.set('Content-Type', 'application/json');


@Injectable()
export class AppService {

  constructor(
    private http: HttpClient
  ) { }

  toHttpParams(params: object): HttpParams{
    return Object.getOwnPropertyNames(params)
      .reduce((p, key) => p.set(key, params[key]), new HttpParams());
  }

  getProcessingPayGroups(params: ProcGroupParams) {
    const date = new Date();
    let options = {
      headers: httpHeaders,
      params: this.toHttpParams(params)
    }
    return this.http.get(endpoints.processingPayGroups + '?' + date.getTime(), options)
      .map((res) => {
        return res;
      });

  }

  getVerifyOutput(params?: OutputParams){
    const date = new Date();
    let options = {
        headers: httpHeaders,
        params: this.toHttpParams(params)
    }
    
    return this.http.get(endpoints.verifyOutput + '?' + date.getTime(), options)
      .map( (res) => {
        return res;
      });
    
  }

  getDetails(params?: any) {
    const date = new Date();
    let options = {
      headers: httpHeaders,
      params: this.toHttpParams(params)
    }
   
    return this.http.get(endpoints.details + '?' + date.getTime(), options)
      .map((res) => {
        return res;
      });

  }

  getBenefitGroups(params?: any) {
    let options = {
      headers: httpHeaders
    }
        
    return this.http.get(
      endpoints.benefitGroups 
        + '?$filter=company+eq+' + "'" + params.company + "'" 
      + '&$filter=group+eq+' + "'" + params.paygroup.replace(/&/g, '%26') + "'"
      , options).map((res) => {
      return res;
    });
  }

  getPaydataBatches(params?: OutputParams) {
    const date = new Date();
    const options = {
        headers: httpHeaders,
        params: this.toHttpParams(params)
    }

    return this.http.get(endpoints.paydataBatches + '?' + date.getTime(), options)
        .map((res) => {
            return res;
        });
  }

  getEmployeeDetails(params?: OutputParams) {
    const date = new Date();
    const options = {
        headers: httpHeaders,
        params: this.toHttpParams(params)
    }

    return this.http.get(endpoints.employeedetails + '?' + date.getTime(), options)
        .map((res) => {
            return res;
        });
  }

  getPermissions(params?: any) {
    const date = new Date();
    let options = {
      headers: httpHeaders,
      params: this.toHttpParams(params)
    }

    return this.http.get(endpoints.permissions + '?' + date.getTime(), options)
      .map((res) => {
        return res;
      });
  }

}
