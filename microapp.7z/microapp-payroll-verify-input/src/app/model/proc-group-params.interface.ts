export interface ProcGroupParams {
  procGroup: string;
}