export interface TableGrid {
  headers: Array<string>;
  tableData: Array<Array<string>>;

}