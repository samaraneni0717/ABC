export interface MiniTile {
  code: string;
  count: number;
  status: string;
}