export interface DetailParams {
  code: string;
  paygroup: string;
  section: string;
}