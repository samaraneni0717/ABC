export interface Header {
  type: string;
  payGroup: {
    payrollGroupCode: string;
    payrollYear: string;
    payrollWeekNumber: string;
    payrollRunNumber: string
  };
  processingGroupName: string;
  description: string;
  quarter: string;
  payDate: string;
  periodStartDate1: string;
  periodEndDate1: string;
  periodStartDate2: string;
  periodEndDate2: string;
  benefitsDeductionReady: string;
}