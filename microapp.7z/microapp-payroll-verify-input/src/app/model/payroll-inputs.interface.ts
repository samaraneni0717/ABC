export interface Donuts {
    name: string;
    code: string;
    colors: Array<string>;
    errorCode?: string;
    links: [{
        name: string,
        code: string,
        count: number,
        status: string
    }];
    status: string;
    count: number;
    data: Array<object>;
    order: number;
}