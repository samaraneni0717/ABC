export interface OutputParams{
  paygroup: string;
  miniTilesOnly?: boolean;
  donutsOnly?: boolean;
}