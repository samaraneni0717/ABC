/**
 * This is the main file that will aggregate your stores
 * Make sure you have installed the required dependencies
 *  npm install --save @ngrx/{store} reselect ngrx-store-freeze
 */

// Import each of your stores using the convention:
//      import * as from[STORE_NAME] from './STORE_NAME.store';
// NOTE: this is the "old way" from ngrx 2. 
// This could be done as a "Feature" see https://github.com/ngrx/platform/blob/master/docs/store/api.md#feature-module-state-composition
import * as fromApp from './reducer/app.reducer';
import * as fromNeedsReview from '../features/needs-review/store/reducer/needs-review.reducer';
import * as fromPaydataBatches from '../features/paydata-batches/store/reducer/paydata-batches.reducer';
import * as fromPayrollInputs from '../features/payroll-inputs/store/reducer/payroll-inputs.reducer';

import { ActionReducer, ActionReducerMap, combineReducers, compose, MetaReducer } from '@ngrx/store';
import { environment } from '../../environments/environment.dev';
import { storeFreeze } from 'ngrx-store-freeze';
import { createSelector } from 'reselect';

// Aggregate all of the individual states into one main state
// this State should have a property for each of you child states
export interface State {
  app: fromApp.State,
  needsReview: fromNeedsReview.State,
  paydataBatches: fromPaydataBatches.State,
  payrollInputs: fromPayrollInputs.State
}

// Aggregate all of the reducers in a similar way
export const reducers: ActionReducerMap<State> = {
  app: fromApp.reducer,
  needsReview: fromNeedsReview.reducer,
  paydataBatches: fromPaydataBatches.reducer,
  payrollInputs: fromPayrollInputs.reducer
}
// Adding the storeFreeze is useful in development because it will cause an exception to be thrown
// if you accidentally mutate the state
/* istanbul ignore next */
export const metaReducers: MetaReducer<State>[] = !environment.production
? [storeFreeze]
: [];

// We will expose a function for getting each state out of our aggregate state

// We will expose the selectors from each of the states by creating a nested selector
// using the functions exposed in each store.


// APP
export const getAppState = (state: State) => state.app;
export const app_getOutputData = createSelector(getAppState, fromApp.outputData);
export const app_getHeaderData = createSelector(getAppState, fromApp.headerData);
export const app_getPayGroup = createSelector(getAppState, fromApp.paygroup);
export const app_getSessionData = createSelector(getAppState, fromApp.sessionData);
export const app_getSlideInData = createSelector(getAppState, fromApp.slideInData);
export const app_getIsGridLoading = createSelector(getAppState, fromApp.isGridLoading);
export const app_getIsModalLoading = createSelector(getAppState, fromApp.isModalLoading);
export const app_getModalData = createSelector(getAppState, fromApp.modalData);
export const app_getKillInitialOutputInterval = createSelector(getAppState, fromApp.killInitialOutputInterval);
export const app_getKillMiniTilesOnly = createSelector(getAppState, fromApp.killMiniTilesOnly);
export const app_getKillDonutsOnly = createSelector(getAppState, fromApp.killDonutsOnly);
export const app_isLandingPageLoading = createSelector(getAppState, fromApp.isLandingPageLoading);
export const app_isSlideInOpen = createSelector(getAppState, fromApp.isSlideInOpen);
export const app_isProcGroupDropdownEnabled = createSelector(getAppState, fromApp.isProcGroupDropdownEnabled);
export const app_isProcGroupDropdownReady = createSelector(getAppState, fromApp.isProcGroupDropdownReady);
export const app_isProcGroupDropdownError = createSelector(getAppState, fromApp.isProcGroupDropdownError);
export const app_getProcessingPayGroups = createSelector(getAppState, fromApp.processingPayGroups);
export const app_isBenefitsCheckComplete = createSelector(getAppState, fromApp.isBenefitsCheckComplete);
export const app_loadPayGroup = createSelector(getAppState, fromApp.loadPayGroup);
export const app_hasAccess = createSelector(getAppState, fromApp.hasAccess);
export const app_isPermissionCallError = createSelector(getAppState, fromApp.isPermissionCallError);
export const app_getLimit = createSelector(getAppState, fromApp.getLimit);
export const app_exportExcelStart = createSelector(getAppState, fromApp.exportExcelStart);
export const app_exportExcelComplete = createSelector(getAppState, fromApp.exportExcelComplete);
export const app_exportExcelError = createSelector(getAppState, fromApp.exportExcelError);

// NEEDS-REVIEW
/* istanbul ignore next */
export const getNeedsReviewState = (state: State) => state.needsReview;

// PAYDATA-BATCHES
export const getPaydataBatchesState = (state: State) => state.paydataBatches;
export const paydataBatches_getPaydataBatchesData = createSelector(getPaydataBatchesState, fromPaydataBatches.paydataBatches);
export const paydataBatches_getIsBatchesGridLoading = createSelector(getPaydataBatchesState, fromPaydataBatches.isBatchesGridLoading);
export const paydataBatches_getIsError = createSelector(getPaydataBatchesState, fromPaydataBatches.isError);
export const paydataBatches_getHasData = createSelector(getPaydataBatchesState, fromPaydataBatches.hasData);

// PAYROLL-INPUTS
/* istanbul ignore next */
export const getPayrollInputs = (state: State) => state.payrollInputs;
