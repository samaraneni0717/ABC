import { ModalComponent } from './../../components/modal/modal.component';
import { VanModalService, VanSlideinService, VanModalOptions } from '@van-genesis/van-genesis';
import { SlideinComponent } from './../../components/slidein/slidein.component';
import * as AppActions from './../actions/app.actions';
import { AppService } from './../../services/app.service';
import { Store } from '@ngrx/store';
import { Effect, Actions, toPayload } from "@ngrx/effects";
import { Injectable } from "@angular/core";
import * as Constants from '../../constants/constants'
import * as fromRoot from '../../store/index';
import { AccessFilter } from '../../filters/access-filter.pipe';
import { map, mergeMap, retry, catchError, withLatestFrom, switchMap, tap } from 'rxjs/operators';

const slideInOptions = new VanModalOptions(true, false,'default','xl',true);
const modalOptions = new VanModalOptions(true, false, undefined, undefined, true);
let error: number = 0;
declare var document: any;
@Injectable()
export class AppEffects {
  constructor(
    private action$: Actions,
    private AppService: AppService,
    private slideinService: VanSlideinService,
    private modalService: VanModalService,
    private store: Store<fromRoot.State>,
    private accessFilter: AccessFilter
  ) {
  }

  @Effect() getProcessingGroups$ = this.action$
    .ofType(AppActions.APP_ACTIONS.START_GET_PROCESSING_PAY_GROUPS)
    .pipe(
      map(toPayload),
      mergeMap((payload) => {
      return this.AppService.getProcessingPayGroups({ procGroup: payload.processingGroupName })
        .pipe(
          mergeMap((data: any) => {
            /* istanbul ignore next */
            if (data.errorCode) {
              console.log('proc group call failed -----> ', data.messages[0].message);
              return [ 
                new AppActions.PROC_GROUP_DROPDOWN_CALL_FAILED() 
              ];
            }
            return [
              new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS(data),
              new AppActions.PROC_GROUP_DROPDOWN_READY(true)
            ]
          }),
          retry(2),
          catchError((error) => {
            /* istanbul ignore next */
            console.log('proc group call failed -----> ', error);
            /* istanbul ignore next */
            return [
              new AppActions.SET_HEADER_DATA({ sessionData: payload, benefitGroups: undefined }),
              new AppActions.BENEFITS_CHECK_COMPLETE(),
              new AppActions.PROC_GROUP_DROPDOWN_CALL_FAILED()
            ]
          })
        )
      })
    )
    

  @Effect() startSetInitialState$ = this.action$
    .ofType(AppActions.APP_ACTIONS.START_SET_INITIAL_STATE)
    .pipe(
      map(toPayload),
      withLatestFrom(this.store.select(fromRoot.app_hasAccess)),
      mergeMap(([payload, hasAccess]) => {

        payload = this.accessFilter.transform(payload, hasAccess);

        return [
          new AppActions.SET_INITIAL_STATE(payload),
        ]
      })
    )
    

  @Effect() getVerifyOutput$ = this.action$
    .ofType(AppActions.APP_ACTIONS.START_GET_VERIFY_OUTPUT)
    .pipe(
      map(toPayload),
      withLatestFrom(this.store.select(fromRoot.app_hasAccess)),
      mergeMap(([payload, hasAccess]) => {
        return this.AppService.getVerifyOutput(payload)
          .pipe(
            mergeMap((data: any) => {
              /* istanbul ignore next */

              if (data.errorCode) {
                console.log('initialOutput call failed -----> ', data.messages[0].message);
              } else {
                data = this.accessFilter.transform(data, hasAccess);
              }
              if (payload.miniTilesOnly) {
                return [
                  new AppActions.SUCCESS_MINI_TILES_ONLY(data),
                ]
              }
              if (payload.donutsOnly) {
                return [
                  new AppActions.SUCCESS_DONUTS_ONLY(data),
                ]
              }
              return [
                new AppActions.SUCCESS_GET_VERIFY_OUTPUT(data),
              ]
            }),
            retry(2),
            catchError((error) => {
              /* istanbul ignore next */
              console.log('call failed -----> ', error);
              /* istanbul ignore next */
              return [
                new AppActions.OUTPUT_CALL_FAILED()
              ]
            })  
          )
      })
    )

  @Effect() openSlideIn$ = this.action$
    .ofType(AppActions.APP_ACTIONS.OPEN_SLIDE_IN)
    .pipe(
      tap(() => this.store.dispatch(new AppActions.START_GRID_LOADING())),
      map(toPayload),
      switchMap((payload) => {
        let headerInfo = {};
        if (payload.section === 'MiniTile') {
          headerInfo['title'] = Constants.Details[payload.code].title || Constants.MiniTileSections[payload.code].name;
        } else {
          headerInfo['title'] = Constants.Details[payload.code].title || Constants.PayrollInputCodes[payload.code];
        }
        headerInfo['instruction'] = Constants.Details[payload.code].instruction;
        headerInfo['componentId'] = Constants.Details[payload.code].componentId;
        this.slideinService
          .open(SlideinComponent, headerInfo, slideInOptions).then(() => {
          })
          .catch(/* istanbul ignore next */() => {

            // scroll bar issue fix 
            if (document.getElementsByClassName('revolution')[0]) {
              document.getElementsByClassName('revolution')[0].style.overflow = 'hidden';
            }
            this.store.dispatch(new AppActions.SLIDE_IN_CLOSED());
          });

        const finalPayload = { paygroup: payload.paygroup, code: payload.code };

        return this.AppService.getDetails(finalPayload)
          .pipe(
            mergeMap((data: any) => {
              const slideInData = {
                data: data,
                code: payload.code
              }
              return [
                new AppActions.SET_SLIDE_IN_DATA(slideInData),
                new AppActions.STOP_GRID_LOADING()
              ]
            }),
            retry(2),
            catchError((error) => {
              //error actions go here
              /* istanbul ignore next */
              return [
                new AppActions.STOP_GRID_LOADING()
              ];
            })
          )
      })
    )
    
    @Effect() openModal$ = this.action$
    .ofType(AppActions.APP_ACTIONS.OPEN_MODAL)
    .pipe(
      tap(() => this.store.dispatch(new AppActions.START_MODAL_LOADING())),
      map(toPayload),
      switchMap((payload) => {

        let headerInfo = {};

        headerInfo['name'] = payload.name;
        headerInfo['componentId'] = payload.componentId;
        headerInfo['size'] = payload.size;
        headerInfo['type'] = payload.type;
        this.modalService
          .open(ModalComponent, headerInfo, modalOptions).then(() => { }).catch(() => { });

        const finalPayload = {
          paygroup: payload.paygroup, employeeId: payload.employeeId,
          fileNumber: payload.fileNumber, employeeRecordNumber: payload.employeeRecordNumber
        };

        return this.AppService.getEmployeeDetails(finalPayload)
          .pipe(
            mergeMap((data: any) => {
              return [
                new AppActions.SET_MODAL_DATA(data),
                new AppActions.STOP_MODAL_LOADING()
              ];
            }),
            retry(2),
            catchError((error) => {
              //error actions go here
              /* istanbul ignore next */
              return [
                new AppActions.STOP_MODAL_LOADING()
              ];
            })
          )
      })
    )

  @Effect() getBenefitGroups$ = this.action$
    .ofType(AppActions.APP_ACTIONS.START_GET_HEADER_DATA)
    .pipe(
      map(toPayload),
      switchMap((payload) => {
        const passThrough = [
          new AppActions.SET_HEADER_DATA({ sessionData: payload, benefitGroups: undefined }),
          new AppActions.BENEFITS_CHECK_COMPLETE()
        ];
        //if deductions in session storage are not empty making call for benefit groups
        if (payload.deductionGroups && payload.deductionGroups.trim().length > 0) {
          const params = { company: payload.company, paygroup: payload.payGroup.payrollGroupCode };
          return this.AppService.getBenefitGroups(params)
            .pipe(
              mergeMap((data: any) => {
                let finalPayload = {
                  sessionData: payload,
                  benefitGroups: data.hwseDeductionGroups
                }
                return [
                  new AppActions.SET_HEADER_DATA(finalPayload),
                  new AppActions.BENEFITS_CHECK_COMPLETE()
                ];
              }),
              //if error: calling passThrough - passing sessionStorage through and stopping main spinner
              retry(2),
              catchError((error) => {
                //error actions go here
                /* istanbul ignore next */
                return passThrough;
              })
            )
            
        } else {
          return passThrough;
        }

      })
    )
    

  @Effect() getPermissions$ = this.action$
    .ofType(AppActions.APP_ACTIONS.START_GET_PERMISSIONS)
    .pipe(
      map(toPayload),
      switchMap((payload) => {
        const failure = [
          new AppActions.FAILED_GET_PERMISSIONS(),
          new AppActions.SET_HEADER_DATA(payload)
        ];
        return this.AppService.getPermissions({ paygroup: payload.payGroup.payrollGroupCode })
          .pipe(
            mergeMap((access: any) => {
              if(access.errorCode){
                return failure;
              }
              return [
                new AppActions.SUCCESS_GET_PERMISSIONS(access)
              ]
            }),
            retry(2),
            catchError((error) => {
              /* access permission call failed */
              return failure;
            })
          ) 
      })
    )
}


