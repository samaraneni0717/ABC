import { AppModule } from './../../app.module';
import { reducers, metaReducers } from './../index';
import { SUCCESS_MINI_TILES_ONLY, STOP_MODAL_LOADING } from './../actions/app.actions';
import { Observable } from 'rxjs/Observable';
import { empty } from 'rxjs/observable/empty';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Actions } from '@ngrx/effects';
import { hot, cold } from 'jasmine-marbles';
import { AppService } from './../../services/app.service';
import { AppEffects } from './app.effects';
import * as AppActions from '../actions/app.actions';
import { VanSlideinService, VanModalService } from '@van-genesis/van-genesis';
import * as fromEffects from './app.effects';
import { of } from 'rxjs/observable/of';
import { Store } from '@ngrx/store';
import * as fromRoot from '../index';

export class TestActions extends Actions {
  constructor() {
    super(empty());
  }

  set stream(source: Observable<any>) {
    this.source = source;
  }
}

export function getActions() {
  return new TestActions();
}

// describe('AppEffects', () => {
//   let actions$: TestActions;
//   let service: AppService;
//   let effects: fromEffects.AppEffects;
//   let modalService: VanModalService;
//   let slideInService: VanSlideinService;
//   let store: Store<fromRoot.State>;
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         HttpClientTestingModule,
//         AppModule
//       ],
//       declarations: [],
//       providers: [
//         Store,
//         AppService,
//         VanSlideinService,
//         VanModalService,
//         fromEffects.AppEffects,
//         { provide: Actions, useFactory: getActions },
//       ],
//     });
//     store = TestBed.get(Store);
//     actions$ = TestBed.get(Actions);
//     effects = TestBed.get(fromEffects.AppEffects);
//     service = TestBed.get(AppService);
//     modalService = TestBed.get(VanModalService);
//     slideInService = TestBed.get(VanSlideinService);
//     spyOn(store, 'dispatch').and.callThrough();
//   });

//   describe('getVerifyOutput$', () => {
//     it('should return data', () => {
//       const testData = [];
//       spyOn(service, 'getVerifyOutput').and.returnValue(of(testData));
//       const action = new AppActions.START_GET_VERIFY_OUTPUT({paygroup: 'KZ2'});
//       const completion = new AppActions.SUCCESS_GET_VERIFY_OUTPUT(testData);

//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-a', { a: completion });

//       expect(effects.getVerifyOutput$).toBeObservable(expected);
//     });

//     it('should be miniTiles Only', () => {
//       const testData = [];
//       spyOn(service, 'getVerifyOutput').and.returnValue(of(testData));
//       const action = new AppActions.START_GET_VERIFY_OUTPUT({ paygroup: 'KZ2', miniTilesOnly: true });
//       const completion = new AppActions.SUCCESS_MINI_TILES_ONLY(testData);

//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-a', { a: completion });
//       expect(effects.getVerifyOutput$).toBeObservable(expected);

//     });

//     it('should be donuts Only', () => {
//       const testData = [];
//       spyOn(service, 'getVerifyOutput').and.returnValue(of(testData));
//       const action = new AppActions.START_GET_VERIFY_OUTPUT({ paygroup: 'KZ2', donutsOnly: true });
//       const completion = new AppActions.SUCCESS_DONUTS_ONLY(testData);

//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-a', { a: completion });
//       expect(effects.getVerifyOutput$).toBeObservable(expected);

//     });

//     it('should error', () => {
//       spyOn(service, 'getVerifyOutput').and.throwError('error');
//       const action = new AppActions.START_GET_VERIFY_OUTPUT({ paygroup: 'KZ2', donutsOnly: true });
//       actions$.stream = hot('-a#|', { a: action });
//       const expected = cold('-#', null, new Error('error'));
//       expect(effects.getVerifyOutput$).toBeObservable(expected);
//     });

//   });

//   describe('getProcessingGroups$', () => {
//     it('should return processing groups', () => {
//       spyOn(service, 'getProcessingPayGroups').and.returnValue(of({data: 'data'}))
     
//       actions$.stream = hot('-a', { a: new AppActions.START_GET_PROCESSING_PAY_GROUPS({processingGroupName: 'PLGRP'}) });
//       const expected = cold('-(bc)', { 
//         b: new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS({ data: 'data' }),
//         c: new AppActions.PROC_GROUP_DROPDOWN_READY(true)
//       });
//       expect(effects.getProcessingGroups$).toBeObservable(expected);
//     });
//   });

//   describe('startGridLoading$', () => {
//     it('should set grid loading to true', () => {
//       const action = new AppActions.OPEN_SLIDE_IN({})
//       const completion = new AppActions.START_GRID_LOADING();
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-b', { b: completion });
//       expect(effects.startGridLoading$).toBeObservable(expected);
//     });
//   });

//   describe('openSlideIn$', () => {
//     it('MiniTile', () => {
//       spyOn(slideInService, 'open').and.returnValue(Promise.resolve());
//       spyOn(service, 'getDetails').and.returnValue(of({}));
//       const action = new AppActions.OPEN_SLIDE_IN({ paygroup: 'PLF', code: 'MTC', section: 'MiniTile', })
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-(ab)', { a: new AppActions.SET_SLIDE_IN_DATA({data: {}, code: 'MTC'}), b: new AppActions.STOP_GRID_LOADING() });
//       expect(effects.openSlideIn$).toBeObservable(expected);
//     });
//     it('section not MiniTile', () => {
//       spyOn(slideInService, 'open').and.returnValue(Promise.resolve());
//       spyOn(service, 'getDetails').and.returnValue(of({}));
//       const action = new AppActions.OPEN_SLIDE_IN({ paygroup: 'PLF', code: 'MTC', section: 'Donuts', })
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-(ab)', { a: new AppActions.SET_SLIDE_IN_DATA({ data: {}, code: 'MTC' }), b: new AppActions.STOP_GRID_LOADING() });
//       expect(effects.openSlideIn$).toBeObservable(expected);
//     });
//   });

//   describe('startModalLoading$', () => {
//     it('should start modal loading', () => {
//       const action = new AppActions.OPEN_MODAL({})
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-a', { a: new AppActions.START_MODAL_LOADING() });
//       expect(effects.startModalLoading$).toBeObservable(expected);
//     });
//   });

//   describe('openModal$', () => {
//     it('should set modal data and stop modal loading', () => {
//       spyOn(modalService, 'open').and.returnValue(Promise.resolve());
//       spyOn(service, 'getEmployeeDetails').and.returnValue(of({}));
//       const action = new AppActions.OPEN_MODAL({ name: 'PLF', componentId: '', size: 'XL', type: '' })
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-(ab)', { a: new AppActions.SET_MODAL_DATA({}), b: new AppActions.STOP_MODAL_LOADING() });
//       expect(effects.openModal$).toBeObservable(expected);
//     }); 
//   });

//   describe('getBenefitGroups$', () => {
//     it('should set data and stop landing page loading', () => {
//       spyOn(service, 'getBenefitGroups').and.returnValue(of({ hwseDeductionGroups: [{group: 'A'}] }));
//       const action = new AppActions.START_GET_HEADER_DATA({company: 'NET', payGroup: { payrollGroupCode: 'KZ2'}, deductionGroups: 'ABCDE'})
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-(bc)', { 
//         b: new AppActions.SET_HEADER_DATA({ sessionData: { company: 'NET', payGroup: { payrollGroupCode: 'KZ2' }, deductionGroups: 'ABCDE' }, benefitGroups: [{group:'A'}]}),
//         c: new AppActions.BENEFITS_CHECK_COMPLETE() 
//       });
//       expect(effects.getBenefitGroups$).toBeObservable(expected);
//     });

//     it('should just passThrough the session data', () => {
//       const action = new AppActions.START_GET_HEADER_DATA({ company: 'NET', payGroup: { payrollGroupCode: 'KZ2' }, deductionGroups: ' ' })
//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-(bc)', {
//         b: new AppActions.SET_HEADER_DATA({ sessionData: { company: 'NET', payGroup: { payrollGroupCode: 'KZ2' }, deductionGroups: ' ' }, benefitGroups: undefined }),
//         c: new AppActions.BENEFITS_CHECK_COMPLETE()
//       });
//       expect(effects.getBenefitGroups$).toBeObservable(expected);
//     });

//     it('error', () => {
//       const action = new AppActions.START_GET_HEADER_DATA({ company: 'NET', payGroup: { payrollGroupCode: 'KZ2' }, deductionGroups: ' ' });
//       spyOn(service, 'getBenefitGroups').and.returnValue(Observable.throw(Error));

//       actions$.stream = hot('-a', { a: action });
//       const expected = cold('-(bc)', {
//         b: new AppActions.SET_HEADER_DATA({ sessionData: { company: 'NET', payGroup: { payrollGroupCode: 'KZ2' }, deductionGroups: ' '}, benefitGroups: undefined}),
//         c: new AppActions.BENEFITS_CHECK_COMPLETE()
//       })
//       expect(effects.getBenefitGroups$).toBeObservable(expected);
//     });

    


//   });

// });