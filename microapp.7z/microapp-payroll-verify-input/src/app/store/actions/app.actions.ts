import { OutputParams } from './../../model/output-params.interface';
import { Action } from '@ngrx/store';

export const APP_ACTIONS = {
  START_SET_INITIAL_STATE: 'APP:START_SET_INITIAL_STATE',
  SET_INITIAL_STATE: 'APP:SET_INITIAL_STATE',
  START_LANDING_PAGE_LOADING: 'APP:START_LANDING_PAGE_LOADING',
  STOP_LANDING_PAGE_LOADING: 'APP:STOP_LANDING_PAGE_LOADING',
  START_GET_VERIFY_OUTPUT: 'APP:START_GET_VERIFY_OUTPUT',
  SUCCESS_GET_VERIFY_OUTPUT: 'APP:SUCCESS_GET_VERIFY_OUTPUT',
  START_GET_HEADER_DATA: 'APP:START_HEADER_DATA',
  SET_HEADER_DATA: 'APP:SET_HEADER_DATA',
  OPEN_SLIDE_IN: 'APP:OPEN_SLIDE_IN',
  SET_SLIDE_IN_DATA: 'APP:SET_SLIDE_IN_DATA',
  OPEN_MODAL: 'APP:OPEN_MODAL',
  SET_MODAL_DATA: 'APP:SET_MODAL_DATA',
  START_GRID_LOADING: 'APP:START_GRID_LOADING',
  STOP_GRID_LOADING: 'APP:STOP_GRID_LOADING',
  SET_PAYGROUP: 'APP:SET_PAYGROUP',
  SET_SESSION_DATA: 'APP:SET_SESSION_DATA',
  START_MODAL_LOADING: 'APP:START_MODAL_LOADING',
  STOP_MODAL_LOADING: 'APP:STOP_MODAL_LOADING',
  SUCCESS_MINI_TILES_ONLY: 'APP:SUCCESS_MINI_TILES_ONLY',
  SUCCESS_DONUTS_ONLY: 'APP:SUCCESS_DONUTS_ONLY',
  SLIDE_IN_CLOSED: 'APP:SLIDE_IN_CLOSED',
  START_GET_PROCESSING_PAY_GROUPS: 'APP:START_GET_PROCESSING_PAY_GROUPS',
  SUCCESS_GET_PROCESSING_PAY_GROUPS: 'APP:SUCCESS_GET_PROCESSING_PAY_GROUPS',
  PROC_GROUP_DROPDOWN_READY: 'APP:PROC_GROUP_DROPDOWN_READY',
  PROC_GROUP_DROPDOWN_ENABLED: 'APP:PROC_GROUP_DROPDOWN_ENABLED',
  PROC_GROUP_DROPDOWN_CALL_FAILED: 'APP:PROC_GROUP_DROPDOWN_CALL_FAILED',
  BENEFITS_CHECK_COMPLETE: 'APP:BENEFITS_CHECK_COMPLETE',
  RESET_STATE: 'APP:RESET_STATE',
  LOAD_PAYGROUP: 'APP:LOAD_PAYGROUP',
  OUTPUT_CALL_FAILED: 'APP:OUTPUT_CALL_FAILED',
  SET_LIMIT: 'APP:SET_LIMIT',
  EXPORT_EXCEL_START: 'APP:EXPORT_EXCEL_START',
  EXPORT_EXCEL_COMPLETE: 'APP:EXPORT_EXCEL_COMPLETE',
  EXPORT_EXCEL_ERROR: 'APP:EXPORT_EXCEL_ERROR',
  EXPORT_EXCEL_RESET: 'APP:EXPORT_EXCEL_RESET',
  START_GET_PERMISSIONS: 'APP:START_GET_PERMISSIONS',
  SUCCESS_GET_PERMISSIONS: 'APP:SUCCESS_GET_PERMISSIONS',
  FAILED_GET_PERMISSIONS: 'APP:FAILED_GET_PERMISSIONS'
}
export class EXPORT_EXCEL_START implements Action {
  readonly type = APP_ACTIONS.EXPORT_EXCEL_START;
}

export class EXPORT_EXCEL_COMPLETE implements Action {
  readonly type = APP_ACTIONS.EXPORT_EXCEL_COMPLETE;
}

export class EXPORT_EXCEL_ERROR implements Action {
  readonly type = APP_ACTIONS.EXPORT_EXCEL_ERROR;
}

export class EXPORT_EXCEL_RESET implements Action {
  readonly type = APP_ACTIONS.EXPORT_EXCEL_RESET;
}

export class SET_INITIAL_STATE implements Action {
  readonly type = APP_ACTIONS.SET_INITIAL_STATE;
  constructor(public payload: any) { }
}

export class START_SET_INITIAL_STATE implements Action {
  readonly type = APP_ACTIONS.START_SET_INITIAL_STATE;
  constructor(public payload: any) { }
}

export class START_GET_VERIFY_OUTPUT implements Action {
  readonly type = APP_ACTIONS.START_GET_VERIFY_OUTPUT;
  constructor(public payload: OutputParams){}
}

export class SET_PAYGROUP implements Action {
  readonly type = APP_ACTIONS.SET_PAYGROUP;
  constructor(public payload: any){}
}

export class SET_SESSION_DATA implements Action {
    readonly type = APP_ACTIONS.SET_SESSION_DATA;
    constructor(public payload: any){}
}

export class SUCCESS_GET_VERIFY_OUTPUT implements Action {
  readonly type = APP_ACTIONS.SUCCESS_GET_VERIFY_OUTPUT;
  constructor(public payload: any){}
}

export class SUCCESS_MINI_TILES_ONLY implements Action {
  readonly type = APP_ACTIONS.SUCCESS_MINI_TILES_ONLY;
  constructor(public payload: any) { }
}

export class SUCCESS_DONUTS_ONLY implements Action {
  readonly type = APP_ACTIONS.SUCCESS_DONUTS_ONLY;
  constructor(public payload: any) { }
}

export class SET_HEADER_DATA implements Action {
  readonly type = APP_ACTIONS.SET_HEADER_DATA;
  constructor(public payload: any){}
}

export class START_GET_HEADER_DATA implements Action {
  readonly type = APP_ACTIONS.START_GET_HEADER_DATA;
  constructor(public payload: any) { }
}

export class OPEN_SLIDE_IN implements Action {
  readonly type = APP_ACTIONS.OPEN_SLIDE_IN;
  constructor(public payload: any) {}
}


export class SET_MODAL_DATA implements Action {
  readonly type = APP_ACTIONS.SET_MODAL_DATA;
  constructor(public payload: any){}
}

export class OPEN_MODAL implements Action {
  readonly type = APP_ACTIONS.OPEN_MODAL;
  constructor(public payload: any) {}
}

export class SET_SLIDE_IN_DATA implements Action {
  readonly type = APP_ACTIONS.SET_SLIDE_IN_DATA;
  constructor(public payload: any) {}
}

export class START_MODAL_LOADING implements Action {
  readonly type = APP_ACTIONS.START_MODAL_LOADING;
}

export class STOP_MODAL_LOADING implements Action {
  readonly type = APP_ACTIONS.STOP_MODAL_LOADING;
}

export class START_LANDING_PAGE_LOADING implements Action {
  readonly type = APP_ACTIONS.START_LANDING_PAGE_LOADING;
}

export class STOP_LANDING_PAGE_LOADING implements Action {
  readonly type = APP_ACTIONS.STOP_LANDING_PAGE_LOADING;
}

export class START_GRID_LOADING implements Action {
  readonly type = APP_ACTIONS.START_GRID_LOADING;
}

export class STOP_GRID_LOADING implements Action {
  readonly type = APP_ACTIONS.STOP_GRID_LOADING;
}

export class SLIDE_IN_CLOSED implements Action {
  readonly type = APP_ACTIONS.SLIDE_IN_CLOSED;
}

export class START_GET_PROCESSING_PAY_GROUPS implements Action {
  readonly type = APP_ACTIONS.START_GET_PROCESSING_PAY_GROUPS;
  constructor(public payload: any) { }
}

export class SUCCESS_GET_PROCESSING_PAY_GROUPS implements Action {
  readonly type = APP_ACTIONS.SUCCESS_GET_PROCESSING_PAY_GROUPS;
  constructor(public payload: any) { }
}

export class PROC_GROUP_DROPDOWN_ENABLED implements Action {
  readonly type = APP_ACTIONS.PROC_GROUP_DROPDOWN_ENABLED;
}

export class PROC_GROUP_DROPDOWN_READY implements Action {
  readonly type = APP_ACTIONS.PROC_GROUP_DROPDOWN_READY;
  constructor(public payload: any) { }
}

export class PROC_GROUP_DROPDOWN_CALL_FAILED implements Action {
  readonly type = APP_ACTIONS.PROC_GROUP_DROPDOWN_CALL_FAILED;
}

export class BENEFITS_CHECK_COMPLETE implements Action {
  readonly type = APP_ACTIONS.BENEFITS_CHECK_COMPLETE;
}

export class RESET_STATE implements Action {
  readonly type = APP_ACTIONS.RESET_STATE;
}

export class LOAD_PAYGROUP implements Action {
  readonly type = APP_ACTIONS.LOAD_PAYGROUP;
  constructor(public payload: any) { }
}

export class OUTPUT_CALL_FAILED implements Action {
  readonly type = APP_ACTIONS.OUTPUT_CALL_FAILED;
}

export class SET_LIMIT implements Action {
  readonly type = APP_ACTIONS.SET_LIMIT;
  constructor(public payload: any) { }
}

export class START_GET_PERMISSIONS implements Action {
  readonly type = APP_ACTIONS.START_GET_PERMISSIONS;
  constructor(public payload: any) { }
}

export class SUCCESS_GET_PERMISSIONS implements Action {
  readonly type = APP_ACTIONS.SUCCESS_GET_PERMISSIONS;
  constructor(public payload: any) { }
}
export class FAILED_GET_PERMISSIONS implements Action {
  readonly type = APP_ACTIONS.FAILED_GET_PERMISSIONS;
}