import * as AppActions from './app.actions';

describe('App Actions', () => {
  it('verify actions', () => {
    for(let key in AppActions.APP_ACTIONS){
      let action = new AppActions[key]();
      expect(action.type).toEqual(AppActions.APP_ACTIONS[key]);
    }
  });
})