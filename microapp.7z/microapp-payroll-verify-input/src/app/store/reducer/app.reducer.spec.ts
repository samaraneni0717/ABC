import { reducer, outputData } from './app.reducer';
import * as fromApp from './app.reducer';
import * as Constants from '../../constants/constants';

// describe('AppReducer', () => {

//   describe('default state', () => {
//     it('should return default state', () => {  
//       const action = {} as any;
//       const result = reducer(undefined, action);
//       expect(result).toEqual(fromApp.initialState);
//     });
//   });

//   describe('SET_PAYGROUP', () => {
//     it('should set given paygroup into the store', () => {
//       const action = { type: 'APP:SET_PAYGROUP', payload: {payGroup: {payrollGroupCode: 'KZ1'}}};
//       const result = reducer(fromApp.initialState, action);
//       expect(result.paygroup).toBe('KZ1');
//     });
//   });

//   describe('SET_INITIAL_STATE', () => {
//     it('should return the aggregated output data', () => {
//       const payload = {
//         data: {
//           miniTiles: [
//             {
//               code: 'ITC',
//               count: 0
//             },
//             {
//               code: 'MTC',
//               count: 0
//             },
//             {
//               code: 'ANC',
//               count: 0
//             },
//             {
//               code: 'UNH',
//               count: 0
//             },
//             {
//               code: 'PXF',
//               count: 0
//             }
//           ],
//           donuts: [
//             {
//               code: 'WFC',
//               links: [
//                 {
//                   code: 'NEH',
//                   count: 0
//                 },
//                 {
//                   code: 'TER',
//                   count: 0
//                 }
//               ]
//             }
//           ]
//         }
//       }
//       const action = { type: 'APP:SET_INITIAL_STATE', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.outputData.donuts[0].name).toBe('Workforce Changes');
//     });
//   });

//   describe('OUTPUT_CALL_FAILED', () => {
//     it('should freeze state and set error', () => {
//       const action = { type: 'APP:OUTPUT_CALL_FAILED' }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.outputData).toEqual({miniTiles: [], donuts: []});
//     }); 
//   });

//   describe('SUCCESS_GET_PROCESSING_PAY_GROUPS', () => {
//     it('should set processing groups in store', () => {
//       const payload = {
//         payCycleProcessingList: [
//           {
//             name: 'PLGRP',
//             payCycleGroups: [
//               {
//                 payGroup: 'ZE1',
//                 description: 'Laxmi Weekly Paygroup',
//                 payCycleProcessingItems: [
//                   {
//                     processingGroupName: '',
//                     description: 'Kaizen &K Other Wkly  PG',
//                     quarter: '4',
//                     payDate1: '2017-10-20',
//                     periodStartDate1: '2017-10-07',
//                     periodEndDate1: '2017-10-15',
//                     periodStartDate2: '2017-10-07',
//                     periodEndDate2: '2017-10-16',
//                     benefitsCalcDate: '2017-10-16',
//                     benefitsProcessed: 'Y',
//                     days: '8',
//                     inputDate: '14-OCT-14',
//                     deductionGroups: 'ABCDEGIR',
//                     company: 'MCF',
//                     cycleStatus: 1
//                   }
//                 ]
//               },
//               {
//                 payGroup: 'ZE2',
//                 description: 'Laxmi Weekly Paygroup',
//                 payCycleProcessingItems: [
//                   {
//                     processingGroupName: '',
//                     description: 'Kaizen &K Other Wkly  PG',
//                     quarter: '4',
//                     payDate1: '2017-10-20',
//                     periodStartDate1: '2017-10-07',
//                     periodEndDate1: '2017-10-15',
//                     periodStartDate2: '2017-10-07',
//                     periodEndDate2: '2017-10-16',
//                     benefitsCalcDate: '2017-10-16',
//                     benefitsProcessed: 'Y',
//                     days: '8',
//                     inputDate: '14-OCT-14',
//                     deductionGroups: 'ABCDEGIR',
//                     company: 'MCF',
//                     cycleStatus: 1
//                   }
//                 ]
//               }
//             ]
//           }
//         ]
//       }
//       const action = { type: 'APP:SUCCESS_GET_PROCESSING_PAY_GROUPS', payload }
//       const result = reducer(fromApp.initialState, action);
//       console.log(result.processingPayGroups);
//       expect(result.processingPayGroups).toBeDefined();
//     });
//   });

//   describe('SET_HEADER_DATA action', () => {
//     it('without benefitGroups', () => {
//       expect(fromApp.initialState.headerData).toEqual(null);
//       const payload = {
//         sessionData: {
//           type: 'Pay Group',
//           payGroup: {
//             payrollGroupCode: 'KZ2',
//           }
//         },
//         benefitGroups: undefined
        
//       }
//       const action = { type: 'APP:SET_HEADER_DATA', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.headerData.payGroup.payrollGroupCode).toBe('KZ2');
//     });

//     it('with benefitGroups and deductionGroup A', () => {
//       expect(fromApp.initialState.headerData).toEqual(null);
//       const payload = {
//         sessionData: {
//           payGroup: {
//             payrollGroupCode: 'KZ2',
//           },
//           deductionGroups: 'A'
//         },
//         benefitGroups: [{deductionGroup: 'A'}]
//       }
//       const action = { type: 'APP:SET_HEADER_DATA', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.headerData.benefitsEnabled).toBeTruthy();
//     });

//     it('with benefitGroups and deductionGroup B', () => {
//       expect(fromApp.initialState.headerData).toEqual(null);
//       const payload = {
//         sessionData: {
//           payGroup: {
//             payrollGroupCode: 'KZ2',
//           },
//           deductionGroups: 'A'
//         },
//         benefitGroups: [{ deductionGroup: 'B' }]
//       }
//       const action = { type: 'APP:SET_HEADER_DATA', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.headerData.benefitsEnabled).toBeFalsy();
//     });

//   });

//   describe('STOP_LANDING_PAGE_LOADING', () => {
//     it('should landing page loading', () => {
//       const action = { type: 'APP:STOP_LANDING_PAGE_LOADING' }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isLandingPageLoading).toBe(false);
//     });
//   });

//   describe('SUCCESS_GET_VERIFY_OUTPUT', () => {
//     it('should return the aggregated output data', () => {
//       const payload = {
//         data: {
//           miniTiles: [
//             {
//               code: 'UNH',
//               count: 13,
//               status: 'R'
//             }
//           ],
//           donuts: [
//             {
//               code: 'PNC',
//               links: [
//                 {
//                   code: 'PRT',
//                   count: 0,
//                   status: 'R'
//                 },
//                 {
//                   code: 'DDP',
//                   count: 0,
//                   status: 'R'
//                 }
//               ]
//             }
//           ]
//         }
//       }
//       const action = { type: 'APP:SUCCESS_GET_VERIFY_OUTPUT', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.outputData.miniTiles[4].count).toBe('13');
//     });

//     it('should be empty arrays if no data in output call', () => {
//       const payload = {
//         data: {
//           miniTiles: [],
//           donuts: []
//         }
//       }
//       const action = { type: 'APP:SUCCESS_GET_VERIFY_OUTPUT', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.outputData.miniTiles).toEqual([]);
//       expect(result.outputData.donuts).toEqual([]);
//     });

//   });

//   describe('SUCCESS_MINI_TILES_ONLY', () => {
//     it('should return the aggregated output data', () => {
//       const payload = {
//         data: {
//           miniTiles: [
//             {
//               code: 'UNH',
//               count: 13,
//               status: 'R'
//             }
//           ]
//         }
//       }
//       const action = { type: 'APP:SUCCESS_MINI_TILES_ONLY', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.outputData.miniTiles[4].count).toBe('13');
//     });
//     describe('prepareMiniTiles', () => {
//       it('error code', () => {
//         const payload = {
//           data: {
//             miniTiles: [
//               {
//                 code: 'UNH',
//                 count: 13,
//                 status: 'E',
//                 errorCode: '502'
//               }
//             ]
//           }
//         }
//         const action = { type: 'APP:SUCCESS_MINI_TILES_ONLY', payload: payload }
//         const result = reducer(fromApp.initialState, action);
//         expect(result.outputData.miniTiles[4].errorCode).toBeTruthy();
//       })
//       describe('calculateTileCountFontSize', () => {
//         it('6 digits', () => {
//           const payload = {
//             data: {
//               miniTiles: [
//                 {
//                   code: 'UNH',
//                   count: 300000,
//                   status: 'R'
//                 }
//               ]
//             }
//           }
//           const action = { type: 'APP:SUCCESS_MINI_TILES_ONLY', payload: payload }
//           const result = reducer(fromApp.initialState, action);
//           expect(result.outputData.miniTiles[4].size).toEqual({ 'font-size': '26px', 'line-height': '2.8' });
//         });
//         it('4 digits', () => {
//           const payload = {
//             data: {
//               miniTiles: [
//                 {
//                   code: 'UNH',
//                   count: 3000,
//                   status: 'R'
//                 }
//               ]
//             }
//           }
//           const action = { type: 'APP:SUCCESS_MINI_TILES_ONLY', payload: payload }
//           const result = reducer(fromApp.initialState, action);
//           expect(result.outputData.miniTiles[4].size).toEqual({ 'font-size': '36px', 'line-height': '2' });
//         });
//         it('3 digits', () => {
//           const payload = {
//             data: {
//               miniTiles: [
//                 {
//                   code: 'UNH',
//                   count: 300,
//                   status: 'R'
//                 }
//               ]
//             }
//           }
//           const action = { type: 'APP:SUCCESS_MINI_TILES_ONLY', payload: payload }
//           const result = reducer(fromApp.initialState, action);
//           expect(result.outputData.miniTiles[4].size).toEqual({ 'font-size': '46px', 'line-height': '1.7' });
//         });
//       })
//     });
//   });

//   describe('SUCCESS_DONUTS_ONLY', () => {
//     it('should return the aggregated output data', () => {
//       const payload = {
//         data: {
//           donuts: [
//             {
//               code: 'HRS',
//               links: [
//                 {
//                   code: 'REG',
//                   count: 0,
//                   status: 'R'
//                 },
//                 {
//                   code: 'OTH',
//                   count: 0,
//                   status: 'R'
//                 }
//               ]
//             }
//           ]
//         }
//       }
//       const action = { type: 'APP:SUCCESS_DONUTS_ONLY', payload: payload }
//       const result = reducer(Object.assign({}, fromApp.initialState, { hasAccess: true }), action);
//       expect(result.outputData.donuts[0].code).toBe('HRS');
//     });
//     describe('prepareDonuts', () => {
//       it('donutsDisabled should be false, else condition', () => {
//         const payload = {
//           data: {
//             donuts: [
//               {
//                 code: 'HRS',
//                 links: [
//                   {
//                     code: 'REG',
//                     count: 20,
//                     status: 'R'
//                   },
//                   {
//                     code: 'OTH',
//                     count: 50,
//                     status: 'R'
//                   }
//                 ]
//               }
//             ]
//           }
//         }
//         const action = { type: 'APP:SUCCESS_DONUTS_ONLY', payload: payload };
//         const result = reducer(Object.assign({}, fromApp.initialState, { hasAccess: true }), action);
//         expect(result.outputData.donuts[0].colors).not.toEqual(['#bbb']);
//       });
//       it('error code', () => {
//         const payload = {
//           data: {
//             donuts: [
//               {
//                 code: 'HRS',
//                 errorCode: '502',
//                 links: []
//               }
//             ]
//           }
//         }
//         const action = { type: 'APP:SUCCESS_DONUTS_ONLY', payload: payload }
//         const result = reducer(Object.assign({}, fromApp.initialState, { hasAccess: true }), action);
//         expect(result.outputData.donuts[0]).toBeTruthy();
//       });
//     });
//   });

//   describe('SET_MODAL_DATA', () => {
//     it('should return the aggregated output data', () => {
//       const payload = {
//         data: [
//           {
//             reportToId: 'report to Id',
//             employeeId: 5
//           }
//         ]
//       }
//       const action = { type: 'APP:SET_MODAL_DATA', payload: payload }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.modalData.employeeId).toBe(5);
//     });

//   });

//   describe('START_GRID_LOADING', () => {
//     it('should start grid loading', () => {
//       const action = { type: 'APP:START_GRID_LOADING'}
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isGridLoading).toBe(true);
//     });
//   });

//   describe('STOP_GRID_LOADING', () => {
//     it('should stop grid loading', () => {
//       const action = { type: 'APP:STOP_GRID_LOADING' }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isGridLoading).toBe(false);
//     });
//   });

//   describe('START_MODAL_LOADING', () => {
//     it('should set modal loading', () => {
//       const action = { type: 'APP:START_MODAL_LOADING' }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isModalLoading).toBe(true);
//     });
//   });

//   describe('STOP_MODAL_LOADING', () => {
//     it('should stop modal loading', () => {
//       const action = { type: 'APP:STOP_MODAL_LOADING' }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isModalLoading).toBe(false);
//     });
//   });

//   describe('STOP_MODAL_LOADING', () => {
//     it('should stop modal loading', () => {
//       const action = { type: 'APP:STOP_MODAL_LOADING' }
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isModalLoading).toBe(false);
//     });
//   });

//   describe('APP_ACTIONS.SET_SLIDE_IN_DATA', () => {
//     it('should set the slide in Data but default to empty array', () => {
//       const payload = {
//         code: 'OTH',
//         data: {
//           data: {
//             details: undefined
//           }
//         }
//       }
//       const action = { type: 'APP:SET_SLIDE_IN_DATA', payload: payload }
//       const result = reducer(fromApp.initialState, action);
      
//       expect(result.slideInData.tableData).toEqual([]);
//     });
//   });

//   describe('APP_ACTIONS.SLIDE_IN_CLOSED', () => {
//     it('should set slide in to closed and reset excel start', () => {
//       const action = { type: 'APP:SLIDE_IN_CLOSED' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isSlideInOpen).toBeFalsy();
//       expect(result.exportExcelStart).toBeUndefined();
//     });
//   });

//   describe('APP_ACTIONS.START_LANDING_PAGE_LOADING', () => {
//     it('should set landing page loading to true', () => {
//       const action = { type: 'APP:START_LANDING_PAGE_LOADING' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isLandingPageLoading).toBeTruthy();
//     });
//   });

//   describe('APP_ACTIONS.BENEFITS_CHECK_COMPLETE', () => {
//     it('proc group ready', () => {
//       const action = { type: 'APP:BENEFITS_CHECK_COMPLETE' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isLandingPageLoading).toBeFalsy();
//     });
//     it('proc group not ready', () => {
//       const action = { type: 'APP:BENEFITS_CHECK_COMPLETE' };
//       const result = reducer(Object.assign({}, fromApp.initialState, 
//         { 
//           procGroupDropdownEnabled: true, 
//           procGroupDropdownReady: false 
//         }), action);
//       expect(result.isLandingPageLoading).toBeTruthy();
//     });
//   });

//   describe('APP_ACTIONS.PROC_GROUP_DROPDOWN_READY', () => {
//     it('should set landing page loading to true', () => {
//       const action = { type: 'APP:PROC_GROUP_DROPDOWN_READY', payload: false };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.procGroupDropdownReady).toBeFalsy();
//     });
//     it('should set landing page loading to true', () => {
//       const action = { type: 'APP:PROC_GROUP_DROPDOWN_READY', payload: false };
//       const result = reducer(Object.assign({}, fromApp.initialState, {benefitsCheckComplete: true}), action);
//       expect(result.isLandingPageLoading).toBeFalsy();
//     });
//   });

//   describe('APP_ACTIONS.PROC_GROUP_DROPDOWN_ENABLED', () => {
//     it('should set procGroupDropdownEnabled to true', () => {
//       const action = { type: 'APP:PROC_GROUP_DROPDOWN_ENABLED' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.procGroupDropdownEnabled).toBeTruthy();
//     });
//   });

//   describe('APP_ACTIONS.EXPORT_EXCEL_START', () => {
//     it('should set export properties', () => {
//       const action = { type: 'APP:EXPORT_EXCEL_START' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.exportExcelStart).toBeTruthy();
//       expect(result.exportExcelComplete).toBeFalsy();
//       expect(result.exportExcelError).toBeFalsy();
//     });
//   });

//   describe('APP_ACTIONS.EXPORT_EXCEL_COMPLETE', () => {
//     it('should set export properties', () => {
//       const action = { type: 'APP:EXPORT_EXCEL_COMPLETE' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.exportExcelStart).toBeFalsy();
//       expect(result.exportExcelComplete).toBeTruthy();
//       expect(result.exportExcelError).toBeFalsy();
//     });
//   });

//   describe('APP_ACTIONS.EXPORT_EXCEL_ERROR', () => {
//     it('should set export properties', () => {
//       const action = { type: 'APP:EXPORT_EXCEL_ERROR' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.exportExcelStart).toBeFalsy();
//       expect(result.exportExcelComplete).toBeFalsy();
//       expect(result.exportExcelError).toBeTruthy();
//     });
//   });

//   describe('APP_ACTIONS.LOAD_PAYGROUP', () => {
//     it('should set loadPayGroup', () => {
//       const action = { type: 'APP:LOAD_PAYGROUP', payload: 'ZE1' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.loadPayGroup).toEqual('ZE1')
//     });
//   });

//   describe('APP_ACTIONS.HAS_ACCESS', () => {
//     it('should set hasAccess', () => {
//       const action = { type: 'APP:HAS_ACCESS', payload: true };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.hasAccess).toBeTruthy();
//     });
//   });

//   describe('APP_ACTIONS.PAY_DATA_CALL_FAILED', () => {
//     it('should handle pay data call failed', () => {
//       const action = { type: 'APP:PAY_DATA_CALL_FAILED' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.isPdCallError).toBeTruthy();
//       expect(result.isLandingPageLoading).toBeFalsy();
//       expect(result.procGroupDropdownEnabled).toBeFalsy();
//     });
//   });

//   describe('APP_ACTIONS.PROC_GROUP_DROPDOWN_CALL_FAILED', () => {
//     it('should set error for procGroupDropdown', () => {
//       const action = { type: 'APP:PROC_GROUP_DROPDOWN_CALL_FAILED' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.procGroupDropdownEnabled).toBeFalsy();
//       expect(result.procGroupDropdownError).toBeTruthy();
//       expect(result.isLandingPageLoading).toBeFalsy();
//     });
//   });

//   describe('APP_ACTIONS.SET_LIMIT', () => {
//     it('hasAccess', () => {
//       const action = { type: 'APP:SET_LIMIT', payload: true };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.limit.miniTiles).toEqual(Constants.InitialState.data.miniTiles.length)
//     });
//     it('!hasAccess', () => {
//       const action = { type: 'APP:SET_LIMIT', payload: false };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.limit.miniTiles).toBeLessThan(Constants.InitialState.data.miniTiles.length)
//     });
//   });

//   describe('APP_ACTIONS.RESET_STATE', () => {
//     it('should reset the store', () => {
//       const action = { type: 'APP:RESET_STATE' };
//       const result = reducer(fromApp.initialState, action);
//       expect(result.outputData.miniTiles).toEqual([]);
//     });
//   });

//   it('exports', () => {
//     for (let key in fromApp) {
//       if (key !== 'reducer' && key !== 'newState') {
//         let prop = fromApp[key];
//         if (typeof prop !== 'object') {
//           prop(fromApp.initialState);
//         }
//       }
//     }
//   });


// });