import { Donuts } from './../../model/payroll-inputs.interface';
import { MiniTile } from './../../model/mini-tile.interface';
import { Header } from './../../model/header.interface';
import { APP_ACTIONS } from './../actions/app.actions';
import { ActionWithPayload } from '../../model/action-with-payload.interface';
import * as Constants from '../../constants/constants'

export interface State {
  outputData: any;
  headerData: Header;
  paygroup: string;
  sessionData: object;
  slideInData: any;
  isGridLoading: boolean;
  isModalLoading: boolean;
  modalData: any;
  killInitialOutputInterval: boolean;
  killMiniTilesOnly: boolean;
  killDonutsOnly: boolean;
  isLandingPageLoading: boolean;
  isSlideInOpen: boolean;
  processingPayGroups: any;
  procGroupDropdownEnabled: boolean;
  procGroupDropdownReady: boolean;
  procGroupDropdownError: boolean;
  benefitsCheckComplete: boolean;
  benefitsEnabled: boolean;
  loadPayGroup: any;
  hasAccess: object;
  limit: object;
  isPermissionCallError: boolean;
  exportExcelStart: boolean;
  exportExcelComplete: boolean;
  exportExcelError: boolean;
}

export const initialState: State = {
  outputData: {
    miniTiles: [],
    donuts: []
  },
  headerData: null,
  paygroup: null,
  sessionData: {},
  slideInData: null,
  modalData: null,
  isGridLoading: false,
  isModalLoading: false,
  killInitialOutputInterval: false,
  killMiniTilesOnly: false,
  killDonutsOnly: false,
  isLandingPageLoading: true,
  isSlideInOpen: false,
  processingPayGroups: null,
  procGroupDropdownEnabled: false,
  procGroupDropdownReady: false,
  procGroupDropdownError: false,
  benefitsCheckComplete: false,
  benefitsEnabled: false,
  loadPayGroup: null,
  hasAccess: undefined,
  limit: {},
  isPermissionCallError: false,
  exportExcelStart: undefined,
  exportExcelComplete: undefined,
  exportExcelError: undefined,
}

export const newState = (state: State, newData: any) => Object.assign( {}, state, newData);

export function reducer(state = initialState, action: ActionWithPayload) {

  switch(action.type) {

    case APP_ACTIONS.SET_PAYGROUP:
      return newState(state, { paygroup: action.payload.payGroup.payrollGroupCode });

      case APP_ACTIONS.SET_SESSION_DATA:
        return newState(state, {sessionData: action.payload});

    case APP_ACTIONS.SET_INITIAL_STATE:
      
      return newState(state, 
        {
          outputData: {
            miniTiles: prepareMiniTiles(action.payload.data.miniTiles),
            donuts: prepareDonuts(action.payload.data.donuts)
          }
        }
      );

    case APP_ACTIONS.OUTPUT_CALL_FAILED:

        return newState(state,
          {
            killInitialOutputInterval: {
              killInitialOutputInterval: true,
              miniTilesReady: true,
              donutsReady: true
            },
            outputData: freezeCurrentStateAndSetError(state.outputData)
          }
        );
      
    case APP_ACTIONS.SUCCESS_GET_PROCESSING_PAY_GROUPS:
   
      const processingPayGroups = action.payload.payCycleProcessingList[0].payCycleGroups.map( (pg: any) => {
        return {
          processingGroupName: action.payload.payCycleProcessingList[0].name,
          payGroup: {
            payrollGroupCode: pg.paygroup,
            payrollYear: pg.payCycleProcessingItems[0].year,
            payrollWeekNumber: pg.payCycleProcessingItems[0].weekNumber,
            payrollRunNumber: pg.payCycleProcessingItems[0].payrollNumber
          },
          quarter: pg.payCycleProcessingItems[0].quarter,
          payDate1: splitDate(pg.payCycleProcessingItems[0].payDate1),
          periodStartDate1: splitDate(pg.payCycleProcessingItems[0].periodStartDate1),
          periodEndDate1: splitDate(pg.payCycleProcessingItems[0].periodEndDate1),
          periodStartDate2: splitDate(pg.payCycleProcessingItems[0].periodStartDate2),
          periodEndDate2: splitDate(pg.payCycleProcessingItems[0].periodEndDate2),
          benefitsCalcDate: splitDate(pg.payCycleProcessingItems[0].benefitDedRunDate1),
          benefitsProcessed: pg.payCycleProcessingItems[0].benefitDeductionsReady,
          days: pg.payCycleProcessingItems[0].numberOfDays,
          inputDate: splitDate(pg.payCycleProcessingItems[0].inputDate),
          deductionGroups: pg.payCycleProcessingItems[0].deductionGroups,
          cycleStatus: pg.payCycleProcessingItems[0].cycleStatus,
          company: pg.payCycleProcessingItems[0].company,
          quickViewPayroll: pg.payCycleProcessingItems[0].quickViewPayroll
          
        }
      })
      .filter( (paygroup: any) => paygroup.cycleStatus == '1');
      const firstEnabled = processingPayGroups[0];
      /* istanbul ignore next */
      processingPayGroups.sort((a: any, b: any) => {
        a = a.payGroup.payrollGroupCode;
        b = b.payGroup.payrollGroupCode;
        if (a < b) {
          return -1;
        } else if (a > b) {
          return 1;
        } else {
          return 0;
        }
      });
      
      return newState(state, { processingPayGroups: {list: processingPayGroups, firstEnabled: firstEnabled} });

    case APP_ACTIONS.SUCCESS_GET_VERIFY_OUTPUT:
      //set data to current store data
      let miniTiles = state.outputData.miniTiles;
      let donuts = state.outputData.donuts;
      //if payload has data update
      if (action.payload.data.miniTiles.length > 0) {
        miniTiles = prepareMiniTiles(updatePayload(action.payload.data.miniTiles, 'miniTiles', state))
      }
      if (action.payload.data.donuts.length > 0) {
        donuts = prepareDonuts(updatePayload(action.payload.data.donuts, 'donuts', state))
      }
      //return the new data and check to see if initial output is done
      return newState(state, 
        { 
          outputData: {
            miniTiles: miniTiles,
            donuts: donuts
          }, 
          killInitialOutputInterval: isInitialOutputReady({
            miniTiles: miniTiles,
            donuts: donuts
          }, state)
        }
      );

    case APP_ACTIONS.SUCCESS_MINI_TILES_ONLY:
    
      return newState(state,
        {
          outputData: {
            donuts: state.outputData.donuts,
            miniTiles: prepareMiniTiles(updatePayload(action.payload.data.miniTiles, 'miniTiles', state))
          },
          killMiniTilesOnly: areAllMiniTilesComplete(action.payload.data.miniTiles, state.limit)
        }
      );  

    case APP_ACTIONS.SUCCESS_DONUTS_ONLY:
      return newState(state,
        {
          outputData: {
            donuts: prepareDonuts(updatePayload(action.payload.data.donuts, 'donuts', state)),
            miniTiles: state.outputData.miniTiles
          },
          killDonutsOnly: areAllDonutsComplete(action.payload.data.donuts, state.limit, state.outputData.donuts) 
        }
      );  

    case APP_ACTIONS.SET_HEADER_DATA:
      let header = action.payload.sessionData;
      let benefitsEnabled = false;
      if(action.payload.benefitGroups){
        
        let benefitsEnabledAtPaygroupLevel = action.payload.benefitGroups.map((group: any) => {
          return group.deductionGroup;
        });
        
        let deductionsEnabled = header.deductionGroups.split('');

        deductionsEnabled.map((dedGroup: any) => {
          benefitsEnabledAtPaygroupLevel.map((benGroup: any) => {
            if (dedGroup === benGroup) {
              benefitsEnabled = true;
            }
          });
        });
        header = Object.assign({}, header, { benefitsEnabled: benefitsEnabled })
      }
      console.log(`%c benefits enabled ?  ${benefitsEnabled}`, 'color: #00FFC5');

      return newState(state, { headerData: header });
      
    case APP_ACTIONS.SET_SLIDE_IN_DATA:

      const slideInData = {
        headers: Constants.Details[action.payload.code].headers,
        tableData: buildTableData(action.payload.data.data ? action.payload.data.data.details:[], action.payload.code),
        code: action.payload.code
      };
      return newState(state, { slideInData: slideInData });

    case APP_ACTIONS.SET_MODAL_DATA:

    const data = action.payload.data[0];
    /* istanbul ignore next */
    const modalData = {
      employeeId: data.reportToId ? data.employeeId : '',
      fileNumber: data.fileNumber ? data.fileNumber : '',
      status: data.status == 'N' ? 'Pending' : (data.emplStatusDescr ? data.emplStatusDescr : ''),
      manager: data.reportToId ? (data.reportToId.trim().length > 0 ? formatManagerDetails(data.reportToId, data.reportToName) : '') : '',
      job: data.jobCode ? (data.jobCode.trim().length > 0 ? data.jobCode+' - '+ data.jobDescr: '') : '',
      location: data.location ? (data.location.trim().length > 0 ? data.location+' - '+ data.locationDescr: ' ') : '',
      department:data.department ? (data.department.trim().length > 0 ? data.department+' - '+ data.departmentDescr: ''):'',
      costNum:data.costNum ? (data.costNum.trim().length > 0 ? data.costNum+' - '+ data.costNumDescr: '') : '',
      payrollDept: data.payDepartment ? 
      (data.payDepartment.trim().length > 0 ? data.payDepartment+' - '+ data.payDepartmentDescr: ' ') : '',
      street1: data.street1 ? data.street1 : '',
      street2: data.street2 ? data.street2 : '',
      city:  data.city ? data.city : '',
      state:  data.state ? data.state : '',
      zip: data.zip ? data.zip : '',
      workStreet1: data.locStreet1 ? data.locStreet1 : '',
      workStreet2: data.locStreet2 ? data.locStreet2 : '',
      workCity: data.locCity ? data.locCity : '',
      workState: data.locState ? data.locState : '',
      workZip: data.locZip ? data.locZip : ''
    };
      return newState(state, { modalData: modalData});

    case APP_ACTIONS.START_GRID_LOADING:
      return newState(state, { isGridLoading: true, isSlideInOpen: true });

    case APP_ACTIONS.STOP_GRID_LOADING:
      return newState(state, { isGridLoading: false });

      case APP_ACTIONS.START_MODAL_LOADING:
      return newState(state, { isModalLoading: true });

    case APP_ACTIONS.STOP_MODAL_LOADING:
      return newState(state, { isModalLoading: false }); 

    case APP_ACTIONS.SLIDE_IN_CLOSED:
      return newState(state, { isSlideInOpen: false, exportExcelStart: undefined, 
        exportExcelComplete: undefined, exportExcelError: undefined }); 

    case APP_ACTIONS.START_LANDING_PAGE_LOADING:
      return newState(state, { isLandingPageLoading: true });  

    case APP_ACTIONS.STOP_LANDING_PAGE_LOADING:
      return newState(state, { isLandingPageLoading: false });
    
    case APP_ACTIONS.BENEFITS_CHECK_COMPLETE:

      //proc group enabled but not ready, so we let the dropdown kill loader from its end
      if (state.procGroupDropdownEnabled && !state.procGroupDropdownReady){
        return newState(state, { benefitsCheckComplete: true });
      } 
      //if not enabled or proc group dropdown is ready
      return newState(state, { benefitsCheckComplete: true, isLandingPageLoading: false });
      
    case APP_ACTIONS.PROC_GROUP_DROPDOWN_READY:
      //if benefits check is complete and proc group is in final state(ready or error) show page
      if(state.benefitsCheckComplete){
        return newState(state, { procGroupDropdownReady: action.payload, isLandingPageLoading: false });
      }
      //benefits check is not complete.. it will kill loader from its end
      return newState(state, { procGroupDropdownReady: action.payload });
      
    case APP_ACTIONS.PROC_GROUP_DROPDOWN_ENABLED:
      return newState(state, { procGroupDropdownEnabled: true });

    case APP_ACTIONS.EXPORT_EXCEL_START:
      return newState(state, {exportExcelStart: true, exportExcelComplete: false, exportExcelError: false}); 
    
    case APP_ACTIONS.EXPORT_EXCEL_COMPLETE:
      return newState(state, {exportExcelStart: false, exportExcelComplete: true, exportExcelError: false});  

    case APP_ACTIONS.EXPORT_EXCEL_ERROR:
      return newState(state, {exportExcelStart: false, exportExcelComplete: false, exportExcelError: true});  

    case APP_ACTIONS.EXPORT_EXCEL_RESET:
      return newState(state, {exportExcelStart: undefined, exportExcelComplete: undefined, exportExcelError: undefined}); 

    case APP_ACTIONS.PROC_GROUP_DROPDOWN_CALL_FAILED:
      return newState(state, { procGroupDropdownEnabled: false, procGroupDropdownError: true, isLandingPageLoading: false });
    
    case APP_ACTIONS.LOAD_PAYGROUP:
      return newState(state, { loadPayGroup: action.payload });

    case APP_ACTIONS.SUCCESS_GET_PERMISSIONS:
      return newState(state, { hasAccess: action.payload });

    case APP_ACTIONS.FAILED_GET_PERMISSIONS:
      return newState(state, { isPermissionCallError: true, isLandingPageLoading: false, procGroupDropdownEnabled: false });

    case APP_ACTIONS.SET_LIMIT:
      /* 
        SETTING THE LIMIT FOR THE INTERVAL CALL
        
        The interval call operates on comparing the length of the constants to the length of data in the call.
        Once the data arrives in R or E status and the limit is reached the interval is complete.

        Here I am setting the limit based on access permissions so that the interval can adjust for variable numbers of tiles and donuts.
      */

      let hasAccess = action.payload.data;
      let limit;

      const fullPermissionMiniTilesLimit = Constants.InitialState.data.miniTiles.length;
      const fullPermissionDonutsLimit = Constants.InitialState.data.donuts.length;

      const pdMiniTilesToRemove = Constants.access_SectionsToFilter.pd.miniTiles.length;
      const pdDonutsToRemove = Constants.access_SectionsToFilter.pd.donuts.length;

      const OffCycleMiniTilesToRemove = Constants.access_SectionsToFilter.offCycle.miniTiles.length;
      /* full permissions */
      if(hasAccess.paydataEntryInd === 'Y' && hasAccess.offCycleCheckInd === 'Y'){
        console.log(`%c ACCESS = FULL PERMISSION`, 'color: #00FFC5');
        console.log(`%c LIMIT = miniTiles ${fullPermissionMiniTilesLimit} donuts ${fullPermissionDonutsLimit}`, 'color: #00FFC5')

        limit = {
          miniTiles: fullPermissionMiniTilesLimit,
          donuts: fullPermissionDonutsLimit
        }
      } 
      /* pd permissions only */
      else if (hasAccess.paydataEntryInd === 'Y' && hasAccess.offCycleCheckInd === 'N'){
        console.log(`%c ACCESS = PD ONLY`, 'color: #00FFC5');
        console.log(`%c LIMIT = miniTiles ${fullPermissionMiniTilesLimit - OffCycleMiniTilesToRemove} donuts ${fullPermissionDonutsLimit}`, 'color: #00FFC5')
        limit = {
          miniTiles: fullPermissionMiniTilesLimit - OffCycleMiniTilesToRemove,
          donuts: fullPermissionDonutsLimit
        }
      }
      /* offcycle permissions only */
      else if (hasAccess.paydataEntryInd === 'N' && hasAccess.offCycleCheckInd === 'Y'){
        console.log(`%c ACCESS = OFFCYCLE ONLY`, 'color: #00FFC5');
        console.log(`%c LIMIT = miniTiles ${fullPermissionMiniTilesLimit - pdMiniTilesToRemove} donuts ${fullPermissionDonutsLimit - pdDonutsToRemove}`, 'color: #00FFC5')

        limit = {
          miniTiles: fullPermissionMiniTilesLimit - pdMiniTilesToRemove,
          donuts: fullPermissionDonutsLimit - pdDonutsToRemove
        }
      }
      /* NO pd or offcycle permissions */
      else {
        console.log(`%c ACCESS = NONE`, 'color: #00FFC5');
        console.log(`%c LIMIT = miniTiles ${(fullPermissionMiniTilesLimit - pdMiniTilesToRemove) - OffCycleMiniTilesToRemove} donuts ${fullPermissionDonutsLimit - pdDonutsToRemove}`, 'color: #00FFC5')

        limit = {
          miniTiles: (fullPermissionMiniTilesLimit - pdMiniTilesToRemove) - OffCycleMiniTilesToRemove,
          donuts: fullPermissionDonutsLimit - pdDonutsToRemove
        }
      }
      return newState(state, { limit });

    case APP_ACTIONS.RESET_STATE:
      return newState(state, {
        outputData: {
          miniTiles: [],
          donuts: []
        },
        headerData: null,
        paygroup: null,
        killInitialOutputInterval: false,
        killMiniTilesOnly: false,
        killDonutsOnly: false,
        benefitsCheckComplete: false,
        isLandingPageLoading: true,
        procGroupDropdownReady: true,
        procGroupDropdownEnabled: true,
        hasAccess: undefined
      });
  
    default:
      return state;

  }
}

export const outputData = ((state: State) => state.outputData);
export const headerData = ((state: State) => state.headerData);
export const paygroup = ((state: State) => state.paygroup);
export const sessionData = ((state: State) => state.sessionData);
export const slideInData = ((state: State) => state.slideInData);
export const modalData = ((state: State) => state.modalData);
export const isGridLoading = ((state: State) => state.isGridLoading);
export const isModalLoading = ((state: State) => state.isModalLoading);
export const killInitialOutputInterval = ((state: State) => state.killInitialOutputInterval);
export const killMiniTilesOnly = ((state: State) => state.killMiniTilesOnly);
export const killDonutsOnly = ((state: State) => state.killDonutsOnly);
export const isLandingPageLoading = ((state: State) => state.isLandingPageLoading);
export const isSlideInOpen = ((state: State) => state.isSlideInOpen);
export const processingPayGroups = ((state: State) => state.processingPayGroups);
export const isProcGroupDropdownEnabled = ((state: State) => state.procGroupDropdownEnabled);
export const isProcGroupDropdownReady = ((state: State) => state.procGroupDropdownReady);
export const isProcGroupDropdownError = ((state: State) => state.procGroupDropdownError);
export const isBenefitsCheckComplete = ((state: State) => state.benefitsCheckComplete);
export const loadPayGroup = ((state: State) => state.loadPayGroup);
export const hasAccess = ((state: State) => state.hasAccess);
export const isPermissionCallError = ((state: State) => state.isPermissionCallError);
export const getLimit = ((state: State) => state.limit);
export const exportExcelStart = ((state: State) => state.exportExcelStart);
export const exportExcelComplete = ((state: State) => state.exportExcelComplete);
export const exportExcelError = ((state: State) => state.exportExcelError);

/* Helper Functions */
/* istanbul ignore next */
function arrayToObject(payload: Array<any>): object{
  return payload.reduce((obj, item) => {
    obj[item.code] = item
    return obj
  }, {})
}
/* istanbul ignore next */
function splitDate(date: any){
  if(date){
    return date.split(' ')[0];
  }
  return date;
}
/* istanbul ignore next */
function writableCopy(payload: Array<object>){
  return payload.map((obj: any) => {
    return { ...obj, writable: true }
  })
}
/* istanbul ignore next */
function freezeCurrentStateAndSetError(payload: any){
  function setErrorCodeForNoStatus(payload: Array<object>){
    return payload.map( (item: any) => {
      if(!item.status){
        item.errorCode = 500;
      }
      return item;
    });
  }
  return {
    miniTiles: setErrorCodeForNoStatus(writableCopy(payload.miniTiles)),
    donuts: setErrorCodeForNoStatus(writableCopy(payload.donuts))
  }
}
/* istanbul ignore next */
function updatePayload(payload: any, type: string, currentState: any){

  let currentData = arrayToObject(currentState.outputData[type]);
  let newData = arrayToObject(payload);
  let updatedPayload: object;

  switch(type){
    case 'miniTiles':
      updatedPayload = Object.keys(currentData).map((key) => {
        if (newData[key]) {
          currentData[key] = newData[key];
        }
        return currentData[key]
      });
      break;
    case 'donuts':
      updatedPayload = Object.keys(currentData).map((key) => {
        if (newData[key]) {
          let newLinks = arrayToObject(newData[key].links);
          let currentLinks = arrayToObject(currentData[key].links);
          let updatedLinks = Object.keys(currentLinks).map( (linkKey) => {
            if(newLinks[linkKey]){
              currentLinks[linkKey] = newLinks[linkKey];
            } 
            return currentLinks[linkKey]
          });
          return {
            code: key,
            errorCode: newData[key].errorCode,
            links: Object.keys(updatedLinks).map((key) => updatedLinks[key])
          }
        }
        return currentData[key]
      });   
  }
  return Object.keys(updatedPayload).map((key) => updatedPayload[key]);
}
/* istanbul ignore next */
function order(ar: Array<object>): Array<object> {
  return ar.sort((a: any, b: any) => a.order - b.order);
}
/* istanbul ignore next */
function isInitialOutputReady(payload: any, state: any) {

  let miniTiles = payload.miniTiles;
  let donuts = payload.donuts;
  
  if(miniTiles.length > 0 && donuts.length > 0){
    let killInitialOutputInterval: boolean;

    const donutsInitialReady = donuts
      .map((donut: any) => donut.links.filter((link: any) => link.status === 'R').length)
      .filter( (length) => length > 0).length > 0;
    
    const miniTilesInitialReady = miniTiles.filter((miniTile: any) => miniTile.status === 'R').length > 0;
    
    if (donutsInitialReady && miniTilesInitialReady) {
      killInitialOutputInterval = true;
    }
    return {
      killInitialOutputInterval: killInitialOutputInterval,
      miniTilesReady: areAllMiniTilesComplete(miniTiles, state.limit),
      donutsReady: areAllDonutsComplete(donuts, state.limit, state.outputData.donuts)
    }
  } else {
    return {
      killInitialOutputInterval: false,
      miniTilesReady: false,
      donutsReady: false
    }
  }
}

/* MINI_TILES //////////////////////////////////////////////////////////////////////////////////////*/
/* istanbul ignore next */
function formatCount(count: any) {
    if (count !== undefined && count !== null && count > 0) {
        return count.toLocaleString();
    }
    return count;
}
/* istanbul ignore next */
function prepareMiniTiles(miniTiles: Array<MiniTile>){

  let data = miniTiles.map((miniTile: any) => {
    /* istanbul ignore else */
    if (Constants.MiniTileSections[miniTile.code]) {
      const count = formatCount(miniTile.count);
      return  {
        name: Constants.MiniTileSections[miniTile.code].name,
        code: miniTile.code,
        count: count,
        status: miniTile.status,
        category: Constants.MiniTileSections[miniTile.code].category,
        size: calculateTileCountFontSize(count),
        order: Constants.MiniTileSections[miniTile.code].order,
        errorCode: miniTile.errorCode ? true : false
      };
    }

  }).filter((miniTile: any) => miniTile !== undefined);

  return order(data);
}

/* istanbul ignore next */
function areAllMiniTilesComplete(miniTiles: any, limit: any): boolean {
 
  //if miniTiles.length does not equal limit then data has not arrived returning false
  if (miniTiles.length !== limit.miniTiles) {
    return false;
  }
  //if miniTiles are in R status or have errorCode then return true
  let status = miniTiles.map( (tile: any) => {
    if(tile.status === 'R' || tile.errorCode){
      return true;
    }
    return false;
  }).sort((a: any, b: any) => a - b);

  console.log(`%c MiniTiles -> Limit: ${limit.miniTiles}  Ready/Error Status: ${miniTiles.filter((tile) => tile.status === 'R' || tile.errorCode).length}`, 'color: #00FFC5')

  if(!status[0]){
    return false;
  }
  return true;
}
/* istanbul ignore next */
function calculateTileCountFontSize(value: number): object {
  if(value){
    value = value.toString().split('').length;
    if (value >= 6) {
      return { 'font-size': '26px', 'line-height': '2.8' }
    } else if (value >= 4 && value < 6) {
      return { 'font-size': '36px', 'line-height': '2' };
    } else if (value === 3) {
      return { 'font-size': '46px', 'line-height': '1.7' };
    }
  }
}

/* DONUTS //////////////////////////////////////////////////////////////////////////////////////*/
/* istanbul ignore next */
function disableClick(code: string) {
    if (code === 'REG' || code === 'OTP') {
        return true;
    }
    return false;
}
/* istanbul ignore next */
function calculateDonutCount(donut: any) {
  let count = donut.links.reduce((total: number, link: any) => total + link.count, 0);
  return formatCount(count);
}
/* istanbul ignore next */
function formatHoursAndAmount(count) {
  let formattedCount = String(formatCount(count));
  if (formattedCount && formattedCount.indexOf('.') === -1) {
        formattedCount = formattedCount + '.00';
    }
    return formattedCount;
}
/* istanbul ignore next */
function prepareDonuts(donuts: Array<Donuts>) {
  let data = donuts.map((donut: any): Donuts => {

    let donutDisabled: boolean;
    const containerCount = calculateDonutCount(donut);
    if (containerCount === 0) {
      donutDisabled = true;
    }
    /* istanbul ignore else */
    if (Constants.PayrollInputSections[donut.code]) {
      return {
        name: Constants.PayrollInputSections[donut.code].name,
        code: donut.code,
        status: setDonutStatus(donut),
        errorCode: donut.errorCode,
        colors: donutDisabled ? ['#bbb'] : Constants.PayrollInputSections[donut.code].colors,
        links: donut.links.map((link: any) => {
          return {
            name: Constants.PayrollInputCodes[link.code],
            code: link.code,
            count: donut.code === 'HRS' ? formatHoursAndAmount(link.count) : formatCount(link.count),
            status: link.status,
            disableClick: disableClick(link.code)
          };
        }),
        count: donut.code === 'HRS' ? formatHoursAndAmount(containerCount) : formatCount(containerCount),
        data: donut.code === 'HRS' ? setDonutData(donut.links, donutDisabled, true) : setDonutData(donut.links, donutDisabled, false),
        order: Constants.PayrollInputSections[donut.code].order
      };
    }
  }).filter((donut: any) => donut !== undefined);

  return order(data);
}
/* istanbul ignore next */
function areAllDonutsComplete(donuts: any, limit: any, currentStoreDonuts: any): boolean{
  
  let currentDonuts = arrayToObject(currentStoreDonuts);
  
  //if the length of donuts available in the new data does not equal the limit then we should not even compare links.. return false
  if (donuts.length !== limit.donuts){
    return false;
  }
  
  let newDonuts = arrayToObject(donuts.map((donut: any) => {
    return {
      code: donut.code,
      errorCode: donut.errorCode,
      links: donut.links.filter((link: any) => {
        return link.status === 'R'
      })
    }
  }));
  
  let status = Object.keys(currentDonuts).map((key) => {
   
      //If the newDonut does not have an errorcode then compare the lengths of the links.
      if (!newDonuts[key].errorCode) {
        //If the links match then the interval is done for that donut.. return true else return false.
        if (newDonuts[key].links.length === currentDonuts[key].links.length) {
          return true;
        }
        return false;
      }
      //If the errorCode exist then return true(looking for 'R' status or errorCode to flag stop for donut);
      else {
        return true;
      }
    
    
  }).sort((a: any, b: any) => a - b);
  
  console.log(`%c Donuts -> Limit: ${limit.donuts}  Ready/Error Status: ${Array.from(status).filter(pred => pred === true).length}`, 'color: #00FFC5')

  if (!status[0]) {
    return false;
  }
  return true;

}
/* istanbul ignore next */
function setDonutData(links: any, disabled: boolean, isHrsOrAmt: boolean) {
  if (disabled) {
    return [{ y: 1, disabled: true }];
  }
  return links.map((link: any) => {
    return { name: Constants.PayrollInputCodes[link.code], y: Math.abs(link.count), count: isHrsOrAmt ? formatHoursAndAmount(link.count) : formatCount(link.count), code: link.code, disableClick: disableClick(link.code) };
  });
}
/* istanbul ignore next */
function setDonutStatus(donut: any): any{
  let constant = arrayToObject(Constants.InitialState.data.donuts);
  if(donut.links.filter((link: any) => link.status === 'R').length === constant[donut.code].links.length){
    return 'R';
  } 
}
/* istanbul ignore next */
 function getValue(value: any) {
  return value ? value : '';
 }
 /* istanbul ignore next */
 function convertToDate(value: any) {
    if (value !== '') {
      return new Date(value);
    }
    return value;
 }
/* istanbul ignore next */
 function decimalFormat(num: number){
   return num.toFixed(2);
 }
/* istanbul ignore next */
 function generateEmployeeDesc(typeDescr: string, regTempDescr: string, fullPartTimeDescr: string){
    let employeeDescr: any = '';
    
      employeeDescr = (typeDescr !== ' ') ? typeDescr : '';
      employeeDescr += (regTempDescr !== ' ') ? '/' + regTempDescr : '';
      employeeDescr += (fullPartTimeDescr !== ' ') ? '/' + fullPartTimeDescr : '';
      return employeeDescr;
      
 }
/* istanbul ignore next */
 function joinWithHyphen(code:string, description : string){
    let codeDesc: any;

      codeDesc = (code !== ' ') ? code : '';
      codeDesc += (description !== ' ') ? ' - ' + description : '';
      return codeDesc;

 }
/* istanbul ignore next */
 function formatManagerDetails(reportToId: string, reportToName: string) {
    if (reportToId === 'ONE') {
      return 'ONE,ONE'
    }
    return joinWithHyphen(reportToId, reportToName);
    }

/* DETAILS //////////////////////////////////////////////////////////////////////////////////////*/
/* istanbul ignore next */
function buildTableData(rows: Array<object>, code: string): Array<Object> {
 
  return rows.map((row: any) => { 
    const coreData = {

      name: getValue(row.name),
      employeeId: getValue(row.employeeId),
      fileNumber: getValue(row.fileNumber),
      employeeType: generateEmployeeDesc(row.employeeTypeDescr, row.regTempDescr, row.fullPartTimeDescr),
      location: joinWithHyphen(row.location, row.locationDescr),
      employeeRecordNumber: getValue(row.employeeRecordNumber),
    };
    let caseData = {}
    switch(code){
        // MiniTile Details
      case 'ITC':
        caseData = {
          taxType: getValue(row.taxCodeType),
          invalidCode: getValue(row.inValidTaxCode)
        }
        break;
      case 'MTC':
        caseData = {
          hireDate: convertToDate(getValue(row.hireDate)),
          filenumberstatusdesc: getValue(row.filenumberstatusdesc)

        }
        break;
      case 'ANC':
        caseData = {
          status: row.status == 'N' ? 'Pending' : getValue(row.emplStatusDescr)
        }
        break;
      case 'PXF':
        caseData = {
          job: joinWithHyphen(row.jobCode, row.jobDescr),
          manager: formatManagerDetails(row.reportToId, row.reportToName),
          submitterName: getValue(row.submitterName),
          approverName: getValue(row.approverName),
          effectiveDate: convertToDate(getValue(row.transferEffectiveDate))
        }
        break;
      // Common entries for 'PDD' and 'PTW'
      case 'PDD':
      case 'PTW':
        caseData = {
          submitter: getValue(row.submitterName),
          approver: getValue(row.approverName),
          effectiveDate: convertToDate(getValue(row.effectiveDate)),
        }
        break;

        case 'WOH':
          caseData = {
            manager: formatManagerDetails(row.reportToId, row.reportToName),
            hireDate: convertToDate(getValue(row.hireDate))
          }
          break;

        case 'TWM':
          caseData = {
            workState: getValue(row.workedInState),
            homeState: getValue(row.livedInState),
            taxCodeType: getValue(row.taxCodeType),
            misMatchedTaxCode: getValue(row.misMatchedTaxCode)
          }
          break;

        case 'UNH':
          caseData = {
              submitterName: getValue(row.submitterName),
              approverName: getValue(row.approverName),
              effectiveDate: convertToDate(getValue(row.newhireEffectiveDate))
          }
          break;
        case 'OST':
          caseData = {
            manager: formatManagerDetails(row.reportToId, row.reportToName),
            batchId: getValue(row.batchId),
            batchType: getValue(row.batchType),
            pay: getValue(row.payNumber),
            stdHours: decimalFormat(row.stdHours),
            regHrs: decimalFormat(row.regularHours)
          }
          break; 
        case 'OCC':
          caseData = {
            status: row.status == 'N' ? 'Pending' : getValue(row.emplStatusDescr),
            reason: getValue(row.reasonDescr),
            netPay: decimalFormat(row.netPay)
          }
          break; 
        // Common entries for 'PDP' and 'PPI'
        case 'PDP':
        // Donuts Details
        case 'PPI':
            caseData = {
                emplStatus: row.status == 'N' ? 'Pending' : getValue(row.emplStatusDescr),
                batchId: getValue(row.batchId),
                batchType: getValue(row.batchType),
                pay: getValue(row.payNumber),
                regHrs: decimalFormat(row.regularHours),
                otHrs: decimalFormat(row.overtimeHrs),
                otherHrs: decimalFormat(row.otherHrs),
                regEarns: decimalFormat(row.regularEarnings),
                otEarns: decimalFormat(row.overtimeEarnings),
                otherEarns: decimalFormat(row.otherEarnings),
            }
            break;
      case 'NEH':
        caseData = {
          hireDate: convertToDate(getValue(row.hireDate)),
          actionDate: convertToDate(getValue(row.actionDate)),
          job: joinWithHyphen(row.jobCode, row.jobDescr),
          manager: formatManagerDetails(row.reportToId, row.reportToName)
        }
        break;
        case 'TER':
        caseData = {
          termDate: convertToDate(getValue(row.terminationDate)),
          status: row.status == 'N' ? 'Pending' : getValue(row.emplStatusDescr),
          reason: getValue(row.actionReasonDescr),
          type: getValue(row.actionReasonDescr).trim().length === 0 ?
          '' : (getValue(row.terminationType) === 'Y' ? 'Voluntary' : 'Involuntary')
        }
        break;
        case 'LOA':
          caseData = {
            loaDate: convertToDate(getValue(row.effectiveDate)),
            dateEntered: convertToDate(getValue(row.actionDate))
          }
        break;
        case 'REH':
          caseData = {
            rehireDate: convertToDate(getValue(row.effectiveDate)),
            dateEntered: convertToDate(getValue(row.actionDate))
          }
        break;
        case 'XFR':
          caseData = {
            transferFrom: row.xfrFromPaygroup,
            transferDate: convertToDate(getValue(row.effectiveDate)),
            dateEntered: convertToDate(getValue(row.actionDate))
          }
          break;
        case 'MCP':
        caseData = {
          emplStatus: row.status == 'N' ? 'Pending' : getValue(row.emplStatusDescr),
          batchId: getValue(row.batchId),
          pay: getValue(row.payNumber),
          check: getValue(row.checkNumber),
          grossPay: decimalFormat(row.grossPay),
          netPay: decimalFormat(row.netPay)
        }
        break;  
      case 'OTH':
          caseData = {
         code: getValue(row.code),
         description: getValue(row.earnCodeDescr),
         field: getValue(row.hoursField),
         hours: decimalFormat(row.hours)
          }
       break;
      case 'RTT':
        caseData = {
          oldRateType: getValue(row.oldRateTypeDescr),
          newRateType: getValue(row.rateTypeDescr),
          effectiveDate: convertToDate(getValue(row.effectiveDate))
        }

    }
    let finalData = {};
    if (code === 'OTH') {
      finalData = caseData;
    } else {
      finalData = { ...coreData, ...caseData };
    }
    return finalData;
  });
}