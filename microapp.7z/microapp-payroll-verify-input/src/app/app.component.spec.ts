import {AppService} from './services/app.service';
import {AppModule} from './app.module';
import {BetterPlatformBrowserLocationService} from './better-platform-location.service';
import {of} from 'rxjs/observable/of';
import {async, ComponentFixture, TestBed, inject} from '@angular/core/testing';
import {AppComponent} from './app.component';
import {StoreModule, Store} from '@ngrx/store';
import {reducers, metaReducers} from './store/index';
import {
    AlertComponent,
    CheckboxComponent,
    BusyIndicatorComponent,
    TableComponent,
    IconComponent,
    PaginatorComponent,
    ButtonModule,
    CheckboxModule,
    AlertModule,
    BusyIndicatorModule,
    SlideinModule,
    ModalModule,
    TableModule
} from '@synerg/components';
import * as fromRoot from './store/index';
import {DonutComponent} from './features/payroll-inputs/donut/donut.component';
import {NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {VanModalService} from '@van-genesis/van-genesis'
import * as AppActions from './store/actions/app.actions';
import {Observable} from 'rxjs/Observable';
import * as Constants from './constants/constants';
import {PlatformLocation} from '@angular/common';

class MockService {
    getVerifyOutput() {
        return Observable.of()
    }

    getPaydataBatches() {
        return Observable.of()
    }
}
const groups = {
    "searchCount": 6, "payCycleProcessingList": [{
        "name": "PLGRP",
        "type": "G",
        "payCycleGroups": [{
            "paygroup": "ZE5",
            "description": "Laxmi Weekly Paygrou",
            "payCycleProcessingItems": [{
                "year": "2018",
                "weekNumber": "04",
                "payrollNumber": "1",
                "quarter": "1",
                "payDate1": "2018-01-26 00:00:00.0",
                "periodStartDate1": "2017-10-07 00:00:00.0",
                "periodEndDate1": "2017-10-15 00:00:00.0",
                "periodStartDate2": "2017-10-07 00:00:00.0",
                "periodEndDate2": "2017-10-16 00:00:00.0",
                "benefitRunDate1": "2017-10-16 00:00:00.0",
                "benefitsProcessed": "Y",
                "days": "8",
                "inputDate": "2017-10-16 00:00:00.0",
                "company": "MCF",
                "payFrequency": "1",
                "cycleStatus": "1",
                "quickViewPayroll": "N",
                "psn": "1",
                "deductionGroups": "B"
            }]
        }]
    }]
}


// describe('AppComponent: Pay Group', () => {
//     let component: AppComponent;
//     let fixture: ComponentFixture<AppComponent>;
//     let store: Store<fromRoot.State>;
//     beforeEach(async(() => {
//         TestBed.configureTestingModule({
//             imports: [
//                 AppModule,
//                 [StoreModule.forRoot(reducers, {metaReducers})]
//             ],
//             declarations: [],
//             providers: [
//                 VanModalService,
//                 {provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService},
//                 {provide: AppService, useClass: MockService}
//             ],
//             schemas: [CUSTOM_ELEMENTS_SCHEMA]
//         })
//             .compileComponents();
//     }));

//     beforeEach(() => {
//         store = TestBed.get(Store);
//         fixture = TestBed.createComponent(AppComponent);
//         component = fixture.componentInstance;
//         const verifyInputData = {
//             'type': 'Pay Group',
//             'payGroup': {
//                 'payrollGroupCode': 'KZ2',
//                 'payrollYear': '2017',
//                 'payrollWeekNumber': '42',
//                 'payrollRunNumber': '1'
//             },
//             'processingGroupName': '',
//             'description': 'Kaizen &K Other Wkly  PG',
//             'quarter': '4',
//             'payDate1': '2017-10-20',
//             'periodStartDate1': '2017-10-07',
//             'periodEndDate1': '2017-10-15',
//             'periodStartDate2': '2017-10-07',
//             'periodEndDate2': '2017-10-16',
//             'benefitsCalcDate': '2017-10-16',
//             'benefitsDeductionReady': 'Y',
//             'days': '8',
//             'inputDate': '14-OCT-14'
//         }
//         sessionStorage.setItem('verifyInputData', JSON.stringify(verifyInputData));

//         fixture.detectChanges();
//     });

//     describe('killAllIntervals', () => {
//         it('all intervals hot', () => {
//             component.makeIntervalSub$ = Observable.create(() => {}).subscribe();
//             component.killAllIntervals();
//             expect(component.makeIntervalSub$.isStopped).toBe(true);
//         });
//     });

//     describe('interval calls', () => {
//        it('all ready in initial output', () => {
//             const data = {
//                 payGroup: {
//                     payrollGroupCode: 'KZ2'
//                 }
//             }
//             store.dispatch(new AppActions.HAS_ACCESS(false));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [
//                         { code: 'PXF', count: 5, status: 'R'}, 
//                         { code: 'ITC', count: 5, status: 'R'}, 
//                         { code: 'MTC', count: 5, status: 'R'}, 
//                         { code: 'ANC', count: 5, status: 'R'}, 
//                         { code: 'UNH', count: 5, status: 'R'},
//                         { code: 'TWM', count: 5, status: 'R'}, 
//                         { code: 'PPI', count: 5, status: 'R'}, 
//                         { code: 'WOH', count: 5, status: 'R'}, 
//                         { code: 'OST', count: 5, status: 'R'},
//                         { code: 'PTW', count: 5, status: 'R' },
//                         { code: 'PDD', count: 5, status: 'R' }
//                     ],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'R'}, {code: 'TER', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));

//             component.makeIntervalCall(data);
//             spyOn(store, 'dispatch').and.callThrough();

//             store.select(fromRoot.app_getKillInitialOutputInterval).subscribe((status: any) => {
//                 expect(status.miniTilesReady).toBe(true);
//             });
//         });

//         it('miniTiles only call', () => {
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();
//             spyOn(store, 'dispatch').and.callThrough();
//             spyOn(Observable, 'interval').and.returnValue(Observable.of());

//             store.dispatch(new AppActions.HAS_ACCESS(true));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [{
//                         code: 'PXF', count: 5, status: 'R'
//                     }],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'R'}, {code: 'TER', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));

//             store.select(fromRoot.app_getKillInitialOutputInterval).subscribe((status: any) => {
//                 expect(status.miniTilesReady).toBe(false);
//             });

//             store.dispatch(new AppActions.SUCCESS_MINI_TILES_ONLY({
//                 data: {
//                     miniTiles: [
//                         { code: 'PXF', count: 5, status: 'R' },
//                         { code: 'ITC', count: 5, status: 'R' },
//                         { code: 'MTC', count: 5, status: 'R' },
//                         { code: 'ANC', count: 5, status: 'R' },
//                         { code: 'UNH', count: 5, status: 'R' },
//                         { code: 'TWM', count: 5, status: 'R' },
//                         { code: 'PPI', count: 5, status: 'R' },
//                         { code: 'WOH', count: 5, status: 'R' },
//                         { code: 'OST', count: 5, status: 'R' },
//                         { code: 'PTW', count: 5, status: 'R' },
//                         { code: 'PDD', count: 5, status: 'R' }
//                     ]
//                 }
//             }));
//             store.select(fromRoot.app_getKillMiniTilesOnly).subscribe((status: any) => {
//                 expect(status).toBe(true);
//             });

//         });
//         it('donuts only call', () => {
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();
//             spyOn(store, 'dispatch').and.callThrough();
//             spyOn(Observable, 'interval').and.returnValue(Observable.of());
//             store.dispatch(new AppActions.HAS_ACCESS(true));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [{
//                         code: 'PXF', count: 5, status: 'R'
//                     }],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'E'}, {code: 'TER', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));
//             store.select(fromRoot.app_getKillInitialOutputInterval).subscribe((status: any) => {
//                 expect(status.donutsReady).toBe(false);
//             });
//             store.dispatch(new AppActions.SUCCESS_DONUTS_ONLY({
//                 data: {
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'R'},
//                             {code: 'TER', count: 8, status: 'R'},
//                             {code: 'LOA', count: 0, status: 'R'},
//                             {code: 'REH', count: 0, status: 'R'},
//                             {code: 'XFR', count: 0, status: 'R'}]
//                     }, {
//                         code: 'HRS',
//                         links: [{code: 'REG', count: 0, status: 'R'},
//                             {code: 'OTP', count: 8, status: 'R'},
//                             {code: 'OTH', count: 0, status: 'R'}]
//                     }, {
//                         code: 'PAY', links: [{code: 'PDP', count: 0, status: 'R'}, {code: 'MCP', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));
//             store.select(fromRoot.app_getKillDonutsOnly).subscribe((status: any) => {
//                 expect(status).toBe(true);
//             });

//         });
//     });
// });
// describe('AppComponent: Processing Group', () => {
//     let component: AppComponent;
//     let fixture: ComponentFixture<AppComponent>;
//     let store: Store<fromRoot.State>;
//     beforeEach(async(() => {
//         TestBed.configureTestingModule({
//             imports: [
//                 AppModule,
//                 [StoreModule.forRoot(reducers, {metaReducers})]
//             ],
//             declarations: [],
//             providers: [
//                 VanModalService,
//                 {provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService},
//                 {provide: AppService, useClass: MockService}
//             ],
//             schemas: [CUSTOM_ELEMENTS_SCHEMA]
//         })
//             .compileComponents();
//     }));

//     beforeEach(() => {
//         store = TestBed.get(Store);
//         fixture = TestBed.createComponent(AppComponent);
//         component = fixture.componentInstance;
//         const verifyInputData = {
//             'type': 'Group',
//             'payGroup': {
//                 'payrollGroupCode': 'KZ2',
//                 'payrollYear': '2017',
//                 'payrollWeekNumber': '42',
//                 'payrollRunNumber': '1'
//             },
//             'processingGroupName': '',
//             'description': 'Kaizen &K Other Wkly  PG',
//             'quarter': '4',
//             'payDate1': '2017-10-20',
//             'periodStartDate1': '2017-10-07',
//             'periodEndDate1': '2017-10-15',
//             'periodStartDate2': '2017-10-07',
//             'periodEndDate2': '2017-10-16',
//             'benefitsCalcDate': '2017-10-16',
//             'benefitsDeductionReady': 'Y',
//             'days': '8',
//             'inputDate': '14-OCT-14'
//         }
//         sessionStorage.setItem('verifyInputData', JSON.stringify(verifyInputData));
//         fixture.detectChanges();
//     });

//     describe('killAllIntervals', () => {
//         it('all intervals hot', () => {
//             component.makeIntervalSub$ = Observable.create(() => {}).subscribe();

//             component.killAllIntervals();
//             expect(component.makeIntervalSub$.isStopped).toBe(true);
//         });
//     });

//     describe('interval calls', () => {
//         it('all ready in initial output', () => {
//             const data = {
//                 payGroup: {
//                     payrollGroupCode: 'KZ2'
//                 }
//             }
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();

//             spyOn(Observable, 'interval').and.returnValue(Observable.of());
//             store.dispatch(new AppActions.HAS_ACCESS(true));
//             store.dispatch(new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS(groups));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [
//                         { code: 'PXF', count: 5, status: 'R' },
//                         { code: 'ITC', count: 5, status: 'R' },
//                         { code: 'MTC', count: 5, status: 'R' },
//                         { code: 'ANC', count: 5, status: 'R' },
//                         { code: 'UNH', count: 5, status: 'R' },
//                         { code: 'TWM', count: 5, status: 'R' },
//                         { code: 'PPI', count: 5, status: 'R' },
//                         { code: 'WOH', count: 5, status: 'R' },
//                         { code: 'OST', count: 5, status: 'R' },
//                         { code: 'PTW', count: 5, status: 'R' },
//                         { code: 'PDD', count: 5, status: 'R' }
//                     ],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 2, status: 'R'}, {code: 'TER', count: 8, status: 'R'}]
//                     }, {
//                         code: 'HRS',
//                         links: [{code: 'REG', count: 0, status: 'R'}, {
//                             code: 'OTP',
//                             count: 8,
//                             status: 'R'
//                         }, {code: 'OTH', count: 0, status: 'R'}]
//                     }, {
//                         code: 'PAY', links: [ {code: 'MCP', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));

//             spyOn(store, 'dispatch').and.callThrough();

//             store.select(fromRoot.app_getKillInitialOutputInterval).subscribe((status: any) => {
//                 expect(status.miniTilesReady).toBeTruthy();
//                 expect(status.donutsReady).toBeFalsy();
//             });
//         });
//         it('miniTiles only call', () => {
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();
//             spyOn(store, 'dispatch').and.callThrough();
//             spyOn(Observable, 'interval').and.returnValue(Observable.of());

//             store.dispatch(new AppActions.HAS_ACCESS(true));
//             store.dispatch(new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS(groups));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [{
//                         code: 'PXF', count: 5, status: 'R'
//                     }],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'R'}, {code: 'TER', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));

//             store.select(fromRoot.app_getKillInitialOutputInterval).subscribe((status: any) => {
//                 expect(status.miniTilesReady).toBe(false);
//             });

//             store.dispatch(new AppActions.SUCCESS_MINI_TILES_ONLY({
//                 data: {
//                     miniTiles: [
//                         { code: 'PXF', count: 5, status: 'R' },
//                         { code: 'ITC', count: 5, status: 'R' },
//                         { code: 'MTC', count: 5, status: 'R' },
//                         { code: 'ANC', count: 5, status: 'R' },
//                         { code: 'UNH', count: 5, status: 'R' },
//                         { code: 'TWM', count: 5, status: 'R' },
//                         { code: 'PPI', count: 5, status: 'R' },
//                         { code: 'WOH', count: 5, status: 'R' },
//                         { code: 'OST', count: 5, status: 'R' },
//                         { code: 'PTW', count: 5, status: 'R' },
//                         { code: 'PDD', count: 5, status: 'R' }
//                     ]
//                 }
//             }));
//             store.select(fromRoot.app_getKillMiniTilesOnly).subscribe((status: any) => {
//                 expect(status).toBe(true);
//             });

//         });
//         it('donuts only call', () => {
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();
//             spyOn(store, 'dispatch').and.callThrough();
//             spyOn(Observable, 'interval').and.returnValue(Observable.of());
//             store.dispatch(new AppActions.HAS_ACCESS(true));
//             store.dispatch(new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS(groups));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [{
//                         code: 'PXF', count: 5, status: 'R'
//                     }],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'E'}, {code: 'TER', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));
//             store.select(fromRoot.app_getKillInitialOutputInterval).subscribe((status: any) => {
//                 expect(status.donutsReady).toBe(false);
//             });
//             store.dispatch(new AppActions.SUCCESS_DONUTS_ONLY({
//                 data: {
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'R'},
//                             {code: 'TER', count: 8, status: 'R'},
//                             {code: 'LOA', count: 0, status: 'R'},
//                             {code: 'REH', count: 0, status: 'R'},
//                             {code: 'XFR', count: 0, status: 'R'}]
//                     }, {
//                         code: 'HRS',
//                         links: [{code: 'REG', count: 0, status: 'R'},
//                             {code: 'OTP', count: 8, status: 'R'},
//                             {code: 'OTH', count: 0, status: 'R'}]
//                     }, {
//                         code: 'PAY', links: [{code: 'PDP', count: 0, status: 'R'}, {code: 'MCP', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));
//             store.select(fromRoot.app_getKillDonutsOnly).subscribe((status: any) => {
//                 expect(status).toBe(true);
//             });

//         });
//         it('nav changes', function() {
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();
//             spyOn(store, 'dispatch').and.callThrough();
//             spyOn(Observable, 'interval').and.returnValue(Observable.of());
//             store.dispatch(new AppActions.HAS_ACCESS(true));
//             store.dispatch(new AppActions.SUCCESS_GET_PROCESSING_PAY_GROUPS(groups));
//             store.dispatch(new AppActions.SUCCESS_GET_VERIFY_OUTPUT({
//                 data: {
//                     miniTiles: [{
//                         code: 'PXF', count: 5, status: 'R'
//                     }],
//                     donuts: [{
//                         code: 'WFC', links: [{code: 'NEH', count: 0, status: 'E'}, {code: 'TER', count: 8, status: 'R'}]
//                     }]
//                 }
//             }));
//             store.dispatch(new AppActions.LOAD_PAYGROUP({
//                 "processingGroupName": "PLGRP",
//                 "payGroup": {
//                     "payrollGroupCode": "ZE4",
//                     "payrollYear": "2018",
//                     "payrollWeekNumber": "04",
//                     "payrollRunNumber": "1"
//                 },
//                 "quarter": "1",
//                 "payDate1": "2018-01-26",
//                 "periodStartDate1": "2017-10-07",
//                 "periodEndDate1": "2017-10-15",
//                 "periodStartDate2": "2017-10-07",
//                 "periodEndDate2": "2017-10-16",
//                 "inputDate": "2017-10-16",
//                 "deductionGroups": "B",
//                 "cycleStatus": "1",
//                 "company": "MCF",
//                 "quickViewPayroll": "N"
//             }));
//             console.log(component.makeIntervalSub$);
//             expect(component.makeIntervalSub$.isActive).toBeUndefined();
//         });
//         it('calling ngOnDestroy', function() {
//             component.makeIntervalSub$ = Observable.create(() => {
//             }).subscribe();
//             store.dispatch(new AppActions.LOAD_PAYGROUP({
//                 "processingGroupName": "PLGRP",
//                 "payGroup": {
//                     "payrollGroupCode": "ZE4",
//                     "payrollYear": "2018",
//                     "payrollWeekNumber": "04",
//                     "payrollRunNumber": "1"
//                 },
//                 "quarter": "1",
//                 "payDate1": "2018-01-26",
//                 "periodStartDate1": "2017-10-07",
//                 "periodEndDate1": "2017-10-15",
//                 "periodStartDate2": "2017-10-07",
//                 "periodEndDate2": "2017-10-16",
//                 "inputDate": "2017-10-16",
//                 "deductionGroups": "B",
//                 "cycleStatus": "1",
//                 "company": "MCF",
//                 "quickViewPayroll": "N"
//             }));
//             component.ngOnDestroy();
//             expect(component.makeIntervalSub$.isStopped).toBeTruthy();
//         });
//     });
// });

