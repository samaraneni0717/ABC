const status = { count: 0 }
export const InitialState: any = {
    data: {
        miniTiles: [
            { code: 'ITC', ...status },
            { code: 'MTC', ...status },
            { code: 'TWM', ...status },
            { code: 'ANC', ...status },
            { code: 'UNH', ...status },
            { code: 'PXF', ...status },
            { code: 'PTW', ...status },
            { code: 'PDD', ...status },
            { code: 'PPI', ...status },
            { code: 'WOH', ...status },
            { code: 'OST', ...status },
            { code: 'OCC', ...status }
        ],
        donuts: [
            {
                code: 'HRS', links: [
                    { code: 'REG', ...status },
                    { code: 'OTP', ...status },
                    { code: 'OTH', ...status }
                ]
            },
            {
                code: 'PAY', links: [
                    { code: 'PDP', ...status },
                    { code: 'MCP', ...status }
                ]
            },

            {
                code: 'WFC', links: [
                    { code: 'NEH', ...status },
                    { code: 'TER', ...status },
                    { code: 'LOA', ...status },
                    { code: 'REH', ...status },
                    { code: 'XFR', ...status }
                ]
            },

            {
                code: 'PRC', links: [
                    { code: 'RTT', ...status}
                ]
            }
        ]
    }     
}

export const access_SectionsToFilter = {
    pd: {
        miniTiles: ['PPI', 'WOH', 'OST'],
        donuts: ['HRS', 'PAY']
    },
    offCycle: {
        miniTiles: ['OCC']
    }
}

export const MiniTileSections = {
    ITC: {
        name: 'Invalid Tax Codes',
        category: 'tax',
        order: 1
    },
    MTC: {
        name: 'Missing Tax Data',
        category: 'tax',
        order: 2
    },
    TWM: {
        name: 'Tax Withholding Mismatch',
        category: 'tax',
        order: 3
    },
    ANC: {
        name: 'Automatic Pay Not Cancelled',
        order: 4
    },
    UNH: {
        name: 'Pending New Hires',
        category: 'pending',
        order: 5
    },
    PXF: {
        name: 'Pending Transfers',
        category: 'pending',
        order: 6
    },
    PTW: {
        name: 'Pending Tax Changes',
        category: 'pending',
        order: 7
    },
    PDD: {
        name: 'Pending Direct Deposits',
        category: 'pending',
        order: 8
    },
    PPI: {
        name: 'Posted Pay for Inactives',
        category: 'paydataentry',
        order: 9
    },
    WOH: {
        name: 'Active Hourly Without Hours',
        category: 'paydataentry',
        order: 10
    },
    OST: {
        name: 'Reg Hours Over Standard',
        category: 'paydataentry',
        order: 11
    },
    OCC: {
        name: 'Off-Cycle Checks Not Posted',
        category: 'paydataentry',
        order: 12
    }


}

export const PayrollInputSections = {
    HRS: {
        name: 'Posted Hours',
        colors: ['#0e5061', '#1a8099', '#3ebede', '#89e3f9'],
        order: 1
    },
    PAY: {
        name: 'Posted Pays',
        colors: ['#3a004a', '#6a0084', '#530067', '#8100a1', '#972eb2', '#ae5cc2', '#c58bd3'],
        order: 2
    },
    WFC: {
        name: 'Workforce Changes',
        colors: ['#70032d', '#a40541', '#e70a5b', '#fd6fa5', '#ffa4cc'],
        order: 3
    },
    PRC: {
        name: 'Personnel Changes',
        colors: ['#073c2c', '#105542', '#1a8569', '#2adbad', '#7fe9ce', '#c0f2e9', '#d6e9e5'],
        order: 4
    }
    
}

export const PayrollInputCodes = {
    // Workforce Changes
    TER: 'Terminations',
    REH: 'Rehire',
    XFR: 'Transfers',
    LOA: 'Leave of Absence',
    NEH: 'New Hire',
    // Posted Hours
    REG: 'Regular',
    OTP: 'Overtime',
    OTH: 'Other',
    // Posted Pays
    PDP : 'Pay Data Entry',
    MCP: 'Manual Check',
    DDP: 'Direct Deposit',
    // Personnel Changes
    RTT: 'Rate Type',
    PRT: 'Rate'
}

const CoreHeaders = ['Name', 'Empl ID', 'File #', 'Pay Type', 'Work Location',  'Employee Record No'];
const securityMessage = 'The employees shown depend on your security access permissions.';
const batchIdNavMessage = ' Click the Batch ID to navigate to the batch.';
export const Details = {
    // MiniTile Details
    ITC: {
        headers: [...CoreHeaders, 'Tax Code Type', 'Invalid Tax Code'],
        instruction: 'Lists employees with one or more invalid tax codes. An invalid tax code can occur when an employee transfers into your pay group and the employee has a tax record with codes that are not set up for the pay group. Review the tax codes and either change the employee’s tax information or contact your ADP consultant to set up the tax code for your pay group. ' + securityMessage,
        componentId: 'InvalidTaxCodes'
    },
    MTC: {
        headers: [...CoreHeaders, 'Hire Date', 'File # Status'],
        instruction: 'Lists new or transferred employees effective within this pay period who have missing or incomplete tax data. ' + securityMessage,
        componentId: 'MissingTax'
    },
    ANC: {
        headers: [...CoreHeaders, 'Status'],
        title: 'Automatic Pay Not Cancelled',
        instruction: 'Lists terminated or transferred employees set up with automatic pay that do not have their automatic pay cancelled in a pay data batch. ' + securityMessage,
        componentId: 'AutoPayNoCancel'
    },
    UNH: {
        headers: [...CoreHeaders, 'Submitter Name', 'Approver Name', 'Effective Date'],
        instruction: 'Lists any new hires that are in progress. ' + securityMessage,
        componentId: 'PendHire'
    },
    PXF: {
        headers: [...CoreHeaders, 'Job', 'Manager', 'Submitter Name', 'Approver Name', 'Effective Date'],
        instruction: 'Lists any unassigned transfers within this pay group. Transfers that are currently pending in workflow do not display. ' + securityMessage,
        componentId: 'PendTransf'
    },
    PTW: {
        headers: [...CoreHeaders, 'Submitter Name', 'Approver Name', 'Effective Date'],
        instruction: 'Lists employees that have a tax withholding change pending in workflow with an effective date on or before the pay period end date. ' + securityMessage,
        componentId: 'PendTaxChanges'
    },
    PDD: {
        headers: [...CoreHeaders, 'Submitter Name', 'Approver Name', 'Effective Date'],
        instruction: 'Lists employees that have a direct deposit change pending in workflow with an effective date on or before the pay period end date. ' + securityMessage,
        componentId: 'PendDirectDep'
    },
    PPI: {
        headers: [...CoreHeaders,  'Empl Status',  'Batch ID', 'Batch Type', 'Pay #', 'Reg Hrs', 'O/T Hrs', 'Other Hrs',
         'Reg EARNS', 'O/T EARNS', 'Other EARNS'],
         title: 'Posted Pay for Inactive Employees',
        instruction: 'Lists posted pay data for inactive hourly employees. ' + securityMessage + batchIdNavMessage,
        componentId: 'PostPayInactive',
        enableBatchId: true
    },
    WOH: {
        headers: [...CoreHeaders, 'Manager', 'Hire Date'],
        title: 'Active Hourly Employees Without Hours',
        instruction: 'Lists active hourly employees without any hours in pay data entry. ' + securityMessage,
        componentId: 'ActiveHrlywoHrs'
    },
    TWM: {
        headers: [...CoreHeaders, 'Work State', 'Home State', 'Tax Code Type', 'Mismatched Tax Code'],
        title: 'Tax Withholding Mismatch',
        instruction: 'Lists active employees with Tax information that differs from their Work or Home State. ' + securityMessage,
        componentId: 'TaxWthhldMismatch'
    },
    OST: {
        headers: [...CoreHeaders, 'Manager', 'Batch ID', 'Batch Type', 'Pay Nbr', 'Payroll Standard Hrs', 'Posted Reg Hrs'],
        title: 'Reg Hours Over Standard',
        instruction: 'Lists posted regular hours that exceed standard hours for active hourly employees.  Any available payroll standard hours listed are from the employee’s job record. Otherwise, a derived value displays based on the employee’s pay frequency. ' + securityMessage + batchIdNavMessage,
        componentId: 'RegHrsOverStd',
        enableBatchId: true
    },
    OCC: {
        headers: [...CoreHeaders, 'Empl Status', 'Reason', 'Net Pay'],
        title: 'Off-Cycle Checks Not Posted',
        instruction: 'Lists any employees that currently have an off-cycle check calculated for this pay period, but not yet posted. ' + securityMessage,
        componentId: 'OffCycChksNotPosted'
    },
    // Donuts Details
    NEH: {
        headers: [...CoreHeaders, 'Hire Date', 'Date Entered', 'Job', 'Manager'],
        instruction: 'Lists any completed new hires effective within this pay period. ' + securityMessage,
        componentId: 'NewHire'
    },
    TER: {
        headers: [...CoreHeaders, 'Term Date', 'Status', 'Reason', 'Type'],
        instruction: 'Lists employees who have a Terminated payroll status during this pay period due to either termination of employment or transfer out of this pay group. ' + securityMessage,
        componentId: 'Terminations'
    },
    OTH: {
        headers: ['Code', 'Description', 'Field#', 'Hours'],
        title: 'Posted Other Hours (Hourly Employees)',
        instruction: 'Lists total hours by Hours Code for all hourly employees with pay data in batches that are included in the current cycle.',
        componentId: 'Other'
    },
    PDP: {
        headers: [...CoreHeaders,  'Empl Status',  'Batch ID', 'Batch Type', 'Pay #', 'Reg Hrs', 'O/T Hrs', 'Other Hrs',
         'Reg EARNS', 'O/T EARNS', 'Other EARNS'],
        instruction: 'Lists employee pay data entries for all batches included in the current pay period. ' + securityMessage,
        componentId: 'PayDataEntry',
        enableBatchId: false
    },
    MCP: {
        headers: [...CoreHeaders,  'Empl Status', 'Batch ID', 'Pay #', 'Check Nbr','Total Gross', 'Total Net'],
        instruction: 'Lists all posted manual checks for the current pay period. ' + securityMessage,
        componentId: 'ManCheck',
        enableBatchId: false
    },
    LOA: {
        headers: [...CoreHeaders, 'LOA Date', 'Date Entered'],
        instruction: 'Lists employees that were placed on Leave of Absence for this pay group this pay period. These employees currently have a Payroll Status of Leave of Absence. '+ securityMessage,
        componentId: 'LeaveAbsence'
    },
    REH: {
        headers: [...CoreHeaders, 'Rehire Date', 'Date Entered'],
        instruction: 'Lists employees that were rehired to this pay group for this pay period. '+ securityMessage,
        componentId: 'Rehires'
    },
    XFR: {
        headers: [...CoreHeaders, 'Transfer From', 'Transfer Date', 'Date Entered'],
        instruction: 'Lists completed transfers to this pay group for this pay period. ' + securityMessage,
        componentId: 'Transfers'
    },
    // Personnel Changes
    RTT: {
        headers: [...CoreHeaders, 'Old Rate Type', 'New Rate Type', 'Effective Date'],
        instruction: 'Lists employees with Rate Type changes effective for this pay period. '+ securityMessage,
        componentId: 'RateType'
    }
}

export const IntervalTime = 3000;

export const RightAlignmentFields  = ['stdHours', 'regHrs', 'otHrs',  'otherHrs', 'regEarns', 'otEarns', 'otherEarns', 'hours', 'grossPay', 'netPay'];

