import { Pipe, PipeTransform } from '@angular/core';
import * as Constants from '../constants/constants';

@Pipe({
  name: 'accessFilter'
})
export class AccessFilter implements PipeTransform {

  transform(data: any, hasAccess: any): any {
    let miniTiles = data.data.miniTiles;
    let donuts = data.data.donuts;

    if (hasAccess.data.paydataEntryInd === 'N') {
      miniTiles = accessFilter(miniTiles, 'pd', 'miniTiles');
      donuts = accessFilter(donuts, 'pd', 'donuts');
    }

    if (hasAccess.data.offCycleCheckInd === 'N') {
      miniTiles = accessFilter(miniTiles, 'offCycle', 'miniTiles');
    }
    return {
      data: {
        miniTiles,
        donuts
      }
    };
  }

}

function accessFilter(data: any, section: any, type: string) {
  if(data) {
    return data.filter(d => {
      if (Constants.access_SectionsToFilter[section][type].indexOf(d.code) === -1) {
        return d;
      }
    })
  }
}