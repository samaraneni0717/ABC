import { AccessFilter } from './filters/access-filter.pipe';
import { PreScrollDirective } from './components/proc-group-dropdown/directives/pre-scroll.directive';
import { AppService } from './services/app.service';

import { environment } from '../environments/environment.portal-prod';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';

// Angular
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {  NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PlatformLocation, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VanSlideinModule, VanSlideinService, VanModalModule, VanModalService} from '@van-genesis/van-genesis'
// Synerg Components - App
import { ButtonModule, 
         BusyIndicatorModule, 
         CheckboxModule, 
         AlertModule,
         TableModule } from '@synerg/components';
     
// NGRX
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './store/index';
import { AppEffects } from './store/effects/app.effects';
import { EffectsModule } from '@ngrx/effects';
// Remove in production
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

// App Components
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { SlideinComponent } from './components/slidein/slidein.component';
import { ModalComponent } from './components/modal/modal.component';
import { ProcGroupDropdownComponent } from './components/proc-group-dropdown/proc-group-dropdown.component';
import { ClickOutDirective } from './components/proc-group-dropdown/directives/click-out.directive';
import { InputFocusDirective } from './components/proc-group-dropdown/directives/input-focus.directive';
import { GridClickOutDirective } from './components/slidein/directives/grid.clickout.directive';
import { SearchFilter } from './components/proc-group-dropdown/filters/search-filter.pipe';
import { SearchHighlight } from './components/proc-group-dropdown/filters/search-highlight.pipe';


// Wijmo Modules
import { WjGridModule } from 'wijmo/wijmo.angular2.grid';
import { WjGridFilterModule } from 'wijmo/wijmo.angular2.grid.filter';
import { WjCoreModule } from 'wijmo/wijmo.angular2.core';
import { WjChartModule } from 'wijmo/wijmo.angular2.chart';
import { WjInputModule } from 'wijmo/wijmo.angular2.input';


// Feature Modules
import { PaydataBatchesModule } from './features/paydata-batches/paydata-batches.module';
import { PayrollInputsModule } from './features/payroll-inputs/payroll-inputs.module';
import { NeedsReviewModule } from './features/needs-review/needs-review.module';

import { PaydataBatchesEffects } from "./features/paydata-batches/store/effects/paydata-batches.effects";

let dev = [];
/* istanbul ignore next */
if(!environment.removeReduxTools){
    dev.push(StoreDevtoolsModule.instrument({
        maxAge: 25
    }));
}

@NgModule({
    declarations: [
        AppComponent,
        HeaderComponent,
        SlideinComponent,
        ModalComponent,
        ProcGroupDropdownComponent,
        ClickOutDirective,
        GridClickOutDirective,
        InputFocusDirective,
        PreScrollDirective,
        SearchFilter,
        AccessFilter,
        SearchHighlight
    ],
    imports: [
        BrowserAnimationsModule,
        BrowserModule,
        HttpClientModule,
        ButtonModule,
        CheckboxModule,
        AlertModule,
        BusyIndicatorModule,
        StoreModule.forRoot(reducers, {metaReducers}),
        EffectsModule.forRoot([AppEffects, PaydataBatchesEffects]),
        NeedsReviewModule,
        PayrollInputsModule,
        PaydataBatchesModule,
        VanSlideinModule,
        VanModalModule,
        WjGridModule,
        WjGridFilterModule,
        WjCoreModule, 
        WjInputModule,
        WjChartModule,
        TableModule,
        FormsModule,
        dev
    ],
    providers: [
        AppService,
        VanSlideinService, 
        VanModalService,
        DatePipe,
        AccessFilter,
        // For portal, you will need this in order to avoid memory leaks
        {provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService}
    ],
    bootstrap: [AppComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    entryComponents: [SlideinComponent, ModalComponent]

})
export class AppModule {

}
