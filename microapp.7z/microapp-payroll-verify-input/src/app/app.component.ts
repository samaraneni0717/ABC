import { OutputParams } from './model/output-params.interface';
import { Header } from './model/header.interface';
import { AppService } from './services/app.service';
import { Component, OnDestroy, ViewEncapsulation, OnInit, ChangeDetectionStrategy } from '@angular/core';

import { PlatformLocation, DatePipe } from '@angular/common';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';
import { Store } from '@ngrx/store';
import * as AppActions from './store/actions/app.actions';
import * as PayDataActions from './features/paydata-batches/store/actions/paydata-batches.actions';
import * as fromRoot from './store/index';
import * as Constants from './constants/constants';

import { switchMap, tap, mergeMap, map, takeUntil } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

/* Don't check in the below code uncommented.
   Uncomment when launching as standalone application
*/
declare var document: any;

//start of test data
/*const verifyInputData = {
  'type': 'Pay Group',
  'payGroup': {
    'payrollGroupCode': 'GD2',
    'payrollYear': '2017',
    'payrollWeekNumber': '42',
    'payrollRunNumber': '1'
  },
  'processingGroupName': 'adsfasdf',
  'description': 'Kaizen &K Other Wkly  PG',
  'quarter': '4',
  'payDate1': '2017-10-20',
  'periodStartDate1': '2017-10-07',
  'periodEndDate1': '2017-10-15',
  'periodStartDate2': '2017-10-07',
  'periodEndDate2': '2017-10-16',
  'benefitsCalcDate': '2017-10-16',
  'benefitsProcessed': 'Y',
  'days': '0',
  'inputDate': '14-OCT-14',
  'deductionGroups': 'ABCDEGIR',
  'company': 'MCF'

}
sessionStorage.setItem('verifyInputData', JSON.stringify(verifyInputData));*/
// end of test data

@Component({
  selector: 'app-microapp-payroll-verify-input-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnDestroy, OnInit {

  headerData$: Observable<Header>;
  isLandingPageLoading$: Observable<boolean>;
  isSlideInOpen$: Observable<boolean>;

  isBenefitsCheckComplete$: Observable<boolean>;
  isProcGroupDropdownEnabled$: Observable<boolean>;
  isProcGroupDropdownError$: Observable<boolean>;
  loadPayGroup$: Observable<boolean>;
  isPermissionCallError$: Observable<boolean>;

  makeIntervalSub$: any;
  navSubscription: any;
  storeSubscriptionEntryGroupCall: any;
  headerDataSubscriptionCall : any;
  alertTitle: any;
  alertType: any;
  dueDays: number;
  dueDate : any;


  constructor(
    private platformLocation: PlatformLocation,
    private datePipe: DatePipe,
    private store: Store<fromRoot.State>,
    private appService: AppService
  ){
  }
  killAllIntervals(){
    // scroll bar issue fix
      /* istanbul ignore next */
    if (document.getElementsByClassName('revolution')[0]) {
      document.getElementsByClassName('revolution')[0].style.overflow = '';
    }
    if (this.makeIntervalSub$){
      this.makeIntervalSub$.unsubscribe();
    }
    console.log('All intervals stopped');
  }
  ngOnInit() {
    
    this.headerData$ = this.store.select(fromRoot.app_getHeaderData);
    this.isLandingPageLoading$ = this.store.select(fromRoot.app_isLandingPageLoading);
    this.isSlideInOpen$ = this.store.select(fromRoot.app_isSlideInOpen);
    this.isBenefitsCheckComplete$ = this.store.select(fromRoot.app_isBenefitsCheckComplete);
    this.isProcGroupDropdownEnabled$ = this.store.select(fromRoot.app_isProcGroupDropdownEnabled);
    this.isProcGroupDropdownError$ = this.store.select(fromRoot.app_isProcGroupDropdownError);
    this.isPermissionCallError$ = this.store.select(fromRoot.app_isPermissionCallError);

    /* istanbul ignore else */
    if (sessionStorage.getItem('verifyInputData')) {
      
      const sessionData = JSON.parse(sessionStorage.getItem('verifyInputData'));
      console.log('Session Data ------> ', sessionData);
      sessionStorage.removeItem('verifyInputData');
      this.store.dispatch(new AppActions.SET_SESSION_DATA(sessionData));
      // type is Pay Group make normal call
      if(sessionData.type === 'Pay Group'){
        this.makeIntervalCall(sessionData);
      } else {
        //if type is group then enable proc group dropdown
        this.store.dispatch(new AppActions.PROC_GROUP_DROPDOWN_ENABLED());
        //get the payroll group list
        this.store.dispatch(new AppActions.START_GET_PROCESSING_PAY_GROUPS(sessionData));

        //waiting on list and when ready making the call.. only need to do this for the first call so unsubscribing immediately after starting intervals
        this.storeSubscriptionEntryGroupCall = this.store.select(fromRoot.app_getProcessingPayGroups).subscribe( (groups) => {
          
          if(groups){
           let selected = groups.list.filter((group: any) =>
              group.payGroup.payrollGroupCode === sessionData.payGroup.payrollGroupCode)[0];
           this.makeIntervalCall(selected || groups.firstEnabled);
           this.storeSubscriptionEntryGroupCall.unsubscribe();
          }
          
        });
        //observable listening for nav changes unsubscribing from this in the on destroy
        this.navSubscription = this.store.select(fromRoot.app_loadPayGroup).subscribe((payGroup) => {
          if (payGroup) {
            this.store.dispatch(new AppActions.SET_SESSION_DATA(payGroup));
            this.killAllIntervals();
            this.makeIntervalCall(payGroup);
          }
        }); 
      }  
    }

    this.headerDataSubscriptionCall = this.store.select(fromRoot.app_getHeaderData).subscribe((headerInfo: any) => {
      if(headerInfo){
         this.dueDays = headerInfo.days;
         this.dueDate = headerInfo.inputDate;
         if(this.dueDays && this.dueDate){
          let inputDate =  this.datePipe.transform(this.dueDate, 'MMMM d');
          if (this.dueDays < 0){
           this.alertType = 'error';
           this.alertTitle = "Payroll was due on " + inputDate;
         } else if(this.dueDays == 0){
           this.alertType = 'warning';
           this.alertTitle = "Payroll is due today";
         } else if (this.dueDays == 1){
           this.alertType = 'warning';
           this.alertTitle = "Payroll is due in " + this.dueDays+ " day on " +inputDate;
         } else if (this.dueDays == 2){
           this.alertType = 'warning';
           this.alertTitle = "Payroll is due in " + this.dueDays+ " days on " +inputDate;
         } else if (this.dueDays > 2){
           this.alertType = 'success';
           this.alertTitle = "Payroll is due in " + this.dueDays+ " days on " +inputDate;
         } 
        }
        
      }
     });
  }

  ngOnDestroy() {
    console.log('destroying AppComponent');
    (<BetterPlatformBrowserLocationService> this.platformLocation).onDestroy();
    this.killAllIntervals();
    this.headerDataSubscriptionCall.unsubscribe();
    //cleaning up processing group subscription
    if(this.navSubscription){
      this.navSubscription.unsubscribe();
    }
  }

  makeIntervalCall(data: any){
    const output$ = new Subject();
    const tiles$ = new Subject();
    const donuts$ = new Subject();
    
    const paygroup: OutputParams = { paygroup: data.payGroup.payrollGroupCode };
    this.store.dispatch(new AppActions.START_GET_PERMISSIONS(data));
    this.store.dispatch(new AppActions.SET_PAYGROUP(data));
    this.makeIntervalSub$ = this.store.select(fromRoot.app_hasAccess)
      .pipe(
        switchMap((hasAccess: any) => {
          
            if(hasAccess !== undefined){
              
              //if PD access make pd call else set PD to empty array
              if(hasAccess.data.paydataEntryInd === 'Y'){
                this.store.dispatch(new PayDataActions.START_GET_PAYDATA_BATCHES(paygroup));
              } else {
                this.store.dispatch(new PayDataActions.SUCCESS_GET_PAYDATA_BATCHES([]));
              }

              //setting limit for interval call 
              this.store.dispatch(new AppActions.SET_LIMIT(hasAccess));

              //get benefits call
              this.store.dispatch(new AppActions.START_GET_HEADER_DATA(data));
              this.store.dispatch(new AppActions.START_SET_INITIAL_STATE(Constants.InitialState));
              //start an interval stream
              return Observable
                //using timer to emit immediately and then at an interval
                .timer(0, Constants.IntervalTime)
                .pipe(
                  //take until subject returns false
                  takeUntil(output$),
                  //in parallel with the stream dispatch the action
                  tap(() => this.store.dispatch(new AppActions.START_GET_VERIFY_OUTPUT(paygroup))),
                  //invoke the inner observable and map that response 
                  switchMap(() => this.store.select(fromRoot.app_getKillInitialOutputInterval)),
                  map((status: any) => {
                    // if output status is ready then call subject and kill output then if needing to switch to miniTiles or Donuts only 
                    // start those intervals
                    if (status.killInitialOutputInterval) {
                      console.log(`%c ----------------- Initial Output Interval Unsubscribing -----------------`, 'color: #00FFC5');
                      console.log('STATUS -> ', status);
                      output$.next(false);
                      if (!status.miniTilesReady || !status.donutsReady){
                        console.log(`%c ----------------- Starting Indv Intervals -----------------`, 'color: #00FFC5');
                        return true;
                      } else {
                        this.makeIntervalSub$.unsubscribe();
                        console.log(`%c ----------------- makeIntervalSub Unsubscribing -----------------`, 'color: #00FFC5');
                      }   
                    }

                  }),
                  switchMap((start) => {
                  /* istanbul ignore next */
                    if (start) {
                      //zip starts the observables in parallel and returns a result together but ive attached a subject to each to kill 
                      //off the observable when completed
                      return Observable.zip(...[

                        Observable
                          .interval(Constants.IntervalTime)
                          .takeUntil(tiles$)
                          .pipe(
                            tap(() => this.store.dispatch(new AppActions.START_GET_VERIFY_OUTPUT({ ...paygroup, miniTilesOnly: true }))),
                            mergeMap( () => this.store.select(fromRoot.app_getKillMiniTilesOnly)),
                            tap( (status) => { if(status) { 
                              console.log(`%c ----------------- Tiles Only Unsubscribing -----------------`, 'color: #00FFC5');
                              tiles$.next(false);
                            }})
                          ),

                        Observable
                          .interval(Constants.IntervalTime)
                          .takeUntil(donuts$)
                          .pipe(
                            tap(() => this.store.dispatch(new AppActions.START_GET_VERIFY_OUTPUT({ ...paygroup, donutsOnly: true }))),
                            mergeMap(() => this.store.select(fromRoot.app_getKillDonutsOnly)),
                            tap((status) => { if (status) { 
                              console.log(`%c ----------------- Donuts Only Unsubscribing -----------------`, 'color: #00FFC5');
                              donuts$.next(false);         
                            }})
                          )

                      ])
                      .flatMap( (status) => Observable.of({tiles: status[0], donuts: status[1]}))
                    } else {
                      return Observable.of();
                    }
                  })
                )

            } else {
              return Observable.of();
            }
        })
      ).subscribe((status: any) => {
        /* istanbul ignore next */
        if (status.tiles && status.donuts){
          this.makeIntervalSub$.unsubscribe();
          console.log(`%c ----------------- makeIntervalSub Unsubscribing -----------------`, 'color: #00FFC5');
        }
      });



  }

}
