import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JpShellComponent } from '../containers/jp-shell/jp-shell.component';
import { SharedModule } from 'src/app/shared/modules/shared.module';
import { JpCreateComponent } from '../components/jp-create/jp-create.component';
import { UtilityModule } from 'src/app/utility/modules/utility.module';
import { JpGridComponent } from '../components/jp-grid/jp-grid.component';

const dashBoardRoutes: Routes = [{ path: '', component: JpShellComponent }];
@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(dashBoardRoutes),
    UtilityModule
  ],
  declarations: [JpShellComponent, JpCreateComponent, JpGridComponent],
  entryComponents: [JpCreateComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DashboardModule {}
