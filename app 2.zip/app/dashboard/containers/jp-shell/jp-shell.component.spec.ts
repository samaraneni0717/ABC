import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JpShellComponent } from './jp-shell.component';

describe('JpShellComponent', () => {
  let component: JpShellComponent;
  let fixture: ComponentFixture<JpShellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JpShellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JpShellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
