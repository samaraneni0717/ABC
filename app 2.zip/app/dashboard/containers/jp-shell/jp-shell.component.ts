import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { JpCreateComponent } from '../../components/jp-create/jp-create.component';
import { ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'jp-shell',
  templateUrl: './jp-shell.component.html',
  styleUrls: ['./jp-shell.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class JpShellComponent implements OnInit {
  showCreate = false;
  showSlidein = false;
  showShell = true;
  constructor(private dialog: MatDialog) {}

  ngOnInit() {}

  openDialog(): void {
    this.showCreate = true;
    const dialogRef = this.dialog.open(JpCreateComponent, {
      width: '850px'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.showCreate = false;
    });
  }

  closeSlidein() {
    this.showSlidein = false;
  }
  openSlidein() {
    this.showSlidein = true;
  }
}
