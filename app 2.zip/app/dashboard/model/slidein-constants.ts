import {
  animate,
  trigger,
  transition,
  style,
  state
} from '@angular/animations';
import { AnimationTriggerMetadata } from '@angular/animations';

export const SLIDE_IN_ANIMATIONS: AnimationTriggerMetadata[] = [
  trigger('destroyAnimation', [
    state(
      '*',
      style({
        transform: 'translateY(0)',
        opacity: 1,
        'z-index': 1041,
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%'
      })
    ),
    transition('* => void', [
      animate('0.35s ease-in', style({ transform: 'translateX(100%)' }))
    ])
  ])
];

export const SLIDE_IN_HOST_BINDINGS = {
  '[@destroyAnimation]': 'true',
  class: 'vdl-slide-in-mount'
};
