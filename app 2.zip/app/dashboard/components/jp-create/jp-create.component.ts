import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';

@Component({
  selector: 'jp-create',
  templateUrl: './jp-create.component.html',
  styleUrls: ['./jp-create.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('slideLeft', [
      state('in', style({ transform: 'translateX(20%)' })),
      transition('void => *', [
        style({ transform: 'translateX(100%)' }),
        animate(1000)
      ]),
      transition('* => void', [
        animate(1000, style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})
export class JpCreateComponent implements OnInit {
  // @HostBinding('@.disabled') disabled = true;
  jpForm: FormGroup;
  degrees: string[] = [
    'High School Diploma or Equivalent(GED)',
    'Assciates',
    'Bachelors',
    'Masters',
    'Ph.D'
  ];
  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.jpForm = this.fb.group({
      jobCode: ['', [Validators.required, Validators.maxLength(50)]],
      jobTitle: ['', [Validators.required, Validators.email]]
    });
  }
}
