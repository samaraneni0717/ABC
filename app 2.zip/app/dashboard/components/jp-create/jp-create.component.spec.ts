import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JpCreateComponent } from './jp-create.component';

describe('JpCreateComponent', () => {
  let component: JpCreateComponent;
  let fixture: ComponentFixture<JpCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JpCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JpCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
