import { Component, OnInit, Output, EventEmitter } from '@angular/core';

export interface GridColumn {
  // color: string;
  cols: number;
  // rows: number;
  text: string;
}
@Component({
  selector: 'jp-grid',
  templateUrl: './jp-grid.component.html',
  styleUrls: ['./jp-grid.component.scss']
})
export class JpGridComponent implements OnInit {
  @Output() itemEdited = new EventEmitter<boolean>();
  displayColumnList: GridColumn[] = [
    { text: 'Job Code', cols: 2 },
    { text: 'Job Title', cols: 2 }
    // { text: 'Reports to', cols: 2 }
  ];
  displayColumnListValues: any[] = [
    { jobTitle: 'Software Engineer', jobCode: '09C126' },
    {
      jobTitle: 'Civil Engineer',
      jobCode: '19C1267'
      //    reportsTo: 'Construction Dept.'
    },
    {
      jobTitle: 'Chemical Engineer',
      jobCode: '09C126'
      //   reportsTo: 'Chemical Dept.'
    },
    {
      jobTitle: 'Mechanical Engineer',
      jobCode: '09C128'
      //    reportsTo: 'Auto Dept.'
    },
    {
      jobTitle: 'Programmer Analyst',
      jobCode: '187UIO'
      //   reportsTo: 'IT Dept.'
    },
    {
      jobTitle: 'Business Analyst',
      jobCode: '187UI1'
      //   reportsTo: 'Administrative Dept.'
    },
    {
      jobTitle: 'Director of Product Development',
      jobCode: '187WYO'
      //   reportsTo: '-'
    }
  ];

  constructor() {}

  ngOnInit() {}

  editItem() {
    this.itemEdited.emit(true);
    console.log('Item edited');
  }
}
