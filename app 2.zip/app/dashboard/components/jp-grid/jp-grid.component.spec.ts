import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JpGridComponent } from './jp-grid.component';

describe('JpGridComponent', () => {
  let component: JpGridComponent;
  let fixture: ComponentFixture<JpGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JpGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JpGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
