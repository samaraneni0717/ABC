import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// NGRX Effects
import { EffectsModule } from '@ngrx/effects';

// NGRX Store
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

// Feature Modules
import { UtilityModule } from './utility/modules/utility.module';
import { SharedModule } from './shared/modules/shared.module';
import { DashboardModule } from './dashboard/modules/dashboard.module';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    UtilityModule,
    SharedModule,
    DashboardModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({}),
    EffectsModule.forRoot([]),
    // Helps in tooling when used with REDUX extension on chrome
    StoreDevtoolsModule.instrument({
      name: 'JOB PROFILES APP DEV TOOLS',
      maxAge: 25 // Amount of actions to be retained in the chrome devTools with the oldest being removed once the age is reached
      //  logOnly: environment.production // when set to true disables all features like time travel debugging excluding logging
    })
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule {}
