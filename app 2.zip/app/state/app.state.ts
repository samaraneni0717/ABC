// Representation of the entire ApplicationState
export interface AppState {
  test: string;
}
