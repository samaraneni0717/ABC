import {enableProdMode, NgModuleRef, ApplicationRef} from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment.dev';

if (environment.production) {
  enableProdMode();
}

declare var wrapper: any;
declare var window: any;

const bootstrapApp = function() {
  console.log('Zone: Ready. Bootstrapping app (non-AOT)');

  const platform = platformBrowserDynamic();
  platform.bootstrapModule(AppModule).then((ref: NgModuleRef<AppModule>) => {

    if (environment.prepareForPortal) {

    if (typeof wrapper !== 'undefined') {
      wrapper.setApplicationComponentNode(ref, platform);
    }
  }

  });
};



// the portal build environments exclude zonejs from the bundle, so we need to
// load it on demand (if it hasn't been loaded yet)
// if (environment.prepareForPortal) {
//   // checks for Zone JS and bootstraps app only once it exists
//   let loadInterval = function () {
//
//     var tmp = setInterval(function () {
//       if (window['Zone'] !== undefined) {
//         console.log('Zone: is done loading');
//
//         delete window['ZoneLoading'];
//         bootstrapApp();
//         clearInterval(tmp);
//       }
//     }, 200);
//   };
//
//   // Loads Zone if is hasn't been (and isn't in the process of being) loaded
//   if (window['ZoneLoading']) {
//     console.log('Zone: is already loading');
//     loadInterval();
//   } else {
//     console.log('Zone: is not loading. See if it exists');
//     if (window['Zone'] === undefined) {
//       console.log('Zone: does not exist');
//       window['ZoneLoading'] = true;
//       let prefix = '';
//       if (window.VANTAGE_ENV) {
//         prefix = '/smicro/microapp-worker/vantage/' + window.VANTAGE_ENV;
//       }
//
//       // dynamically add the zonejs bundle to the page
//       console.log('Zone: loading via script tag');
//
//       var zonejs = document.createElement('script');
//       zonejs.setAttribute('src', prefix + '/zone.min.js');
//       document.head.appendChild(zonejs);
//       loadInterval();
//     }
//   }
// } else {
  // don't have to wait for zonejs, so just bootstrap as normal
  bootstrapApp();
// }