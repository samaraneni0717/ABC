import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/timeoutWith';
import { IEda, ITemplate, IUploadStatus, IUploadHistory, IErrorHistory } from './eda';
@Injectable()

export class EdaService {

    private _edaUrl = '/taasgateway/api/eda';
    private _edaStaticUrl = '/smicro/eda-ui-app/1/taas/assets/';


    constructor(private _http: HttpClient) { }

    uploadEdaFile(jsonData: any): Observable<any> {
        const header: HttpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
        return this._http.post(this._edaUrl, jsonData, { headers: header })
            .map(res => {
                return res;
            })._catch(this.handleError);
    }

    getUploadStatus(AttchmentID: number): Observable<IUploadStatus> {
        return this._http.get<IUploadStatus>(this._edaUrl + '/getUploadStatus/' + AttchmentID).map(data => {
            return data;
        })._catch(this.handleError);
    }

    getUploadHistory(): Observable<IUploadHistory[]> {

        return this._http.get<IUploadHistory[]>(this._edaUrl + '/getUploadHistory').map(data => {

            return data;
        })._catch(this.handleError);
    }

    getErrorHistory(AttachmentID: number): Observable<IErrorHistory[]> {

        return this._http.get<IErrorHistory[]>(this._edaUrl + '/getErrorHistory/' + AttachmentID).map(data => {

            return data;
        })._catch(this.handleError);
    }

    UpdateUserReview(AttachmentID: number): Observable<any> {

        return this._http.put(this._edaUrl + '/UpdateUserReview/' + AttachmentID, '').map(data => {
            return data;
        })
            ._catch(this.handleError);
    }

    downloadEdaTemplates(selectedTemplates: ITemplate[]): Observable<IEda> {
        const arraybuffer: any = 'arraybuffer';
        let downloadFilesObservables: any[] = [];
        for (let index in selectedTemplates) {
            if (selectedTemplates[index].isCurrentTemplate) {
                if (selectedTemplates[index].category == 'Employee') {
                    const empHeader: HttpHeaders = new HttpHeaders().set('DefinitionType', 'employee');
                    downloadFilesObservables.push(this._http.get<IEda>(this._edaUrl, { headers: empHeader }).map(data => {
                        let edaCurrEmplObj: IEda = {} as IEda;
                        edaCurrEmplObj.filename = '';
                        edaCurrEmplObj.filedata = atob(data.filedata);
                        return edaCurrEmplObj;
                    }));
                }
                else {
                    const sysHeader: HttpHeaders = new HttpHeaders().set('DefinitionType', 'system');
                    downloadFilesObservables.push(this._http.get<IEda>(this._edaUrl, { headers: sysHeader }).map(data => {
                        let edaCurrSysObj: IEda = {} as IEda;
                        edaCurrSysObj.filename = '';
                        edaCurrSysObj.filedata = atob(data.filedata);
                        return edaCurrSysObj;
                    }));
                }

            }
            else {
                downloadFilesObservables.push(this._http.get<IEda>(this._edaStaticUrl + selectedTemplates[index].name, { responseType: arraybuffer }).map(data => {
                    let edaSampleObj: IEda = {} as IEda;
                    edaSampleObj.filename = '';
                    edaSampleObj.filedata = data;
                    return edaSampleObj;
                }));

            }
        }

        return Observable.forkJoin(downloadFilesObservables
        ).map((data: any[]) => {
            return data;
        })
            .catch(this.handleError);
    }


    private handleError(err: HttpErrorResponse) {
        return Observable.throw(err.message);
    }

}
