export interface IUploadEda {
    filename: string;
    data: string[];
}

export interface IEda {
    filename: string;
    filedata: any;
}

export interface ITemplate {
    title: string;
    description: string;
    id: number;
    isCurrentTemplate: boolean;
    category: string;
    name: string;
}

// Interface to validate rules status with exact reason for failure
export interface IRule {
    isvalidRuleFile: boolean;
    warningMssg: string;
    isSystemRule: boolean;
}

// Interface to get the upload status of file upload
export interface IUploadStatus {
    FILENAME: string;
    STATUS: string;
    PROGRESS: number;
}

// Interface to get the upload file history
export interface IUploadHistory {
    AOID: string;
    ATTACHMENTID: number;
    DEFINITIONTYPE: string;
    DESCRIPTION: string;
    FILENAME: string;
    CREATIONDATE: string;
    FILESIZE: number;
}

//Interface to get error history
export interface IErrorHistory {
    ATTACHMENTID: number;
    FILENAME: string;
    AOID: string;
    CREATIONDATE: string;
    DEFINITIONTYPE: string;
    DESCRIPTION: string;
    TOTALBLOCKS: string;
    PROCESSEDBLOCKS: string;
    ERRORSWARNINGS: IErrorsWarnings[];
}

//Interface for errors/ warnings
export interface IErrorsWarnings {
    STATUS: string;
    RANK: string;
    REMARKS: string;

}
