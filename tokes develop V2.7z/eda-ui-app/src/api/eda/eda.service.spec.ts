import { EdaService } from './eda.service';
import { IEda, IUploadEda, ITemplate, IUploadStatus, IUploadHistory } from './eda';
import { TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('EDaServiceTest', () => {
  const mockApiUrl = '/taasgateway/api/eda';
  const staticEmpMockApiUrl = '/smicro/eda-ui-app/1/taas/assets/SampleEmployeeDataTemplate.xlsx';
  beforeEach(() => {
    //  set up the test environment
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [
        EdaService
      ]
    });
  });

  afterEach(inject([HttpTestingController], (backend: HttpTestingController) => {
    // to make sure all request urls are matched
    backend.verify();
  }));

  it('UploadEdaFile :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      let jsonData: any = { 'filename': 'EDAExample', 'attamentdata': { 'data': ['U1JDX0FCU'] } };
      tick(2000);
      service.uploadEdaFile(jsonData).subscribe((next) => {
        expect(next).toBeTruthy();
      });
      backend.expectOne(mockApiUrl).flush(null, { status: 200, statusText: 'Ok' });
    })));

  it('UploadEdaFile :Service returns to catch with exception to be defined', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      let jsonData: any = { 'filename': 'EDAExample', 'data': ['U1JDX0FCU'] };
      tick(2000);
      service.uploadEdaFile(jsonData).subscribe((next) => { }
        , next => {
          expect(next).toBeDefined();
        });
      backend.expectOne(mockApiUrl).flush(null, { status: 400, statusText: 'NotFound' });

    })));

  it('GetUploadStatus :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      tick(2000);
      service.getUploadStatus(123).subscribe((next) => {
        expect(next).toBeDefined();
      });
      backend.expectOne(mockApiUrl + '/getUploadStatus/' + 123).flush(null, { status: 200, statusText: 'Ok' });
    })));

  it('GetUploadHistory :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      tick(2000);
      service.getUploadHistory().subscribe((next) => {
        expect(next).toBeDefined();
      });
      backend.expectOne(mockApiUrl + '/getUploadHistory').flush(null, { status: 200, statusText: 'Ok' });
    })));


    it('GetErrorHistory :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
      (service: EdaService, backend: HttpTestingController) => {
        tick(2000);
        service.getErrorHistory(123).subscribe((next) => {
          expect(next).toBeDefined();
        });
        backend.expectOne(mockApiUrl + '/getErrorHistory/' + 123).flush(null, { status: 200, statusText: 'Ok' });
      })));

  it('UpdateUserReview :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      tick(2000);
      service.UpdateUserReview(123).subscribe((next) => {
        expect(next).toBeDefined();
      });
      backend.expectOne(mockApiUrl + '/UpdateUserReview/' + 123).flush(null, { status: 200, statusText: 'Ok' });
    })));

  it('downloadEdaTemplateFile:Current Template:employee :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      let selectedTemplates: ITemplate[] = [
        {
          title: 'Current Employee Data Assignment Configuration',
          description: 'Select this employee data template to download the current Employee Data Assignment configuration.',
          id: 2, isCurrentTemplate: true, category: 'Employee', name: 'CurrentEmployeeDataTemplate.csv'
        }];
      tick(2000);
      service.downloadEdaTemplates(selectedTemplates).subscribe((next) => {
        expect(next).toBeDefined();
      });
      backend.expectOne(mockApiUrl).flush({ 'filename': 'test', 'filedata': '123' }, { status: 200, statusText: 'FileFound' });
    })));

  it('downloadEdaTemplateFile:Current Template:System :Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      let selectedTemplates: ITemplate[] = [
        {
          title: 'Current System Configuration Template',
          description: 'Select this system configuration template to download the current system configuration parameters.',
          id: 4, isCurrentTemplate: true, category: 'System', name: 'CurrentSystemConfigurationTemplate.csv'

        }
      ];
      tick(2000);
      service.downloadEdaTemplates(selectedTemplates).subscribe((next) => {
        expect(next).toBeDefined();
      });
      backend.expectOne(mockApiUrl).flush({ 'filename': 'test', 'filedata': '123' }, { status: 200, statusText: 'FileFound' });
    })));

  it('downloadEdaTemplateFile:Sample Template::Service returns ok with 200 response', fakeAsync(inject([EdaService, HttpTestingController],
    (service: EdaService, backend: HttpTestingController) => {
      let selectedTemplates: ITemplate[] = [
        {
          title: 'Sample Employee Data Template',
          description: 'Select this employee data template to download a blank .csv file to begin your data translation work in mapping the Employee Data Assignments.',
          id: 1, isCurrentTemplate: false, category: 'Employee', name: 'SampleEmployeeDataTemplate.xlsx'
        }
      ];
      tick(2000);
      service.downloadEdaTemplates(selectedTemplates).subscribe((next) => {
        expect(next).toBeDefined();
      });
      let buffer = new ArrayBuffer(8);
      backend.expectOne(staticEmpMockApiUrl).flush(buffer, { status: 200, statusText: 'FileFound' });
    })));
});



