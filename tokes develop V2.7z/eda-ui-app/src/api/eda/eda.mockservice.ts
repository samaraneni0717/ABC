import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/timeoutWith';
import 'rxjs/add/observable/of';
import { IEda, ITemplate, IUploadStatus, IUploadHistory, IErrorHistory, IErrorsWarnings } from './eda';
@Injectable()

export class EdaMockService {

    uploadEdaFile(jsonData: any): Observable<any> {
        let obj: any = JSON.parse(jsonData);
        if (obj.filename == 'valid')
            return Observable.of({});
        else
            return Observable.throw('invalid');
    }

    getUploadHistory(): Observable<IUploadHistory[]> {
        let res = {} as IUploadHistory;
        res.DESCRIPTION = 'NEEDSREVIEW';
        res.ATTACHMENTID = 2;
        res.CREATIONDATE = '09/13/1989';
        let res1 = {} as IUploadHistory;
        res1.ATTACHMENTID = 1;
        res1.DESCRIPTION = 'REQUESTED';
        res1.CREATIONDATE = '10/13/1989';
        let resp: IUploadHistory[] = [res, res1];
        return Observable.of(resp);
    }


    getErrorHistory(AttchmentID: number): Observable<IErrorHistory[]> {
        if (AttchmentID == 310) {
            let res = {} as IErrorHistory;
            res.AOID = '';
            res.ATTACHMENTID = 2;
            res.CREATIONDATE = '13/09/1989';
            res.DEFINITIONTYPE = 'system';
            res.DESCRIPTION = '';
            let err = {} as IErrorsWarnings;
            err.RANK = '1';
            err.REMARKS = "failure";
            let errArr: IErrorsWarnings[] = [err];
            res.ERRORSWARNINGS = errArr;
            res.FILENAME = '';
            res.PROCESSEDBLOCKS = '310';
            res.TOTALBLOCKS = '535';
            let resp: IErrorHistory[] = [res];
            return Observable.of(resp);
        }
        if (AttchmentID == 535) {
            let res = {} as IErrorHistory;
            res.AOID = '';
            res.ATTACHMENTID = 2;
            res.CREATIONDATE = '13/09/1989';
            res.DEFINITIONTYPE = 'system';
            res.DESCRIPTION = '';
            let err = {} as IErrorsWarnings;
            err.RANK = '1d';
            err.REMARKS = "failure";
            let errArr: IErrorsWarnings[] = [err];
            res.ERRORSWARNINGS = errArr;
            res.FILENAME = '';
            res.PROCESSEDBLOCKS = '310';
            res.TOTALBLOCKS = '535';
            let resp: IErrorHistory[] = [res];
            return Observable.of(resp);
        }

        else {
            return Observable.throw('invalid');
        }
    }

    UpdateUserReview(AttachmentID: number): Observable<any> {

        if (AttachmentID == 310)
            return Observable.of({});
        else
            return Observable.throw('invalid');


    }

    downloadEdaTemplates(selectedTemplates: ITemplate[]): Observable<any> {
        if (selectedTemplates[0].id == 310) {
            let resp: any = {} as IEda;
            resp.filename = '';
            resp.filedata = '1233';
            let res: any[] = [{ resp }]
            return Observable.of(res);
        }
        else {
            return Observable.throw('invalid');
        }


    }

}


export class fakeSlideinService {
}

export class fakeActiveModal {
}

export class fakeModalOptions {

}




