export const environment = {
  production: false,
  prepareForPortal: false
};
