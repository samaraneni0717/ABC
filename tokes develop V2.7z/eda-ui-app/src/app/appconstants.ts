import { InjectionToken } from '@angular/core';

export interface IAppConstants {

    headingText: string,
    fileHistoryHeadingText: string,
    fileHistoryBodyText: string,
    uploadButtonText: string;
    buttonStyle: string;
    confirmServiceText: string,
    error: string,
    warning: string,
    success: string,
    info: string,
    uploadErrorText: string,
    fileFilterWarningTxt: string,
    fileUploadWarningtxt: string,
    uploadSuccessText: string,
    uploadwarningText: string,
    uploadInfoText: string,
    uploadText: string,
    download: string,
    definitionType: string,
    rulesMandtHeading: string,
    rulesoneRule: string,
    rulesoneTrgtHeadr: string,
    rulesinvalidDef: string,
    rulesnoSrcHeader: string,
    rulesoneSrcHeader: string,
    employee: string,
    system: string,
    template: string,
    templateDwnldError: string,
    uploadStatusInProgress: string,
    history: string,   
    uploadstsvalidated: string,
    uploadstscompleted: string,
    uploadstsprocessing: string,
    uploadstsfailed: string,
    uploadstsneedsreview: string,
    uploadstsinitiated: string,
    uploadstsrequested: string,
    uploadrulestswarning: string,
    uploadrulestserror: string,
    uploadSubmitErrorText: string

}
export const APP_DI_CONSTANTS: IAppConstants =
    {

        headingText: 'Let\'s get started on the process of uploading your data.',
        fileHistoryHeadingText: 'Let\'s get started on checking your data.',
        fileHistoryBodyText: 'Upload your employee data here and we\'ll let you know what potential errors and warnings are in your list(s).Once we\'re done reviewing your information you can view everything here or simply download the list to correct any errors in your .csv files at your own pace. By the way,feel free to upload  your list(s) as many times as you need to ensure everything looks good at all times!',
        uploadButtonText: 'Upload files',
        buttonStyle: 'primary',
        confirmServiceText: 'You are about to load a System Configuration file.  This will overwrite the current System Configuration parameters and replace with the values in the current file.  Are you sure you want to continue?',
        error: 'error',
        warning: 'warning',
        success: 'success',
        info: 'info',
        uploadErrorText: 'File upload and processing completed with errors.',
        uploadSubmitErrorText: 'An error was encountered in the processing of the file.Please try your file upload again.',
        uploadwarningText: 'File upload and processing completed with warnings.',
        fileFilterWarningTxt: 'Please select a file with .csv extension to upload.',
        fileUploadWarningtxt: 'Please select at least one file to upload.',
        uploadSuccessText: 'File upload and processing completed successfully.',
        uploadInfoText: 'File Upload In Progress...',
        uploadText: 'upload',
        download: 'download',
        definitionType: 'definitiontype',
        rulesMandtHeading: 'File is missing mandatory header definition type.',
        rulesoneRule: 'Rule file must contain at least one rule.',
        rulesoneTrgtHeadr: 'Rule file must contain at least one target header.',
        rulesinvalidDef: 'Invalid definition type. Definition type must be either System or Employee.',
        rulesnoSrcHeader: 'System rules may not contain Source headers.',
        rulesoneSrcHeader: 'Employee rules must contain at least one Source header.',
        employee: 'employee',
        system: 'system',
        template: 'template',
        templateDwnldError: 'An error has occurred during download.',
        uploadStatusInProgress: 'INPROGRESS',
        history: 'history',   
       //begin of upload statuses
        uploadstsvalidated: 'VALIDATED',
        uploadstscompleted: 'COMPLETED',
        uploadstsprocessing: 'PROCESSING',
        uploadstsfailed: 'FAILED',
        uploadstsneedsreview: 'NEEDSREVIEW',
        uploadstsinitiated: 'INITIATED',
        uploadstsrequested: 'REQUESTED',
        uploadrulestswarning: 'WARNING',
        uploadrulestserror: 'ERROR'
        // end of upload statuses

    }

export let APP_CONSTANTS = new InjectionToken<IAppConstants>('app.constants');
