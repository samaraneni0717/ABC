import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { UploadFileComponent, TepmlateSelectionListComponent, EdaSlideinComponent, dateFormatPipe } from './uploadfile.component';
import { AppModule } from '../app.module';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs';
import { EdaService } from '../../api/eda/eda.service';
import { EdaMockService, fakeSlideinService, fakeActiveModal, fakeModalOptions } from '../../api/eda/eda.mockservice';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import 'rxjs/add/operator/takeWhile';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/takeUntil';
import 'rxjs/add/observable/timer';
import { Subscription } from 'rxjs/Subscription';
import { IEda, IUploadEda, ITemplate, IUploadStatus, IUploadHistory, IErrorsWarnings } from '../../api/eda/eda';
import { TabsComponent, ListSelectionService, ConfirmService, ConfirmConfig, ModalService, ModalAnchorComponent, TileComponent, ProgressBarComponent, SlideinService, SLIDE_IN_ANIMATIONS, ModalModel, ActiveModal, ModalOptions, TabsModule } from 'synerg-components';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';


window['PORTAL_BASE_PATH'] = 'MOCK';
describe('UploadFileComponent', () => {
    let fixture: any;
    let comp: any;
    let pipe: dateFormatPipe;
    let timerObserver: Observer<any>;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                AppModule, TabsModule
            ],
            declarations: [

            ],
            providers: [
                { provide: EdaService, useClass: EdaMockService },
            ]
        });
        TestBed.compileComponents();
        fixture = TestBed.createComponent(UploadFileComponent);
        comp = fixture.debugElement.componentInstance;
        pipe = new dateFormatPipe();
        spyOn(fixture.componentInstance, 'getUploadProgress').and.returnValue(Observable.create(
            (observer => {
                timerObserver = observer;
            })
        ));

    });

    it(' UploadFileComponent: should create the component', function (done) {

        expect(fixture.componentInstance).toBeDefined();
        done();
    });

    it(' UploadFileComponent: should call Init', function (done) {

        fixture.whenStable().then(() => {
            fixture.detectChanges();
        });
        done();
    });


    it(' UploadFileComponent: should call poller', function (done) {
        fixture.componentInstance.isPolling = true;
        fixture.whenStable().then(() => {
            timerObserver.next('');
            timerObserver.complete();
        });
        done();
    });



    it('UploadFileComponent:  Alert Methods :: onAlertClose() should hide alert-upload', function (done) {
        fixture.componentInstance.showAlert = true;
        fixture.componentInstance.onAlertClose('upload');
        expect(fixture.componentInstance.showAlert).toBeFalsy();
        done();
    });
    it('UploadFileComponent:  Alert Methods :: onAlertClose() should hide alert-template', function (done) {
        fixture.componentInstance.showAlert = true;
        fixture.componentInstance.onAlertClose('template');
        expect(fixture.componentInstance.showAlertTemplate).toBeFalsy();
        done();
    });
    it('UploadFileComponent:  Alert Methods :: onAlertClose() should hide alert-history', function (done) {
        fixture.componentInstance.showAlertHistory = true;
        fixture.componentInstance.onAlertClose('history');
        expect(fixture.componentInstance.showAlertHistory).toBeFalsy();
        done();
    });



    it('UploadFileComponent: Alert Methods :: showAlertMessage() should set alert message-upload', function (done) {

        fixture.componentInstance.showAlertMessage(true, 'warn', 'success', 'upload');
        expect(fixture.componentInstance.alertContent).toEqual('success');
        expect(fixture.componentInstance.showAlert).toEqual(true);
        expect(fixture.componentInstance.alertType).toEqual('warn');
        done();
    });
    it('UploadFileComponent: Alert Methods :: showAlertMessage() should set alert message-template', function (done) {

        fixture.componentInstance.showAlertMessage(true, 'warn', 'success', 'template');
        expect(fixture.componentInstance.alertContentTemplate).toEqual('success');
        expect(fixture.componentInstance.showAlertTemplate).toEqual(true);
        expect(fixture.componentInstance.alertTypeTemplate).toEqual('warn');
        done();
    });
    it('UploadFileComponent: Alert Methods :: showAlertMessage() should set alert message-history', function (done) {

        fixture.componentInstance.showAlertMessage(true, 'warn', 'success', 'history');
        expect(fixture.componentInstance.showAlertHistory).toEqual(true);
        done();
    });


    it('UploadFileComponent: Upload Methods :: convertToBase64() should throw exception', function (done) {

        let file: File = {} as File;
        let result: any;
        fixture.componentInstance.convertToBase64(file).then(data => { result = data; }, data => { result = data })
        expect(result).toBeUndefined();
        done();
    });
    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Rule File Should Contain Atleast One rule ', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'MSwy';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Rule file must contain at least one rule.');
        done();
    });
    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Missing Mandatory Header Definition Type. ', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'UmFuayxSdWxlTmFtZSwNCkVtcGxveWVlLDE=';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('File is missing mandatory header definition type.');
        done();
    });

    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // check atleast one rule inner loop. ', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUsUmFuaw0Kc3lzdGVtLDEsSE9MTFlJVkFOLVBvc2l0aW9uDQo=';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.isvalidRuleFile).toBeTruthy();
        done();
    });

    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // check atleast one rule inner loop- negative scenario ', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'ZGVmaW5pdGlvbnR5cGUseA0K';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Rule file must contain at least one rule.');
        done();
    });



    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // check atleast one Target Header ', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUsDQpzeXN0ZW0sMSxIT0xMWUlWQU4tUG9zaXRpb24NCg==';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Rule file must contain at least one target header.');
        done();
    });

    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Is employee file', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0KZW1wbG95ZWUsMSxIT0xMWUlWQU4tUG9zaXRpb24NCg==';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.isvalidRuleFile).toBeTruthy();
        done();
    });



    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Not valid definiton type- header', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0KZW1wbG95ZSwxLEhPTExZSVZBTi1Qb3NpdGlvbg0K';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Invalid definition type. Definition type must be either System or Employee.');
        done();
    });

    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Not valid definiton type- no proper rule #1', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0KLA0K';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Invalid definition type. Definition type must be either System or Employee.');
        done();
    });

    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Not valid definiton type- no 2nd row-column', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0KZW1wbG95ZWUsMSxIT0xMWUlWQU4tUG9zaXRpb24NCiwNCg==';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Invalid definition type. Definition type must be either System or Employee.');
        done();
    });
    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Not valid definiton type-  2nd row-invalid def type column--employee', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0KZW1wbG95ZWUsMSxIT0xMWUlWQU4tUG9zaXRpb24NCnNzLA0K';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Invalid definition type. Definition type must be either System or Employee.');
        done();
    });
    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Not valid definiton type-  2nd row-invalid def type column--system', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0Kc3lzdGVtLDEsSE9MTFlJVkFOLVBvc2l0aW9uDQpzcyw=';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Invalid definition type. Definition type must be either System or Employee.');
        done();
    });

    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // system rules should not have src headers', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseCxzcmNfaA0Kc3lzdGVtLDEsSE9MTFlJVkFOLVBvc2l0aW9u';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('System rules may not contain Source headers.');
        done();
    });
    it('UploadFileComponent: Upload Methods :: validateRuleFiles() :Test // Employee rules should  have atleast 1src header', function (done) {

        let base64String: any;
        let result: any;
        base64String = 'RGVmaW5pdGlvblR5cGUseA0KZW1wbG95ZWUsMSxIT0xMWUlWQU4tUG9zaXRpb24=';
        result = fixture.componentInstance.validateRuleFiles(base64String);
        expect(result.warningMssg).toEqual('Employee rules must contain at least one Source header.');
        done();
    });

    it(' UploadFileComponent: Post method', function (done) {
        fixture.componentInstance.fileName = 'gga.csv';
        fixture.componentInstance.postFile('valid');
        expect(fixture.componentInstance.showBusy).toEqual(false);
        done();
    });


    it(' UploadFileComponent: Post method -exception', function (done) {
        fixture.componentInstance.fileName = 'gga.csv';
        fixture.componentInstance.postFile('invalid');
        expect(fixture.componentInstance.showAlert).toEqual(true);
        expect(fixture.componentInstance.alertType).toEqual('error');
        done();
    });

    it(' UploadFileComponent: Download Template', function (done) {

        fixture.componentInstance.selectedEmployeeTemplates = [{
            title: 'Sample Employee Data Template',
            description: 'Select this employee data template to download a blank .csv file to begin your data translation work in mapping the Employee Data Assignments.',
            id: 310, isCurrentTemplate: false, category: 'Employee', name: 'SampleEmployeeDataTemplate.xlsx'
        }];
        fixture.componentInstance.downloadSelectedTemplates();
        expect(fixture.componentInstance.showBusyTemplate).toEqual(false);
        done();
    });
    it(' UploadFileComponent: Download Template -IE Browser', function (done) {
        window.navigator.msSaveOrOpenBlob = function () { return true; };
        fixture.componentInstance.selectedEmployeeTemplates = [{
            title: 'Sample Employee Data Template',
            description: 'Select this employee data template to download a blank .csv file to begin your data translation work in mapping the Employee Data Assignments.',
            id: 310, isCurrentTemplate: false, category: 'Employee', name: 'SampleEmployeeDataTemplate.xlsx'
        }];
        fixture.componentInstance.downloadSelectedTemplates();
        expect(fixture.componentInstance.showBusyTemplate).toEqual(false);
        done();
    });

    it(' UploadFileComponent: Download Template -- Exception ', function (done) {

        fixture.componentInstance.selectedEmployeeTemplates = [{
            title: 'Sample Employee Data Template',
            description: 'Select this employee data template to download a blank .csv file to begin your data translation work in mapping the Employee Data Assignments.',
            id: 1, isCurrentTemplate: false, category: 'Employee', name: 'SampleEmployeeDataTemplate.xlsx'
        }];
        fixture.componentInstance.downloadSelectedTemplates();
        expect(fixture.componentInstance.showBusyTemplate).toEqual(false);
        done();
    });
    it(' UploadFileComponent: uploadFile - No Files ', function (done) {
        let files: any[];
        let item: any = {};
        let target: any = {};
        files = [];
        target = { files };
        item = { target };
        fixture.componentInstance.uploadFile(item);
        expect(fixture.componentInstance.showAlert).toEqual(true);
        done();
    });

    it(' UploadFileComponent: uploadFile - Invalid  File Extension ', function (done) {
        let files: any[];
        let item: any = {};
        let target: any = {};
        let file: File = new File(["DefinitionType,x employee,1,HOLLYIVAN-Position"], " ");
        files = [];
        target = { files };
        item = { target };
        fixture.componentInstance.uploadFile(item);
        expect(fixture.componentInstance.showAlert).toEqual(true);
        done();
    });
    it(' UploadFileComponent: uploadFile', function (done) {
        let files: any[];
        let item: any = {};
        let target: any = {};
        let file: File = new File(["DefinitionType,x employee,1,HOLLYIVAN-Position"], "sample.csv");
        files = [file];
        target = { files };
        item = { target };
        fixture.componentInstance.uploadFile(item);
        expect(fixture.componentInstance.showBusy).toEqual(false);
        done();
    });

    it(' UploadFileComponent: getErrorHistory', function (done) {

        let obj: any = {} as IUploadHistory;
        obj.ATTACHMENTID = 310;
        obj.DESCRIPTION = 'GGA';
        let objArr: IUploadHistory[] = [obj];
        fixture.componentInstance.uploadHistory = objArr;
        fixture.componentInstance.getErrorHistory(0);
        done();
    });

    it(' UploadFileComponent: getErrorHistory -exception', function (done) {

        let obj: any = {} as IUploadHistory;
        obj.ATTACHMENTID = 310535;
        obj.DESCRIPTION = 'GGA';
        let objArr: IUploadHistory[] = [obj];
        fixture.componentInstance.uploadHistory = objArr;
        fixture.componentInstance.getErrorHistory(0);
        done();
    });

    it(' UploadFileComponent: getErrorHistory - no proper rank', function (done) {

        let obj: any = {} as IUploadHistory;
        obj.ATTACHMENTID = 535;
        obj.DESCRIPTION = 'GGA';
        let objArr: IUploadHistory[] = [obj];
        fixture.componentInstance.uploadHistory = objArr;
        fixture.componentInstance.getErrorHistory(0);
        done();
    });


    it(' UploadFileComponent: getErrorHistory -call user review -exception', function (done) {

        fixture.whenStable().then(() => {
            let obj: any = {} as IUploadHistory;
            obj.ATTACHMENTID = 310;
            obj.DESCRIPTION = 'NEEDSREVIEW';
            let objArr: IUploadHistory[] = [obj];
            let latest: any = {} as IUploadHistory;
            latest.ATTACHMENTID = 535;
            fixture.componentInstance.lastestUpload = latest;
            fixture.componentInstance.alertTypeHistory = 'error';
            fixture.componentInstance.uploadHistory = objArr;
            fixture.componentInstance.getErrorHistory(0);

        });
        done();
    });


    it(' UploadFileComponent: getErrorHistory -call user review', function (done) {

        fixture.whenStable().then(() => {
            let obj: any = {} as IUploadHistory;
            obj.ATTACHMENTID = 310;
            obj.DESCRIPTION = 'NEEDSREVIEW';
            let objArr: IUploadHistory[] = [obj];
            let latest: any = {} as IUploadHistory;
            latest.ATTACHMENTID = 310;
            fixture.componentInstance.lastestUpload = latest;
            fixture.componentInstance.alertTypeHistory = 'error';
            fixture.componentInstance.uploadHistory = objArr;
            fixture.componentInstance.getErrorHistory(0);

        });
        done();
    });

    it(' UploadFileComponent: uploadButtonTab', function (done) {

        fixture.whenStable().then(() => {
            fixture.componentInstance.uploadButtonTab();

        });
        done();
    });

    it(' UploadFileComponent: getUploadHistory', function (done) {

        fixture.whenStable().then(() => {
            fixture.componentInstance.getUploadHistory(false);
            fixture.detectChanges();
            expect(fixture.componentInstance.showAlertHistory).toBeTruthy();
        });
        done();
    });


    it(' UploadFileComponent: getUploadHistory', function (done) {

        fixture.whenStable().then(() => {
            fixture.componentInstance.getUploadHistory(false);
            fixture.detectChanges();
            expect(fixture.componentInstance.showAlertHistory).toBeTruthy();
        });
        done();
    });


    it(' UploadFileComponent: Test Date Pipe', function (done) {

        expect(pipe.transform('2018-05-22T03:24:07')).toBe('05/22/18 at 3:24 AM');
        done();
    });

});

describe('EdaSlideinComponent', () => {
    let fixture: any;
    let comp: any;
    let slideInModel: ModalModel = {
        'fileName': 'gga',
        'isCompleteSuccess': true,
        'errorsWarnings': '',
        'totalBlocks': 5,
        'processedBlocks': 5,
        'creationDate': ''

    };
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                AppModule, TabsModule
            ],
            declarations: [

            ],
            providers: [
                { provide: EdaService, useClass: EdaMockService },
                { provide: ModalModel, useValue: slideInModel },
                { provide: ActiveModal, useClass: fakeActiveModal },
                { provide: ModalOptions, useClass: fakeModalOptions },
                { provide: SlideinService, useClass: fakeSlideinService }
            ]
        });
        TestBed.compileComponents();
        fixture = TestBed.createComponent(EdaSlideinComponent);
        comp = fixture.debugElement.componentInstance;
    });

    it(' EdaSlideinComponent : should create the component', function (done) {

        fixture.whenStable().then(() => {
            fixture.componentInstance.done();
        });

        done();
    });

    it(' EdaSlideinComponent : should create the component', function (done) {

        fixture.whenStable().then(() => {
            fixture.componentInstance.model.fileName = 'gga.csv';
            let x = {} as IErrorsWarnings;
            x.RANK = '1';
            x.REMARKS = 'gga';
            let y = {} as IErrorsWarnings;
            y.RANK = '2';
            y.REMARKS = 'gga310';

            fixture.componentInstance.model.errorsWarnings = [x, y];
            fixture.componentInstance.downLoadErrors();
        });

        done();
    });

});
