import { Component, OnDestroy, ViewEncapsulation, ElementRef, OnInit, Input, HostBinding, HostListener, ViewChild, Injectable, Inject, CUSTOM_ELEMENTS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { PlatformLocation, DatePipe } from '@angular/common';
import { BetterPlatformBrowserLocationService } from '../better-platform-location.service';
import { EdaService } from '../../api/eda/eda.service';
import { IEda, IUploadEda, ITemplate, IRule, IUploadStatus, IUploadHistory, IErrorHistory, IErrorsWarnings } from '../../api/eda/eda';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import 'rxjs/add/operator/takeWhile';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/takeUntil';
import 'rxjs/add/observable/timer';
import { TabsComponent, ListSelectionService, ConfirmService, ConfirmConfig, ModalService, ModalAnchorComponent, TileComponent, ProgressBarComponent, SlideinService, SLIDE_IN_ANIMATIONS, ModalModel, ActiveModal, ModalOptions } from 'synerg-components';
import * as JSZip from 'jszip';
import { APP_CONSTANTS, IAppConstants } from '../appconstants';




@Component({
  selector: 'app-upload-file',
  templateUrl: './uploadfile.component.html',
  styleUrls: ['./uploadfile.component.scss'],
  providers: [ModalService, ConfirmService, ConfirmConfig, SlideinService],
  encapsulation: ViewEncapsulation.None
})
export class UploadFileComponent implements OnDestroy, OnInit {

  button: any = {};
  heading = this.appConstants.headingText;
  fileHistoryHeading = this.appConstants.fileHistoryHeadingText;
  fileHistoryBody = this.appConstants.fileHistoryBodyText;
  edaData: any = {} as IEda;
  edaDataUpload: any = {} as IUploadEda;
  alertType: string;
  alertContent: string;
  showAlert: boolean;
  showAlertTemplate: boolean;
  showAlertHistory: boolean;
  alertTypeTemplate: string;
  alertContentTemplate: string;
  alertTypeHistory: string;
  alertContentHistory: string;
  showBusy: boolean;
  showBusyTemplate: boolean;
  selectedEmployeeTemplates: ITemplate[];
  allEmployeeTemplates: ITemplate[];
  selectedSystemTemplates: ITemplate[];
  allSystemTemplates: ITemplate[];
  selectedTemplates: ITemplate[];
  isTemplateTabSelected: boolean;
  isUploadTabSelected: boolean;
  fileName: string;
  fileSize: number;
  isActiveUpload: boolean;
  isPolling: boolean;
  uploadProgressPercnt: number;
  uploadHistory: IUploadHistory[];
  isReviewPending: boolean;
  lastestUpload: IUploadHistory;
  options: any = new ModalOptions();
  isReviewAlertClick: boolean;
  private unsubscribe: Subject<void> = new Subject<void>();
  @ViewChild(TabsComponent) tabs: TabsComponent;

  constructor(@Inject(APP_CONSTANTS) private appConstants: IAppConstants,
    private platformLocation: PlatformLocation, private _edaService: EdaService, private confirmService: ConfirmService, private slideinService: SlideinService) {
    this.showAlert = false;
    this.showAlertTemplate = false;
    this.showAlertHistory = false;
    this.showBusy = false;
    this.showBusyTemplate = false;
    this.setTempaltesDefaultText();
    this.button.buttonText = this.appConstants.uploadButtonText;
    this.button.buttonStyle = this.appConstants.buttonStyle;
    this.isTemplateTabSelected = true;
    this.isUploadTabSelected = false;
    this.isPolling = false;
    this.isActiveUpload = false;
    this.uploadProgressPercnt = 0;
    this.isReviewPending = false;
    this.fileSize = 0;
    this.isReviewAlertClick = false;

  }
  // Upload Methods
  uploadFile(item: any): void {
    let regex: RegExp;
    let base64String: any;
    let ruleChk: IRule;
    regex = new RegExp('(.*?)\.(csv)$');
    this.onAlertClose(this.appConstants.uploadText);
    if (item.target.files.length > 0) {
      this.fileName = item.target.files[0].name;
      this.fileSize = item.target.files[0].size;
      if ((regex.test(this.fileName.toLowerCase()))) {
        base64String = this.convertToBase64(item.target.files[0]).then(
          (data: any) => {
            base64String = data.substring(data.indexOf(',') + 1);
            this.showBusy = true;
            ruleChk = this.validateRuleFiles(base64String);
            // making sure that no uploads are forced during active upload          
            if (!this.isActiveUpload) {
              if (ruleChk.isvalidRuleFile) {
                if (ruleChk.isSystemRule) {
                  this.showBusy = false;
                  this.confirmService.open(this.appConstants.confirmServiceText).
                    then((result: any) => {
                      this.showBusy = true;
                      this.postFile(base64String);
                    }).catch((rejection: any) => {

                    });
                }
                else {
                  this.postFile(base64String);
                }

              }
              else {
                this.showAlertMessage(true, this.appConstants.error, ruleChk.warningMssg, this.appConstants.uploadText);
              }
            }
          }, (data: any) => {
            console.log('Failed at encoding to base 64' + data);
            this.showAlertMessage(true, this.appConstants.error, this.appConstants.uploadSubmitErrorText, this.appConstants.uploadText);
          }
        );

      }
      else {
        this.showAlertMessage(true, this.appConstants.warning, this.appConstants.fileFilterWarningTxt, this.appConstants.uploadText);
      }
    }
    else {
      this.showAlertMessage(true, this.appConstants.warning, this.appConstants.fileUploadWarningtxt, this.appConstants.uploadText);
    }
  }

  // it will auto convert to base 64 
  convertToBase64(file: File): any {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }

  validateRuleFiles(base64String: any): IRule {
    let ruleCheck: any = {} as IRule;
    let csvString: string;
    let headers: any;
    let allRows: any;
    let delimiter: string = ',';
    let row: any;
    let column: any;
    let firstRow: any;
    let firstColumn: any;
    let isSystemRule: boolean = false;
    let isEmployeeRule: boolean = false;
    let trgheaderCount: number = 0;

    csvString = atob(base64String);
    allRows = csvString.split(/\r\n|\n/);

    if (allRows && allRows.length > 1) {
      headers = allRows[0].split(delimiter);
      firstRow = allRows[1].split(delimiter);

      // Definition Type header check
      if (headers && headers.length > 0) {
        if (headers[0].toLowerCase() != this.appConstants.definitionType) {
          ruleCheck.isvalidRuleFile = false;
          ruleCheck.warningMssg = this.appConstants.rulesMandtHeading;
          return ruleCheck;
        }
      }

      if (firstRow != '') {
        firstColumn = firstRow[0];
      }
      else {
        ruleCheck.isvalidRuleFile = false;
        ruleCheck.warningMssg = this.appConstants.rulesoneRule;
        return ruleCheck;
      }
    }
    else {
      ruleCheck.isvalidRuleFile = false;
      ruleCheck.warningMssg = this.appConstants.rulesoneRule;
      return ruleCheck;
    }




    // 1) At least One Target header values should exist in the import irrespective of Definition type

    for (let i = 0; i < headers.length; i++) {

      if (headers[i] != '' && (!(headers[i].toLowerCase().startsWith('src_')))) {
        if (headers[i].toLowerCase() != this.appConstants.definitionType) {
          trgheaderCount++;
        }
      }
    }
    if (trgheaderCount == 0) {
      ruleCheck.isvalidRuleFile = false;
      ruleCheck.warningMssg = this.appConstants.rulesoneTrgtHeadr;
      return ruleCheck;
    }


    // 2) Import should allow only DefinitionType, more than one should throw validation error

    if (firstRow != '' && firstColumn != '') {
      if (firstColumn.toLowerCase() == this.appConstants.employee) {
        isEmployeeRule = true;
      }
      else if (firstColumn.toLowerCase() == this.appConstants.system) {
        isSystemRule = true;
      }
      else {
        ruleCheck.isvalidRuleFile = false;
        ruleCheck.warningMssg = this.appConstants.rulesinvalidDef;
        return ruleCheck;
      }

    }
    else {
      ruleCheck.isvalidRuleFile = false;
      ruleCheck.warningMssg = this.appConstants.rulesinvalidDef;
      return ruleCheck;
    }

    for (let i = 2; i < allRows.length; i++) {
      row = allRows[i];
      if (row != '') {
        if (row.split(delimiter)[0] != '') {
          column = row.split(delimiter)[0];
          if (!((isSystemRule && column.toLowerCase() == this.appConstants.system) || (isEmployeeRule && column.toLowerCase() == this.appConstants.employee))) {
            // throw error no proper def type      
            console.log("Invalid definition type at row no: %i", i + 1);
            ruleCheck.isvalidRuleFile = false;
            ruleCheck.warningMssg = this.appConstants.rulesinvalidDef;
            return ruleCheck;
          }
        }
        else {
          console.log("Invalid definition type at row no: %i", i + 1);
          ruleCheck.isvalidRuleFile = false;
          ruleCheck.warningMssg = this.appConstants.rulesinvalidDef;
          return ruleCheck;
        }
      }
    }

    // 3) When Definition type is SYSTEM, SRC_ headers or values data are not allowed
    if (isSystemRule) {
      for (let i = 0; i < headers.length; i++) {
        if (headers[i].toLowerCase().startsWith('src_')) {
          // src headers not be there in system rules
          ruleCheck.isvalidRuleFile = false;
          ruleCheck.warningMssg = this.appConstants.rulesnoSrcHeader;
          return ruleCheck;
        }
      }
    }

    // 4) When Definition Type is EMPLOYEE, should contains at least one SRC header
    if (isEmployeeRule) {
      let srcCount: number = 0;

      for (let i = 0; i < headers.length; i++) {
        if (headers[i].toLowerCase().startsWith('src_')) {
          srcCount++;
        }
      }
      if (srcCount == 0) {
        // should contain atleast one src_ header
        ruleCheck.isvalidRuleFile = false;
        ruleCheck.warningMssg = this.appConstants.rulesoneSrcHeader;
        return ruleCheck;
      }


    }

    ruleCheck.isvalidRuleFile = true;
    ruleCheck.warningMssg = '';
    ruleCheck.isSystemRule = isSystemRule;
    return ruleCheck;

  }
  postFile(base64data: any) {
    let jsonData: any;
    let postData: string[] = [];
    postData.push(base64data);
    this.edaDataUpload.filename = this.fileName;
    this.edaDataUpload.data = postData;
    jsonData = JSON.stringify(this.edaDataUpload);
    this._edaService.uploadEdaFile(jsonData).takeUntil(this.unsubscribe).subscribe(response => {
      this.getUploadHistory(false);
    }, Error => {
      console.log('ErrorMessage:' + Error +
        'Current Request' + JSON.stringify(this.edaDataUpload.filename) + 'At Post Method.');
      this.showAlertMessage(true, this.appConstants.error, this.appConstants.uploadSubmitErrorText, this.appConstants.uploadText);
    });
  }


  // end of Upload Methods

  // Download Templates Section
  setTempaltesDefaultText() {
    this.allEmployeeTemplates = [{
      title: 'Sample Employee Data Assignment Template',
      description: 'Select this employee data template to download a blank .csv file to begin your data translation work in mapping the Employee Data Assignments.',
      id: 1, isCurrentTemplate: false, category: 'Employee', name: 'SampleEmployeeDataTemplate.xlsx'
    },
    {
      title: 'Current Employee Data Assignment Template',
      description: 'Select this employee data template to download the current Employee Data Assignment configuration.',
      id: 2, isCurrentTemplate: true, category: 'Employee', name: 'CurrentEmployeeDataTemplate.csv'
    }];
    this.allSystemTemplates = [{
      title: 'Sample System Configuration Template',
      description: 'Select this configuration template to download a blank .csv file to begin your data translation work in mapping the system configuration.',
      id: 3, isCurrentTemplate: false, category: 'System', name: 'SampleSystemConfigurationTemplate.xlsx'
    },
    {
      title: 'Current System Configuration Template',
      description: 'Select this system configuration template to download the current system configuration parameters.',
      id: 4, isCurrentTemplate: true, category: 'System', name: 'CurrentSystemConfigurationTemplate.csv'

    }]

  }

  downloadSelectedTemplates() {
    this.selectedTemplates = this.selectedEmployeeTemplates.concat(this.selectedSystemTemplates);
    if (this.selectedTemplates.length > 0) {
      this.onAlertClose(this.appConstants.template);
      this.showBusyTemplate = true;
      this._edaService.downloadEdaTemplates(this.selectedTemplates).takeUntil(this.unsubscribe).subscribe(response => {

        let files: any = response;
        let zipFile: JSZip = new JSZip();
        for (let index in files) {
          zipFile.file(this.selectedTemplates[index].name, files[index].filedata);
        }
        zipFile.generateAsync({ type: 'arraybuffer' }).
          then((zipdata) => { return this.downloadZipFile(zipdata); }).catch((error) => {
            this.showBusyTemplate = false;
            console.log(error);
          });
        this.showBusyTemplate = false;
      }, Error => {
        this.showBusyTemplate = false;
        this.showAlertMessage(true, this.appConstants.error, this.appConstants.templateDwnldError, this.appConstants.template);
        console.log('ErrorMessage:' + Error);
      });
    }
    else {
      //if no templates selected
    }
  }

  downloadZipFile(data: any) {
    let fileName: string;
    fileName = 'EDA_TEMPLATES.zip';
    let csvBlob = new Blob([data], { type: 'application/octet-stream' });
    this.showBusyTemplate = false;
    // for IE browser
    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(csvBlob, fileName);
    }
    else {
      let downloadLink: any = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(csvBlob);
      downloadLink.setAttribute('download', fileName);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  }
  // end of download templates

  //Begin of File History Methods

  getUploadProgress(AttchmentID: number) {
    Observable.timer(0, 5000)
      .takeWhile(() => this.isPolling)
      .subscribe(() => {
        this._edaService.getUploadStatus(AttchmentID).takeUntil(this.unsubscribe)
          .subscribe(res => {
            let response: IUploadStatus = res;
            // upload is in progress
            if ((response.STATUS.toUpperCase() == this.appConstants.uploadstsrequested)
              || (response.STATUS.toUpperCase() == this.appConstants.uploadstsinitiated) ||
              (response.STATUS.toUpperCase() == this.appConstants.uploadstsvalidated) ||
              (response.STATUS.toUpperCase() == this.appConstants.uploadstsprocessing)) {
              this.uploadProgressPercnt = response.PROGRESS;
            }
            // upload completed /errored
            else {
              this.uploadProgressPercnt = 0;
              this.isPolling = false;
              this.isActiveUpload = false;
              this.getUploadHistory(false);
            }
          }, Error => {
            this.isPolling = false;
            console.log('ErrorMessage:' + Error);
          }
          );
      });
  }

  // called from  post file, progress end,on load,post review
  getUploadHistory(isReload: boolean) {
    this._edaService.getUploadHistory().takeUntil(this.unsubscribe)
      .subscribe(res => {
        this.showBusy = false;
        this.uploadHistory = res;
        // sort desc with top date as latest record      
        this.uploadHistory.sort((x, y) => Date.parse(y.CREATIONDATE) - Date.parse(x.CREATIONDATE));
        // indicates active upload
        if ((this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstsrequested)
          || (this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstsinitiated) ||
          (this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstsvalidated) ||
          (this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstsprocessing)) {
          this.lastestUpload = this.uploadHistory.shift();
          this.tabs.switchTab(2);
          this.isActiveUpload = true;
          this.isPolling = true;
          this.showAlertMessage(true, this.appConstants.info, this.appConstants.uploadInfoText, this.appConstants.history);
          this.getUploadProgress(this.lastestUpload.ATTACHMENTID);
        }

        // needs review indicates file is errored and user action is needed
        else if (this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstsneedsreview) {
          // focusing on history tab as user needs to review
          this.tabs.switchTab(2);
          this.lastestUpload = this.uploadHistory[0];
          //show error alert for now in future we should have warnings too          
          this.showAlertMessage(true, this.appConstants.error, this.appConstants.uploadErrorText, this.appConstants.history);


        }
        // if success and not reload then only show success mssg
        else if ((this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstscompleted) && !isReload) {
          this.tabs.switchTab(2);
          // latest upload is  a success 
          this.showAlertMessage(true, this.appConstants.success, this.appConstants.uploadSuccessText, this.appConstants.history);
        }
      }, Error => {
        this.showBusy = false;
        console.log('ErrorMessage:' + Error);
      });
  }

  getErrorHistory(index: number) {

    this._edaService.getErrorHistory(this.uploadHistory[index].ATTACHMENTID).takeUntil(this.unsubscribe)
      .subscribe(res => {
        let response: IErrorHistory[] = res;
        this.openErrorSlideIn(response[0]);
      }, Error => {
        console.log('ErrorMessage:' + Error);
      }
      );
    if (index == 0 && (this.uploadHistory[0].DESCRIPTION.toUpperCase() == this.appConstants.uploadstsneedsreview)) {
      // fire api call to mark as review and close alert
      this.onAlertClose('history');
    }
  }

  openErrorSlideIn(errorHist: IErrorHistory) {

    // model for slide-in
    let slideInModel: ModalModel = {
      'fileName': errorHist.FILENAME,
      'isCompleteSuccess': errorHist.DESCRIPTION == 'COMPLETED' ? true : false,
      'errorsWarnings': errorHist.ERRORSWARNINGS,
      'totalBlocks': errorHist.TOTALBLOCKS,
      'processedBlocks': errorHist.PROCESSEDBLOCKS,
      'creationDate': errorHist.CREATIONDATE

    };
    // opening a slide-in returns a promise
    let promise = this.slideinService.open(EdaSlideinComponent, slideInModel, this.options);
    // handle the resolution and rejection
    promise.then((data: any) => {
      // handler for the "close" button
    }).catch((rejection: any) => {
      // handler for the rejection from the "back" button or from clicking
    });

  }


  updateUserReview() {
    this._edaService.UpdateUserReview(this.lastestUpload.ATTACHMENTID).takeUntil(this.unsubscribe)
      .subscribe(res => {
        // confirmation from server that user has reviewed and  status should be FAILED
        // Update Attachment Status Successful once success make uploadhistory call to reload latest status
        this.getUploadHistory(false);
      }, Error => {
        console.log('ErrorMessage:' + Error);
      });
  }

  // End of File History Methods

  // Alert  Methods
  showAlertMessage(showAlert: boolean, alertType: string, alertContent: string, screen: string) {
    if (screen == this.appConstants.uploadText) {
      this.showBusy = false;
      this.showAlert = showAlert;
      this.alertType = alertType;
      this.alertContent = alertContent;
    }
    else if (screen == this.appConstants.template) {
      this.showAlertTemplate = showAlert;
      this.alertTypeTemplate = alertType;
      this.alertContentTemplate = alertContent;
    }
    else if (screen == this.appConstants.history) {
      this.showAlertHistory = showAlert;
      this.alertTypeHistory = alertType;
      this.alertContentHistory = alertContent;
    }
  }

  onAlertClose(screen: string) {
    if (screen == this.appConstants.uploadText) {
      this.showAlert = false;
    }
    else if (screen == this.appConstants.template) {
      this.showAlertTemplate = false;
    }

    else if (screen == this.appConstants.history) {
      this.showAlertHistory = false;
      // fire a call to api stating that user has reviewed error/ warning 
      if (this.alertTypeHistory == this.appConstants.error) {
        this.updateUserReview();
      }
    }
  }
  // end of Alert  Methods

  uploadButtonTab(): void {
    this.tabs.switchTab(0);
  }
  // Life Cycle hooks
  ngOnInit(): void {
    this.getUploadHistory(true);
  }
  ngOnDestroy() {
    console.log('destroying UploadFileComponent and unsubscribing observables');
    // unsubscribing to prevent memory leaks.
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}


@Component({
  selector: 'app-template-selection-list',
  template: `
    <div class='templateselection'>
      <h4>{{data.title}} </h4>
      <p>
      {{data.description}}
      </p>     
    </div>   
  `,
  encapsulation: ViewEncapsulation.None
})
export class TepmlateSelectionListComponent implements OnDestroy {

  @Input()
  data: any;

  subscriber: Subscription;

  @HostBinding('class.selected')
  selected = false;

  @HostListener('click')
  toggle() {
    if (!this.selected) {
      this.service.addToSelection(this.data);
    } else {
      this.service.removeFromSelection(this.data);
    }
  }

  constructor(private service: ListSelectionService) {
    this.subscriber = this.service.selection$.subscribe((selection) => {
      this.selected = selection.indexOf(this.data) > -1;
    });
  }

  ngOnDestroy() {
    this.subscriber.unsubscribe();
  }
}


@Component({
  selector: 'app-eda-slidein',
  template: `    
    <adp-slidein [options]="options"> 
    <slide-in-body>
      <br>
      <div class="vdl-row" style="padding-left: 100%;">
            <div class="vdl-col-md-12 vdl-col-lg-12 vdl-col-sm-12">
              <i class="fa fa-close" style="color: #1a8099;cursor: pointer;font-size:37px" (click)="done()"></i>
          </div> 
          <br> 
          <br>
        </div>
         <div class="vdl-row">
            <div class="vdl-col-md-12 vdl-col-lg-12 vdl-col-sm-12" style="font-size: 20px;font-weight: 700;color:#0d6277">
              <p>{{model.fileName}}</p>
          </div>  
        </div>          
        <br> 
         <div *ngIf='!model.isCompleteSuccess' class="vdl-row">         
            <div class="vdl-col-md-12 vdl-col-lg-12 vdl-col-sm-12" style=" font-size: 16px;font-weight: 500;padding-left: 84%;">            
                <i class="fa fa-download" style="color: #086274" aria-hidden="true"></i>
                <adp-button (click)='downLoadErrors()'  buttonStyle="link">Download all</adp-button>          
          </div>  
        </div>          
       
         <adp-tabs orientation="horizontal">        
          <adp-tab *ngIf='!model.isCompleteSuccess' label="Errors" [selected]="true" [disabled]="false">
          <div style="height: 70vh;overflow:auto;">
          <div *ngFor="let err of customErrors">
          <br>
          <p class="bodyText" style="color:#2d2b2b" > {{err}}</p>
          <hr style="border: solid 1px #b6bcbd;" />
          </div>
          </div>
          </adp-tab>
          <adp-tab *ngIf='model.isCompleteSuccess' label="Status" [selected]="true" [disabled]="false">
          <div>
          <br>
          <p class="bodyText" style="color:#2d2b2b"><b style="font-size: x-large;">{{model.processedBlocks}}</b> Records Were Processed Successfully.</p>
          </div>          
          </adp-tab>
        </adp-tabs>
      </slide-in-body>      
    </adp-slidein>
  `,
  animations: SLIDE_IN_ANIMATIONS
})
export class EdaSlideinComponent {

  customErrors: string[] = [];
  @HostBinding('@destroyAnimation') destroyAnimation = true;
  @HostBinding('class.vdl-slide-in-mount') isSlidein = true;

  constructor(public model: ModalModel,
    private activeModal: ActiveModal,
    public options: ModalOptions,
    private slideinService: SlideinService) {
    if (!model.isCompleteSuccess) {
      this.prepareErrorsModel(model.errorsWarnings);
    }
  }


  // triggers the promise to be resolved
  done() {
    this.activeModal.close('Slide-in was closed!');
  }

  prepareErrorsModel(errorsWarnings: IErrorsWarnings[]) {
    // allow only +ve nums even 03
    let regexNum = new RegExp('^\\d*[1-9]\\d*$');
    this.model.errorsWarnings.forEach((item: any, index: any) => {
      // indicates valid rank
      if (regexNum.test(item.RANK)) {
        this.customErrors.push('Rank: ' + item.RANK + '  ' + '|    ' + item.REMARKS);
      }
      else {
        this.customErrors.push(item.REMARKS);
      }
    });

  }

  downLoadErrors() {
    let downloadCsvString: string;
    let fileName: string = this.model.fileName.substring(0, this.model.fileName.indexOf('.csv')) + '_Errors' + '_' +
      this.model.creationDate.split("T")[0] + '_' + this.model.creationDate.split("T")[1].replace(/:/g, '-') + '.csv';

    this.customErrors.forEach((item: any, index: any) => {
      if (index == 0) {
        downloadCsvString = item + ',' + '\n';
      }
      else if (index < this.model.errorsWarnings.length - 1) {
        downloadCsvString = downloadCsvString + item + ',' + '\n';
      }
      // indicates last element dont append , after that
      else {
        downloadCsvString = downloadCsvString + item;
      }
    });

    let csvBlob = new Blob([downloadCsvString], { type: 'text/csv;charset=utf-8;' });

    // for IE browser
    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveBlob(csvBlob, fileName);
    }
    else {
      let downloadLink: any = document.createElement('a');
      downloadLink.href = window.URL.createObjectURL(csvBlob);
      downloadLink.setAttribute('download', fileName);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  }
}

@Pipe({ name: 'dateFormatPipe' })
export class dateFormatPipe implements PipeTransform {
  transform(value: string) {
    var datePipe = new DatePipe("en-US");
    value = datePipe.transform(value, 'MM/dd/yy') + ' at ' + datePipe.transform(value, 'shortTime');
    return value;
  }

}

