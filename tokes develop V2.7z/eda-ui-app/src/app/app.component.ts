import { Component, OnDestroy, ViewEncapsulation, ElementRef, OnInit } from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnDestroy, OnInit {
  constructor(private platformLocation: PlatformLocation) {

  }
  // Life Cycle hooks
  ngOnInit(): void {

  }
  ngOnDestroy() {
    console.log('destroying AppComponent');
    (<BetterPlatformBrowserLocationService>this.platformLocation).onDestroy();
  }

}

