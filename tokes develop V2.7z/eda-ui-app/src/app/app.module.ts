import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { APP_BASE_HREF, PlatformLocation } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { UploadFileComponent } from './uploadfile/uploadfile.component';
import { TepmlateSelectionListComponent ,EdaSlideinComponent, dateFormatPipe} from './uploadfile/uploadfile.component';
import { RouterModule, Route } from '@angular/router';
import { ButtonModule, AlertModule, TabsModule, SelectionListModule, BusyIndicatorModule, FileBrowseModule,ConfirmModule,ModalModule,TileModule,ProgressBarModule,SlideinModule } from 'synerg-components';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';
import { EdaService } from '../api/eda/eda.service';
import {APP_DI_CONSTANTS,APP_CONSTANTS} from './appconstants';


 


declare var PORTAL_BASE_PATH: string;

/* Routing demo */
const routes: Route[] = [
    { path: '', redirectTo: '/pracEmployeeDataAssignmentsRulesUpload', pathMatch: 'full' },
    { path: 'pracEmployeeDataAssignmentsRulesUpload', component: UploadFileComponent }
];

export function getBaseLocation() {
    const PREFIX_PARTS_COUNT = 1;
    let paths: string[] = location.hash.split('/');
    // trim off the #
    paths.shift();
    // the first two parts of the hash are from the portal. Those are effectively
    // the base path of this app
    paths.length = PREFIX_PARTS_COUNT;
    let pathParts: string[] = [];
    for (let i = 0; i < PREFIX_PARTS_COUNT; i++) {
        if (paths[i]) {
            pathParts.push(paths[i]);
        } else {
            pathParts.push('x'); // pad the base path
        }
    }

    let basePath = '/' + pathParts.join('/') + '/';

    console.log('Base path locked in as: ' + basePath);
    // we need to set our global variable so the router will
    // know when we are navigating away from the application
    PORTAL_BASE_PATH = basePath;

    return basePath;
}

@NgModule({
    declarations: [
        AppComponent, UploadFileComponent, TepmlateSelectionListComponent, EdaSlideinComponent, dateFormatPipe
    ],
    entryComponents: [EdaSlideinComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    imports: [
        BrowserAnimationsModule,
        BrowserModule,
        FormsModule,
        ButtonModule,
        TabsModule,
        BusyIndicatorModule,
        FileBrowseModule,
        HttpClientModule,
        AlertModule,
        SelectionListModule,
        ConfirmModule,
        ModalModule,
        TileModule,
        ProgressBarModule,
        SlideinModule,       
        RouterModule.forRoot(routes, { useHash: true })

    ],
    providers: [
        EdaService,
        {
            provide: APP_BASE_HREF,
            useFactory: getBaseLocation
        },
        {
            provide: APP_CONSTANTS,
            useValue: APP_DI_CONSTANTS

        },
        // For portal, you will need this in order to avoid memory leaks
        { provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {

}
