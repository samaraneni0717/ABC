/**
 * Created by mckeowr on 4/3/17.
 */
let fs = require('fs-extra');

let pkgPath = './node_modules/synerg-components/package.json';

console.log("Resetting synerg-components dependencies to peer dependencies (fixed in 0.0.14).");
fs.readFile(pkgPath, {encoding: 'utf8'}, function(err, data) {
  if (err) {
    console.error(err);
    process.exit(1);
  } else {
    let packageJson = JSON.parse(data);
    let peerDeps = [
      '@angular',
      'adp-css-framework',
      'adp-icon-font',
      'classlist.js',
      'core-js',
      'font-awesome',
      'intl',
      'proxima-nova',
      'reflect-metadata',
      'rxjs',
      'ts-helpers',
      'web-animations-js',
      'zone.js'
    ];

    packageJson.peerDependencies = {};

    Object.keys(packageJson.dependencies).forEach(name => {

      if (peerDeps.some(p => name.startsWith(p))) {
        packageJson.peerDependencies[name] = packageJson.dependencies[name];
        delete packageJson.dependencies[name];
      }
    });

    fs.writeFileSync(pkgPath, JSON.stringify(packageJson, null, 2));

    console.log('Removing nested @angular folder from /node_modules/synerg-components/node_modules');
    fs.remove('./node_modules/synerg-components/node_modules/@angular', (err) => {
      process.exit(0);
    });
  }
});
