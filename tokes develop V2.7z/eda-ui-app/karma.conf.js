// Karma configuration file, see link for more information
// https://karma-runner.github.io/0.13/config/configuration-file.html
const path = require('path');

module.exports = function (config) {

    config.set({
        basePath: '.',
        frameworks: ['jasmine', '@angular/cli'],
        plugins: [
            require('karma-jasmine'),
            require('karma-chrome-launcher'),
            require('karma-jasmine-html-reporter'),
            require('karma-coverage-istanbul-reporter'),
            require('karma-sonarqube-unit-reporter'),
            require('@angular/cli/plugins/karma')
        ],
        client: {
            clearContext: false // leave Jasmine Spec Runner output visible in browser
        },
        files: [
            {pattern: './node_modules/libphonenumber-js/bundle/libphonenumber-js.min.js'},
            {pattern: './src/test.ts', watched: false}
        ],
        preprocessors: {
            './src/test.ts': ['@angular/cli']
        },
        mime: {
            'text/x-typescript': ['ts', 'tsx']
        },
        coverageIstanbulReporter: {
            reports: ['html', 'lcovonly'],
            fixWebpackSourcePaths: true
        },
        sonarQubeUnitReporter: {
            sonarQubeVersion: 'LATEST',
            outputFile: 'build/tests/ut_report.xml',
            useBrowserName: false
        },
        angularCli: {
            environment: 'dev',
            codeCoverage: true
        },
        reporters: config.angularCli && config.angularCli.codeCoverage
            ? ['progress', 'coverage-istanbul', 'kjhtml', 'sonarqubeUnit']
            : ['progress', 'kjhtml'],

        port: 9876,
        colors: true,
        logLevel: config.LOG_INFO,
        autoWatch: true,
        browsers: ['ChromeHeadless'],
        captureTimeout: 210000,
        browserDisconnectTolerance: 3, 
        browserDisconnectTimeout : 210000,
        browserNoActivityTimeout : 210000,         
        singleRun: false,
        webpack: {
            resolve: {
                // we need to override this and add .json in order to get the
                // require('./metadata.min'); statement in the
                // libphonenumber-js index.es6.js work
                extensions: [
                    ".ts",
                    ".js",
                    ".json"
                ]
            }
        }
    });
};