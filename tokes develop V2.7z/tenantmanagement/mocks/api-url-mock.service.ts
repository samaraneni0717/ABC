import { Injectable, Inject } from '@angular/core';
//import { API_PREFIX } from  '../src/app/services/api-url-prefix'


export class ApiUrlMockService {

    constructor ( private prefix: '/api'){
        
            }
    getPrefix() {
        return this.prefix;
    }

    applyPrefix(url: string) {
        return this.prefix + url;
    }
}