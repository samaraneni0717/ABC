/**
 * Created by mckeowr on 3/9/17.
 */
const fs = require('fs');

const utils = {
    /**
     * Reads a file and sends the JSON contents as the response. Optionally
     * pass a function to call after parsing the JSON file but before sending
     * to the client.
     *
     * @param fileNameOrOptions - Full file name to read or options object with properties matching the argument names
     *              such as: {fileName: 'foo.json', req: req, postParse: function() {...}}
     * @param req - the http request
     * @param res - the http response
     * @param postParse - the optional function to call before sending the data back
     *              this function will get a single argument that is the parses JS object
     * @param statusCode - the HTTP status code. Defaults to 200 if not set or 500 if
     *              there is an error reading the file and 404 if the file isn't found.
     * @param delay - optional delay in milliseconds before sending response
     */
    readFileAndSend: function(fileNameOrOptions, req, res, postParse, statusCode, delay) {
        var file;
        if (typeof fileNameOrOptions === 'object') {
            file = fileNameOrOptions.fileName;
            req = fileNameOrOptions.req;
            res = fileNameOrOptions.res;
            postParse = fileNameOrOptions.postParse;
            statusCode = fileNameOrOptions.statusCode;
            delay = fileNameOrOptions.delay

        } else {
            file = fileNameOrOptions;
        }

        if (!file || !req || !res) {
            throw new Error("fileName, req, and res are required arguments");
        }

        if (!statusCode) {
            statusCode = 200;
        }

        fs.exists(file, function (existence) {
            if (existence) {
                fs.readFile(file, function (err, data) {
                    if (err) {
                        console.error(file, err);
                        res.sendStatus(500);
                    } else {
                        var json;
                        try {
                            json = JSON.parse(data);
                        } catch (e) {
                            console.log(e);
                            res.sendStatus(500);
                            return;
                        }
                        if (postParse) {
                            postParse(json);
                        }

                        res.charset="utf-8";

                        if (delay) {
                            setTimeout(function() {
                                res.status(statusCode).send(json);
                            }, delay);
                        } else {
                            res.status(statusCode).send(json);
                        }
                    }
                });
            } else {
                console.log("Couldn't find file: " + file);
                res.sendStatus(404);
            }
        });
    }
};


module.exports = utils;