/**
 * Created by mckeowr on 3/9/17.
 */

const utils = require('./file-util');
const options = require('../build.options');
const path = require('path');

const API_ROOT = options.apiRoot;


function getJsonFilePath(req, fileName) {

    const folderPath = [process.cwd(), 'mock-server', 'json'];

    // To support different scenarios, you may store different versions of JSON files in different directories
    // and switch between them based on a header.

    const scenario = req.get('scenario'); // get the 'scenario' from the request header

    // For example, setting the scenario header of the request to 'foo', would cause the JSON files
    // to be loaded out of the mock-server/json/foo

    if (scenario) {
          folderPath.push(scenario);
    }

    folderPath.push(fileName);

    return path.join.apply(null, folderPath);
}

// You can mock your api calls here. The app argument is an express application
const setup = function(app) {

    /* You can respond to specific requests and return whatever data you want as shown here.

        app.get(API_ROOT + '/foo', (req, res) => {

           res.json({success: 'true'});
        });

    */
    console.log("Setting up dev server...");
    app.use(function (req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
       res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");

        next();
    });

    // Default route. You should add any custom routes above this
    app.use(API_ROOT + '/:fileName', (req, res) => {
    let fileLocation = getJsonFilePath(req, req.params.fileName + '.json');
    utils.readFileAndSend(fileLocation, req, res);
    });

};

module.exports = setup;