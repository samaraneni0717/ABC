
// Build environment configuration
// The intent here is to expose the most commonly modify configuration options. You can of course, edit the
// webpack.config.js file but hopefully you won't have to

// These can also be passed in via command line args such as --env.portal=true
// NOTE: the npm run package* scripts automatically pass portal and prod variables for you. Changing them here
// would only impact the npm run package-dev and npm run start commands

// When running locally with npm run start, you may want to intercept the api calls and pass to either
// a real backend or a locally running mock server (see mock-server.js). This is the url to that server.
// Any requests to it, such as "http://localhost:9000/api" will be routed to that server
// You can change the api root here as well.
const API_ROOT = '/taascommon/TaaS.Tenant.Api/v1/Tenant';
const PROXY_URL = 'http://adpvantage-dit.nj.adp.com'; // <!-- url to actual backend

// For more configuration options that can be specified in this proxyConfig object, see
// https://webpack.js.org/configuration/dev-server/#devserver-proxy
let proxyConfig = {};

// TAAS Web tier rules for local development.  This proxy rule mimic the TAAS routing rules for APIs. 
// the rules are defined at https://confluence.es.ad.adp.com/display/AEPDT/TAAS+Routing+Rules
// Web Tier Rule for TAAS Common (.Net)
 proxyConfig['/taascommon/**'] = {
      target: 'http://commonvip.dit.taas.oneadp.com/',
      changeOrigin: true,      
       pathRewrite: {'^/taascommon/' : ''}, //Remove the Taascommon from the uri.             
      logLevel: 'debug'  //this will print to the console
    };
  
//Web Tier Rule for TAAS apigateway
proxyConfig['/taasgateway/**'] = {
  target: 'http://apigateway.dit.taas.oneadp.com:8081/',
  changeOrigin: true, 
pathRewrite: {'^/taasgateway/' : ''}, //Remove the Taascommon from the uri. 
  logLevel: 'debug' //this will print to the console
};

let config = {
  // portal flag turns on portal packaging which excludes zone.js and will use the styles-portal.scss file
  "portal": false,

  // prod flag turns on Angular's enableProdMode()
  "prod": false,

  // this is the public path of the application. If the application is going into a
  // WAR called app.war, your would use
  //  root: '/app/'
  // When you run: npm run start
  //    this will automatically be set to '/' so that the webpack dev server works correctly
  "root": "",

  //v-------- Used when running via npm run start only
  // see the proxyConfig defined above
  "proxy": proxyConfig,

  // used in the mock-server as the base 'dir' for api requests
  "apiRoot": API_ROOT,

    // This must match the selector of your app.component
    "rootTag": "app-tenantmanagement-root"
};



module.exports = config;