import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


import { TenantNewComponent } from './tenantnew.component';
import { TenantNewModule } from './tenantnew.module';
import { ModalAnchorComponent } from 'synerg-components';
import { AppModule } from '../app.module';
import { TenantActions } from '../tenantlist/tenant.actions';
import { TenantDataService } from '../services/tenantdata.service';
import { TenantDetailMockService } from '../../app/services/tenantdata-mock.service';
import { ITenant} from '../tenantlist/Models/ITenant';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';
import * as iTenantSearch from '../tenantlist/Models/ITenantSearchFields';

import { Observable } from 'rxjs/Observable';

import * as mockdata from '../services/tenantdata-mockdata';

const existingtenantdata = mockdata.multipleOrgoidsResponse[0];


describe('Tenant New Component', () => {

  let comp: TenantNewComponent;
  let fixture: ComponentFixture<TenantNewComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        TenantNewModule
      ],
      providers: [
        { provide: TenantDataService, useClass: TenantDetailMockService }
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TenantNewComponent);
    comp = fixture.debugElement.componentInstance;
    comp.orgOid = 'G347EYZNRMJEMT5E';
    fixture.detectChanges();
    console.log('Before Each run Tenant New Component......');
  });


  it('should create tenant new component', async(() => {
    console.log('List New Tenant Component Test 1......');
    fixture.whenStable().then(() => {
      const srchFlds: ITenantSearchFields = iTenantSearch.initialSearchFields;
      comp.orgOid = 'G347EYZNRMJEMT5E';
      srchFlds.coid = comp.orgOid;
      fixture.detectChanges();
      expect(comp.orgOid).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should create tenant new component', async(() => {
    console.log('List New Tenant Component Test 1A......');
    fixture.whenStable().then(() => {
      const srchFlds: ITenantSearchFields = iTenantSearch.initialSearchFields;
      comp.orgOid = '0';
      srchFlds.coid = comp.orgOid;
      fixture.detectChanges();
      expect(comp.orgOid).toBe('0');
    });
  }));
  it('should load tenant data into new component', async(() => {
    console.log('List New Tenant Load Component Test 2......');
    fixture.whenStable().then(() => {
      comp.orgOid = 'G347EYZNRMJEMT5E';
      const srchFlds: ITenantSearchFields = iTenantSearch.initialSearchFields;
      srchFlds.coid = comp.orgOid;
      const tendata = mockdata.multipleOrgoidsResponse[0];
      comp.InitializeData();
      fixture.detectChanges();
      console.log('TenantData =' + tendata.SMSName + ' ' + tendata.ISIOrgCd + ' ' + tendata.OrgOID);
      expect(comp.orgOid).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should FindExisting tenant new component', async(() => {
    console.log('List New Tenant Component Test 3......');
    fixture.whenStable().then(() => {
      const srchFlds: ITenantSearchFields = iTenantSearch.initialSearchFields;
      comp.orgOid = 'G347EYZNRMJEMT5E';
      srchFlds.coid = comp.orgOid;

      comp.findExistingTenant(srchFlds);

      fixture.detectChanges();
      const tendata = comp.tenantData;
      console.log('TenantData =' + tendata.SMSName + ' ' + tendata.ISIOrgCd + ' ' + tendata.OrgOID);
      expect(comp.orgOid).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should Initialize Existing Tenant in New Component', async(() => {
    console.log('List New Tenant Component InitializeTenant  Test 4......');
    fixture.whenStable().then(() => {
      comp.orgOid = 'G347EYZNRMJEMT5E';
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.InitializeData();
      fixture.detectChanges();
      expect(comp.tenantData.OrgOID).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should Call Status in New Component', async(() => {
    console.log('List New Tenant Component setStatus  Test 5......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.setStatus('Active');
      fixture.detectChanges();
      expect(comp.tenantData.Active).toBe(true);
    });
  }));

  it('should Call Reveal Password in New Component', async(() => {
    console.log('List New Tenant Component revealPassword  Test 6......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.revealNewPassword('text');
      fixture.detectChanges();
      comp.revealNewPassword('password');
      expect(comp.integrationPasswordDisplay).toBe('password');
    });
  }));

  it('should Call Reveal SecretKey in New Component', async(() => {
    console.log('List New Tenant Component revealSecretKey  Test 7......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.revealNewSecretKey('text');
      fixture.detectChanges();
      comp.revealNewSecretKey('password');
      expect(comp.tenantSecretKeyDisplay).toBe('password');
    });
  }));

  it('should Call SetIntegrationSelectionMode in New Component', async(() => {
    console.log('List New Tenant Component setDataIntegrationSelection  Test 8......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.setDataIntegrationSelectionNew('Parallel');
      fixture.detectChanges();
      comp.setDataIntegrationSelectionNew('ON');
      fixture.detectChanges();
      comp.setDataIntegrationSelectionNew('OFF');
      fixture.detectChanges();
      expect(comp.integrationMode).toBe('OFF');
    });
  }));

  it('should Call setDataIntegration in New Component', async(() => {
    console.log('List New Tenant Component setDataIntegration  Test 9......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.dataIntegrationwithWFMValueChecked = true;
      comp.dataIntegrationwithVantageEtimeValueChecked = true;
      comp.setDataIntegrationNew();
      fixture.detectChanges();

      comp.dataIntegrationwithWFMValueChecked = true;
      comp.dataIntegrationwithVantageEtimeValueChecked = false;
      comp.setDataIntegrationNew();
      fixture.detectChanges();
      comp.dataIntegrationwithWFMValueChecked = false;
      comp.dataIntegrationwithVantageEtimeValueChecked = false;
      comp.setDataIntegrationNew();
      fixture.detectChanges();      expect(comp.integrationMode).toBe('OFF');
    });
  }));

  it('should Call SetSSODisplay in New Component', async(() => {
    console.log('List New Tenant Component SetSSODisplay  Test 10......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.displaySignOn = false;
      const event = 'test';
      comp.setSSODisplayNew(event);
      fixture.detectChanges();
      expect(comp.displaySignOn).toBe(true);
    });
  }));

  it('should Call SaveTenantData ADD in New Component', async(() => {
    console.log('List New Tenant Component ADD saveTenantData  Test 11......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.tenantData = tenantData;
      comp.TenantMode = 'ADD';
      comp.displaySignOn = false;
      const eventsent: Event = null;
      comp.saveNewTenantData(event);
      fixture.detectChanges();
      expect(comp.tenantData.OrgOID).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should Call SaveTenantData SAVE in New Component', async(() => {
    console.log('List New Tenant Component SAVE saveTenantData  Test 12......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.tenantData = tenantData;
      comp.TenantMode = 'SAVE';
      comp.displaySignOn = false;
      const eventsent: Event = null;
      comp.saveNewTenantData(event);
      fixture.detectChanges();
      expect(comp.tenantData.OrgOID).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should load tenant data into new component with null properties', async(() => {
    console.log('List New Tenant Load Component Test 13......');
    fixture.whenStable().then(() => {
      comp.orgOid = 'G347EYZNRMJEMT5E';
      const srchFlds: ITenantSearchFields = iTenantSearch.initialSearchFields;
      srchFlds.coid = comp.orgOid;
      const tendata = <ITenant>mockdata.multipleOrgoidsResponse[0];
      tendata.Properties = null;
      comp.InitializeData();
      fixture.detectChanges();
      console.log('TenantData =' + tendata.SMSName + ' ' + tendata.ISIOrgCd + ' ' + tendata.OrgOID);
      expect(comp.orgOid).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should return to Tenant Add screen', async(() => {
    console.log('Return to Tenant Add Component Test 14......');
    fixture.whenStable().then(() => {
      comp.returnToSMSList();
      fixture.detectChanges();
      expect(comp.displaySignOn).toBe(false);
    });
  }));

  it('should execute resetTenantSaved Add screen', async(() => {
    console.log('Return resetTenantSaved Test 15......');
    fixture.whenStable().then(() => {
      comp.onDetailAddCloseAlert(true);
      fixture.detectChanges();
      expect(comp.displaySignOn).toBe(false);
    });
  }));
});
