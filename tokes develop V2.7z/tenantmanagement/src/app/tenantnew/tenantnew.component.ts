import { FormsModule, NgForm } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output, ElementRef, ViewEncapsulation, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Location } from '@angular/common';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { select, NgRedux } from 'ng2-redux';

import { ISms } from '../tenantlist/Models/ISms';
import { ITenant } from '../tenantlist/Models/ITenant';
import * as ITennt from '../tenantlist/Models/ITenant';
import { TenantDataValidator } from '../tenantlist/Models/TenantDataValidate';

import * as itentantConstants from '../tenantlist/Models/ITenant';
import * as iTenantSearch from '../tenantlist/Models/ITenantSearchFields';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';

import {
  DateFormatService, TextboxComponent, TextboxModule, FormGroupModule, CheckboxComponent,
  BusyIndicatorModule
} from 'synerg-components';
import { SecondaryNavComponent, FormGroupMessage, FormGroupConfig, IconComponent } from 'synerg-components';
import { ConfirmService, ConfirmConfig } from 'synerg-components';
import {
  ModalService, ModalAnchorComponent, ModalComponent, ModalModel,
  ModalOptions, ActiveModal, MODAL_ANIMATIONS
} from 'synerg-components';

import * as detailconstants from '../tenantdetail/tenantdetailconstants';

import { AppState } from '../store/';
import * as store from '../store';
import { TenantActions } from '../tenantlist/tenant.actions';

import { Pipe, PipeTransform } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { forEach } from '@angular/router/src/utils/collection';
import { UrlTree } from '@angular/router/src/url_tree';
import { UIActions } from '../store/ui-actions';



@Component({
  selector: 'app-tenantnew',
  templateUrl: './tenantnew.component.html',
  styleUrls: ['../tenantlist/tenantlist.component.scss'],
  providers: [ModalService, ConfirmService, ConfirmConfig],
  encapsulation: ViewEncapsulation.None
})
export class TenantNewComponent implements OnInit {
  @select(store.getNewTenant) newTenant$: Observable<ITenant>;
  @select(store.isTenantSaving) isSaveLaunched$: Observable<boolean>;
  @select(store.isNewTenantLoading) isNewTenantLoading$: Observable<boolean>;
  @select(store.didTenantSave) didTenantAdd$: Observable<boolean>;
  @select(store.didTenantSaveError) didTenantAddError$: Observable<boolean>;
  @select(store.errorMessages) errorMessages$: Observable<any>;
  @select(store.getLoggedOnUser) loggedOnUser$: Observable<any>;

  @ViewChild('addNewTenantForm') addForm: NgForm;
  dataValidator: TenantDataValidator;

  listconstants = detailconstants;
  // Initialize TenantDetail data
  tenantData = itentantConstants.initialTenant;

  // tslint:disable-next-line:no-inferrable-types
  orgOid = '0';

  // Calculate integration mode
  integrationMode: string;

  currentUser: string;

  // default settings
  dataIntegrationwithWFMValueChecked = false;
  dataIntegrationwithVantageEtimeValueChecked = false;
  activeValue = 'Active';
  displaySignOn = false;

  tenantSecretKeyDisplay = 'password';
  integrationPasswordDisplay = 'password';

  searchParameters: ITenantSearchFields = iTenantSearch.initialSearchFields;

  netSecureResults: ISms[];
  netSecureIdsList: ISms[] = [];


  querySMSNetsecureid = '';

  displaySMSList = false;

  smsName = '';
  netSecureId = '';
  tenantExists$ = false;

  clientExistsConfirm = false;
  TenantMode = 'ADD';

  regionValueAttribute: any = { 'value': '0000', 'name': '0000 none' };

  regionList = detailconstants.listtenantregion;

  errorFound$ = '';
  primaryTenant = true;
  otherPrimaryExists = false;
  existingPrimaryTenantId = '';

  constructor(private tenantActions: TenantActions, private router: Router,
    private route: ActivatedRoute, private confirmService: ConfirmService, private location: Location, private uiActions: UIActions, ) {

  }
  ngOnInit() {

    this.initializeTenant();

    this.getLoggedOnInfo();

    this.dataValidator = new TenantDataValidator();

    window.scrollTo(0, 0);

  } //  end oninit

  initializeTenant() {
    // Defaults to 0 if no query param provided.
    this.orgOid = this.route.snapshot.queryParams['orgOid'] || '0';
    this.smsName = this.route.snapshot.queryParams['smsName'];
    this.netSecureId = this.route.snapshot.queryParams['netSecureID'];

    const srchData = iTenantSearch.initialSearchFields;
    srchData.coid = this.orgOid;
    srchData.netSecureID = this.netSecureId;
    srchData.clientName = this.smsName;

    this.InitializeData();

    if (!(this.orgOid === '0')) {      
      this.uiActions.startLoading('UI:NEW_TENANTLOADING_START');
      this.findExistingTenant(srchData);
    }

  }

  findExistingTenant(srchData: ITenantSearchFields) {
    this.tenantActions.getTenantByOrgoid(srchData).subscribe(data => {

      this.uiActions.stopLoading('UI:NEW_TENANTLOADING_FINISHED');

      if (data != null && data.OrgOID === this.orgOid) {
        this.clientExistsConfirm = true;
        this.confirmService.open({
          'title': 'Tenant Already Exists',
          'contents': 'Do you wish to continue Adding a New Tenant for this Client?',
          'confirmLabel': 'Continue',
          'dismissLabel': 'Cancel'
        })
          .then(() => { this.tenantData.isPrimary = false;
            this.otherPrimaryExists = true;
            this.existingPrimaryTenantId = data.tenantid;
          })
          .catch((rejection: any) => {
            this.tenantExists$ = false;
            this.location.back();
          });

      }
    }, error => {
      this.uiActions.stopLoading('UI:NEW_TENANTLOADING_FINISHED');
      console.log('Error during Get Tenant by Orgoid ' + error.error + ' ' + error.message + 'url ' + error.url);
    });
  }


  InitializeData() {
    this.tenantData.SMSName = this.smsName;
    this.tenantData.ISIOrgCd = this.netSecureId;
    this.tenantData.OrgOID = this.orgOid;
    this.tenantData.Active = false;
    this.tenantData.AppKey = '';
    this.tenantData.CompanyCode = '';
    this.tenantData.IntegrationMode = 'OFF';
    this.tenantData.MetadataUrl = '';
    this.tenantData.Modifiedby = '';
    this.tenantData.Modifieddate = '';
    this.tenantData.OAuthEndPoint = '';
    this.tenantData.ProductName = '';
    this.tenantData.Properties = [
      {
        'PropertyType': '',
        'PropertyKey': '',
        'PropertyValue': ''
      }
    ];
    this.tenantData.Region = '';
    this.tenantData.RouteName = '';
    this.tenantData.SamlAcsUrl = '';
    this.tenantData.SamlAssertionUrl = '';
    this.tenantData.TenantId = '';
    this.tenantData.TenantPassWord = '';
    this.tenantData.TenantRoot = '';
    this.tenantData.TenantSecretKey = '';
    this.tenantData.TenantShortName = '';
    this.tenantData.TenantSsoUrl = '';
    this.tenantData.TenantType = '';
    this.tenantData.TenantUserName = '';
    this.tenantData.isPrimary = true;
  }

  getLoggedOnInfo()
  {
    this.loggedOnUser$.subscribe(info => {
      this.currentUser = detailconstants.formatLogonUser(info.FirstName, info.LastName);
      this.tenantData.Modifiedby = this.currentUser;
    });
  }

  setStatus(selection: any) {
    const isActive = selection === 'Active' ? true : false;
    this.tenantData.Active = isActive;
  }

  revealNewPassword(event: any) {
    if (this.integrationPasswordDisplay === 'text') {
      this.integrationPasswordDisplay = 'password';
    } else {
      this.integrationPasswordDisplay = 'text';
    }

  }

  revealNewSecretKey(event: any) {
    if (this.tenantSecretKeyDisplay === 'text') {
      this.tenantSecretKeyDisplay = 'password';
    } else {
      this.tenantSecretKeyDisplay = 'text';
    }
  }


  infoLinkEditDisable(): boolean {
    let resp = false;
    if (this.tenantData.RouteName === 'Infolink') {
      resp = true;
    }

    return resp;
  }

  setDataIntegrationSelectionNew(mode: string) {
    if (mode === 'Parallel') {
      this.dataIntegrationwithWFMValueChecked = true;
      this.dataIntegrationwithVantageEtimeValueChecked = true;
      this.integrationMode = 'Parallel';
      return;
    }

    if (mode === 'ON') {
      this.dataIntegrationwithWFMValueChecked = true;
      this.dataIntegrationwithVantageEtimeValueChecked = false;
      this.integrationMode = 'ON';
      return;
    }

    if (mode === 'OFF') {
      this.dataIntegrationwithWFMValueChecked = false;
      this.dataIntegrationwithVantageEtimeValueChecked = false;
      this.integrationMode = 'OFF';
      return;
    }

  }

  setDataIntegrationNew() {
    if (this.dataIntegrationwithWFMValueChecked && this.dataIntegrationwithVantageEtimeValueChecked) {
      this.integrationMode = 'Parallel';
    }

    if (this.dataIntegrationwithWFMValueChecked && !this.dataIntegrationwithVantageEtimeValueChecked) {
      this.integrationMode = 'ON';
    }

    if (!this.dataIntegrationwithWFMValueChecked) {
      this.integrationMode = 'OFF';
    }
  }

  setSSODisplayNew(event: any) {
    this.displaySignOn = !this.displaySignOn;
  }

  setRegion() {
    const code = this.regionValueAttribute['value'];
    this.tenantData.Region = code;
  }

  saveNewTenantData(data: Event) {
    try {

      if (!(this.tenantData == null)) {

        this.tenantData.IntegrationMode = this.integrationMode;

        const isActive = this.activeValue === 'Active' ? true : false;
        this.tenantData.Active = isActive;

        if (this.dataValidator.ValidateTenantData(this.tenantData)) {
          return true;
        }

        this.tenantData.Modifiedby = this.currentUser;

        const tenantDataJson = JSON.parse(JSON.stringify(this.tenantData));
        let title = 'Save Tenant Data';
        let contents = `Do you wish to continue Saving Tenant Data?`;
        const confirmLabel= 'Continue';
        const dismissLabel = 'Cancel';

        if (this.otherPrimaryExists && this.tenantData.isPrimary && (this.tenantData.TenantId !== this.existingPrimaryTenantId)) {
          title = 'Warning: Existing Primary Tenant Assignment';
          contents = `We have identified that the client already has a Primary Tenant assigned. 
          Do you want to make this tenant the new Primary tenant?`;
          }

          this.confirmService.open({
            'title': title,
            'contents': contents,
            'confirmLabel': confirmLabel,
            'dismissLabel': dismissLabel
        })
          .then(() => {this.saveData(tenantDataJson)} )
          .catch((rejection: any) => {
            return true;
          });
      }
    } catch (e) { console.log('Error During Tenant Save'); }    
  }

  saveData(tenantDataJson: any) {

    if (this.TenantMode === 'ADD') {
      this.tenantActions.addTenant(tenantDataJson);
    } else {
      this.tenantActions.saveTenant(tenantDataJson);
    }

    this.tenantData.Modifieddate = new Date().toLocaleString();

    this.errorMessages$.subscribe( dataerr =>  { this.errorFound$ = dataerr; } );

    this.addForm.form.markAsPristine();

  }

  onDetailAddCloseAlert(returnToPrevious: boolean) {
    this.tenantActions.resetTenantSaved();
    if (returnToPrevious) {
      this.returnToSMSList();
    }
  }

  returnToNewTenant() {
    this.router.navigate(['tenantnew']);
  }

  returnToTenantList() {
    this.tenantActions.resetTenantSaved();
    this.router.navigate(['/tenantlist']);
  }

  returnToSMSList() {
    this.tenantActions.resetTenantSaved();
    this.router.navigate(['/tenantadd']);
  }

  getOrgoId(): string {
    return this.tenantData.OrgOID;
  }

  getTenantId(): string {
    return this.tenantData.TenantId;
  }

  ngOnDestroy() {
    this.tenantActions.resetTenantSaved();
  }
}
