
import { NgRedux } from '../../../node_modules/ng2-redux';
import { AppState } from './store';
import { Injectable } from '../../../node_modules/@angular/core';
import { IUIAlert } from '../store/IUIAlert';

export const TENANTS_START_LOADING = 'UI:TENANTS_START_LOADING';
export const TENANTS_STOP_LOADING = 'UI:TENANTS_STOP_LOADING';
export const TENANT_SAVE_LAUNCHED = 'UI:TENANT_SAVE_LAUNCHED';
export const TENANT_SAVE_FINISHED = 'UI:TENANT_SAVE_FINISHED';
export const HTTP_ERROR = 'UI:HTTP_ERROR';
export const HTTP_SUCCESS = 'UI:HTTP_SUCCESS';
export const SMS_START_LOADING = 'UI:SMS_START_LOADING';
export const SMS_STOP_LOADING = 'UI:SMS_STOP_LOADING';
export const NEW_TENANTLOADING_START = 'UI:NEW_TENANTLOADING_START';
export const NEW_TENANTLOADING_FINISHED = 'UI:NEW_TENANTLOADING_FINISHED';
export const TENANTS_FOUND = 'UI:TENANTS_FOUND';
export const TENANTS_NOTFOUND = 'UI:TENANTS_NOTFOUND';
export const SMS_ENTRIES_FOUND = 'UI:SMS_ENTRIES_FOUND';
export const SMS_ENTRIES_NOTFOUND = 'UI:SMS_ENTRIES_NOTFOUND';
export const TENANT_HAS_SAVED = 'UI:TENANT_HAS_SAVED';
export const TENANT_NOT_SAVING = 'UI:TENANT_NOT_SAVING';
export const TENANT_SAVE_RESET = 'UI:TENANT_SAVE_RESET';
export const SET_REQUESTING_USER = 'UI:SET_REQUESTING_USER';
export const ENTITLEMENTS_FOUND ='UI:ENTITLEMENTS_FOUND';


@Injectable()
export class UIActions {
    constructor(private ngRedux: NgRedux<AppState>) { }

    startLoading(uiActionType: string) {
        this.ngRedux.dispatch({
            type: uiActionType
        });
    }

    stopLoading(uiAction: string) {
        this.ngRedux.dispatch({
            type: uiAction
        });
    }

    stopLoadingWithErrors(uiActionType: string, error: string) {
        this.ngRedux.dispatch({
            type: uiActionType,
            error
        });
    }

    alert(uiAlert: IUIAlert) {
        this.ngRedux.dispatch({
            type: uiAlert.type,
            uiAlert
        });
    }
    setUserData(uiActionType: string, userName: string) {
        this.ngRedux.dispatch({
            type: uiActionType,
            userName
        });
    }

}
