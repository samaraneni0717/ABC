import * as UI_ACTIONS from './ui-actions';

// Define the interface for the state that this store manages
export interface UIState {
  isLoading: boolean;
  isTenantSaving: boolean;
  isDetailSMSLoading: boolean;
  isNewTenantLoading: boolean;
  tenantsFound: boolean;
  smsEntriesFound: boolean;
  didTenantSave: boolean;
  didTenantSaveError: boolean;
  error: any;
  requestingUser: string;
  entitlementsFound: boolean;
}

// This is the initial state
const initialState: UIState = {
  isLoading: false,
  isTenantSaving: false,
  isDetailSMSLoading: false,
  isNewTenantLoading: false,
  tenantsFound: true,
  smsEntriesFound: true,
  didTenantSave: false,
  didTenantSaveError: false,
  error: null,
  requestingUser: '',
  entitlementsFound: false
};

export function reducer(state = initialState, action: any) {
  switch (action.type) {
    case UI_ACTIONS.TENANTS_START_LOADING:
      return Object.assign({}, state, { isLoading: true, isTenantSaving: false, isDetailSMSLoading: false,
        isNewTenantLoading: false, didTenantSave: false, didTenantSaveError: false, error: null });

    case UI_ACTIONS.TENANTS_STOP_LOADING:
    case UI_ACTIONS.TENANT_SAVE_FINISHED:
    case UI_ACTIONS.NEW_TENANTLOADING_FINISHED:
    case UI_ACTIONS.TENANT_SAVE_RESET:
    case UI_ACTIONS.SMS_STOP_LOADING:
      return Object.assign({}, state, { isLoading: false, isTenantSaving: false, isDetailSMSLoading: false,
        isNewTenantLoading: false, didTenantSave: false, didTenantSaveError: false, error: null  });

    case UI_ACTIONS.TENANT_HAS_SAVED:
      return Object.assign({}, state, { isLoading: false, isTenantSaving: false, isDetailSMSLoading: false,
        isNewTenantLoading: false, didTenantSave: true, didTenantSaveError: false, error: null });

    case UI_ACTIONS.TENANT_NOT_SAVING:
      return Object.assign({}, state, { isLoading: false, isTenantSaving: false, isDetailSMSLoading: false,
         isNewTenantLoading: false, didTenantSave: false, didTenantSaveError: true, error: action.error });

    case UI_ACTIONS.TENANT_SAVE_LAUNCHED:
      return Object.assign({}, state, { isLoading: false, isTenantSaving: true, isDetailSMSLoading: false,
         isNewTenantLoading: false, didTenantSave: false, didTenantSaveError: false, error: null });

    case UI_ACTIONS.NEW_TENANTLOADING_START:
      return Object.assign({}, state, { isLoading: false, isTenantSaving: false, isDetailSMSLoading: false,
        isNewTenantLoading: true, didTenantSave: false, didTenantSaveError: false, error: null });

    case UI_ACTIONS.TENANTS_FOUND:
      return Object.assign({}, state, {
        isLoading: false, isTenantSaving: false, isDetailSMSLoading: false, isNewTenantLoading: false,
         tenantsFound: true, didTenantSave: false, didTenantSaveError: false, error: null
      });

    case UI_ACTIONS.TENANTS_NOTFOUND:
      return Object.assign({}, state, {
        isLoading: false, isTenantSaving: false, isDetailSMSLoading: false, isNewTenantLoading: false,
         tenantsFound: false, didTenantSave: false, didTenantSaveError: false, error: action.error
      });

    case UI_ACTIONS.SMS_START_LOADING:
      return Object.assign({}, state, { isLoading: false, isTenantSaving: false, isDetailSMSLoading: true,
         isNewTenantLoading: false, didTenantSave: false, didTenantSaveError: false, error: null });

    case UI_ACTIONS.SMS_ENTRIES_FOUND:
      return Object.assign({}, state, {
        isLoading: false, isTenantSaving: false, isDetailSMSLoading: false, isNewTenantLoading: true,
        tenantsFound: true, smsEntriesFound: true
      });

    case UI_ACTIONS.SMS_ENTRIES_NOTFOUND:
      return Object.assign({}, state, {
        isLoading: false, isTenantSaving: false, isDetailSMSLoading: false, isNewTenantLoading: false,
        tenantsFound: false, smsEntriesFound: false, error: action.error
      });

      case UI_ACTIONS.ENTITLEMENTS_FOUND:
      return Object.assign({}, state, {
        isLoading: false, isTenantSaving: false, isDetailSMSLoading: false, isNewTenantLoading: false,
        tenantsFound: true, smsEntriesFound: false, error: action.error, entitlementsFound: true
      });

    case UI_ACTIONS.HTTP_ERROR:
      return Object.assign({}, state, { isLoading: false, error: action.error });

    case UI_ACTIONS.HTTP_SUCCESS:
      return Object.assign({}, state, { isLoading: false, error: action.error });

    case UI_ACTIONS.SET_REQUESTING_USER:  
        return Object.assign({}, state, { isLoading: false, requestingUser: action.userName });

    default:
      return state;
  }
}
