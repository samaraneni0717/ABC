import {ISms} from '../tenantlist/Models/ISms';
import {ISMSList} from '../tenantlist/Models/ISMSList';
import {ISMSSearchFields} from '../tenantlist/Models/ISMSSearchFields';
import { ITenant } from '../tenantlist/Models/ITenant';
import { ITenantList } from '../tenantlist/Models/ITenantList';
import * as tenant from '../tenantlist/tenant.actions';
import { retry } from 'rxjs/operator/retry';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';



export interface SMSState {
    smsEntries: ISMSList;
    displaySMSEntries: ISMSList;
    searchModel: ISMSSearchFields;
}

export const initialState: SMSState = {
    smsEntries: { list: [] },
    displaySMSEntries: { list: [] },
    searchModel: { OrgOID: '', SMSName: '', ISIOrgCd: '', searchType: '' }
};

function storeSMSEntries(state: SMSState, action: any): SMSState {

    let currentSMSEntries: any = <ISms[]>action.smsDataFound;
    // deepcopy; Object.assign is a shallow copy
    if (currentSMSEntries == null) {
        currentSMSEntries = [];
    }
    const copyObj = deepCopyObj(currentSMSEntries);

    return Object.assign({}, state, {
        smsEntries: { list: currentSMSEntries },
        displaySMSEntries: { list: copyObj.slice(0, 15) },
    });
}

function sortSMS(state: SMSState, action: any) {

    if (action.colname && action.order) {
      const currentSMSEntries = <ISms[]>state.smsEntries.list;
      const copyObj = deepCopyObj(currentSMSEntries);
      copyObj.sort(compareValues(action.colname, action.order));
      return Object.assign({}, state, {
          smsEntries: {list: copyObj },
          displaySMSEntries:  { list: copyObj.slice(0, 15) },
      });
    }
  }

  function compareValues(key: any, order = 'asc') {
    return function(a: any, b: any) {
      if (!a.hasOwnProperty(key) ||
         !b.hasOwnProperty(key)) {
          return 0;      }
  
      const varA = (typeof a[key] === 'string') ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string') ? b[key].toUpperCase() : b[key];
  
      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return (
        (order === 'desc') ? (comparison * -1) : comparison
      );
    };
  }  



function scrollnext(state: SMSState, action: any): SMSState {
    const filteredTenantssObj = deepCopyObj(state.smsEntries.list);
    return Object.assign({}, state, {
        displayTenants: { list: filteredTenantssObj.list.slice(0, state.displaySMSEntries.list.length + action.smsEntriesPerPage) }
    });
}


function deepCopyObj(obj: any) {

    return JSON.parse(JSON.stringify(obj));

}

export function reducer(state: SMSState = initialState, action: any): SMSState {
    switch (action.type) {
        case tenant.REQUEST_SMSENTRIES_SUCCESS:
            return storeSMSEntries(state, action);
        case tenant.REQUEST_SMSENTRIES_NEXT:
            return scrollnext(state, action);
        case tenant.REQUEST_SORTSMSENTRIES:
            return sortSMS(state, action);
        default:
            return state;
    }
}
