import { Store, combineReducers, createStore, Reducer, applyMiddleware, GenericStoreEnhancer, compose } from 'redux';

import * as uistate from './ui-actions.reducer';
import * as tenant from './tenant.reducer';
import * as tenantdetail from './tenantdetail.reducer';
import * as tenantadd from './tenantadd.reducer';
import * as tenantnew from './tenantnew.reducer';
import * as entitlements from './tenantentitlement.reducer';

declare var window: any;
// for chrome devToolsExtension
// import applyMiddleware, GenericStoreEnhancer, compose  from redux
// Add the 8-12 lines code
//
const devToolsExtension: GenericStoreEnhancer = (window.devToolsExtension)
    ? window.devToolsExtension() : (f) => f;

export interface AppState {
    tenant: tenant.AppState;
    uistate: uistate.UIState;
    tenantdetail: tenantdetail.AppStateDetail;
    tenantadd: tenantadd.SMSState;
    tenantnew: tenantnew.TenantState;
    entitlements: entitlements.AppStateEntitlements;
}


const reducers = {
    tenant: tenant.reducer,
    tenantdetail: tenantdetail.reducer,
    tenantadd: tenantadd.reducer,
    tenantnew: tenantnew.reducer,
    uistate: uistate.reducer,
    entitlements: entitlements.reducer
};

const rootReducer: Reducer<AppState> = combineReducers(reducers);
export const store: Store<AppState> = createStore(rootReducer,
    compose(devToolsExtension) as GenericStoreEnhancer);


export const getDisplayTenants = (state: AppState) => state.tenant.displayTenants.list;
export const getTenantDetails = (state: AppState) => state.tenantdetail.tenantdetails;
export const getComponentListSerach = (state: AppState) => state.tenant.searchModel;
export const getSMSEntries = (state: AppState) => state.tenantadd.displaySMSEntries.list;
export const getNewTenant = (state: AppState) => state.tenantnew.tenant;
export const getLoggedOnUser = (state: AppState) => state.tenant.userInfo;
export const getEntitlements = (state: AppState) => state.entitlements.displayentitlements.list;
export const isSearchLoading = ((state: AppState) => state.uistate.isLoading);
export const isTenantSaving = ((state: AppState) => state.uistate.isTenantSaving);
export const isDetailSMSLoading = ((state: AppState) => state.uistate.isDetailSMSLoading);
export const isNewTenantLoading = ((state: AppState) => state.uistate.isNewTenantLoading);
export const noSearchResults = ((state: AppState) => state.uistate.tenantsFound);
export const noSmSSearchResults = ((state: AppState) => state.uistate.smsEntriesFound);
export const didTenantSave = ((state: AppState) => state.uistate.didTenantSave);
export const didTenantSaveError = ((state: AppState) => state.uistate.didTenantSaveError);
export const errorMessages = ((state: AppState) => state.uistate.error);
export const isEntitlementFound = ((state: AppState)=> state.uistate.entitlementsFound);

