import { ITenant } from '../../app/tenantlist/Models/ITenant';

import * as ITen from '../../app/tenantlist/Models/ITenant';
import { ITenantList } from '../../app/tenantlist/Models/ITenantList';
import * as tenant from '../../app/tenantlist/tenant.actions';
import { retry } from 'rxjs/operator/retry';



export interface AppStateDetail {
    tenantdetails: ITenant;
}

export const initialState: AppStateDetail = {
        tenantdetails: ITen.initialTenant
    };

function storeTenants(state: AppStateDetail, action: any): AppStateDetail {

    const currentTenant: any = <ITenant>action.tenantdetails;
    // deepcopy; Object.assign is a shallow copy
    return Object.assign({}, state, {
        tenantdetails: currentTenant,
    });
}


function scrollnext(state: AppStateDetail, action: any): AppStateDetail {

    const filteredTenantssObj = state.tenantdetails; // deepCopyObj(state.tenants.list);
    return Object.assign({}, state, {
        tenantdetails: { list: filteredTenantssObj }
    });
}


function filterTenants(state: AppStateDetail, action: any): AppStateDetail {
    console.log('inside reducer:filterTenants');

    const displayTenantsObj = deepCopyObj(state.tenantdetails);
    return Object.assign({}, state, {
        tenantdetails: { list: displayTenantsObj.slice(0, 12) }
    });
}


function deepCopyObj(obj: any) {

    return JSON.parse(JSON.stringify(obj));

}

export function reducer(state: AppStateDetail = initialState, action: any): AppStateDetail {
    switch (action.type) {
        case tenant.REQUEST_TENANTDETAIL_SUCCESS:
            return storeTenants(state, action);
        default:
            return state;
    }
}
