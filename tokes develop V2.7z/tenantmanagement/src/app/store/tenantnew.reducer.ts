import { ITenant } from '../tenantlist/Models/ITenant';
import { ITenantList } from '../tenantlist/Models/ITenantList';
import * as tenant from '../tenantlist/tenant.actions';
import { retry } from 'rxjs/operator/retry';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';



export interface TenantState {
    tenant: ITenant;
    displayTenant: ITenant;
    searchModel: ITenantSearchFields;
    newtenant: boolean;
}

export const initialState: TenantState = {
    tenant: null,
    displayTenant: null,
    newtenant: false,
    searchModel: { coid: '', tenantid: '', vanityURL: '', clientName: '', netSecureID: '' }
};

function storeTenant(state: TenantState, action: any): TenantState {

    const currentTenant = <ITenant>action.tenant;
    // deepcopy; Object.assign is a shallow copy
    const copyObj = deepCopyObj(currentTenant);
    return Object.assign({}, state, {
        tenant:  currentTenant,
        displayTenant: copyObj,
        newtenant: true
    });
}

function addTenant(state: TenantState, action: any): TenantState {

    const currentTenant = state.tenant;

    return Object.assign({}, state, {
        tenant: currentTenant,
        displaytenant: currentTenant,
        newtenant: true
    });
}

function deepCopyObj(obj: any) {

    return JSON.parse(JSON.stringify(obj));

}

export function reducer(state: TenantState = initialState, action: any): TenantState {
    switch (action.type) {
        case tenant.REQUEST_TENANT_SUCCESS:
            return storeTenant(state, action);
        default:
            return state;
    }
}
