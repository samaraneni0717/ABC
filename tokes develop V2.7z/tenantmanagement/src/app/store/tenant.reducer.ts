import { ITenant } from '../tenantlist/Models/ITenant';
import { ITenantList } from '../tenantlist/Models/ITenantList';
import * as tenant from '../tenantlist/tenant.actions';
import { retry } from 'rxjs/operator/retry';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';
import { IAdpUserInfo } from '../tenantlist/Models/IAdpUserInfo';
import * as iadpusrinfo from '../tenantlist/Models/IAdpUserInfo';



export interface AppState {
    tenants: ITenantList;
    displayTenants: ITenantList;
    searchModel: ITenantSearchFields;
    newtenant: ITenant;
    userInfo: IAdpUserInfo;
}

export const initialState: AppState = {
    tenants: { list: [] },
    displayTenants: { list: [] },
    newtenant: null,
    userInfo: iadpusrinfo.initialAdpUserInfo,
    searchModel: { coid: '', tenantid: '', vanityURL: '', clientName: '', netSecureID: '' }
};

function storeTenants(state: AppState, action: any): AppState {

    const currentTenants: any = <ITenant[]>action.tenants;
    // deepcopy; Object.assign is a shallow copy
    const copyObj = deepCopyObj(currentTenants);
    return Object.assign({}, state, {
        tenants: { list: currentTenants },
        displayTenants: { list: copyObj.slice(0, 15) },
    });
}

function sortTenants(state: AppState, action: any) {

    if (action.colname && action.order) {
      const currentTenants = <ITenant[]>state.tenants.list;
      const copyObj = deepCopyObj(currentTenants);
      copyObj.sort(compareValues(action.colname, action.order));
      return Object.assign({}, state, {
          tenants: {list: copyObj },
          displayTenants:  { list: copyObj.slice(0, 15) },
      });
    }
  }

  function compareValues(key: any, order = 'asc') {
    return function(a: any, b: any) {
      if (!a.hasOwnProperty(key) ||
         !b.hasOwnProperty(key)) {
          return 0;      }
  
      const varA = (typeof a[key] === 'string') ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string') ? b[key].toUpperCase() : b[key];
  
      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return (
        (order === 'desc') ? (comparison * -1) : comparison
      );
    };
  }  

function setUserInfo(state: AppState, action: any): AppState {
    const userinfo = <IAdpUserInfo>action.userinfo;
    return Object.assign({}, state, {userInfo: userinfo});
}


function scrollnext(state: AppState, action: any): AppState {
    const filteredTenantssObj = deepCopyObj(state.tenants);
    return Object.assign({}, state, {
        displayTenants: { list: filteredTenantssObj.list.slice(0, state.displayTenants.list.length + action.tenantsPerPage) }
    });
}


function deepCopyObj(obj: any) {

    return JSON.parse(JSON.stringify(obj));

}

export function reducer(state: AppState = initialState, action: any): AppState {
    switch (action.type) {
        case tenant.REQUEST_TENANTS_SUCCESS:
            return storeTenants(state, action);
        case tenant.REQUEST_TENANTS_NEXT:
            return scrollnext(state, action);
        case tenant.REQUEST_USERINFO:
            return setUserInfo(state, action);
        case tenant.REQUEST_SORT:
            return sortTenants(state, action);

        default:
            return state;
    }
}
