import { ITenant } from '../../app/tenantlist/Models/ITenant';

import * as ITen from '../../app/tenantlist/Models/ITenant';
import { IEntitlementSummary, initialEntitlementSummary, IEntitlementSummaryList } from '../tenantlist/Models/IEntitlementSummary';
import * as tenant from '../../app/tenantlist/tenant.actions';
import { retry } from 'rxjs/operator/retry';



export interface AppStateEntitlements {
    tenantentitlements: IEntitlementSummaryList;
    displayentitlements: IEntitlementSummaryList;
}

export const initialState: AppStateEntitlements = {
    tenantentitlements: {list: [] },
    displayentitlements: {list: [] }
    };

function storeEntilementLicenses(state: AppStateEntitlements, action: any): AppStateEntitlements {
    const currentTenantEntitlements = <IEntitlementSummary[]>action.entitlementinfo;
    if (!action.entitlementinfo) {        
        return Object.assign({}, initialState);
    }

    // deepcopy; Object.assign is a shallow copy
    const copyObj = deepCopyObj(currentTenantEntitlements);
    return Object.assign({}, state, {
        tenantentitlements: { list: currentTenantEntitlements },
        displayentitlements: { list: copyObj.slice(0, 15) }
    });
}


function deepCopyObj(obj: any) {

    return JSON.parse(JSON.stringify(obj));

}

export function reducer(state: AppStateEntitlements = initialState, action: any): AppStateEntitlements {
    switch (action.type) {
        case tenant.REQUEST_ENTITLEMENTSUMMARY:
            return storeEntilementLicenses(state, action);
        default:
            return state;
    }
}
