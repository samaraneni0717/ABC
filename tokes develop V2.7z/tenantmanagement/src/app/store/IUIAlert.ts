export interface  IUIAlert{ 
    code: number;
    type: string; 
    message: string;
}