/**
 * This is the base component of your application. It shows a basic example of how to use ngrx for
 * state management in your application. There is much more that you can do with it that this simple
 * example. See the official sample app at: https://github.com/ngrx/example-app
 *
 */
import { Component, OnDestroy, ViewEncapsulation } from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';

@Component({
  selector: 'app-tenantmanagement-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnDestroy {
  title = 'Tenant Management';

  constructor(private platformLocation: PlatformLocation) {

  }

  ngOnDestroy() {
    console.log('destroying AppComponent');
    (<BetterPlatformBrowserLocationService> this.platformLocation).onDestroy();
  }

}



