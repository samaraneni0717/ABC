import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


import { TenantDetailComponent } from './tenantdetail.component';
import { ModalAnchorComponent } from 'synerg-components';
import { AppModule } from '../app.module';
import { TenantDetailModule } from './tenantdetail.module';
import { TenantActions } from '../tenantlist/tenant.actions';
import { TenantDataService } from '../services/tenantdata.service';
import { TenantDetailMockService } from '../../app/services/tenantdata-mock.service';
import { Subject } from 'rxjs/Subject';
import { Params } from '@angular/router/src/shared';

import * as mockdata from '../services/tenantdata-mockdata';

class MockActivatedRoute {
  // here you can add your mock objects, like snapshot or parent or whatever
  // example:
  parent =
    {
      snapshot: { data: { existingTenantId: 'G347EYZNRMJEMT5E' } }
    };
}

describe('Tenant Detail Component', () => {

  let comp: TenantDetailComponent;
  let fixture: ComponentFixture<TenantDetailComponent>;
  let de: DebugElement;
  let el: HTMLElement;
  let params: Subject<Params>;

  beforeEach(() => {
    params = new Subject<Params>();
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        TenantDetailModule
      ],
      providers: [
        { provide: TenantDataService, useClass: TenantDetailMockService, useValue: {} },
        // {provide: ActivatedRoute, useClass: MockActivatedRoute},
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TenantDetailComponent);
    comp = fixture.debugElement.componentInstance;
    comp.existingTenantId = 'G347EYZNRMJEMT5E';
    fixture.detectChanges();
    console.log('Before Each run......');
  });


  it('should create the TenantDetail app', async(() => {
    fixture.whenStable().then(() => {
      comp.existingTenantId = 'G347EYZNRMJEMT5E';
      console.log('Detail Component Test 1......');
      expect((comp.existingTenantId)).toBe('G347EYZNRMJEMT5E');
    });
  }));


  it('should Call Status in Detail Component', async(() => {
    console.log('List Tenant Detail Component setStatus  Test 5......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];

      comp.setStatus('Active');
      fixture.detectChanges();
      expect(comp.tenantData.Active).toBe(true);
    });
  }));

  it('should Call Reveal Password in Detail Component', async(() => {
    console.log('List Detail Tenant Component revealPassword  Test 6......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];

      comp.revealPassword('text');
      fixture.detectChanges();
      comp.revealPassword('password');
      expect(comp.integrationPasswordDisplay).toBe('password');
    });
  }));

  it('should Call Reveal SecretKey in Detail Component', async(() => {
    console.log('List Detail Tenant Component revealSecretKey  Test 7......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.revealSecretKey('text');
      fixture.detectChanges();
      comp.revealSecretKey('password');
      expect(comp.tenantSecretKeyDisplay).toBe('password');
    });
  }));

  it('should Call SetIntegrationSelectionMode in Detail Component', async(() => {
    console.log('List Detail Tenant Component setDataIntegrationSelection  Test 8......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.setDataIntegrationSelection('Parallel');
      fixture.detectChanges();
      comp.setDataIntegrationSelection('ON');
      fixture.detectChanges();
      comp.setDataIntegrationSelection('OFF');
      fixture.detectChanges();
      expect(comp.integrationMode).toBe('OFF');
    });
  }));

  it('should Call setDataIntegration in Detail Component', async(() => {
    console.log('List Detail Tenant Component setDataIntegration  Test 9......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.dataIntegrationwithWFMValueChecked = true;
      comp.dataIntegrationwithVantageEtimeValueChecked = true;
      comp.setDataIntegration();
      fixture.detectChanges();

      comp.dataIntegrationwithWFMValueChecked = true;
      comp.dataIntegrationwithVantageEtimeValueChecked = false;
      comp.setDataIntegration();
      fixture.detectChanges();
      comp.dataIntegrationwithWFMValueChecked = false;
      comp.dataIntegrationwithVantageEtimeValueChecked = false;
      comp.setDataIntegration();
      fixture.detectChanges(); expect(comp.integrationMode).toBe('OFF');
    });
  }));

  it('should Call SetSSODisplay in Detail Component', async(() => {
    console.log('List Detail Tenant Component SetSSODisplay  Test 10......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.displaySignOn = false;
      const event = 'test';
      comp.setSSODisplay(event);
      fixture.detectChanges();
      expect(comp.displaySignOn).toBe(true);
    });
  }));


  it('should Call SaveTenantData SAVE in Detail Component', async(() => {
    console.log('List Detail Tenant Component SAVE saveTenantData  Test 12......');
    fixture.whenStable().then(() => {
      const tenantData = mockdata.multipleOrgoidsResponse[0];
      comp.tenantData = tenantData;
      const eventsent: Event = null;
      comp.saveTenantData(event);
      fixture.detectChanges();
      expect(comp.tenantData.OrgOID).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should load tenant data into Detail component with null properties', async(() => {
    console.log('List Detail Tenant Load Component Test 13......');
    fixture.whenStable().then(() => {
      comp.tenantData.OrgOID = 'G347EYZNRMJEMT5E';
      const tenant = null;
      comp.setTenantDetail(tenant);
      fixture.detectChanges();
      expect(true).toBe(true);
    });
  }));

  it('should return to Tenant List screen', async(() => {
    console.log('Return to Tenant List Component Test 14......');
    fixture.whenStable().then(() => {
      comp.returnToTenantList();
      fixture.detectChanges();
      expect(comp.displaySignOn).toBe(false);
    });
  }));

  it('should load tenant data into Detail component with Tenant data properties', async(() => {
    console.log('List Detail Tenant Load Component Test 15......');
    fixture.whenStable().then(() => {
      comp.tenantData.OrgOID = 'G347EYZNRMJEMT5E';
      const tenant = mockdata.multipleOrgoidsResponse[0];
      comp.setTenantDetail(tenant);
      fixture.detectChanges();
      expect(comp.tenantData.OrgOID).toBe('G347EYZNRMJEMT5E');
    });
  }));

  it('should create the TenantDetail app with 0 tenantid', async(() => {
    fixture.whenStable().then(() => {
      comp.existingTenantId = '0';
      console.log('Detail Component Test 16......');
      expect((comp.existingTenantId)).toBe('0');
    });
  }));

  it('should execute resetTenantSaved Add screen', async(() => {
    console.log('Return resetTenantSaved Test 17......');
    fixture.whenStable().then(() => {
      comp.onDetailSavedCloseAlert(true);
      fixture.detectChanges();
      expect(comp.displaySignOn).toBe(false);
    });
  }));

  it('should execute setRegion Add screen', async(() => {
    console.log('Return resetTenantSaved Test 19......');
    fixture.whenStable().then(() => {
      comp.setRegion();
      fixture.detectChanges();
      expect(comp.tenantData.Region).toBe('0000');
    });
  }));


  it('should execute setTenantDetail FindRegion Add screen', async(() => {
    console.log('FindRegion Test 20......');
    fixture.whenStable().then(() => {
      const tenant = mockdata.multipleOrgoidsResponse[0];
      tenant.Region = '0010';
      comp.setTenantDetail(tenant);
      fixture.detectChanges();
      expect(comp.tenantData.Region).toBe('0010');
    });
  }));


});
