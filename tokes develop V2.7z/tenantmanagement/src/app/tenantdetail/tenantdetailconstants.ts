export const listtenantstatus: string[] = ['Active', 'Inactive'];
export const listproducts: string[] = ['Vantage', 'WFN', 'EnterpriseHR', 'Standalone', 'Streamline', 'GlobablView'];
export const listtenanttype: string[] = ['PROD', 'UAT', 'UAT-NEXT', 'CFN', 'CFN-NEXT'];
export const listtenantradio: string[] = ['ON', 'OFF'];
export const listtenantregion = [
    {'value': '0010', 'name': '0010	New England'},
    {'value': '0020', 'name': '0020	NY Metro'},
    {'value': '0030', 'name': '0030	SEMA'},
    {'value': '0032', 'name': '0032	Carolinas'},
    {'value': '0034', 'name': '0034	Ohio Valley'},
    {'value': '0036', 'name': '0036	Miami'},
    {'value': '0040', 'name': '0040	Mid-Atlantic'},
    {'value': '0052', 'name': '0052	Chesapeake'},
    {'value': '0055', 'name': '0055	Penn Jersey'},
    {'value': '0056', 'name': '0056	Great Lakes'},
    {'value': '0060', 'name': '0060	Chicago'},
    {'value': '0062', 'name': '0062	South Central'},
    {'value': '0069', 'name': '0069	Central Plains'},
    {'value': '0070', 'name': '0070	So California'},
    {'value': '0073', 'name': '0073	Desert Mountain'},
    {'value': '0075', 'name': '0075	No California'},
    {'value': '0076', 'name': '0076	Pacific Northwest'},
    {'value': '0080', 'name': '0080	Canada (Legacy)'},
    {'value': '0086', 'name': '0086	Canada'},
    {'value': '0120', 'name': '0120	Clifton NA (NPC NE)'},
    {'value': '0130', 'name': '0130	Atlanta NA (NPC SE)'},
    {'value': '0131', 'name': '0131	COS/MPS'},
    {'value': '0136', 'name': '0136	NAS TLM'},
    {'value': '0137', 'name': '0137	ADP Ventures'},
    {'value': '0160', 'name': '0160	Chicago NA'},
    {'value': '0170', 'name': '0170	Cerritos NA (NPC West)'},
    {'value': '0741', 'name': '0741	SBS Region'},
    {'value': '0997', 'name': '0997	UK'},
    {'value': '0998', 'name': '0998	SBS/Waterview'},
    {'value': '0999', 'name': '0999	Corporate/Waterview'}];

export const listintegrationtype: string[] = ['ADP People Import', 'ADP Custom People Import', 'ADP Person API Direct'];
export const listpathtype: string[] = ['Infolink', 'Client Schema Name'];
export const listpathtypeenum: string[] = ['Infolink', 'SharedFolder'];
export const listsmssrchoptions: string[] = ['StartsWith', 'Contains', 'Equals', 'EndsWith'];

export function findRegion(regionCode: string) {
    return listtenantregion.find(regn => regn.value === regionCode);
}

export function formatLogonUser(firstname: string, lastname: string) {
    let resName = '';

    if ( firstname ) {
    resName = firstname + ' ';
    }

    if ( lastname ) {
        resName = firstname + lastname;
    }
    return resName;
}