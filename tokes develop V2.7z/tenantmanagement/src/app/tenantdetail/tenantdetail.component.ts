import { FormsModule, NgForm } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output, ElementRef, ViewEncapsulation, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { select, NgRedux } from 'ng2-redux';

import { ISms } from '../tenantlist/Models/ISms';
import { ITenant } from '../tenantlist/Models/ITenant';
import * as itentantConstants from '../tenantlist/Models/ITenant';
import * as iTenantSearch from '../tenantlist/Models/ITenantSearchFields';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';


import {
  DateFormatService, TextboxComponent, TextboxModule, FormGroupModule, CheckboxComponent,
  BusyIndicatorModule
} from 'synerg-components';
import { SecondaryNavComponent, FormGroupMessage, FormGroupConfig, IconComponent } from 'synerg-components';
import { ConfirmService, ConfirmConfig } from 'synerg-components';
import { ModalService, ModalAnchorComponent, ModalComponent, ModalModel } from 'synerg-components';

import * as detailconstants from './tenantdetailconstants';
import { TenantDataValidator } from '../tenantlist/Models/TenantDataValidate';

import { AppState } from '../store/';
import * as store from '../store';
import { TenantActions } from '../tenantlist/tenant.actions';

import { Pipe, PipeTransform } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { forEach } from '@angular/router/src/utils/collection';
import { UrlTree } from '@angular/router/src/url_tree';
import { initialSearchFields } from '../tenantlist/Models/ISMSSearchFields';



@Component({
  selector: 'app-tenantdetail',
  templateUrl: './tenantdetail.component.html',
  styleUrls: ['../tenantlist/tenantlist.component.scss'],
  providers: [ModalService, ConfirmService, ConfirmConfig],
  encapsulation: ViewEncapsulation.None
})
export class TenantDetailComponent implements OnInit {
  @select(store.getDisplayTenants) tenantdetails$: Observable<ITenant[]>;
  @select(store.isTenantSaving) isSaveLaunched$: Observable<boolean>;
  @select(store.didTenantSave) didTenantSave$: Observable<boolean>;
  @select(store.didTenantSaveError) didTenantSaveError$: Observable<boolean>;
  @select(store.errorMessages) errorMessages$: Observable<any>;
  @select(store.getLoggedOnUser) loggedOnUser$: Observable<any>;

  @ViewChild('detailTenantForm') detailForm: NgForm;

  dataValidator: TenantDataValidator;

  listconstants = detailconstants;
  // Initialize TenantDetail data
  tenantData = itentantConstants.initialTenant;

  existingOrgoid = '0';
  existingTenantId = '0';

  // Calculate integration mode
  integrationMode: string;

  currentUser: string;

  // default settings
  dataIntegrationwithWFMValueChecked = false;
  dataIntegrationwithVantageEtimeValueChecked = false;
  activeValue = 'Active';
  displaySignOn = false;

  tenantSecretKeyDisplay = 'password';
  integrationPasswordDisplay = 'password';

  searchParameters: ITenantSearchFields = iTenantSearch.initialSearchFields;

  netSecureResults: ISms[];
  netSecureIdsList: ISms[] = [];

  querySMSNetsecureid = '';

  displaySMSList = false;

  regionValueAttribute: any = { 'value': '0000', 'name': '0000 none' };

  regionList = detailconstants.listtenantregion;

  TenantSaveDescription = '';

  errorFound$ = '';
  primaryTenant = false;
  otherPrimaryExists = false;
  currentPrimaryTenant: ITenant;

  constructor(private tenantActions: TenantActions, private confirmService: ConfirmService,
    private router: Router, private route: ActivatedRoute) {



  }
  ngOnInit() {
    // Defaults to 0 if no orgoid param provided.
    this.existingTenantId = this.route.snapshot.queryParams['existingTenantId'] || '0';
    this.existingOrgoid = this.route.snapshot.queryParams['existingOrgoId'] || '0';

    this.getExistingTenantData();

    this.dataValidator = new TenantDataValidator();

    this.getLoggedOnInfo();

    window.scrollTo(0, 0);

  } // end oninit

  getExistingTenantData() {
    if (!(this.existingTenantId === '0')) {
      this.tenantdetails$.subscribe(data => {
        const tenantSelected = data.find(i => i.TenantId === this.existingTenantId && i.OrgOID === this.existingOrgoid);
        this.setTenantDetail(tenantSelected);
        this.getExistingPrimaryTenantList();
      }
      );
    };
  }

  getLoggedOnInfo()
  {
    this.loggedOnUser$.subscribe(info => {
      if ( info ) {
        this.currentUser = detailconstants.formatLogonUser(info.FirstName, info.LastName);
      }
    });
  }

  getExistingPrimaryTenantList() {
    const srchFlds = iTenantSearch.initialSearchFields;
    srchFlds.coid = this.tenantData.OrgOID;
    // Tenant list contains other tenant not == to existing and is set as primary
    this.tenantActions.getTenantByOrgoid(srchFlds).subscribe( foundtenant => { if (foundtenant) {
        this.currentPrimaryTenant = foundtenant;
        }
      });
  }

  setStatus(selection: any) {
    const isActive = selection === 'Active' ? true : false;
    this.tenantData.Active = isActive;
  }

  setTenantDetail(tenant: any) {
    const copyTenantData = this.deepCopyObj(tenant);
    const tenantdata: ITenant = copyTenantData;
    if (tenantdata != null && (tenantdata.Properties == null || tenantdata.Properties[0] == null)) {
      tenantdata.Properties = [
        {
          'PropertyType': '',
          'PropertyKey': '',
          'PropertyValue': ''
        }
      ];
    }

    if (tenantdata != null) {
      this.tenantData = tenantdata;
      this.activeValue = this.tenantData.Active ? 'Active' : 'Inactive';
      if (!this.isNullorEmpty(this.tenantData.Region)) {
        this.regionValueAttribute = detailconstants.findRegion(this.tenantData.Region);
      }
      this.setDataIntegrationSelection(this.tenantData.IntegrationMode);

    }

  }

  deepCopyObj(obj: any) {
    return JSON.parse(JSON.stringify(obj));
  }

  revealPassword(event: any) {
    if (this.integrationPasswordDisplay === 'text') {
      this.integrationPasswordDisplay = 'password';
    } else {
      this.integrationPasswordDisplay = 'text';
    }

  }

  revealSecretKey(event: any) {
    if (this.tenantSecretKeyDisplay === 'text') {
      this.tenantSecretKeyDisplay = 'password';
    } else {
      this.tenantSecretKeyDisplay = 'text';
    }
  }


  infoLinkDisable(): boolean {
    let resp = false;
    if (this.tenantData.RouteName === 'Infolink') {
      resp = true;
    }

    return resp;
  }

  setDataIntegrationSelection(mode: string) {
    if (mode === 'Parallel') {
      this.dataIntegrationwithWFMValueChecked = true;
      this.dataIntegrationwithVantageEtimeValueChecked = true;
      this.integrationMode = 'Parallel';
      return;
    }

    if (mode === 'ON') {
      this.dataIntegrationwithWFMValueChecked = true;
      this.dataIntegrationwithVantageEtimeValueChecked = false;
      this.integrationMode = 'ON';
      return;
    }

    if (mode === 'OFF') {
      this.dataIntegrationwithWFMValueChecked = false;
      this.dataIntegrationwithVantageEtimeValueChecked = false;
      this.integrationMode = 'OFF';
      return;
    }

  }

  setDataIntegration() {
    if (this.dataIntegrationwithWFMValueChecked && this.dataIntegrationwithVantageEtimeValueChecked) {
      this.integrationMode = 'Parallel';
    }

    if (this.dataIntegrationwithWFMValueChecked && !this.dataIntegrationwithVantageEtimeValueChecked) {
      this.integrationMode = 'ON';
    }

    if (!this.dataIntegrationwithWFMValueChecked) {
      this.integrationMode = 'OFF';
    }
  }

  setSSODisplay(event: any) {
    this.displaySignOn = !this.displaySignOn;
  }

  setRegion() {
    const code = this.regionValueAttribute['value'];
    this.tenantData.Region = code;
  }

  saveTenantData(data: Event) {
    let title = 'Save Tenant Data';
    let contents = `Do you wish to continue Saving Tenant Data?`;
    const confirmLabel= 'Continue';
    const dismissLabel = 'Cancel';

    try {

      if (!(this.tenantData == null)) {

        this.tenantData.IntegrationMode = this.integrationMode;

        if (this.dataValidator.ValidateTenantData(this.tenantData)) {
          return true;
        }

        this.tenantData.Modifiedby = this.currentUser;

        const saveTenantData = JSON.parse(JSON.stringify(this.tenantData));

        if (this.tenantData.isPrimary) {
        this.findExistingPrimaries(); //Check in case Tenantid has been modified

        if (this.otherPrimaryExists && (this.tenantData.TenantId !== this.currentPrimaryTenant.TenantId) ) {
          title = 'Warning: Existing Primary Tenant Assignment';
          contents = `We have identified that the client already has a Primary Tenant assigned. 
          Do you want to make this tenant the new Primary tenant?`;
          }
        }

          this.confirmService.open({
            'title': title,
            'contents': contents,
            'confirmLabel': confirmLabel,
            'dismissLabel': dismissLabel
        })
          .then(() => {this.saveData(saveTenantData)} )
          .catch((rejection: any) => {
            return true;
          });
      }
    } catch (e) { console.log('Error During Tenant Save'); }    
  }

  primarySearch(event: any) {
    // Search Tenant space for orgoid and existing primaries
    if (this.tenantData.isPrimary) {
      this.findExistingPrimaries();
    }
  }

  saveData(saveTenantData: any) {
    this.tenantActions.saveTenant(saveTenantData);

    this.tenantData.Modifieddate = new Date().toLocaleString();

    this.errorMessages$.subscribe(dataerr =>  { this.errorFound$ = dataerr; } );

    this.detailForm.form.markAsPristine();
  }

  findExistingPrimaries() {
      // Tenant list contains other tenant not == to existing tenantid and is set as primary
      if (this.currentPrimaryTenant) {
        if(this.currentPrimaryTenant.isPrimary) {
            this.otherPrimaryExists =  true;
        }
    }

  }

  returnToTenantList() {
    this.tenantActions.resetTenantSaved();
    this.router.navigate(['/tenantlist']);
  }

  isNullorEmpty(value: string) {
    return (value == null || value.length === 0);
  }

  onDetailSavedCloseAlert(returnToPrevious: boolean) {
    this.tenantActions.resetTenantSaved();
    if (returnToPrevious) {
      this.returnToTenantList();
    }
  }

  getOrgoId(): string {
    return this.tenantData.OrgOID;
  }

  getTenantId(): string {
    return this.tenantData.TenantId;
  }

  openLicenseDetail() {
    this.router.navigate(['tenantentitlement'], { queryParams: { existingTenantId: this.tenantData.TenantId ,  existingOrgoId: this.tenantData.OrgOID }});
  };

  tabLicenseClick() {
    this.openLicenseDetail();
  }

  ngOnDestroy() {
    this.tenantActions.resetTenantSaved();
  }

}
