import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { CommonModule } from '@angular/common';
import { TenantListRoutingModule } from '../tenantlist/tenantlistrouting.module';
import { TenantEntitlementComponent } from './tenantentitlement.component';
import {
    ButtonModule, BusyIndicatorModule, MastheadModule, SecondaryNavModule, TableModule, LeftNavModule,
    PopoverModule, TextboxModule, DatePickerModule, FormGroupModule, FormGroupConfig, DateFormatService,
    DropdownListModule, SlideinModule, ModalModule, DualSelectModule, RadioModule,
    DropdownListComponent, ToggleSwitchModule, IconComponent, IconModule, CheckboxModule, ConfirmModule, AlertModule
} from 'synerg-components';
import { TenantDataService } from '../services/tenantdata.service';

@NgModule({
  imports: [
    CommonModule,
    TenantListRoutingModule,
    FormGroupModule,
    ButtonModule,
    FormsModule,
    BrowserModule,
    DatePickerModule,
    DropdownListModule,
    InfiniteScrollModule,
    SecondaryNavModule,
    TextboxModule,
    ToggleSwitchModule,
    RadioModule,
    IconModule,
    CheckboxModule,
    ModalModule,
    ConfirmModule,
    BusyIndicatorModule,
    AlertModule
  ],
  declarations: [TenantEntitlementComponent],
  exports: [TenantEntitlementComponent]
})
export class TenantEntitlementModule { }
