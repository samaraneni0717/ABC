import { FormsModule, NgForm } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output, ElementRef, ViewEncapsulation, ViewChild, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { select, NgRedux } from 'ng2-redux';

import { ISms } from '../tenantlist/Models/ISms';
import { ITenant } from '../tenantlist/Models/ITenant';
import * as itentantConstants from '../tenantlist/Models/ITenant';
import * as iTenantSearch from '../tenantlist/Models/ITenantSearchFields';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';


import {
  DateFormatService, TextboxComponent, TextboxModule, FormGroupModule, CheckboxComponent,
  BusyIndicatorModule
} from 'synerg-components';
import { SecondaryNavComponent, FormGroupMessage, FormGroupConfig, IconComponent } from 'synerg-components';
import { ConfirmService, ConfirmConfig } from 'synerg-components';
import { ModalService, ModalAnchorComponent, ModalComponent, ModalModel } from 'synerg-components';

import * as detailconstants from '../tenantdetail/tenantdetailconstants';
import { TenantDataValidator } from '../tenantlist/Models/TenantDataValidate';

import { AppState } from '../store/';
import * as store from '../store';
import { TenantActions } from '../tenantlist/tenant.actions';

import { Pipe, PipeTransform } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { forEach } from '@angular/router/src/utils/collection';
import { UrlTree } from '@angular/router/src/url_tree';
import { initialSearchFields } from '../tenantlist/Models/ISMSSearchFields';
import { initialEntitlementSummary, IEntitlementSummaryList, IEntitlementSummary } from '../tenantlist/Models/IEntitlementSummary';



@Component({
  selector: 'app-tenantentitlement',
  templateUrl: './tenantentitlement.component.html',
  styleUrls: ['./tenantentitlement.component.scss'],
  providers: [ModalService, ConfirmService, ConfirmConfig],
  encapsulation: ViewEncapsulation.None
})
export class TenantEntitlementComponent implements OnInit {
    @Input() existOrgoid: string;
    @Input() existTenantid: string;

    @select(store.getEntitlements) tenantentitlements$: Observable<IEntitlementSummary[]>;
    @select(store.getDisplayTenants) tenantdetails$: Observable<ITenant[]>;

    listconstants = detailconstants;

    tenantData = itentantConstants.initialTenant;

    existingOrgoId = '';
    existingTenantId = '0';
    activeValue = 'Inactive';
    moddate = '****';

    hrly = {seats: '', assignedSeats: '', remSeats: ''};
    salry = {seats: '', assignedSeats: '', remSeats: ''};
    accrl = {seats: '', assignedSeats: '', remSeats: ''};
    accrllv = {seats: '', assignedSeats: '', remSeats: ''};
    wkforce = {seats: '', assignedSeats: '', remSeats: ''};
    coreschd = {seats: '', assignedSeats: '', remSeats: ''};
    advancedschd = {seats: '', assignedSeats: '', remSeats: ''};
    absence = {seats: '', assignedSeats: '', remSeats: ''};
    analytics = {seats: '', assignedSeats: '', remSeats: ''};

  constructor(private tenantActions: TenantActions, private confirmService: ConfirmService,
    private router: Router, private route: ActivatedRoute) {

      this.tenantentitlements$.subscribe( licdata => {
        if (licdata) {
            const info = licdata;
            this.setLicenseInfo(licdata);
        }
    });

  }
  ngOnInit() {
    // Defaults to 0 if no orgoid param provided.
    this.existingTenantId = this.route.snapshot.queryParams['existingTenantId'] || '0';
    this.existingOrgoId = this.route.snapshot.queryParams['existingOrgoId'] || '0';

    this.existingOrgoId = this.existOrgoid;
    this.existingTenantId = this.existTenantid;

    this.tenantActions.getEntitlmentSummaryInfo(this.existingOrgoId, 'true');
    this.getExistingTenantData();

  } // end oninit

  setTenantInfo(orgid:string, tenantid: string) {
    this.existingOrgoId = orgid;
    this.existingTenantId = tenantid;
    this.tenantActions.getEntitlmentSummaryInfo(this.existingOrgoId, 'true');
    this.getExistingTenantData();
  }

  setLicenseInfo(licdata: IEntitlementSummary[]) {
    this.clearLicenseInfo();

    licdata.forEach(function(val) { if(val.name === 'Hourly Timekeeping') {
        this.hrly.seats = val.seats;
        this.hrly.assignedSeats = val.assignedSeats;
        this.hrly.remSeats = val.remSeats; 
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Salaried Timekeeping') {
        this.salry.seats = val.seats;
        this.salry.assignedSeats = val.assignedSeats;
        this.salry.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Accruals') {
        this.accrl.seats = val.seats;
        this.accrl.assignedSeats = val.assignedSeats;
        this.accrl.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Accruals & Leave') {
        this.accrllv.seats = val.seats;
        this.accrllv.assignedSeats = val.assignedSeats;
        this.accrllv.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Workforce Scheduler') {
        this.wkforce.seats = val.seats;
        this.wkforce.assignedSeats = val.assignedSeats;
        this.wkforce.remSeats = val.remSeats; 
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Scheduling') {
        this.coreschd.seats = val.seats;
        this.coreschd.assignedSeats = val.assignedSeats;
        this.coreschd.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
       }
      if(val.name === 'Advanced Scheduling') {
        this.advancedschd.seats = val.seats;
        this.advancedschd.assignedSeats = val.assignedSeats;
        this.advancedschd.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Absence') {
        this.absence.seats = val.seats;
        this.absence.assignedSeats = val.assignedSeats;
        this.absence.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
      if(val.name === 'Analytics') {
        this.analytics.seats = val.seats;
        this.analytics.assignedSeats = val.assignedSeats;
        this.analytics.remSeats = val.remSeats;
        if(val.currentDate) {
          this.moddate = this.dtformat(val.currentDate); }
      }
    }, this);
  }


  clearLicenseInfo() {
    this.moddate = '';
    this.hrly = {seats: '', assignedSeats: '', remSeats: ''};
    this.salry = {seats: '', assignedSeats: '', remSeats: ''};
    this.accrl = {seats: '', assignedSeats: '', remSeats: ''};
    this.accrllv = {seats: '', assignedSeats: '', remSeats: ''};
    this.wkforce = {seats: '', assignedSeats: '', remSeats: ''};
    this.coreschd = {seats: '', assignedSeats: '', remSeats: ''};
    this.advancedschd = {seats: '', assignedSeats: '', remSeats: ''};
    this.absence = {seats: '', assignedSeats: '', remSeats: ''};
    this.analytics = {seats: '', assignedSeats: '', remSeats: ''};
  }

  dtformat(datestr: string ): string {
    const dt = new Date(datestr);
    return dt.toLocaleString();
  }


  getExistingTenantData() {
    if (!(this.existingTenantId === '0')) {
      this.tenantdetails$.subscribe(data => {
        const tenantSelected = data.find(i => i.TenantId === this.existingTenantId && i.OrgOID === this.existingOrgoId);
        this.setTenantDetail(tenantSelected);
      }
      );
    };
}

    setTenantDetail(tenant: any) {
        const tenantdata: ITenant = tenant;

        if(tenantdata != null) {
            this.tenantData = tenantdata;
            this.activeValue = this.tenantData.Active ? 'Active' : 'Inactive';
        }
    }

    getLicenses() {
        this.tenantActions.getEntitlmentSummaryInfo(this.existingOrgoId, 'true');
    }

}
