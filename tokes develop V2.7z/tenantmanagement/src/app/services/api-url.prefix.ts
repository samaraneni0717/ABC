
import { InjectionToken } from '@angular/core';

export const API_PREFIX: InjectionToken<string> = new InjectionToken<string>('API URL Prefix');

export const API_URL_PREFIX_VALUE:  string  =  '/taascommon/TaaS.Tenant.Api/v1/Tenant/';