import   {  Injectable } from  '@angular/core' 
import  { UIActions, HTTP_ERROR, HTTP_SUCCESS } from '../store/ui-actions'
import  { HttpErrorResponse } from  '@angular/common/http'
import  { IUIAlert } from  '../store/IUIAlert'

@Injectable()
export class HttpErrorHandlerService{
    
    constructor(private uiActions: UIActions) { 

    }

    alert(error: HttpErrorResponse) { 
        console.log("HttpErrorResponse service was called....");
        this.uiActions.alert( {  
            code   : error.status,  
            message :  error.statusText,  
            type: HTTP_ERROR
        });
    }
}

