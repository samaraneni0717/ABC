/**
 * Created by amarenes on 10/23/2017.
 */
import { Injectable } from '@angular/core';
import { ITenant } from '../tenantlist/Models/ITenant';
import { ITenantList } from '../tenantlist/Models/ITenantList';
import { ISms, ISmsData } from '../tenantlist/Models/ISms';
import { ISMSSearchFields } from '../tenantlist/Models/ISMSSearchFields';

import { Http, Response } from '@angular/http';
import { ITenantsListHttpResponse, ITenantHttpResponse } from '../tenantlist/Models/ITenantsListHttpResponse';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { ApiUrlService } from './api-url.service';
import { HttpParams, HttpClient } from '@angular/common/http';
import { HttpErrorHandlerService } from './http-error-handler.service';
import 'rxjs/add/operator/catch';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import * as mockdata from './tenantdata-mockdata';
import { IAdpUserInfo } from '../tenantlist/Models/IAdpUserInfo';


@Injectable()
export class TenantDetailMockService {

    constructor(private httpClient: HttpClient, private apiUrlService: ApiUrlService,
        private httpErrorHandlerService: HttpErrorHandlerService) { }



    getTenants(): Observable<ITenantsListHttpResponse> {

        const response: any = mockdata.multipleOrgoidsResponse;
        return Observable.of(response);
    };


    getTenantByOrgoid(): Observable<ITenant> {
        const tenantOrgoid = mockdata.multipleOrgoidsResponse[0];
        return Observable.of(tenantOrgoid);
    }

    getTenantDetail(): Observable<ITenantsListHttpResponse> {

        const tenantDetailResponse = mockdata.multipleOrgoidsResponse[0];
        return Observable.of(tenantDetailResponse);
    };

    getSMSInfo(netSecureInfo: string): Observable<ITenant[]> {
        const responseSms: any = mockdata.multipleOrgoidsResponse;

        return Observable.of(responseSms);
    }

    saveTenantDetails(tenantdata: ITenant): Observable<ITenant> {
        const responseSave = mockdata.multipleOrgoidsResponse[0];
        return Observable.of(responseSave);

    }

    addTenantDetails(tenantdata: ITenant): Observable<ITenant> {
        const responseadd = mockdata.multipleOrgoidsResponse[0];

        return Observable.of(responseadd);
    }

    getSMSData(smsSrch: ISMSSearchFields): Observable<ISmsData> {

        const response: any = {
                'totalResults': 3,
                'itemsPerPage': 3,
                'startIndex': 0,
                'Resources': {
                    'Resource': [
                        {
                            'orgId': 'G3THD9E2RPGMQQVM',
                            'isiOrgCd': 'Linga',
                            'name': 'Linga'
                        },
                        {
                            'orgId': 'G3THD9E2RPGM2H0M',
                            'isiOrgCd': 'wfnwfn12',
                            'name': 'wfnwfn12'
                        },
                        {
                            'orgId': 'G3THD9E2RPGM8F3Y',
                            'isiOrgCd': 'SMS201',
                            'name': 'SMS201'
                        }
                    ]
                }
            };
        return Observable.of(response);
    }

    getUserInfo(): Observable<IAdpUserInfo>
    {
        const response: any = {
            'UserId': 'TESTUSER',
            'LastName': 'TESTLASTNAME',
            'FirstName': 'TESTFIRSTNAME',
            'Email': 'TESTEMAIL',
            'AoId': 'TESTAOID'
        }

        return Observable.of(response);
    }
}


