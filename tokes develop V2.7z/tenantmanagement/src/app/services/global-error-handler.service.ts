import   { ErrorHandler, Injectable, Injector } from  '@angular/core' 
import   { HttpErrorResponse } from  '@angular/common/http' 
import  { HttpErrorHandlerService } from  './http-error-handler.service'
@Injectable()
export class GlobalErrorHandler implements ErrorHandler{
    constructor(private injector: Injector) { 

    }

    handleError(error: any) { 
        
        if ( error instanceof HttpErrorResponse){
            const httpErrorHandlerService: HttpErrorHandlerService = this.injector.get(HttpErrorHandlerService);
            httpErrorHandlerService.alert(error);
        }
        //throw error;
    }
}