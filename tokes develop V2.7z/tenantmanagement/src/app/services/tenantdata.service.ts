import { AppState } from '../store';
import { Injectable, Inject } from '@angular/core';
import { ITenant } from '../tenantlist/Models/ITenant';
import { IAdpUserInfo } from '../tenantlist/Models/IAdpUserInfo';
import { ISms, ISmsData } from '../tenantlist/Models/ISms';
import { ISMSList } from '../tenantlist/Models/ISMSList';
import { ITenantsListHttpResponse, ITenantHttpResponse } from '../tenantlist/Models/ITenantsListHttpResponse';

import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { ApiUrlService } from '../services/api-url.service';
import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';
import { ISMSSearchFields } from '../tenantlist/Models/ISMSSearchFields';
import { IEntitlementSummary } from '../tenantlist/Models/IEntitlementSummary';

import * as detailconstants from '../tenantdetail/tenantdetailconstants';


@Injectable()
export class TenantDataService {
  constructor(private httpClient: HttpClient) { }

  public getTenants(searchData: ITenantSearchFields): Observable<ITenant[]> {
    let predicate = '';

    let url = '/taascommon/Taas.Tenant.Api/v1/Tenant/Query';  // returns all by default

    predicate = this.buildPredicate(searchData);

    if (!this.isNullorEmpty(predicate)) {
      url = '/taascommon/Taas.Tenant.Api/v1/Tenant/Query?$filter=' + predicate;
    }
    const resp = this.httpClient.get<ITenant[]>(url, {
      headers:
        new HttpHeaders().set('Content-Type', 'application/json')
    });

    return resp;

  }

  public getTenantByOrgoid(searchData: ITenantSearchFields) {

    const url = '/taascommon/Taas.Tenant.Api/v1/Tenant' + '/' + searchData.coid;

    const resp = this.httpClient.get<ITenant>(url, {
      headers:
        new HttpHeaders().set('Content-Type', 'application/json')
    });

    return resp;

  }

  public getTenantByTenantId(searchData: ITenantSearchFields) {

    const url = '/taascommon/Taas.Tenant.Api/v1/Tenant/Tenant' + '/' + searchData.tenantid;

    const resp = this.httpClient.get<ITenant>(url, {
      headers:
        new HttpHeaders().set('Content-Type', 'application/json')
    });

    return resp;

  }



  saveTenantDetails(tenantdata: ITenant): Observable<ITenant> {
    if (!(tenantdata == null)) {
      this.validateDataToSave(tenantdata);
      const jsonData = JSON.stringify(tenantdata);
      const url = '/taascommon/Taas.Tenant.Api/v1/Tenant';
      const resp = this.httpClient.put<ITenant>(url, jsonData, { headers: new HttpHeaders().set('Content-Type', 'application/json') });
      return resp;
    };
  }

  addTenantDetails(tenantdata: ITenant): Observable<ITenant> {
    if (!(tenantdata == null)) {
      this.validateDataToSave(tenantdata);
      const jsonData = JSON.stringify(tenantdata);
      const url = '/taascommon/Taas.Tenant.Api/v1/Tenant';
      const resp = this.httpClient.post<ITenant>(url, jsonData, { headers: new HttpHeaders().set('Content-Type', 'application/json') });
      return resp;
    };
  }

  validateDataToSave(tenantData: ITenant) {
    if (this.isNullorEmpty(tenantData.Region)) {
       tenantData.Region = null;
    }

    // Set enum for Client Schema
    if(tenantData.RouteName) {
        if(tenantData.RouteName === detailconstants.listpathtype[1]) {
          tenantData.RouteName = detailconstants.listpathtypeenum[1];
        }
      }
    if (tenantData.Properties != null) {
      const props = tenantData.Properties[0];
      if (this.isNullorEmpty(props.PropertyKey) && this.isNullorEmpty(props.PropertyType) && this.isNullorEmpty(props.PropertyValue)) {
        tenantData.Properties = [];
      } else if (!this.isNullorEmpty(props.PropertyKey) && this.isNullorEmpty(props.PropertyType)) {
        tenantData.Properties[0].PropertyType = 'INTEGRATION';
      }

    } tenantData.Modifieddate = new Date().toLocaleString();

  }

   getSMSData(smsSrch: ISMSSearchFields): Observable<ISmsData> {
    const url = '/taascommon/Taas.Tenant.Api/v1/Tenant/GetSmSClients?';
    const params = this.buildSmsQueryParms(smsSrch);
    const resp = this.httpClient.get<ISmsData>(url, { headers: new HttpHeaders().set('Content-Type', 'application/json'), params: params});
    return resp;
  };


  buildPredicate(searchData: ITenantSearchFields): string {
    let predicate = '';
    let predicatecoid = '';
    let predicatevanityurl = '';
    let predicateclientname = '';
    let predicatenetsecureid = '';

    if (!this.isNullorEmpty(searchData.coid)) {
      predicatecoid = 'startswith(OrgOID, ' + '\'' + searchData.coid + '\'' + ')';
    }
    if (!this.isNullorEmpty(searchData.vanityURL)) {
      predicatevanityurl = 'startswith(TenantRoot, ' + '\'' + searchData.vanityURL + '\'' + ')';
    }

    if (!this.isNullorEmpty(searchData.clientName)) {
      predicateclientname = 'startswith(SMSName, ' + '\'' + searchData.clientName + '\'' + ')';
    }

    if (!this.isNullorEmpty(searchData.netSecureID)) {
      predicatenetsecureid = 'startswith(ISIOrgCd, ' + '\'' + searchData.netSecureID + '\'' + ')';
    }
    if (!this.isNullorEmpty(predicatecoid)) {
      predicate = predicatecoid;
    }

    if (!this.isNullorEmpty(predicatevanityurl)) {
      if (!this.isNullorEmpty(predicate)) {
        predicate = predicate + ' and ';
      }
      predicate = predicate + predicatevanityurl;
    }
    if (!this.isNullorEmpty(predicateclientname)) {
      if (!this.isNullorEmpty(predicate)) {
        predicate = predicate + ' and ';
      }

      predicate = predicate + predicateclientname;
    }

    if (!this.isNullorEmpty(predicatenetsecureid)) {
      if (!this.isNullorEmpty(predicate)) {
        predicate = predicate + ' and ';
      }
      predicate = predicate + predicatenetsecureid;
    }
    return predicate;
  }

  isNullorEmpty(value: string) {
    return (value == null || value.length === 0);
  }

  buildSmsQueryParms(searchData: ISMSSearchFields): HttpParams {

    let queryParms = new HttpParams();
    let searchType = 'SW';

    if (!this.isNullorEmpty(searchData.searchType)) {
      searchType = searchData.searchType;
    }

    queryParms = queryParms.set('smsQueryFilter.searchType', searchType);

    if (!this.isNullorEmpty(searchData.SMSName)) {
      queryParms = queryParms.set('smsQueryFilter.propertyName', 'name');
      queryParms = queryParms.set('smsQueryFilter.propertyValue', searchData.SMSName);
      return queryParms;
    }

    if (!this.isNullorEmpty(searchData.ISIOrgCd)) {
      queryParms = queryParms.set('smsQueryFilter.propertyName', 'isiOrgCd');
      queryParms = queryParms.set('smsQueryFilter.propertyValue', searchData.ISIOrgCd);
      return queryParms;
    }

    if (!this.isNullorEmpty(searchData.OrgOID)) {
      queryParms = queryParms.set('smsQueryFilter.propertyName', 'orgId');
      queryParms = queryParms.set('smsQueryFilter.propertyValue', searchData.OrgOID);
      return queryParms;
    }


    return queryParms;
  }

  public getUserInfo(): Observable<IAdpUserInfo> {

    const url = '/taascommon/Taas.Tenant.Api/v1/Tenant/UserInfo';
    let headrs = new HttpHeaders();
    headrs = headrs.append('Content-Type', 'application/json');
    const resp = this.httpClient.get<IAdpUserInfo>(url, {
      headers: headrs
    });

    return resp;

  }

  public getEntitlmentSummaryInfo(orgoid: string, ifnonematch: string): Observable<IEntitlementSummary[]> {

    const url = '/taascommon/ADP.TaaS.Common.Codelist/taas/v1/licensing/entitlementsummary';
    let headrs = new HttpHeaders();
    headrs = headrs.append('Content-Type', 'application/json');
    headrs = headrs.append('ORGOID', orgoid);
    headrs = headrs.append('IfNoneMatch', ifnonematch);

    const resp = this.httpClient.get<IEntitlementSummary[]>(url, {
      headers: headrs
    });

    return resp;
  }

}
