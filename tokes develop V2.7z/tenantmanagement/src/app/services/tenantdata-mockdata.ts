
import { ISms } from '../tenantlist/Models/ISms';

export const smsAddData: ISms = {
    'name': 'CANDITNB',
    'orgId': 'G347EYZNRMJEMT5E',
    'isiOrgCd': 'CANDITNB'
};

export const multipleOrgoidsResponse: any =
    [
        {
            'OrgOID': 'G347EYZNRMJEMT5E',
            'TenantId': 'c74_nonprd_04_kcfn01',
            'OAuthEndPoint': 'https://sso-oam02.cfn.mykronos.com/authn/oauth2',
            'TenantRoot': 'https://c74-adp05.cfn.mykronos.com',
            'TenantUserName': 'SeanIvan',
            'TenantPassWord': 'Kr0n0s@Cloud',
            'TenantSecretKey': 'Ydgjt3MClX6BinmW',
            'ProductName': 'Vantage',
            'IntegrationMode': 'ON',
            'RouteName': 'Infolink',
            'RoutePath': '\\FalconTests//EPIPFileFromServer',
            'TenantSsoUrl': 'https://c23-adp023-idptest.cfn.mykronos.com/',
            'SamlAssertionUrl': null,
            'SamlAcsUrl': null,
            'MetadataUrl': null,
            'TenantShortName': 'c74_nonprd_04',
            'Active': true,
            'AppKey': 'XlwkP5owwWeSfmap1yGOku6jgvAgukAx',
            'Properties': [
                {
                    'PropertyType': 'INTEGRATION',
                    'PropertyKey': 'ADP People Import',
                    'PropertyValue': 'r-e783003b-8819-41b7-a441-a6883d7ba724-2'
                }
            ],
            'Modifiedby': 'cgoppa',
            'Modifieddate': '11/21/2017 8:42:27 AM',
            'Region': null,
            'Companycode': null,
            'SMSName': 'CANDITNB',
            'ISIOrgCd': 'CANDITNB'
        },
        {
            'OrgOID': 'G30X0PJHN30D8T2F',
            'TenantId': 'c74_nonprd_45_kcfn01',
            'OAuthEndPoint': 'https://sso-oam02.cfn.mykronos.com/authn/oauth2',
            'TenantRoot': 'https://c74-adp09-CLN1.cfn.mykronos.com',
            'TenantUserName': 'AnnaClark',
            'TenantPassWord': 'Kr0n0s@Cloud',
            'TenantSecretKey': 'iCwOL9ifFCj59Tht',
            'ProductName': 'Vantage',
            'IntegrationMode': 'ON',
            'RouteName': 'Infolink',
            'RoutePath': '\\cdlisilon01-fs1.es.oneadp.com\\fit_hrcore_ehrms\\clientdata\\nem2hp\\batch\\temp\\21d',
            'TenantSsoUrl': 'https://c74-adp09-CLN1-sso.cfn.mykronos.com',
            'SamlAssertionUrl': 'https://sso-oam02.cfn.mykronos.com/authn/c74_nonprd_45/hsp/887',
            'SamlAcsUrl': 'https://sso-oam02.cfn.mykronos.com/authn/AuthConsumer/metaAlias/c74_nonprd_45/887',
            'MetadataUrl': 'https://sso-oam02.cfn.mykronos.com/authn/saml2/jsp/exportmetadata.jsp?entityid=https://sso-oam02.cfn.mykronos.com/authn/c74_nonprd_45/hsp/887&realm=c74_nonprd_45',
            'TenantShortName': 'c74_nonprd_45',
            'Active': true,
            'AppKey': 'glJQHPCzQMGdj0obZ0MWYLM9oQy0srQg',
            'Properties': null,
            'Modifiedby': 'irisjuka',
            'Modifieddate': '11/29/2017 6:51:22 AM',
            'Region': null,
            'Companycode': null,
            'SMSName': 'Vance, Sitfor & Ditman, LLC',
            'ISIOrgCd': 'VANSIT4DIT'
        },
        {
            'OrgOID': 'G2DRXY5BBEVM65WF',
            'TenantId': 'c74_nonprd_45_kcfn01',
            'OAuthEndPoint': 'https://sso-oam02.cfn.mykronos.com/authn/oauth2',
            'TenantRoot': 'https://c74-adp09-CLN1.cfn.mykronos.com',
            'TenantUserName': 'AnnaClark',
            'TenantPassWord': 'Kr0n0s@Cloud',
            'TenantSecretKey': 'iCwOL9ifFCj59Tht',
            'ProductName': 'Vantage',
            'IntegrationMode': 'ON',
            'RouteName': 'Infolink',
            'RoutePath': '\\cdlisilon01-fs1.es.oneadp.com\\fit_hrcore_ehrms\\clientdata\\nem2hp\\batch\\temp\\21d',
            'TenantSsoUrl': 'https://c74-adp09-CLN1-sso.cfn.mykronos.com',
            'SamlAssertionUrl': 'https://sso-oam02.cfn.mykronos.com/authn/c74_nonprd_45/hsp/887',
            'SamlAcsUrl': 'https://sso-oam02.cfn.mykronos.com/authn/AuthConsumer/metaAlias/c74_nonprd_45/887',
            'MetadataUrl': 'https://sso-oam02.cfn.mykronos.com/authn/saml2/jsp/exportmetadata.jsp?entityid=https://sso-oam02.cfn.mykronos.com/authn/c74_nonprd_45/hsp/887&realm=c74_nonprd_45',
            'TenantShortName': 'c74_nonprd_45',
            'Active': true,
            'AppKey': 'glJQHPCzQMGdj0obZ0MWYLM9oQy0srQg',
            'Properties': null,
            'Modifiedby': null,
            'Modifieddate': '1/29/2018 10:40:57 AM',
            'Region': null,
            'Companycode': '12345',
            'SMSName': 'VANSQ5DIT2-Development',
            'ISIOrgCd': 'VANSQ5DIT2'
        },
        {
            'OrgOID': 'G3BQ0EKGP5Q2MC2V',
            'TenantId': 'c74_nonprd_45_kcfn01',
            'OAuthEndPoint': 'https://c74-adp09-CLN1.cfn.mykronos.com',
            'TenantRoot': 'https://c74-adp09-CLN1.cfn.mykronos.com',
            'TenantUserName': 'AnnaClark',
            'TenantPassWord': 'Kr0n0s@Cloud',
            'TenantSecretKey': 'iCwOL9ifFCj59Tht',
            'ProductName': 'Vantage',
            'IntegrationMode': 'ON',
            'RouteName': 'Infolink',
            'RoutePath': '\\cdlisilon01-fs1.es.oneadp.com\\fit_hrcore_ehrms\\clientdata\\nem2hp\\batch\\temp\\21d',
            'TenantSsoUrl': 'https://c74-adp09-CLN1-sso.cfn.mykronos.com',
            'SamlAssertionUrl': 'https://sso-oam02.cfn.mykronos.com/authn/c74_nonprd_45/hsp/887',
            'SamlAcsUrl': 'https://sso-oam02.cfn.mykronos.com/authn/AuthConsumer/metaAlias/c74_nonprd_45/887',
            'MetadataUrl': 'https://sso-oam02.cfn.mykronos.com/authn/saml2/jsp/exportmetadata.jsp?entityid=https://sso-oam02.cfn.mykronos.com/authn/c74_nonprd_45/hsp/887&realm=c74_nonprd_45',
            'TenantShortName': 'c74_nonprd_45',
            'Active': true,
            'AppKey': 'glJQHPCzQMGdj0obZ0MWYLM9oQy0srQg',
            'Properties': [
                {
                    'PropertyType': 'INTEGRATION',
                    'PropertyKey': 'ADP Person API Direct',
                    'PropertyValue': 'r-0ded548d-ab86-403c-b0b5-35c269f3d39c-1'
                }
            ],
            'Modifiedby': 'irisjuka',
            'Modifieddate': '1/22/2018 10:46:22 AM',
            'Region': null,
            'Companycode': null,
            'SMSName': 'VANDITAC21',
            'ISIOrgCd': 'VANDITAC21'
        }
    ];
