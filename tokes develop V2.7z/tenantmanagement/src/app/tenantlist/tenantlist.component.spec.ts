import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


import { TenantListComponent } from './tenantlist.component';
import { TenantListModule } from './tenantlist.module';
import { ModalAnchorComponent } from 'synerg-components';
import { AppModule } from '../app.module';
import { TenantActions } from '../tenantlist/tenant.actions';
import { TenantDataService } from '../services/tenantdata.service';
import { TenantDetailMockService } from '../../app/services/tenantdata-mock.service';

import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';
import { ITenant } from '../tenantlist/Models/ITenant';

import * as mockdata from '../services/tenantdata-mockdata';



describe('Tenant List Component', () => {

  let comp: TenantListComponent;
  let fixture: ComponentFixture<TenantListComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        TenantListModule
      ],
      providers: [
        { provide: TenantDataService, useClass: TenantDetailMockService },
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TenantListComponent);
    comp = fixture.debugElement.componentInstance;
    fixture.detectChanges();
    console.log('Before Each run List Component......');
  });


  it('should create tenant list component', function(done) {
    console.log('List Component Test 1......');
    fixture.whenStable().then(() => {
      const bres = true;
      expect(bres).toBe(true);
      done();
    });
  });

  it('should create tenant list component and run getTenants', function(done) {
    console.log('List Component Test 2......');
    fixture.whenStable().then(() => {
      comp.searchParameters = {
        coid: 'G',
        vanityURL: '',
        clientName: '',
        netSecureID: '',
        tenantid: ''
      };
      const listSearch: DebugElement = fixture.debugElement.query(By.css('adp-button'));
      listSearch.triggerEventHandler('click', null);
      fixture.detectChanges();
      expect(comp.tenants$).toBeDefined();

    });
    done();
  });

  it('should create tenant list component and Open Client', function(done)  {
    console.log('List Component Test 3......');
    fixture.whenStable().then(() => {
      comp.openClientDetail(mockdata.multipleOrgoidsResponse[0]);
      fixture.detectChanges();
      expect(comp.tenants$).toBeDefined();
      done();
    });
  });

  it('should Toggle Filter List Component', function(done) {
    console.log('List Component Test 4......');
    fixture.whenStable().then(() => {
      comp.selectedOrgoid = mockdata.smsAddData.orgId;
      comp.showFilters = false;
      comp.toggleFilters();
      fixture.detectChanges();
      expect(comp.showFilters).toBe(true);
      done();
    });
  });

  it('should SetSelected Row List Component', function(done) {
    console.log('List Component Test 5......');
    fixture.whenStable().then(() => {
      comp.selectedOrgoid = mockdata.smsAddData.orgId;
      const tendata = mockdata.multipleOrgoidsResponse[0];
      comp.setSelectedRow(1, tendata);
      fixture.detectChanges();
      comp.isSelected(1);
      fixture.detectChanges();
      expect(comp.isSelectedRow).toBe(true);
      done();
    });
  });

  it('should onScroll List Component', function(done){
    console.log('List Component Test 7......');
    fixture.whenStable().then(() => {
      const listSearch: DebugElement = fixture.debugElement.query(By.css('adp-button'));
      listSearch.triggerEventHandler('click', null);
      fixture.detectChanges();
      comp.onScroll();
      fixture.detectChanges();
      expect(comp.tenants$).toBeDefined();
      done();
    });
  });

  it('should call onCloseAlert of List Component',function(done) {
    console.log('List Component Test 8......');
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      comp.onCloseAlert();
      fixture.detectChanges();
      expect(comp.tenants$).toBeDefined();
      done();
    });
  });

});
