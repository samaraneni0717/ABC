import { Component, OnInit, ViewEncapsulation} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { DateFormatService, BusyIndicatorModule } from 'synerg-components';
import { SecondaryNavComponent, FooterComponent } from 'synerg-components';

import { select } from 'ng2-redux';
import { Observable } from 'rxjs/Observable';


import { ITenant } from './Models/ITenant';
import * as iTenantSearch from './Models/ITenantSearchFields';
import { ITenantSearchFields } from './Models/ITenantSearchFields';
import { TenantActions } from './tenant.actions';

import * as store from '../store';
import { ITenantList } from './Models/ITenantList';



@Component({
  selector: 'app-tenantlist',
  templateUrl: './tenantlist.component.html',
  styleUrls: ['./tenantlist.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class TenantListComponent implements OnInit {
  @select(store.getDisplayTenants) tenants$: Observable<ITenant[]>;
  @select(store.getComponentListSerach) searchFields$: Observable<ITenantSearchFields>;
  @select(store.isSearchLoading) isSearchLoading$: Observable<boolean>;
  @select(store.noSearchResults) tenantSearchResults$: Observable<boolean>;
  @select(store.errorMessages) errorMessages$: Observable<any>;


  showFilters = true;
  isSelectedRow = false;

  displayTenants$: boolean;
  selectedRow: number;
  selectedOrgoid: string;
  errorFound$ = '';

  public list: any[];

  headers = [
    { label: 'CLIENT NAME', sort: true, order: 'none', dataname: 'SMSName'},
    { label: 'CLIENT OID', sort: true, order: 'none', dataname: 'OrgOID' },
    { label: 'VANITY URL', sort: false },
    { label: 'TENANT STATUS', sort: false },
    { label: 'PRIMARY INSTANCE', sort: false },
    { label: 'EDIT', sort: false, width: '18%' }
  ];

  tenants: ITenant[];

  searchParameters: ITenantSearchFields = iTenantSearch.initialSearchFields;

  public items: string[];

  constructor(private _dateFormatSerice: DateFormatService, private router: Router, private tenantActions: TenantActions) {
  }

  ngOnInit() {
      this.displayTenants$ = true;
      this.searchFields$.subscribe(data => {
        this.searchParameters = data;
      });

      this.GetUserInfo(); //make sure userinfo is populated

  }

  openClientDetail(clientdata: ITenant) {
    this.router.navigate(['tenantdetail'], { queryParams: { existingTenantId: clientdata.TenantId, existingOrgoId: clientdata.OrgOID } });
  };


  toggleFilters() {
    this.showFilters = !this.showFilters;
  }

  FindAnyClients() {

    const srchData = this.searchParameters;
    this.tenantActions.resetTenantsFound();
    this.tenantActions.getSpecifiedTenants(srchData);

    this.errorMessages$.subscribe(data =>  { this.errorFound$ = data; } );
  }

  GetUserInfo()
  {
    this.tenantActions.getUserInfo();
  }


  onScroll(): void {
    this.tenantActions.next();
  }

  isSelected(idx: number): boolean {
    if (idx === this.selectedRow) {
      return true;
    }
    return false;
  }

  setSelectedRow(idx: number, selectedData: ITenant) {
    this.selectedRow = idx;
    this.isSelectedRow = true;
    this.selectedOrgoid = selectedData.OrgOID;
  }

  sort(index: number, colname: string, headers: any) {
    const head = headers[index];
    let order = 'none';

    if (head.order === 'desc') {
      order = 'asc';
  }
    if (head.order === 'none' || head.order === 'asc') {
        order = 'desc';
    }

    head.order = order;

    this.tenantActions.sortTenants(colname, head.order);
  }

  onCloseAlert() {
    this.tenantActions.resetTenantsFound();
  }


}
