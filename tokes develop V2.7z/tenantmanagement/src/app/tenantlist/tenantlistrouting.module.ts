import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TenantListComponent } from './tenantlist.component';
import { TenantDetailComponent } from '..//tenantdetail/tenantdetail.component';
import { TenantAddComponent} from '../tenantadd/tenantadd.component';
import {TenantNewComponent} from '../tenantnew/tenantnew.component';

const routes: Routes = [
  {
    path: 'tenantlist',
    component: TenantListComponent
  },
  {
    path: 'tenantdetail',
    component: TenantDetailComponent
  },
  {
    path: 'tenantadd',
    component: TenantAddComponent
  },
  {
    path: 'tenantnew',
    component: TenantNewComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TenantListRoutingModule { }
