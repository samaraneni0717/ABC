import { NgRedux } from 'ng2-redux';
import { Injectable } from '@angular/core';

import { AppState } from '../store';
import { UIActions } from '../store/ui-actions';

import { ITenant } from '../tenantlist/Models/ITenant';
import { ITenantSearchFields } from './Models/ITenantSearchFields';

import { TenantDataService } from '../services/tenantdata.service';

import { Observable, } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { ISMSSearchFields } from '../tenantlist/Models/ISMSSearchFields';
import { HttpClient, HttpHeaders } from '@angular/common/http';


export const REQUEST_TENANTS_SUCCESS = 'tenants/REQUEST_TENANTS_SUCCESS';
export const REQUEST_TENANTS_NEXT = 'tenants/REQUEST_TENANTS_NEXT';
export const REQUEST_TENANTS_FILTER = 'tenants/REQUEST_TENANTS_FILTER';
export const REQUEST_ADD_PERIOD_SUCCESS = 'tenants/REQUEST_ADD_PERIOD_SUCCESS';
export const REQUEST_TENANTSUMMARY_SUCCESS = 'tenantEntries/REQUEST_TENANTSUMMARY_SUCCESS';
export const HTTP_SUCCESS = 'UI:HTTP_SUCCESS';
export const HTTP_ERROR = 'UI:HTTP_ERROR';
export const REQUEST_TENANTDETAIL_SUCCESS = 'tenants/REQUEST_TENANTDETAIL_SUCCESS';
export const REQUEST_TENANTDETAIL_SAVE = 'tenants/REQUEST_TENANTDETAIL_SAVE';
export const REQUEST_SMSENTRIES_SUCCESS = 'tenants/REQUEST_SMSENTRIES_SUCCESS';
export const REQUEST_SMSENTRIES_NEXT = 'tenants/REQUEST_SMSENTRIES_NEXT';
export const REQUEST_SMSENTRIES_FILTER = 'tenants/REQUEST_SMSENTRIES_NEXT';
export const REQUEST_TENANT_ADD = 'tenants/REQUEST_TENANT_ADD';
export const REQUEST_TENANT_SUCCESS = 'tenants/REQUEST_TENANT_SUCCESS';
export const REQUEST_USERINFO = 'tenants/REQUEST_USERINFO';
export const REQUEST_SORT = 'tenants/REQUEST_SORT';
export const REQUEST_SORTSMSENTRIES = 'tenants/REQUEST_SORTSMSENTRIES';
export const REQUEST_ENTITLEMENTSUMMARY = 'tenants/REQUEST_ENTITLEMENTSUMMARY';

const NOSEARCHRESULTS = 'Your search did not result in any matches.';

@Injectable()
export class TenantActions {
    constructor(
        private ngRedux: NgRedux<AppState>,
        private tenantService: TenantDataService,
        private uiActions: UIActions,
        private httpClient: HttpClient
    ) { }


    getSpecifiedTenants(searchData: ITenantSearchFields) {
        this.uiActions.startLoading('UI:TENANTS_START_LOADING');
        this.tenantService.getTenants(searchData).subscribe(tenants => {
            this.ngRedux.dispatch(
                {
                    type: REQUEST_TENANTS_SUCCESS,
                    tenants,
                    searchData
                });

            this.uiActions.stopLoading('UI:TENANTS_STOP_LOADING');

            if (tenants == null || tenants.length === 0) {
                this.uiActions.stopLoadingWithErrors('UI:TENANTS_NOTFOUND', NOSEARCHRESULTS);
            }
        }, error => {
                const errordata = NOSEARCHRESULTS + '     Error durring GET Tenants. ' + error.statusText;
                console.log(errordata);
            this.uiActions.stopLoadingWithErrors('UI:TENANTS_NOTFOUND', errordata);
        });

    }


    searchForSMSClients(searchData: ISMSSearchFields) {
        this.uiActions.stopLoading('UI:SMS_ENTRIES_FOUND');
        this.uiActions.startLoading('UI:SMS_START_LOADING');
        this.tenantService.getSMSData(searchData).subscribe(smsEntries => {

            this.uiActions.stopLoading('UI:SMS_STOP_LOADING');

            this.ngRedux.dispatch(
                {
                    type: REQUEST_SMSENTRIES_SUCCESS,
                    smsDataFound: smsEntries.Resources.Resource,
                    searchData
                });

                if (smsEntries == null || smsEntries.Resources == null || smsEntries.Resources.Resource == null ||
                    smsEntries.Resources.Resource.length === 0) {
                    this.uiActions.stopLoadingWithErrors('UI:SMS_ENTRIES_NOTFOUND', NOSEARCHRESULTS);
                }

        }, error => {
            this.uiActions.stopLoading('UI:SMS_STOP_LOADING');
                const errordata = NOSEARCHRESULTS  + '     Error durring GET SMS Clients. ' + error.statusText;
                console.log(errordata);
                this.uiActions.stopLoadingWithErrors('UI:SMS_ENTRIES_NOTFOUND', errordata);
        });

    }


    next() {
        this.ngRedux.dispatch({
            type: REQUEST_TENANTS_NEXT,
            tenantsPerPage: 15,
        });
    }


    nextSMSEntries() {
        this.ngRedux.dispatch({
            type: REQUEST_SMSENTRIES_NEXT,
            smsEntriesPerPage: 15,
        });
    }


    saveTenant(tenantdata: ITenant) {
        try {
            this.uiActions.startLoading('UI:TENANT_SAVE_LAUNCHED');
            this.tenantService.saveTenantDetails(tenantdata).subscribe(
                tenant => {
                    // check return properties array null or empty array will cause angular display errors
                    this.checkTenantProperties(tenant);
                    this.uiActions.stopLoading('UI:TENANT_SAVE_FINISHED');
                    this.uiActions.stopLoading('UI:TENANT_HAS_SAVED');
                }, error => {
                    const errordata = 'Error durring Tenant Save. ' + error.statusText;
                    console.log(errordata);
                    this.uiActions.stopLoadingWithErrors('UI:TENANT_NOT_SAVING', errordata);
                });
        } catch (e) { console.log('Error during Save Tenant'); }
    }

    addTenant(tenantdata: ITenant) {
        try {
            this.uiActions.startLoading('UI:TENANT_SAVE_LAUNCHED');
            this.tenantService.addTenantDetails(tenantdata).subscribe(
                tenant => {
                    console.log('Tenant ADD Result = ' + tenant);
                    this.uiActions.stopLoading('UI:TENANT_SAVE_FINISHED');
                    this.uiActions.stopLoading('UI:TENANT_HAS_SAVED');
                }, error => {
                    const errordata = 'Error durring Tenant Add. Response Status = ' + error.status + ', ' + error.statusText
                     + ', ' + error.error + '  -  Response Message = ' + error.message;
                     console.log(errordata);
                     const errordataless = 'Error durring Tenant Add. ' + error.statusText;
                     this.uiActions.stopLoadingWithErrors('UI:TENANT_NOT_SAVING', errordataless);
                });
        } catch (e) { console.log('Error During Add Tenant'); }
    }

    checkTenantProperties(tenant: ITenant) {
        if (tenant != null && tenant.Properties == null || tenant.Properties[0] == null) {
            tenant.Properties = [
                {
                    'PropertyType': '',
                    'PropertyKey': '',
                    'PropertyValue': ''
                }];
        }
    }


    public getTenantByOrgoid(searchData: ITenantSearchFields): Observable<any> {
        try {
            const url = '/taascommon/Taas.Tenant.Api/v1/Tenant' + '/' + searchData.coid;

            const tenantResp = this.httpClient.get(url, {
                headers:
                  new HttpHeaders().set('Content-Type', 'application/json')}); // .map((res: any) => {res.json()});
            return tenantResp;

        } catch (e) {  console.log('Error during Get getTenantOrgoidMap ' + e);
     }

    }

    public getTenantByTenantid(searchData: ITenantSearchFields): Observable<any> {
        try {
            const url = '/taascommon/Taas.Tenant.Api/v1/Tenant' + '/' + searchData.tenantid;

            const tenantResp = this.httpClient.get(url, {
                headers:
                  new HttpHeaders().set('Content-Type', 'application/json')}); // .map((res: any) => {res.json()});
            return tenantResp;

        } catch (e) {  console.log('Error during Get getTenantByTenantid ' + e);
     }

    }

    public resetTenantsFound() {
        this.uiActions.stopLoading('UI:TENANTS_FOUND');
    }

    public resetSmsEntriesFound() {
        this.uiActions.stopLoading('UI:SMS_ENTRIES_FOUND');
    }

    public resetTenantSaved() {
        this.uiActions.stopLoading('UI:TENANT_SAVE_RESET');
    }

    public setRequestingUserName(aoid: string) {
        this.uiActions.setUserData('UI:SET_REQUESTING_USER', aoid);
    }

    public setTenantInfoError(errordata: string)
    {
        this.uiActions.stopLoadingWithErrors('UI:TENANT_NOT_SAVING', errordata);
    }

    public getUserInfo() {
        try {
            const resp = this.tenantService.getUserInfo().subscribe(userinfo => {
                this.ngRedux.dispatch(
                    {
                        type: REQUEST_USERINFO,
                        userinfo
                    });
            }, error => {
                console.log('Error during GET UserInfo = ' + ' Response Status = ' + error);
            });
        } catch (e) { console.log('Error during GET UserInfo ' + 'Response Status = ' + e); }
    }

    sortTenants(column: string, order: string) {

        this.ngRedux.dispatch(
            {
                type: REQUEST_SORT,
                colname: column,
                order: order
            }
        );
    }

    sortSMSEntries(column: string, order: string) {

        this.ngRedux.dispatch(
            {
                type: REQUEST_SORTSMSENTRIES,
                colname: column,
                order: order
            }
        );
    }

    getEntitlmentSummaryInfo(orgoid: string, ifnonematch: string) {
        try {

            if ( ifnonematch === '' || ifnonematch === null) {
                ifnonematch = 'true';
            }

            const resp = this.tenantService.getEntitlmentSummaryInfo(orgoid, ifnonematch).subscribe(entitlementinfo => {
                this.ngRedux.dispatch(
                    {
                        type: REQUEST_ENTITLEMENTSUMMARY,
                        entitlementinfo
                    });
            }, error => {
                console.log('Error during GET EntitlementSummaryInfo = ' + ' Response Status = ' + error);
            });
        } catch (e) { console.log('Error during GET EntitlementSummaryInfo ' + 'Response Status = ' + e); }
    }
}
