import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { CommonModule } from '@angular/common';
import { TenantListRoutingModule } from './tenantlistrouting.module';
import { TenantListComponent } from './tenantlist.component';
import {
  ButtonModule, BusyIndicatorModule, MastheadModule, SecondaryNavModule, TableModule, LeftNavModule,
  PopoverModule, TextboxModule, DatePickerModule, FormGroupModule, FormGroupConfig, DateFormatService,
  DropdownListModule, SlideinModule, ModalModule, DualSelectModule, RadioModule,
  DropdownListComponent, FooterModule, AlertModule
} from 'synerg-components';


@NgModule({
  imports: [
    CommonModule,
    TenantListRoutingModule,
    FormGroupModule,
    ButtonModule,
    FormsModule,
    BrowserModule,
    DatePickerModule,
    DropdownListModule,
    InfiniteScrollModule,
    SecondaryNavModule,
    BusyIndicatorModule,
    FooterModule,
    AlertModule
  ],
  declarations: [TenantListComponent],
  exports: [TenantListComponent, BusyIndicatorModule, InfiniteScrollModule, FooterModule],
  providers: [FormGroupConfig, DateFormatService]
})
export class TenantListModule { }
