export class TenantSearchFields {
    public coid: string;
    public vanityURL: string;
    public clientName: string;
    public netSecureID: string;
}
