export interface ISMSClientInfo {
 id: string;
 name: string;
 isiOrgCd: string;
}
