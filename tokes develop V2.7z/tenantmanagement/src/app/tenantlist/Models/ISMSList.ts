import {  ISms } from './ISms';

export interface ISMSList {
     list: ISms[];
}
