export interface ISmsData {
    totalResults: string;
    itemsPerPage: string;
    startIndex: string;
    Resources: Resources;
}

export interface Resources {
    Resource: ISms[];
}

export interface ISms {
    name: string;
    isiOrgCd: string;
    orgId: string;
}

export const initialSmsFields: ISms = {
        name: '',
        isiOrgCd: '',
        orgId: ''
    };
