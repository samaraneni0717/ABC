export interface ISMSSearchFields {
    OrgOID: string;
    SMSName: string;
    ISIOrgCd: string;
    searchType: string;
};

export const initialSearchFields: ISMSSearchFields = {
        OrgOID: '',
        SMSName: '',
        ISIOrgCd: '',
        searchType: 'SW'
    };
