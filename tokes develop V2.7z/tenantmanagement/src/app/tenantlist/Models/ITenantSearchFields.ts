export interface ITenantSearchFields {
    coid: string;
    tenantid: string;
    vanityURL: string;
    clientName: string;
    netSecureID: string;
};

export const initialSearchFields: ITenantSearchFields = {
        coid: '',
        tenantid: '',
        vanityURL: '',
        clientName: '',
        netSecureID: ''
    };
