import {IProperty} from './IProperty';
import {ISMSClientInfo} from './ISMSClientInfo';

export interface  ITenant {
  OrgOID: string;
  TenantId: string;
  OAuthEndPoint: string;
  TenantRoot: string;
  TenantUserName: string;
  TenantPassWord: string;
  TenantSecretKey: string;
  ProductName: string;
  IntegrationMode: string;
  RouteName: string;
  RoutePath: string;
  TenantSsoUrl: string;
  SamlAssertionUrl: string;
  SamlAcsUrl: string;
  MetadataUrl: string;
  TenantShortName: string;
  Active: boolean;
  AppKey: string;
  Modifiedby: string;
  Modifieddate: string;
  TenantType: string;
  CompanyCode: string;
  Region: string;
  Properties: IProperty[];
  SMSName: string;
  ISIOrgCd: string;
  isPrimary: boolean;
}

export const initialTenant: ITenant = {
    'OrgOID': '',
    'TenantId': '',
    'OAuthEndPoint': '',
    'TenantRoot': '',
    'TenantUserName': '',
    'TenantPassWord': '',
    'TenantSecretKey': '',
    'ProductName': '',
    'IntegrationMode': 'OFF',
    'RouteName': '',
    'RoutePath': '',
    'TenantSsoUrl': '',
    'SamlAssertionUrl': '',
    'SamlAcsUrl': '',
    'MetadataUrl': '',
    'TenantShortName': '',
    'Active': false,
    'AppKey': '',
    'TenantType': '',
    'CompanyCode': '',
    'Region': '',
    'Properties': [
        {
            'PropertyType': '',
            'PropertyKey': '',
            'PropertyValue': ''
        }
    ],
    'Modifiedby': '',
    'Modifieddate': '',
    'SMSName': '',
    'ISIOrgCd': '',
    'isPrimary': false
};
