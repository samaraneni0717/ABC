import { ITenant } from './ITenant';

export interface ITenantsListHttpResponse {
    responseCode: number;
    responseMessage: string;
    Data: ITenant;
}

export interface ITenantHttpResponse {
    responseCode: number;
    responseMessage: string;
    Data: ITenant;

}
