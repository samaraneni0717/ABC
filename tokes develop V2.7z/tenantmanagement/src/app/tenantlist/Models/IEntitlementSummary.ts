export interface IEntitlementSummary {
    id: string;
    seats: string;
    assignedSeats: string;
    remSeats: string;
    solutionId: string;
    currentDate: string;
    name: string;
};

export interface IEntitlementSummaryList {
    list: IEntitlementSummary[];
}

export const initialEntitlementSummary = {
    id: '',
    seats: '',
    assignedSeats: '',
    remSeats: '',
    solutionId: '',
    currentDate: '',
    name: '',
};