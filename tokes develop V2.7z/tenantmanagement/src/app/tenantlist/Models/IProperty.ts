
export interface IProperty{
        PropertyType: string;
        PropertyKey:string;
        PropertyValue: string;
  }