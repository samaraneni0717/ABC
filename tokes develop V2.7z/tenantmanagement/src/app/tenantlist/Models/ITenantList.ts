import {  ITenant } from './ITenant';

export interface ITenantList {
     list: ITenant[];
}
