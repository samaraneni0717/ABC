import { ITenant } from './ITenant';

export class TenantDataValidator {

    valErrMessage = '';
    validationError = false;

    constructor(){}

    public ValidateTenantData(tenantData: ITenant): boolean {
    this.validationError = false;
    if (this.isNullorEmpty(tenantData.TenantId) || tenantData.TenantId.length < 4) {
      this.valErrMessage = 'Tenant Client Id is required and must be at least 4 characters in length';
      this.validationError = true;
      return true;
    }

    if (this.isNullorEmpty(tenantData.TenantRoot)) {
      this.valErrMessage = 'Vanity URL is required';
      this.validationError = true;
      return true;
    }

    if (this.isNullorEmpty(tenantData.TenantType)) {
      this.valErrMessage = 'Tenant Type is required';
      this.validationError = true;
      return true;
    }

    if (this.isNullorEmpty(tenantData.ProductName)) {
      this.valErrMessage = 'HCM Product is required';
      this.validationError = true;
      return true;
    }

    if (this.isNullorEmpty(tenantData.IntegrationMode)) {
      this.valErrMessage = 'A Data Integration Mode must be selected';
      this.validationError = true;
      return true;
    }

    if (this.isNullorEmpty(tenantData.Region)) {
      this.valErrMessage = 'A Client Region must be selected';
      this.validationError = true;
      return true;
    }

    if (this.isNullorEmpty(tenantData.RouteName)) {
      this.valErrMessage = 'A Pay Data File Path Type must be selected';
      this.validationError = true;
      return true;
    }
  }

  isNullorEmpty(value: string) {
    return (value == null || value.length === 0);
  }
}