import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';


import { TenantAddComponent } from './tenantadd.component';
import { ModalAnchorComponent } from 'synerg-components';
import { AppModule } from '../app.module';
import { TenantAddModule } from './tenantadd.module';
import { TenantActions } from '../tenantlist/tenant.actions';
import { TenantDataService } from '../services/tenantdata.service';
import { TenantDetailMockService } from '../../app/services/tenantdata-mock.service';
import { Subject } from 'rxjs/Subject';
import { Params } from '@angular/router/src/shared';
import { ISMSSearchFields } from '../tenantlist/Models/ISMSSearchFields';
import * as ISMSSrch from '../tenantlist/Models/ISMSSearchFields';
import { ISms } from '../tenantlist/Models/ISms';
import * as ISmsData from '../tenantlist/Models/ISms';

import * as mockdata from '../services/tenantdata-mockdata';

class MockActivatedRoute {
  // here you can add your mock objects, like snapshot or parent or whatever
  // example:
  parent =
  {
    snapshot: {data: {existingTenantId: 'G347EYZNRMJEMT5E' }}
  };
}

describe('Tenant Add Component', () => {

        let comp: TenantAddComponent;
        let fixture: ComponentFixture<TenantAddComponent>;
        let de: DebugElement;
        let el: HTMLElement;
        let params: Subject<Params>;

        beforeEach(() => {
          params = new Subject<Params>();
          TestBed.configureTestingModule({
            imports: [
              AppModule,
              TenantAddModule
            ],
            providers: [
              { provide: TenantDataService, useClass: TenantDetailMockService, useValue: {}},
              // {provide: ActivatedRoute, useClass: MockActivatedRoute},
            ]
          });
        });

        beforeEach(() => {
          fixture = TestBed.createComponent(TenantAddComponent);
          comp = fixture.debugElement.componentInstance;
          fixture.detectChanges();
          console.log('Before Each run......');
        });


        it('should create tenant add component' , function(done) {
          console.log('Tenant Add Component Test 1......');
          fixture.whenStable().then(() => {

            const bres = true;
            expect(bres).toBe(true);
            done();
           });
          
        });

        it('should create the TenantAdd list', function(done){
          fixture.whenStable().then(() => {
            console.log('Tenant Add Component Test 2......');
            comp.searchParameters.SMSName = 'VAN1';
            comp.FindSMSEntriesOnSMSName('VAN1');
            fixture.detectChanges();
            let rowcnt = 0;
            comp.smsClients$.subscribe(data => {rowcnt = data.length; console.log('smsdata' + data); } );
            expect((rowcnt)).toBe(3);
            done();
          });
        });

        it('should open new Tenant screen', function(done) {
          fixture.whenStable().then(() => {
            console.log('Tenant Add Open New Screen Test 3......');
            comp.selectedSMSEntry = mockdata.smsAddData;

            comp.openNewTenant();
            fixture.detectChanges();
            expect((comp.selectedSMSEntry.orgId)).toBe('G347EYZNRMJEMT5E');
            done();
          });
        });

        it('should create the TenantAdd list for isiOrgCd', function(done) {
          fixture.whenStable().then(() => {
            console.log('Tenant Add Component Test 4......');
            const srch = mockdata.smsAddData.isiOrgCd;
            comp.searchParameters.ISIOrgCd = mockdata.smsAddData.isiOrgCd;
            comp.FindSMSEntriesOnISIOrgCd(srch);
            fixture.detectChanges();
            let rowcnt = 0;
            comp.smsClients$.subscribe(data => {rowcnt = data.length; console.log('smsdata' + data); } );
            expect((rowcnt)).toBe(3);
            done();
          });
        });
        it('should create the TenantAdd list for OrgOid', function(done) {
          fixture.whenStable().then(() => {
            console.log('Tenant Add Component Test 5......');
            const srch = mockdata.smsAddData.orgId;
            comp.searchParameters.OrgOID = mockdata.smsAddData.orgId;
            comp.FindSMSEntriesOnOrgOID(srch);
            fixture.detectChanges();
            let rowcnt = 0;
            comp.smsClients$.subscribe(data => {rowcnt = data.length; console.log('smsdata' + data); } );
            expect((rowcnt)).toBe(3);
            done();
          });
        });

        it('should Set Selected Row', function(done) {
          console.log('Tenant Add Component Test 6......');
          fixture.whenStable().then(() => {
            const smsData = mockdata.smsAddData;
            const listSearch: DebugElement = fixture.debugElement.query(By.css('adp-button'));
            comp.setSelectedRow(1, smsData);
            fixture.detectChanges();
            expect(comp.isSelectedRow).toBe(true);
            done();
          });
        });

        it('should Translate Search Type', function(done) {
          console.log('Tenant Add Component Test 7......');
          fixture.whenStable().then(() => {
            const smsData = mockdata.smsAddData;
            comp.TranslateSMSSearchType('StartsWith');
            fixture.detectChanges();
            comp.TranslateSMSSearchType('Contains');
            fixture.detectChanges();
            comp.TranslateSMSSearchType('EndsWith');
            fixture.detectChanges();
            comp.TranslateSMSSearchType('Equals');
            fixture.detectChanges();
            expect(smsData.orgId).toBe('G347EYZNRMJEMT5E');
            done();
          });
        });

});
