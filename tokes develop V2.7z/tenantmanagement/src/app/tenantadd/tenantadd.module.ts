import { NgModule } from '@angular/core';
import { TenantAddComponent } from './tenantadd.component';

import {TenantDetailModule} from '../tenantdetail/tenantdetail.module';

import { TabsModule, TabComponent } from 'synerg-components';

@NgModule({
  imports: [
    TenantDetailModule,
    TabsModule
  ],
  declarations: [TenantAddComponent],
  exports: [TenantAddComponent, TabComponent]
})
export class TenantAddModule { }
