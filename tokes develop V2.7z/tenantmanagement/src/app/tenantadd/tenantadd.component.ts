import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, OnInit, Output, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { select, NgRedux } from 'ng2-redux';

import { ITenant } from '../tenantlist/Models/ITenant';
import * as itentantConstants from '../tenantlist/Models/ITenant';
import * as iTenantSearch from '../tenantlist/Models/ITenantSearchFields';
import { ITenantSearchFields } from '../tenantlist/Models/ITenantSearchFields';

import {
    DateFormatService, TextboxComponent, TextboxModule, FormGroupModule, CheckboxComponent,
    BusyIndicatorModule
} from 'synerg-components';
import { SecondaryNavComponent, FormGroupMessage, FormGroupConfig, IconComponent } from 'synerg-components';
import { ConfirmService, ConfirmConfig, ConfirmDirective } from 'synerg-components';
import { ModalService, ModalAnchorComponent, ModalComponent, ModalModel } from 'synerg-components';


import { AppState } from '../store/';
import { SMSState } from '../store/tenantadd.reducer';
import * as store from '../store';
import { TenantActions } from '../tenantlist/tenant.actions';

import { Pipe, PipeTransform } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { forEach } from '@angular/router/src/utils/collection';
import { UrlTree } from '@angular/router/src/url_tree';

import { ISms } from '../tenantlist/Models/ISms';
import * as ISmsSearch from '../tenantlist/Models/ISms';
import * as ISMSSearch from '../tenantlist/Models/ISMSSearchFields';
import { ISMSSearchFields } from '../tenantlist/Models/ISMSSearchFields';
import { ISMSList } from '../tenantlist/Models/ISMSList';
import { UIActions } from '../store/ui-actions';

import * as detailconstants from '../tenantdetail/tenantdetailconstants';

@Component({
    selector: 'app-tenantadd',
    templateUrl: './tenantadd.component.html',
    styleUrls: ['./tenantadd.component.scss'],
    providers: [ModalService, ConfirmService, ConfirmConfig],
    encapsulation: ViewEncapsulation.None
})
export class TenantAddComponent implements OnInit {
    @select(store.getSMSEntries) smsClients$: Observable<ISms[]>;
    @select(store.isDetailSMSLoading) isDetailSMSLoading$: Observable<boolean>;
    @select(store.isSearchLoading) isSearchLoading$: Observable<boolean>;
    @select(store.noSmSSearchResults) smsSearchResults$: Observable<boolean>;
    @select(store.errorMessages) errorMessages$: Observable<any>;

    headers = [
        { label: 'CLIENT NAME', sort: true, order: 'none', dataname: 'name' },
        { label: 'CLIENT ID', sort: true, order: 'none', dataname: 'isiOrgCd' },
        { label: 'CLIENT OID', sort: true, order: 'none', dataname: 'orgId' }
    ];

    searchParameters: ISMSSearchFields = ISMSSearch.initialSearchFields;

    listconstants = detailconstants;
    srchOption = 'StartsWith';

    smsClients: ISms[] = [];
    tenantExists$ = false;

    selectedSMSEntry: ISms = ISmsSearch.initialSmsFields;
    selectedRow: number;

    isSelectedRow = false;
    errorFound$ = '';

    constructor(private _dateFormatSerice: DateFormatService, private router: Router,
        private tenantActions: TenantActions, private confirmService: ConfirmService,
        private httpClient: HttpClient, private uiActions: UIActions) { }

    ngOnInit() {

    }

    openNewTenant() {
        this.tenantExists$ = false;
        const srchData = iTenantSearch.initialSearchFields;
        srchData.coid = this.selectedSMSEntry.orgId != null ? this.selectedSMSEntry.orgId : '0';
        srchData.netSecureID = this.selectedSMSEntry.isiOrgCd;
        srchData.clientName = this.selectedSMSEntry.name;

        this.router.navigate(['tenantnew'], {
            queryParams: {
                orgOid: srchData.coid,
                smsName: srchData.clientName, netSecureID: srchData.netSecureID
            }
        });
    }



    FindSMSEntriesOnISIOrgCd(srchISI: string) {
        this.searchParameters.OrgOID = '';
        this.searchParameters.SMSName = '';
        this.searchParameters.searchType = this.TranslateSMSSearchType(this.srchOption);

        if (this.searchParameters.ISIOrgCd.length > 2) {
            this.tenantActions.searchForSMSClients(this.searchParameters);
        }
        this.errorMessages$.subscribe(data =>  { this.errorFound$ = data; } );
    }

    FindSMSEntriesOnOrgOID(srchISI: string) {
        this.searchParameters.ISIOrgCd = '';
        this.searchParameters.SMSName = '';
        this.searchParameters.searchType = this.TranslateSMSSearchType(this.srchOption);

        if (this.searchParameters.OrgOID.length > 2) {
            this.tenantActions.searchForSMSClients(this.searchParameters);
        }

        this.errorMessages$.subscribe(data =>  { this.errorFound$ = data; } );
    }

    FindSMSEntriesOnSMSName(srchISI: string) {
        this.searchParameters.OrgOID = '';
        this.searchParameters.ISIOrgCd = '';
        this.searchParameters.searchType = this.TranslateSMSSearchType(this.srchOption);

        if (this.searchParameters.SMSName.length > 2) {
            this.tenantActions.searchForSMSClients(this.searchParameters);
        }

        this.errorMessages$.subscribe(data =>  { this.errorFound$ = data; } );
    }

    onScroll(): void {
        this.tenantActions.nextSMSEntries();
    }

    isSelected(idx: number): boolean {
        if (idx === this.selectedRow) {
            return true;
        }
        return false;
    }
    setSelectedRow(idx: number, ismsdata: ISms) {
        this.selectedSMSEntry = ismsdata;
        this.selectedRow = idx;
        this.isSelectedRow = true;

    }

    onSmsCloseAlert() {
      this.tenantActions.resetSmsEntriesFound();
    }

    TranslateSMSSearchType(srchMethod: string): string {
        switch (srchMethod) {
            case ('StartsWith'):
                return 'SW';
            case ('Contains'):
                return 'CO';
            case ('EndsWith'):
                return 'EW';
            case ('Equals'):
                return 'EQ';
            default:
                return 'SW';
        }
    }

    sort(index: number, colname: string, headers: any) {
        const head = headers[index];
        let order = 'none';

        if (head.order === 'desc') {
          order = 'asc';
      }
        if (head.order === 'none' || head.order === 'asc') {
            order = 'desc';
        }

        head.order = order;

        this.tenantActions.sortSMSEntries(colname, head.order);
      }

      returnToTenantList() {
        this.tenantActions.resetTenantSaved();
        this.router.navigate(['/tenantlist']);
      }

    ngOnDestroy() {
      this.tenantActions.resetSmsEntriesFound();
    }
}
