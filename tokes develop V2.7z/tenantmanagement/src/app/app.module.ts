import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler } from '@angular/core';
import { APP_BASE_HREF, PlatformLocation } from '@angular/common';

import { UIActions } from './store/ui-actions';
import { API_PREFIX } from './services/api-url.prefix';

import { AppComponent } from './app.component';
import { RouterModule, Route } from '@angular/router';
import { NgReduxModule, NgRedux } from 'ng2-redux';
import { store, AppState } from '../app/store/store';
import { HttpClientModule } from '@angular/common/http';
/*NGRX_DEMO:*/
// import { NgrxExampleModule } from './ngrx/ngrx.module';
import { ButtonModule } from 'synerg-components';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';

import { MastheadModule } from 'synerg-components';
import { SidebarModule } from 'synerg-components';
import { FooterModule } from 'synerg-components';

import { AppRoutingModule } from './app-routing.module';
import { SecondaryNavModule, BusyIndicatorModule, TabsModule } from 'synerg-components';
import { TenantListModule, TenantListComponent } from './tenantlist';
import { TenantDetailModule } from './tenantdetail/tenantdetail.module';
import { TenantAddModule } from './tenantadd/tenantadd.module';
import { TenantNewModule } from './tenantnew/tenantnew.module';
import { HttpErrorHandlerService } from './services/http-error-handler.service';
import { ApiUrlService } from './services/api-url.service';
import { GlobalErrorHandler } from './services/global-error-handler.service';
import { TenantDataService } from './services/tenantdata.service';
import { TenantActions } from './tenantlist/tenant.actions';
import { TenantEntitlementModule } from './tenantentitlement/tenantentitlement.module';


declare var PORTAL_BASE_PATH: string;

/* Routing demo */
const routes: Route[] = [
    { path: 'adpWorkforceManagerSupport', redirectTo: '/tenantlist', pathMatch: 'full' },
    { path: 'adpADP_ttd_adpWorkforceManagerSupport', redirectTo: '/tenantlist', pathMatch: 'full' },
    { path: 'tenantlist', component: TenantListComponent },    
    { path: '', redirectTo: '/tenantlist', pathMatch: 'full' }
];

export function getBaseLocation() {
    const PREFIX_PARTS_COUNT = 1;
    let paths: string[] = location.hash.split('/');
    // trim off the #
    paths.shift();
    // the first two parts of the hash are from the portal. Those are effectively
    // the base path of this app
    paths.length = PREFIX_PARTS_COUNT;
    let pathParts: string[] = [];
    for (let i = 0; i < PREFIX_PARTS_COUNT; i++) {
        if (paths[i]) {
            pathParts.push(paths[i]);
        } else {
            pathParts.push('x'); // pad the base path
        }
    }

    let basePath = '/' + pathParts.join('/') + '/';

    console.log('Base path locked in as: ' + basePath);
    // we need to set our global variable so the router will
    // know when we are navigating away from the application
    PORTAL_BASE_PATH = basePath;

    return basePath;
}

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserAnimationsModule,
        BrowserModule,
        ButtonModule,
        TenantListModule,
        TenantDetailModule,
        TenantAddModule,
        TenantNewModule,
        NgReduxModule,
        HttpClientModule,
        BusyIndicatorModule,
        SecondaryNavModule,
        TenantEntitlementModule,
        TabsModule,

        ///*NGRX_DEMO:*/
        // For the purposes of the demo, the NgRX stuff is put in the
        // ngrx folder. That is just to make it easier for this demo. It doesn't
        // have to go in a special folder
        //NgrxExampleModule.forRoot(),
        // end ngrx
        // For routing demo
        RouterModule.forRoot(routes, { useHash: true })

    ],
    exports: [
        BusyIndicatorModule, TabsModule
    ],
    providers: [
        {
            provide: ErrorHandler,
            useClass: GlobalErrorHandler
        },
        HttpErrorHandlerService,
        ApiUrlService,
        {
            provide: APP_BASE_HREF,
            useFactory: getBaseLocation
        },
        // For portal, you will need this in order to avoid memory leaks
        { provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService },
        { provide: API_PREFIX, useValue: '/taascommon/TaaS.Tenant.Api/v1/Tenant/' },
        TenantDataService,
        TenantActions,
        UIActions
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
    constructor(ngRedux: NgRedux<AppState>) {
        ngRedux.provideStore(store);
    }
}
