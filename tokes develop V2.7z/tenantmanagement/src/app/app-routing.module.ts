import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'tenantlist',
    pathMatch: 'full'
  },
  {
    path: 'tenantlist',
    redirectTo: 'tenantlist',
    pathMatch: 'full'
  },
  {
    path: 'adpADP_ttd_adpWorkforceManagerSupport',
    redirectTo: 'tenantlist',
    pathMatch: 'full'
  },
  {
    path: 'tenantadd',
    redirectTo: 'tenantadd',
    pathMatch: 'full'
  },
  {
    path: 'tenantnew',
    redirectTo: 'tenantnew',
    pathMatch: 'full'
  },
  {
    path: '',
    loadChildren: './ux/ux.module#UxModule'
  },
  {
    path: 'tenantdetail',
    redirectTo: 'tenantdetail',
    pathMatch: 'full'
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'tenantentitlement',
    redirectTo: 'tenantentitlement',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash : false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
