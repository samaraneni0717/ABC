export const environment = {
  production: false,
  prepareForPortal: true
};
