import {enableProdMode, NgModuleRef, ApplicationRef} from '@angular/core';
import { platformBrowser } from '@angular/platform-browser';

import { AppModuleNgFactory } from './aot/app/app.module.ngfactory';
import { environment } from './environments/environment.dev';
import { AppModule } from './app/app.module';

if (environment.production) {
  enableProdMode();
}

declare var wrapper:any;
declare var window: any;
let bootstrapApp = function() {
let platform = platformBrowser();
platform.bootstrapModuleFactory(AppModuleNgFactory).then((ref: NgModuleRef<AppModule>) => {

  if (environment.prepareForPortal) {

    if (typeof wrapper !== 'undefined') {
      wrapper.setApplicationComponentNode(ref, platform);
    }
  }

});
};

// the portal build environments exclude zonejs from the bundle, so we need to
// load it on demand (if it hasn't been loaded yet)
if (environment.prepareForPortal) {
  
  if (!window['Zone']) {
    console.log('Zone: does not exist');

   let prefix = '/smicro/tenantmanagement/1/taas';

    let zoneFile = prefix + '/zone.min.js';
    console.log('Zone: loading from ' + zoneFile);
    // we need to load zone.js
    let req = window['require'];
    req([zoneFile], function(zone: any) {
      bootstrapApp();
    });
  } else {
    bootstrapApp();
  }
} else {
  // don't have to wait for zonejs, so just bootstrap as normal
  bootstrapApp();
}
