const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ProgressPlugin = require('webpack/lib/ProgressPlugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const autoprefixer = require('autoprefixer');
const BannerWebpackPlugin = require('banner-webpack-plugin');
const fs = require('fs');


const {NoEmitOnErrorsPlugin, LoaderOptionsPlugin, DefinePlugin} = require('webpack');
const {BaseHrefWebpackPlugin, GlobCopyWebpackPlugin} = require('@angular/cli/plugins/webpack');
const {AotPlugin} = require('@ngtools/webpack');
const UglifyJSPlugin = require('webpack').optimize.UglifyJsPlugin;

const nodeModules = path.join(process.cwd(), 'node_modules');
const entryPoints = ["inline", "main"];

const devServerSetup = require('./mock-server/setup');
const options = require('./build.options');

const pkg = require('./package.json');
const bundleName = pkg.name + '-' + pkg.version + '-';

const AngularPatchPlugin = require('./plugins/webpack-angular-patch-plugin');
const PortalPatchPlugin = require('./plugins/webpack-portal-patch-plugin');
const SourcemapsBannerPlugin = require('./plugins/webpack-sourcemaps-banner-plugin');


module.exports = function (env) {

    let defaultEnv = {portal: false, prod: false, root: ''};

    if (!env) {
        env = Object.assign(defaultEnv, options);
    } else {
        env = Object.assign(defaultEnv, options, env);
    }

    let envType = '';

    if (env.portal) { //these exclude zonejs
        envType = (env.prod) ? 'portal-prod' : 'portal-dev';
    } else {
        envType = (env.prod) ? 'prod' : 'dev'
    }

    let environmentFile = `environments/environment.${envType}.ts`;

    let mainFile = env.prod ? 'src/main-aot.ts' : 'src/main.ts';


    let stylesFile = (env.portal) ? 'src/styles-portal.scss' : 'src/styles.scss';
    console.log('Using env:\t', environmentFile);
    console.log('Using main:\t', mainFile);
    console.log('Using styles:\t', stylesFile);

    let prefix = fs.readFileSync('./wrapper.prefix.txt', 'utf8').replace('<%=appRootTag%>', options.rootTag) + '\n';
    let suffix = fs.readFileSync('./wrapper.suffix.txt', 'utf8').replace('<%=appRootTag%>', options.rootTag) + '\n';

    let entries = [
        "./src/polyfills.ts",
        "./src/zone.ts",
        "./" + mainFile,
        "./" + stylesFile
    ];

    if (env.portal) {
        console.log('Stripping out zone for portal', env);
        entries.splice(entries.indexOf('./src/zone.ts'), 1);
    }


    let plugins = [
        new NoEmitOnErrorsPlugin(),
        new BannerWebpackPlugin({
            chunks: {
                'main': {
                    beforeContent: prefix,
                    afterContent: suffix
                }
            }
        }),
        new HtmlWebpackPlugin({
            "template": "./src/index.ejs",
            "filename": "./index.html",
            "hash": false,
            "inject": true,
            "compile": true,
            "favicon": false,
            "minify": false,
            "cache": true,
            "showErrors": true,
            "chunks": "all",
            "excludeChunks": [],
            "title": "Webpack App",
            "xhtml": true,
            "chunksSortMode": function sort(left, right) {
                let leftIndex = entryPoints.indexOf(left.names[0]);
                let rightindex = entryPoints.indexOf(right.names[0]);
                if (leftIndex > rightindex) {
                    return 1;
                }
                else if (leftIndex < rightindex) {
                    return -1;
                }
                else {
                    return 0;
                }
            }
        }),
        new BaseHrefWebpackPlugin({}),
        new GlobCopyWebpackPlugin({
            "patterns": [
                "assets",
                "favicon.ico"
            ],
            "globOptions": {
                "cwd": path.join(process.cwd(), "src"),
                "dot": true,
                "ignore": "**/.gitkeep"
            }
        }),
        new GlobCopyWebpackPlugin({
            "patterns": [
                {
                    glob:"flags",
                    output: "assets"
                }

            ],
            "globOptions": {
                "cwd":  path.join(process.cwd(),"node_modules/flag-icon-css"),
                "dot": true,
                "ignore": "**/.gitkeep"
            }
        }),        
        new ProgressPlugin(),
        new ExtractTextPlugin({
            "filename": "[name].bundle.css",
            "disable": true
        }),
        new LoaderOptionsPlugin({
            "sourceMap": true,
            "options": {
                "postcss": [
                    autoprefixer()
                ],
                "sassLoader": {
                    "sourceMap": false,
                    "includePaths": []
                },
                "lessLoader": {
                    "sourceMap": false
                },
                "context": ""
            }
        }),

        new GlobCopyWebpackPlugin({
            "patterns": [
                "zone.min.js"
            ],
            "globOptions": {
                "cwd": path.join(process.cwd(), "node_modules/zone.js/dist"),
                "dot": true,
                "ignore": "**/.gitkeep"
            }
        }),
        new GlobCopyWebpackPlugin({
            "patterns": [
                "shim.js"
            ],
            "globOptions": {
                "cwd": path.join(process.cwd(), "node_modules/core-js"),
                "dot": true,
                "ignore": "**/.gitkeep"
            }
        }),
        // We need to revisit the sourcemaps as they don't seem to work when
        // running in the portal
        new SourcemapsBannerPlugin({
            "entries": [{
                "bundle": bundleName + 'main',
                "prefix": prefix
            }]
        })
    ];

    if (env.portal) {
        plugins.push(new PortalPatchPlugin({
            bundle: bundleName + 'main'
        }));

        plugins.push(new AngularPatchPlugin({
            bundle: bundleName + 'main',
            portal: env.portal
        }));
    }

    // Use AOT when in prod mode
    let prodPlugins = [
        new AotPlugin({
            "tsConfigPath": "src/tsconfig-aot.json",
            entryModule: path.join(process.cwd(), 'src/app/app.module#AppModule'),
            "hostReplacementPaths": {
                "environments/environment.dev": environmentFile
            },
            "exclude": [
                "**/*.spec.ts",
                "test.ts"
            ],
            "skipCodeGeneration": false
        }),


        new UglifyJSPlugin({
            sourceMap: true,
            minimize: true,
            mangle: false,
            compress: {warnings: false}
        })
    ];

    if (env.prod) {
        plugins = plugins.concat(prodPlugins);
    }

    return {
        "devtool": "source-map",
        // we pull in the local dev server setup here
        "devServer": {
            setup: devServerSetup,
            proxy: options.proxy
        },
        "resolve": {
            "extensions": [
                ".ts",
                ".js",
                ".json"
            ],
            "modules": [
                nodeModules
            ]
        },
        "resolveLoader": {
            "modules": [
                nodeModules
            ]
        },
        "entry": {
            "main": entries
        },
        "output": {
            "path": path.join(process.cwd(), "dist"),
            "filename": bundleName + "[name].js",
            "chunkFilename": "[id].chunk.js",
            "publicPath": env.root
        },
        "module": {
            "rules": [
                {
                    "enforce": "pre",
                    "test": /\.js$/,
                    "loader": "source-map-loader",
                    "exclude": [
                        /\/node_modules\//
                    ]
                },
                {
                    "test": /\.json$/,
                    "loader": "json-loader"
                },
                {
                    "test": /\.html$/,
                    "loader": "raw-loader"
                },
                {
                    "test": /\.(eot|svg)$/,
                    "loader": "file-loader?name=[name].[ext]"
                },
                {
                    "test": /\.(jpg|png|gif|otf|ttf|woff|woff2|cur|ani)$/,
                    "loader": "url-loader?name=assets/[name].[ext]&limit=10000"
                },
                {
                    "exclude": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.css$/,
                    "loaders": [
                        "exports-loader?module.exports.toString()",
                        "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                        "postcss-loader"
                    ]
                },
                {
                    "exclude": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.scss$|\.sass$/,
                    "loaders": [
                        "exports-loader?module.exports.toString()",
                        "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                        "postcss-loader",
                        "sass-loader"
                    ]
                },
                {
                    "exclude": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.less$/,
                    "loaders": [
                        "exports-loader?module.exports.toString()",
                        "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                        "postcss-loader",
                        "less-loader"
                    ]
                },
                {
                    "exclude": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.styl$/,
                    "loaders": [
                        "exports-loader?module.exports.toString()",
                        "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                        "postcss-loader",
                        "stylus-loader?{\"sourceMap\":false,\"paths\":[]}"
                    ]
                },
                {
                    "include": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.css$/,
                    "loaders": ExtractTextPlugin.extract({
                        "use": [
                            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                            "postcss-loader"
                        ],
                        "fallback": "style-loader",
                        "publicPath": env.root
                    })
                },
                {
                    "include": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.scss$|\.sass$/,
                    "loaders": ExtractTextPlugin.extract({
                        "use": [
                            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                            "postcss-loader",
                            "sass-loader"
                        ],
                        "fallback": "style-loader",
                        "publicPath": env.root
                    })
                },
                {
                    "include": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.less$/,
                    "loaders": ExtractTextPlugin.extract({
                        "use": [
                            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                            "postcss-loader",
                            "less-loader"
                        ],
                        "fallback": "style-loader",
                        "publicPath": env.root
                    })
                },
                {
                    "include": [
                        path.join(process.cwd(), stylesFile)
                    ],
                    "test": /\.styl$/,
                    "loaders": ExtractTextPlugin.extract({
                        "use": [
                            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}",
                            "postcss-loader",
                            "stylus-loader?{\"sourceMap\":false,\"paths\":[]}"
                        ],
                        "fallback": "style-loader",
                        "publicPath": env.root
                    })
                },
                {
                    "test": /\.ts$/,
                    "loader": env.prod ? "@ngtools/webpack" : "awesome-typescript-loader",
                    "options": env.prod ? {} : {configFileName: 'src/tsconfig.json'},
                    "exclude": [
                        /\.(spec|e2e)\.ts$/
                    ]
                },
                {
                    test: /\.ts$/,
                    loader: 'angular2-template-loader'
                }
            ]
        },

        "plugins": plugins, // defined above

        "node": {
            "fs": "empty",
            "global": true,
            "crypto": "empty",
            "tls": "empty",
            "net": "empty",
            "process": true,
            "module": false,
            "clearImmediate": false,
            "setImmediate": false
        }
    };
};
