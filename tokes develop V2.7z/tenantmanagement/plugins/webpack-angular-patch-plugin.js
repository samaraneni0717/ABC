/**
 * Created by mckeowr on 3/8/17.
 */
var RawSource = require('webpack-sources').RawSource;

const OriginalSource = require('webpack-sources').OriginalSource;


/**
 * Patches the generated main module with some Angular tweaks to handle teardown memory issues
 * @constructor
 */
class AngularPatchPlugin {
    constructor(options) {
        this.bundleName = options.bundle + '.js';
        this.prefix = options.prefix;
        this.suffix = options.suffix;
        this.portal = options.portal;
    }

    apply(compiler) {
        let bundleFile = this.bundleName;

        compiler.plugin("compilation", (compilation) => {

            compilation.plugin("optimize-chunk-assets", (chunks, callback) => {

                const files = [];
                chunks.forEach((chunk) => files.push.apply(files, chunk.files));
                files.push.apply(files, compilation.additionalChunkAssets);
                files.filter((file) => {
                    return file === this.bundleName;

                }).forEach((file) => {
                    let asset = compilation.assets[bundleFile];
                    console.log("Patching Angular");

                    let JS, map;

                    if(asset.sourceAndMap) {

                        let sourceAndMap = asset.sourceAndMap();
                        map = sourceAndMap.map;
                        let input = sourceAndMap.source;

                        JS = input;
                    } else {
                        JS = compilation.assets[bundleFile].source();
                    }


                    JS = JS.replace(/(BrowserGetTestability\.prototype\.addToWindow = function \(registry\) \{\n)/gi, '$1\t\t//Added via AngularPatchPlugin\n\t\twindow.testabilityRegistry = registry;\n\n');
                    JS = JS.replace(/(return TestabilityRegistry;)/gi, 'TestabilityRegistry.prototype.destroy = function() {this._applications.clear();};$1');

                    // fix for routing in portal
                    if (this.portal) {
                        // change the subscription to destroy itself when navigating away
                        let replacement = `
                        var self = this;
                        this.locationSubscription = (this.location.subscribe(Zone.current.wrap(function(change) {
                            if(PORTAL_BASE_PATH && !window.location.hash.startsWith('#' + PORTAL_BASE_PATH)) {
                                 console.log('Comparing hash (' + window.location.hash + ') to: #' + PORTAL_BASE_PATH);
                                 console.log('\tNavigating away from application. Destroying router and navigating to ' + window.location.hash);
                                 self.dispose();
                                return;
                            }\n`;

                        JS = JS.replace(/this\.locationSubscription = \(this\.location\.subscribe\(Zone\.current\.wrap\(function \(change\) {/gi, replacement);
                    }
                    // apply the patched JS code
                    let newSource;
                    if (map) {
                        newSource = new OriginalSource(JS, map);
                    } else {
                        newSource = new RawSource(JS);
                    }

                    compilation.assets[bundleFile] = newSource;

                });

                callback();
            });
        });

    }
}

module.exports = AngularPatchPlugin;
