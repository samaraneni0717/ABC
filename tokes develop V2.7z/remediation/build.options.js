
// RESOURCE ID pracTransactionAssistant


const API_ROOT = '/taasgateway/api/v1/logging';
const PROXY_URL = 'http://apigateway.dit.taas.oneadp.com'; // <!-- url to actual backend
// For more configuration options that can be specified in this proxyConfig object, see
// https://webpack.js.org/configuration/dev-server/#devserver-proxy
let proxyConfig = {};

// TAAS Web tier rules for local development.  This proxy rule mimic the TAAS routing rules for APIs. 
// the rules are defined at https://confluence.es.ad.adp.com/display/AEPDT/TAAS+Routing+Rules
// Web Tier Rule for TAAS Common (.Net)
proxyConfig['/**/taasgateway/**'] = {
        target: 'http://10.204.253.166:8081/',
        changeOrigin: true,      
        pathRewrite: {'^/taasgateway/' : ''}, //Remove the taasapigateway from the uri.             
        logLevel: 'debug'  //this will print to the console
      };

proxyConfig['/**/taascommon/**'] = {
        target: 'http://commonvip.dit.taas.oneadp.com/',
        changeOrigin: true,      
        pathRewrite: {'^/taascommon/' : ''}, //Remove the commonvip from the uri.             
        logLevel: 'debug',  //this will print to the console
        //headers: {AOID: 'G0JIH4IIV6J9DDKJ', ORGOID:'FFFFFFFFFFFFFFFF', APPID: 'HRIIPortal',sm_serversessionid: 'tMTt5Fj5JRLp4BhEhY467RLaH3E=', sm_transactionid: '0200007f-7e3f-5b116607-4b015940-98a71ffed64f' }
        //headers: {AOID: 'G0JIH4IIV6Jy9053Y', ORGOID:'FFFFFFFFFFFFFFFF',AOID: 'G0JIH4IIV6J9053Y', APPID: 'HRIIPortal',sm_serversessionid: 'RWH5Pe5dxVlPCXOhC7yC15469kM=', sm_transactionid: '0200007f-7e3f-5b116607-4b015940-98a71ffed64f' }
      };    

module.exports = {
      // portal flag turns on portal packaging which excludes zone.js and will use the styles-portal.scss file
  "portal": false,

  // prod flag turns on Angular's enableProdMode()
  "prod": false,
    // this is the public path of the application. If the application is going into a
    // WAR called app.war, your would use
    //  root: '/app/'
    // When you run: npm run start
    //    this will automatically be set to '/' so that the webpack dev server works correctly
    "root": "",

    //v-------- Used when running via npm run start only
    // see the proxyConfig defined above
    "proxy": proxyConfig,

    // the url relative to the portal where the JS files will be loaded from
    // NOTE: the string $$ROLE_PREFIX is a genesis specific placeholder
    // that will automatically resolve to either 'micro' or 'smicro' depending
    // on the users role.
    appPrefix: '/smicro/remediation/1/taas',

    // This must match the selector of your app.component
    // YOU MUST CHANGE THIS TO SOMETHING SPECIFIC
    rootTag: "app-remediation-root",
    
    // used in the mock-server as the base 'dir' for api requests
    "apiRoot": API_ROOT,

    // you need this for IE unless the portal starts including it
    includePromisePolyfill: true,

    // objects on the window that may be overwritten by dependencies in our application
    // There are defaults built into the wrapper such as Highcharts and libphonenumber,
    // but you can add more here
    windowObjectsToCache: [],

    // Some window objects need to still be accessible using just the name, such as: libphonenumber (included by default)
    // Adding other items will make them available as local variables inside the closure that surrounds
    // the application.
    windowObjectsToMakeLocal: []
}
