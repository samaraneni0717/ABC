import { enableProdMode, NgModuleRef, PlatformRef, TestabilityRegistry } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment.dev';

if (environment.production) {
  enableProdMode();
}

// platformBrowserDynamic().bootstrapModule(AppModule)
// .catch(err => console.log(err));

declare var wrapper: any;
declare var window: any;
declare var bootstrapper: any; 
const bootstrapApp = function () {
  console.log('Zone: Ready. Bootstrapping app');

 platformBrowserDynamic().bootstrapModule(AppModule).then((ref: NgModuleRef<AppModule>) => {

    if (environment.prepareForPortal) {

      if (typeof wrapper !== 'undefined') {
        wrapper.setApplicationComponentNode(ref, ref.injector.get(PlatformRef), ref.injector.get(TestabilityRegistry));
      }
    }

  }).catch(err => console.log(err));
};

if (typeof bootstrapper === 'function') {
  bootstrapper(environment.prepareForPortal, bootstrapApp);
} else {
  console.log('No bootstrapper... is this running locally?');
  bootstrapApp();
}
