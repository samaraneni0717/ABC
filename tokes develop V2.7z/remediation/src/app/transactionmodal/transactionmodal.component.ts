import { Component, OnInit, HostBinding, ViewEncapsulation } from '@angular/core';
import { FormsModule, NgForm, FormGroup, FormControl, Validators, Form } from '@angular/forms';
import {
  FormGroupModule, ButtonComponent, FormGroupComponent, FormGroupConfig, FormGroupMessage,
  TableComponent, TableRowClickEvent, TableSortEvent, TableCell, TableHeader, TableRow
} from '@synerg/components';
import { modalAnimation } from '@synerg/components/modal/modal.animations';
import { ActivatedRoute, Router } from '@angular/router';
import { Transaction, initializeTransaction } from '../models/ITransaction';
import { IAdpUserInfo} from '../models/IAdpUserInfo';
import { TransactionlogService } from '../services/transactionlog.service';
import { Location } from '@angular/common';

import { Store } from '@ngrx/store';
import * as fromRoot from '../ngrx/store';
import { Observable } from 'rxjs/Observable';
import { setInterval } from 'timers';
import * as fromACSPermissions from '../ngrx/store/acspermission.store';
import * as util from '../Util/util';


@Component({
  selector: 'app-transactionmodal',
  templateUrl: './transactionmodal.component.html',
  providers: [FormGroupConfig],
  animations: [modalAnimation],
  styleUrls: ['./transactionmodal.component.scss'],
  encapsulation:  ViewEncapsulation.None
})
export class RetryModalComponent implements OnInit {  
  @HostBinding('@modalTransition') modalTransition = 'modal';

  public percentage = 0;
  public progress = 0;

  types = [
    { label: 'Default', value: 'default' },
    { label: 'Success', value: 'success' },
    { label: 'Warning', value: 'warning' },
    { label: 'Error', value: 'error' }
  ];

  sizes = [
    { label: 'Small', value: 'sm' },
    { label: 'Medium', value: 'md' },
    { label: 'Large', value: 'lg' },
    { label: 'Extra Large', value: 'xl' },
    { label: 'Full Screen', value: 'full' }
  ];

  type = 'default';
  size = 'md';
  closeable = true;
  icon = true;
  location = false;
  indexrow = 0;

  isBusy$ = false;
  errorFound$ = '';
  didTransactionSave$ = false;
  didTransactionError$ = false;
  errorMessages$ = '';

  transactiondata$: Observable<Transaction[]>;
  transactionfound$: Observable<Transaction>;
  currenttransaction = initializeTransaction;
  noRetryAvailable = false;

  maskon = true;
  maskinterval: any;
  repeat = 10;

  radius = 54;
  circumference = 2 * Math.PI * this.radius;
  dashoffset: number;

  acsPermissionInfo$: Observable<fromACSPermissions.State>;
  acsUserCanUnmask$ = false;
  usrInfo$: Observable<IAdpUserInfo>;
  
  constructor(private route: ActivatedRoute, private tranlogsvc: TransactionlogService,
    private router: Router, private locationsv: Location, private store: Store<fromRoot.State>) {

    this.transactiondata$ = store.select(fromRoot.getTransactionDisplayData);
    this.acsPermissionInfo$ = store.select(fromRoot.getACSPermissionData);
    this.usrInfo$ = store.select(fromRoot.getUserInfoData);

    this.acsPermissionInfo$.subscribe(acsdata => { if (acsdata) {
      this.acsUserCanUnmask$ = acsdata.acsCanUnmask;
    }
  });


  this.usrInfo$.subscribe(usrdata => { if (usrdata) {
    if (!this.acsUserCanUnmask$) {
        this.acsUserCanUnmask$ = usrdata.OrginalOrgOid === util.adpUserOrgOid;
      }
    }
  });

}

  ngOnInit() {

    // Must use parent in order to retrieve query parms
    const parmsob = this.route.snapshot.parent.paramMap.get('queryParams');

    const parmsin = JSON.parse(JSON.stringify(parmsob));

    if (!parmsin) {
       return;
    }

    // set desired modal settings
    this.indexrow = parmsin.idx;
    this.type = parmsin.type;
    this.size = parmsin.size;
    this.closeable = parmsin.closeable === 'true';
    this.icon = parmsin.icon === 'true';

    // Get the single observable transaction being analyzed
    this.transactionfound$ =
      this.store.select(fromRoot.getTransactionDisplayData).map(storedTransactions => storedTransactions[this.indexrow]);

    // Store transaction as is.
    this.transactiondata$.map(storedTransactions =>
      storedTransactions[this.indexrow]).subscribe(item => {
      this.currenttransaction = item;

      if (this.currenttransaction) {
              if (this.currenttransaction.STATUS.toUpperCase() === 'ERROR' || this.currenttransaction.PAYLOAD == null) {
                        this.noRetryAvailable = true;
      }

    }
    });

  }

  onClose() {
    // console.log('close!');
  }

  toggleBusy(busy: boolean) {
    this.isBusy$ = busy;
  }

  postRetry() {
    try {
      this.toggleBusy(true);

      // console.log('Transaction value after mask before send ' + this.currenttransaction.PAYLOAD);

      this.tranlogsvc.postManualRetryForTransaction(this.currenttransaction).subscribe(data => {
        this.didTransactionSave$ = true;

        this.toggleBusy(false);
        return;
      },
        error => {
        this.errorFound$ = error.message;
          this.didTransactionError$ = true;
          console.log('Error Posting Manual Retry ' + error.message);
          this.toggleBusy(false);
        }
      );
    } catch (error) {
      this.didTransactionError$ = true;
    }

  }

  finishedPostRetry(issuccess: boolean) {
    this.didTransactionSave$ = issuccess;
    this.didTransactionError$ = issuccess;
  }

  toggleMask() {
    console.log('Maskon Toggle = ' + this.maskon);
    const that = this;
    if (!this.maskon) {
      return;
    }
    this.maskon = !this.maskon;
    console.log('Toggle');

    setTimeout(() => {this.maskon = true; }, 10000);

    this.startprogress(that);
    }


  startprogress(obj: any) {
    let repeatnum = 10;
    updatePercentage();
    function updatePercentage() {
        obj.percentage += 10;
        if (--repeatnum >= 0) {
          setTimeout(updatePercentage, 1000);
          return;
        }
        if (obj.percentage >= 90) {
          console.log('Over 90 = ' + obj.percentage);
        obj.percentage = 0;

      }
    }

}

}
