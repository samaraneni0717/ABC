import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ModalModule } from '@synerg/components/modal/modal.module';
import { modalAnimation } from '@synerg/components/modal/modal.animations';
import { ButtonModule } from '@synerg/components/button';
import { RadioModule } from '@synerg/components/radio';
import { CheckboxModule } from '@synerg/components/checkbox';
import { RetryModalComponent } from './transactionmodal.component';
import { FormGroupModule, FormGroupConfig, AlertModule, BusyIndicatorModule } from '@synerg/components';
import { TextareaModule } from '@synerg/components/textarea';
import { ProgressBarModule } from '@synerg/components/progress-bar';
import { PayloadMask } from '../pipes/PayloadMask';
import { BlockCopyPasteDirective } from '../Util/blockcopypaste.directive';


  @NgModule({
    imports: [
      CommonModule,
      FormsModule,
      FormGroupModule,
      ModalModule,
      RadioModule,
      CheckboxModule,
      ButtonModule,
      TextareaModule,
      AlertModule,
      BusyIndicatorModule,
      ProgressBarModule
    ],
    declarations: [RetryModalComponent, PayloadMask, BlockCopyPasteDirective],
    exports: [RetryModalComponent, PayloadMask],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
  })
  export class RetryModalModule { }
