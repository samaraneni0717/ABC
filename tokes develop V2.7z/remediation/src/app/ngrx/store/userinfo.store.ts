
/*
 * This is an example of an ngrx/store that serves as an example of how to use it
 * In this case, its state simply consists of a single boolean, but more complex states
 * are handled exactly the same way.
 *
 */

import { Action } from '@ngrx/store';
import { IAdpUserInfo, initialAdpUserInfo } from '../../models/IAdpUserInfo';

// These are the actions that this store supports
// Note that the constant's value is prefixed with the store name. This isn't mandatory in this case, but when
// you have multiple stores that have simlar action names such as SAVE, you will want to distinguish them
export const USRINFO_ACTIONS = {
    REQUEST_USRINFO: 'USRINFO:LOAD'
};

// Define the interface for the state that this store manages
export interface State {
    usrInfo: IAdpUserInfo;
}

// This is the initial state
const initialState: State = {
    usrInfo: initialAdpUserInfo
};

function storeUsrInfo(state: State, action: any) {
    const currentInfo = <IAdpUserInfo>action.usrinfo;
    return Object.assign({}, state, {
        usrInfo: currentInfo
    });
}

function deepCopyObj(obj: any) {
    return JSON.parse(JSON.stringify(obj));
}


export function reducer(state = initialState, action: Action) {
  switch (action.type) {
    case USRINFO_ACTIONS.REQUEST_USRINFO:
        return storeUsrInfo(state, action);

    default:
      return state;
  }
}

// Return any helper functions that you would like to expose to access parts of your state
// For example, if your state maintained a collection of items and properties you want to filter by,
// you may export a function to return the whole list and a function that returns the filtered list
export const getUserInfoData = ((state: State) => state.usrInfo);
