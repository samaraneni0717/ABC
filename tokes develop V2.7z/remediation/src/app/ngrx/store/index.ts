/**
 * This is the main file that will aggregate your stores
 * Make sure you have installed the required dependencies
 *  npm install --save @ngrx/{store} reselect ngrx-store-freeze
 */

// Import each of your stores using the convention:
//      import * as from[STORE_NAME] from './STORE_NAME.store';
// NOTE: this is the "old way" from ngrx 2. 
// This could be done as a "Feature" see https://github.com/ngrx/platform/blob/master/docs/store/api.md#feature-module-state-composition

import * as fromUI from './ui.store';
import * as fromTransaction from './transaction.store';
import * as fromUserInfo from './userinfo.store';
import * as fromACSPermissions from './acspermission.store';

import { ActionReducer, ActionReducerMap, combineReducers, compose, MetaReducer } from '@ngrx/store';
import { environment } from '../../../environments/environment.dev';
import { storeFreeze } from 'ngrx-store-freeze';
import { createSelector } from 'reselect';

// Aggregate all of the individual states into one main state
// this State should have a property for each of you child states
export interface State {
    ui: fromUI.State;
    transaction: fromTransaction.State;
    userinfo: fromUserInfo.State;
    acsinfo: fromACSPermissions.State;
}

// Aggregate all of the reducers in a similar way
export const reducers: ActionReducerMap<State> = {
    ui: fromUI.reducer, // <--this could be done as a "Feature" see https://github.com/ngrx/platform/blob/master/docs/store/
    transaction: fromTransaction.reducer,
    userinfo: fromUserInfo.reducer,
    acsinfo: fromACSPermissions.reducer
    // api.md#feature-module-state-composition
};

// Adding the storeFreeze is useful in development because it will cause an exception to be thrown
// if you accidentally mutate the state
export const metaReducers: MetaReducer<State>[] = !environment.production
? [storeFreeze]
: [];

// We will expose a function for getting each state out of our aggregate state
export const getUIState = (state: State) => state.ui;
export const getTransDataState = (state: State) =>  state.transaction;
export const getCurrentState = (state: State) => state;
export const getUserInfoState = (state: State) => state.userinfo;
export const getAcsInfoState = (state: State) => state.acsinfo;

// We will expose the selectors from each of the states by creating a nested selector
// using the functions exposed in each store.
export const getIsLoading = createSelector(getUIState, fromUI.isLoading);
export const getTransactionDisplayData =   createSelector(getTransDataState, fromTransaction.getTransactionDisplayData);
export const getAllTransactionSummaryInfo = createSelector(getTransDataState, fromTransaction.getTransactionSummaryData);
export const getUserInfoData = createSelector(getUserInfoState, fromUserInfo.getUserInfoData);
export const getACSPermissionData = createSelector(getAcsInfoState, fromACSPermissions.getACSPermissionData);


