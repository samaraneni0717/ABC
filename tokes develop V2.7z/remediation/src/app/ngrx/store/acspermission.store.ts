
/*
 * This is an example of an ngrx/store that serves as an example of how to use it
 * In this case, its state simply consists of a single boolean, but more complex states
 * are handled exactly the same way.
 *
 */

import { Action } from '@ngrx/store';
import { IACSPermissions, initialACSPermissions } from '../../models/IACSPermissions';

// These are the actions that this store supports
// Note that the constant's value is prefixed with the store name. This isn't mandatory in this case, but when
// you have multiple stores that have simlar action names such as SAVE, you will want to distinguish them
export const ACSINFO_ACTIONS = {
    REQUEST_ACSINFO: 'ACSINFO:LOAD'
};

// Define the interface for the state that this store manages
export interface State {
    acsPermissions: IACSPermissions;
    acsCanUnmask: boolean;
}

// This is the initial state
const initialState: State = {
    acsPermissions: initialACSPermissions,
    acsCanUnmask: false
};

function storeAcsInfo(state: State, action: any) {
    const currentAcsInfo = <IACSPermissions>action.acsinfo;
    const copyObj = deepCopyObj(currentAcsInfo);
    const canUnmask = getUnmaskResource(copyObj);
    return Object.assign({}, state, {
        acsPermissions: currentAcsInfo,
        acsCanUnmask: canUnmask
    });
}

function getUnmaskResource(obj: any) {
    if (obj.resources) {
        const jsonACS = JSON.stringify(obj.resources).includes('"resourceId":"pracUnmaskSensitivePersonalInformation"');
        return jsonACS;
    }

    return false;
}

function deepCopyObj(obj: any) {
    return JSON.parse(JSON.stringify(obj));
}


export function reducer(state = initialState, action: Action) {
  switch (action.type) {
    case ACSINFO_ACTIONS.REQUEST_ACSINFO:
        return storeAcsInfo(state, action);

    default:
      return state;
  }
}

// Return any helper functions that you would like to expose to access parts of your state
// For example, if your state maintained a collection of items and properties you want to filter by,
// you may export a function to return the whole list and a function that returns the filtered list
export const getACSPermissionData = ((state: State) => state);
export const getAcsCanUnmask = ((state: State) => state.acsCanUnmask);
