
/*
 * This is an example of an ngrx/store that serves as an example of how to use it
 * In this case, its state simply consists of a single boolean, but more complex states
 * are handled exactly the same way.
 *
 */

import { Action } from '@ngrx/store';
import { Transaction, initializeTransaction } from '../../models/ITransaction';
import { TransactionLogSummary, initializeTransLogSummary} from '../../models/TransactionLogSummary';

// These are the actions that this store supports
// Note that the constant's value is prefixed with the store name. This isn't mandatory in this case, but when
// you have multiple stores that have simlar action names such as SAVE, you will want to distinguish them
export const TRANSACTION_ACTIONS = {
  REQUEST_TRANSACTIONS: 'TRANSACTIONS:LOAD',
  REQUEST_NEXT_TRANSACTIONS: 'TRANSACTION:NEXT',
  REQUEST_TRANSACTIONS_NONE: 'TRANSACTIONS:NONE',
  REQUEST_SORT: 'TRANSACTIONS:SORT'
};

// Define the interface for the state that this store manages
export interface State {
  isLoading: boolean;
  transactionData: Transaction[];
  displayTransactionData: Transaction[];
  transactionLogSummary: TransactionLogSummary;
}

// This is the initial state
const initialState: State = {
  isLoading: false,
  transactionData: [],
  displayTransactionData: [],
  transactionLogSummary: initializeTransLogSummary
};

function storeTransactions(state: State, action: any) {
  if (action.transactionData) {
    const currentTransactions = <Transaction[]>action.transactionData;
    // console.log('Number of currentTransactions = ' + currentTransactions.length);
    const copyObj = deepCopyObj(currentTransactions);
    const tranlogsummary = calculateAggregates(copyObj);
    return Object.assign({}, state, {
        transactionData: currentTransactions,
        displayTransactionData:  copyObj.slice(0, 15),
        transactionLogSummary: tranlogsummary
    });
  }

  return Object.assign({}, state);
}

function sortTransactions(state: State, action: any) {

  if (action.colname && action.order) {
    const currentTransactions = <Transaction[]>state.transactionData;

    const copyObj = deepCopyObj(currentTransactions);
    copyObj.sort(compareValues(action.colname, action.order));
    const tranlogsummary = state.transactionLogSummary;
    return Object.assign({}, state, {
        transactionData: copyObj,
        displayTransactionData:  copyObj.slice(0, 15),
        transactionLogSummary: tranlogsummary
    });
  }
}

function compareValues(key, order = 'asc') {
  return function(a, b) {
    if (!a.hasOwnProperty(key) ||
       !b.hasOwnProperty(key)) {
        return 0;      }

    const varA = (typeof a[key] === 'string') ? a[key].toUpperCase() : a[key];
    const varB = (typeof b[key] === 'string') ? b[key].toUpperCase() : b[key];

    let comparison = 0;
    if (varA > varB) {
      comparison = 1;
    } else if (varA < varB) {
      comparison = -1;
    }
    return (
      (order === 'desc') ? (comparison * -1) : comparison
    );
  };
}

function scrollNext(state: State, action: any) {
    const currentTransactionData = deepCopyObj(state.transactionData);
    return Object.assign({}, state, {
        displayTransactionData: currentTransactionData.slice(0, state.displayTransactionData.length + action.transactionsPerPage)
    });
}


function deepCopyObj(obj: any) {
    return JSON.parse(JSON.stringify(obj));
}

function calculateAggregates(allcurrenttransactions: Transaction[]): TransactionLogSummary {
    const statusArr = allcurrenttransactions.map(val => ( {STATUS: val.STATUS }) );
    const newStatArr = JSON.stringify(statusArr);

    const countedStatus = function (statusTot, statusType){
      if (statusType.STATUS in statusTot) {
        statusTot[statusType.STATUS]++;
      } else {
        statusTot[statusType.STATUS] = 1;
      }

      return statusTot;
    };

    const translogsummary = {TotalRecords: 0, TotalCompleted: 0, TotalErrors: 0, TotalCompwErrors: 0,
        TotalReceived: 0, TotalAutoRetries: 0, TotalManualRetries: 0, TotalEIMCompleted: 0, TotalEIMRunning: 0, TotalOther: 0 };
    const statArray = JSON.parse(newStatArr);
    const statusTotals = statArray.reduce(countedStatus, {});

    const knownKeys = ['RECEIVED', 'COMPLETED', 'ERROR'];

    for (const key of Object.keys(statusTotals)) {
      if (!(knownKeys.indexOf(key.toUpperCase()))) {
        translogsummary.TotalOther = translogsummary.TotalOther + statusTotals[key];
        continue;
      }

      if (key.toUpperCase() === 'RECEIVED') {
        translogsummary.TotalReceived = translogsummary.TotalReceived + statusTotals[key];
      }

      if (key.toUpperCase() === 'COMPLETED') {
        translogsummary.TotalCompleted = translogsummary.TotalCompleted + statusTotals[key];
      }

      if (key.toUpperCase() === 'ERROR') {
        translogsummary.TotalErrors = translogsummary.TotalErrors + statusTotals[key];
      }

    }

    translogsummary.TotalRecords = allcurrenttransactions.length;

    return translogsummary;
  }






export function reducer(state = initialState, action: Action) {
  switch (action.type) {
    case TRANSACTION_ACTIONS.REQUEST_TRANSACTIONS:
        return storeTransactions(state, action);

    case TRANSACTION_ACTIONS.REQUEST_NEXT_TRANSACTIONS:
        return scrollNext(state, action);

    case TRANSACTION_ACTIONS.REQUEST_SORT:
        return sortTransactions(state, action);

    case TRANSACTION_ACTIONS.REQUEST_TRANSACTIONS_NONE:
        return initialState;

    default:
      return state;
  }
};

// Return any helper functions that you would like to expose to access parts of your state
// For example, if your state maintained a collection of items and properties you want to filter by,
// you may export a function to return the whole list and a function that returns the filtered list

export const isLoading = ((state: State) => state.isLoading);
export const getTransactionDisplayData = ((state: State) => state.displayTransactionData);
export const getTransactionSummaryData = ((state: State) => state.transactionLogSummary);
