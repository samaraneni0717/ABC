/**
 * This is also stuck in its own module just for the demo. It doesn't
 * have to go in its own directory.
 * In fact, the StoreModule.forRoot() is usually done in the
 * AppModule's imports
 */
import {NgModule, ModuleWithProviders} from '@angular/core';
import { CommonModule } from '@angular/common';

import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './store/index';


@NgModule({
  imports: [
    CommonModule,
    StoreModule.forRoot(reducers, {metaReducers}),
  ],
})
export class NgrxModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: NgrxModule,
      providers: [

      ]
    };
  }
}
