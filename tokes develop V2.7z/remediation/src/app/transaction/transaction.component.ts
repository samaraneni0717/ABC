import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormsModule, NgForm, FormGroup, FormControl, Validators, Form } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroupModule, ButtonComponent, FormGroupComponent, FormGroupConfig, FormGroupMessage,
  TableComponent, TableRowClickEvent, TableSortEvent, TableCell, TableHeader, TableRow,
  PopoverTrigger, PopoverTransition } from '@synerg/components';

import { Transaction, initializeTransaction } from '../models/ITransaction';
import * as util from '../Util/util';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';
import { TransactionLogSummary } from '../models/TransactionLogSummary';

import { RetryModalComponent} from '../transactionmodal/transactionmodal.component';
import {TransactionDispatcher} from '../services/transactiondispatcher.service';

import { Store } from '@ngrx/store';
import * as fromRoot from '../ngrx/store';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/distinctUntilChanged';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [FormGroupConfig],
  styleUrls: ['./transaction.component.scss']
})
export class TransactionComponent implements OnInit {


  tranlogheaders = [{'label': 'Date Created', 'sort': true, 'order': 'none', 'dataname': 'CREATIONDATE'},
  {'label': 'STATUS', 'sort': true, 'order': 'none', 'dataname': 'STATUS'},
  {'label': 'SOR', 'sort': false, 'order': 'none', 'dataname': 'SOR'},
  {'label': 'PROCESS NAME', 'sort': true, 'order': 'none', 'dataname': 'PROCESSNAME'},
  {'label': 'Transaction ID', 'sort': false, 'order': 'none', 'dataname': 'TXID'}

  // {'label': 'REFERENCEID', 'sort': false}
 ];

  translogdata$: Observable<Transaction[]>;
  translogsummarydata$: Observable<TransactionLogSummary>;

  retTypeList = util.retTypeList;

  selectedretType = '';

  selectedRow = 0;

  isBusy$: Observable<boolean>;

  statusNotComplete = true;

  hoverdata = '';
  hoverpayload = false;

  hovertitle = 'Result';
  place = 'Top';
  autoplace = true;
  trigger = 'hover';
  transition = 'fade';

  filterFormModel: SearchParams = initializeSearchParms;
  errorMessages: FormGroupMessage[] = [
    { errorType: 'pattern', errorMessage: '{fieldName} must be MM/DD/YYYY' }
  ];

  constructor(private router: Router, private transactionDispatcher: TransactionDispatcher,
    private store: Store<fromRoot.State>) {

    this.translogdata$ = store.select(fromRoot.getTransactionDisplayData);
    this.translogsummarydata$ = store.select(fromRoot.getAllTransactionSummaryInfo);
    this.isBusy$ = store.select(fromRoot.getIsLoading);
  }

  ngOnInit() {

    this.selectedretType = util.retTypeList[1];

    window.scrollTo(0, 0);
  }

  isSelected(idx: number): boolean {
    if (idx === this.selectedRow) {
      return true;
    }
    return false;
  }

  onScroll(): void {
    this.transactionDispatcher.nextTransactions();
  }

  searchTransLog(evt: any) {
    this.transactionDispatcher.getTransactionLog(this.filterFormModel);
  }

  setRetType(evt: any) {
    this.filterFormModel.getlastrecord = util.retTypeList.indexOf(evt);
  }

  setSelectedRow(idx: number, selectedStatus: string) {
    this.selectedRow = idx;

    this.statusNotComplete = false;
    if(selectedStatus) {
          if ( selectedStatus.toUpperCase() === 'COMPLETED' || selectedStatus.toUpperCase() === 'EIM-COMPLETED'  ) {
                   this.statusNotComplete = true; }
    }
  }

  openRetryTransaction() {

    this.router.navigate([{queryParams: {idx: this.selectedRow, closeable: 'true', size: 'full'},
    skipLocationChange: true}, {outlets: { retrymodal: ['retry-modal'] }}]);
  }

  showRowData(index: any, data: string) {
    this.hoverpayload = false;

    if (data) {
      this.hoverdata = data;
      if ( data.trim().length > 0 ) {
        this.hoverpayload = true;
      }
    }
  }

  sort(index: number, colname: string, headers: any) {
    const head = headers[index];
    let order = 'none';

    if (head.order === 'desc') {
      order = 'asc';
  }
    if (head.order === 'none' || head.order === 'asc') {
        order = 'desc';
    }

    head.order = order;

    this.transactionDispatcher.sortTransactions(colname, head.order);
  }
}
