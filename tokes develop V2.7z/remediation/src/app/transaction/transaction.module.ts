import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes} from '@angular/router';

import { TransactionComponent } from './transaction.component';
import { RetryModalComponent} from '../transactionmodal/transactionmodal.component';
import { RetryModalModule } from '../transactionmodal/transactionmodal.module';
import { DashboardModule } from '../dashboard/dashboard.module';

import { DataCoinModule} from '@synerg/components/data-coin';

import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { RouterModule} from '@angular/router';
import {
    ButtonModule, BusyIndicatorModule, MastheadModule, SecondaryNavModule, TableModule, LeftNavModule,
    PopoverModule, TextboxModule, DatePickerModule, FormGroupModule, FormGroupConfig, DateFormatService,
    DropdownListModule, SlideinModule, ModalModule, DualSelectModule, RadioModule, TimePickerModule,
    DropdownListComponent, ToggleSwitchModule, IconComponent, IconModule, CheckboxModule, AlertModule,
    PopoverComponent
} from '@synerg/components';

import { StoreModule } from '@ngrx/store';

@NgModule({
    imports: [
        CommonModule,
        ButtonModule,
        BusyIndicatorModule,
        FormsModule,
        BrowserModule,
        FormGroupModule,
        TableModule,
        InfiniteScrollModule,
        DatePickerModule,
        TimePickerModule,
        DropdownListModule,
        CheckboxModule,
        RadioModule,
        RetryModalModule,
        RouterModule,
        DashboardModule,
        DataCoinModule,
        PopoverModule
    ],
    declarations: [
        TransactionComponent
    ],
    exports: [
        TransactionComponent, InfiniteScrollModule
    ],

    providers: [DateFormatService, FormGroupConfig],

    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TransactionModule {

}
