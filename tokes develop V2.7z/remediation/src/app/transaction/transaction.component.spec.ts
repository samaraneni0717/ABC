import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AppModule } from '../app.module';


import { Transaction, initializeTransaction } from '../models/ITransaction';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';
import { TransactionLogSummary } from '../models/TransactionLogSummary';

import { TransactionComponent } from './transaction.component';
import { TransactionModule } from './transaction.module';
import { TransactionDispatcher } from '../services/transactiondispatcher.service';
import { TransactionlogService } from '../services/transactionlog.service';
import { TransactionMockService } from '../services/transaction-mock.service';
import * as mockdata from '../services/transaction-mockdata';


describe('Transaction List Component', () => {

    let comp: TransactionComponent;
    let fixture: ComponentFixture<TransactionComponent>;
    let de: DebugElement;
    let el: HTMLElement;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [
          AppModule,
          TransactionModule
        ],
        providers: [
          { provide: TransactionlogService, useClass: TransactionMockService },
        ]
      });
    });

    beforeEach(() => {
      fixture = TestBed.createComponent(TransactionComponent);
      comp = fixture.debugElement.componentInstance;
      fixture.detectChanges();
      console.log('Before Each run TransactionComponent......');
    });


    it('should create TransactionComponent component', function(done) {
      console.log('TransactionComponent Test 1......');
      fixture.whenStable().then(() => {
        expect(comp.filterFormModel).toBeDefined();
      });
      done();
    });

    it('should create TransactionComponent and run getTransactions', function(done) {
      console.log('TransactionComponent Test 2......');
      fixture.whenStable().then(() => {
        comp.filterFormModel = initializeSearchParms;
        comp.filterFormModel.orgoid = 'G3BQ0EKGP5Q2MC2V';
        comp.filterFormModel.startdate = '04-APR-2018';
        comp.filterFormModel.enddate = '04-10-2018';
        comp.searchTransLog('TestSearch');

        fixture.detectChanges();
        expect(comp.translogdata$).toBeDefined();
        done();
      });
 
    });

    it('should create TransactionComponent run getTransactions and select Transaction', function(done) {
      console.log('TransactionComponent Test 3......');
      fixture.whenStable().then(() => {
        comp.filterFormModel = initializeSearchParms;
        comp.filterFormModel.orgoid = 'G3BQ0EKGP5Q2MC2V'
        comp.filterFormModel.startdate = '04-APR-2018';
        comp.filterFormModel.enddate = '04-10-2018';
        comp.searchTransLog('TestSearch');
        fixture.detectChanges();
        comp.selectedRow = 1;
        const listSearch: DebugElement = fixture.debugElement.query(By.css('tr'));
        listSearch.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(comp.translogdata$).toBeDefined();
        done();
      });

    });

    it('should create TransactionComponent and set Query type ', function(done) {
      console.log('TransactionComponent Test 4......');
      fixture.whenStable().then(() => {
        comp.setRetType('All');
        fixture.detectChanges();
        expect(comp.translogdata$).toBeDefined();
       done();
      });

    });

    it('should create TransactionComponent and set selectedRow ', function(done) {
      console.log('TransactionComponent Test 5......');
      fixture.whenStable().then(() => {
        const trandata = mockdata[2];
        comp.setSelectedRow(2, trandata);
        fixture.detectChanges();
        expect(comp.statusNotComplete).toBe(false);
       done();
      });

    });

    it('should create TransactionComponent and set selectedRow and Click Retry ', function(done) {
      console.log('TransactionComponent Test 6......');

      fixture.whenStable().then(() => {
        comp.filterFormModel = initializeSearchParms;
        comp.filterFormModel.orgoid = 'G3BQ0EKGP5Q2MC2V'
        comp.filterFormModel.startdate = '04-APR-2018';
        comp.filterFormModel.enddate = '04-10-2018';
        comp.searchTransLog('TestSearch');
        fixture.detectChanges();
        comp.selectedRow = 2;
        const listSearch: DebugElement = fixture.debugElement.query(By.css('tr'));
        listSearch.triggerEventHandler('click', null);
        const retrybtn: DebugElement = fixture.debugElement.query(By.css('#retrybtn'));
        // retrybtn.triggerEventHandler('click', null);
        fixture.detectChanges();
        expect(comp.translogdata$).toBeDefined();
        done();
      });

    });

});
