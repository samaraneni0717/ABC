import { Pipe, PipeTransform } from '@angular/core';
import { PasswordStrengthIndicatorComponent } from '@synerg/components';

@Pipe({name: 'maskpayload'})
export class PayloadMask implements PipeTransform {

  maskval = '*****';

  transform(value: string, mask: boolean): string {

    if (!mask ) {
      return value;
    }

    let payloadObj = '';
    try {
       payloadObj = JSON.parse(value);
    } catch (e) {
      payloadObj = value;
    }

  const replacedPayload = JSON.stringify(payloadObj, this.replaceJSONValues);

  return replacedPayload;
  }

  replaceJSONValues(key, value) {

    if (['ASSOCIATEOID', 'AOID', 'ORGOID', 'SSN', 'SOCIAL SECURITY NUMBER', 'BIRTHDATE', 'ADDRESS',
     'LEGALADDRESS', 'GOVERNMENTIDS', 'HOMEWORKLOCATION', 'OTHERPERSONALADDRESSES', 'LEGALNAME', 'SSN',
     'SOCIAL SECURITY NUMBER', 'TELEPHONE NUMBER', 'HOME TELEPHONE NUMBER', 'CELL PHONE',
     'HOMEORGANIZATIONALUNITS', 'PAYGRADEPAYRANGE', 'PAYRATE', 'RATE', 'RATE1', 
     'PAYGRADEPAYRANGE', 'PAYCODE', 'PAYROLLGROUPCODE', 'PAYROLLFILENUMBER', 'FILENUMBER',
     'PAYROLLREGIONCODE', 'REGIONCODE', 'SALARY', 'SALARIED', 'DOB', 'DATEOFBIRTH', 'DATE OF BIRTH', 'PAYGRADECODE',
     'AGE', 'PAYROLLREGIONCODE', 'MONTHLYRATEAMOUNT', 'HOURLYRATEAMOUNT', 'PAYCYCLECODE',
     'STANDARDPAYPERIODHOURS', 'WORKERID', 'payScaleCode'].indexOf(key.toUpperCase()) > -1) {
      value = '*****';
    }

    return value;
  }

 }
