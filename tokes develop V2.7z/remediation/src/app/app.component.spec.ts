import { PlatformLocation } from '@angular/common';
import { ButtonModule } from '@synerg/components';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';
import { AppComponent} from './app.component';
import { DashboardComponent} from '../app/dashboard/dashboard.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';

describe('AppComponent', () => {
  let router;
  let mockPlatformLocation;
  beforeEach(function(done) {
    mockPlatformLocation = jasmine.createSpyObj('PlatformLocation', ['onDestroy']);
    TestBed.configureTestingModule({
      imports: [
        ButtonModule,
        RouterTestingModule.withRoutes([
          { path: 'remediationdashboard', redirectTo: '/remediationdashboard', pathMatch: 'full' }
        ])
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        {provide: PlatformLocation, useValue: mockPlatformLocation}
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents()
      .then(() => {
        router = TestBed.get(Router);
      });
      done();
  });

  it('should create the app', function(done) {
    const fixture = TestBed.createComponent(AppComponent);
    router.initialNavigation();
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
    done();
  });

  it('should have as title Blank', function(done) {
    const fixture = TestBed.createComponent(AppComponent);
    router.initialNavigation();
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('');
    done();
  });

  it('should render title in a h1 tag', function(done) {
    const fixture = TestBed.createComponent(AppComponent);
    router.initialNavigation();
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('');
    done();
  });
});
