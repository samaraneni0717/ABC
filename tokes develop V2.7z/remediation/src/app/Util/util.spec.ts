import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as util from '../Util/util';

import { AppModule } from '../app.module';

describe('Util', () => {

    let de: DebugElement;
    let el: HTMLElement;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [
          AppModule
        ],
        providers: [        ]
      });
    });

    beforeEach(() => {
      console.log('Before Each run Utils......');
    });


it('should execute and test Util', function(done) {
    console.log('Util Test 1......');
    const dateval = util.convertDateToDDMMMYYYY('04/05/2018');
    console.log('Dateval = ' + dateval);
    expect(dateval).toBe('05-Apr-2018');

    done();
  });

  it('should execute and test Util fromatdate', function(done) {
    console.log('Util Test 2......');
    const parms = util.initialDateSearch();
    console.log('Dateval = ' + JSON.stringify(parms));
    expect(parms).toBeDefined();

    done();
  });
});
