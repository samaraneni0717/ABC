
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';

export const retTypeList = ['All', 'Last only'];
export const adpUserOrgOid ='FFFFFFFFFFFFFFFF';

export function convertDateToDDMMMYYYY(dateval: string): string {
    const splitDates = new Date(dateval).toDateString().split(' ');
    const newDate = splitDates[2] + '-' + splitDates[1] + '-' + splitDates[3];

    return newDate;
}

export function initialDateSearch(): SearchParams {
        const srchParms: SearchParams = initializeSearchParms;

        const enddate = new Date();
        const begindate = enddate;
        const hrend = enddate.toLocaleTimeString('en-US', {hour: 'numeric', minute: 'numeric', hour12: true }).replace(/[^ -~]/g, '');
        begindate.setHours(begindate.getHours() - 3 );

        const beginmonth = begindate.getMonth() + 1;
        const beginday = begindate.getDate();
        const beginyear = begindate.getFullYear();
        const endday = enddate.getDate();
        const endmonth = enddate.getMonth() + 1;
        const endyear = enddate.getFullYear();

        const hrbegin = begindate.toLocaleTimeString('en-US', {hour: 'numeric', minute: 'numeric', hour12: true }).replace(/[^ -~]/g, '');

        const stdt = beginmonth + '/' + beginday + '/' + beginyear;
        const enddt = endmonth + '/' + endday + '/' + endyear;
        // console.log('stdt = ' + stdt + ' enddt = ' + enddt + 'Hrnow = ' + hrend, + ' nowday = ' + nowday);

        srchParms.startdate = stdt;
        srchParms.enddate = enddt;
        srchParms.starttime = hrbegin;
        srchParms.endtime = hrend;

    return srchParms;
}


