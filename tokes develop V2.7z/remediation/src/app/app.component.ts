import { Router } from '@angular/router';
/**
 * This is the base component of your application. It shows a basic example of how to use ngrx for
 * state management in your application. There is much more that you can do with it that this simple
 * example. See the official sample app at: https://github.com/ngrx/example-app
 *
 */
import { Component, OnDestroy, ViewEncapsulation } from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';

@Component({
  selector: 'app-remediation-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy {
  title = '';

  constructor(private platformLocation: PlatformLocation, private router: Router) {

  }

  ngOnDestroy() {
    // console.log('destroying AppComponent');
    this.router.dispose();
    (<BetterPlatformBrowserLocationService> this.platformLocation).onDestroy();
  }

}
