import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { APP_BASE_HREF, PlatformLocation } from '@angular/common';

import { AppComponent} from './app.component';
import { RouterModule, Route, Routes } from '@angular/router';

import { API_PREFIX } from './services/api-url.prefix';

import { HttpClientModule } from '@angular/common/http';

/*NGRX_DEMO:*/
import { NgrxModule } from '../app/ngrx/ngrx.module';

import { ButtonModule } from '@synerg/components/button';
import { SecondaryNavModule } from '@synerg/components/secondary-nav';
import { BetterPlatformBrowserLocationService } from './better-platform-location.service';

import { TransactionComponent} from '../app/transaction/transaction.component';
import { TransactionModule } from '../app/transaction/transaction.module';
import { TransactionlogService } from '../app/services/transactionlog.service';
import { RetryModalComponent} from '../app/transactionmodal/transactionmodal.component';
import { RetryModalModule } from '../app/transactionmodal/transactionmodal.module';

import { ApiUrlService } from './services/api-url.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TransactionDispatcher } from './services/transactiondispatcher.service';
declare var PORTAL_BASE_PATH: string;

/* Routing demo */
const routes: Route[] = [
    {path: 'People_ttd_pracTransactionAssistant', redirectTo: '/pracTransactionAssistant', pathMatch: 'full' },
    {path: 'transaction', component: TransactionComponent},
    {path: 'retrymodal', component: RetryModalComponent, outlet: 'retrymodal'},
    {path: 'retry-modal', component: RetryModalComponent, outlet: 'retrymodal'},
    {path: 'pracTransactionAssistant', component: DashboardComponent},
    {path: '', redirectTo: '/pracTransactionAssistant', pathMatch: 'full'}

    // {path: 'transaction', redirectTo: '/transaction', pathMatch: 'full'}
];

const routemodal: Routes = [{
    path: 'transaction',
    component: TransactionComponent,
    children: [
      {
        path: 'retry-modal',
        outlet: 'retrymodal',
        component: RetryModalComponent
      }
    ]
  }];

export function getBaseLocation() {
    const PREFIX_PARTS_COUNT = 1;
    const paths: string[] = location.hash.split('/');
    // trim off the #
    paths.shift();
    // the first two parts of the hash are from the portal. Those are effectively
    // the base path of this app
    paths.length = PREFIX_PARTS_COUNT;
    const pathParts: string[] = [];
    for (let i = 0; i < PREFIX_PARTS_COUNT; i++) {
        if (paths[i]) {
            pathParts.push(paths[i]);
        } else {
            pathParts.push('x'); // pad the base path
        }
    }

    const basePath = '/' + pathParts.join('/') + '/';

    console.log('Base path locked in as: ' + basePath);
    // we need to set our global variable so the router will
    // know when we are navigating away from the application
    try {
        PORTAL_BASE_PATH = basePath;
    } catch (e) {
        // this will fail when running locally
    }
    return basePath;
}

@NgModule({
    declarations: [
        AppComponent
    ],    imports: [
        BrowserAnimationsModule,
        BrowserModule,
        ButtonModule,
        SecondaryNavModule,
        TransactionModule,
        HttpClientModule,
        RetryModalModule,
        // /*NGRX_DEMO:*/
        // For the purposes of the demo, the NgRX stuff is put in the
        // ngrx folder. That is just to make it easier for this demo. It doesn't
        // have to go in a special folder
        NgrxModule.forRoot(),
        // end ngrx
        // For routing demo
        RouterModule.forRoot(routes, {useHash: true}),
        RouterModule.forChild(routemodal)

    ],
    providers: [
        {
            provide: APP_BASE_HREF,
            useFactory: getBaseLocation
        },
        ApiUrlService,
        // For portal, you will need this in order to avoid memory leaks
        {provide: PlatformLocation, useClass: BetterPlatformBrowserLocationService},
        {provide: API_PREFIX, useValue: '/taasgateway/api/v1/logging'},
        TransactionlogService,
        TransactionDispatcher
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    bootstrap: [AppComponent]
})
export class AppModule {

}
