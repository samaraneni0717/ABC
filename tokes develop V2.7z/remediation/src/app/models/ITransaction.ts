export interface Transaction {
    TXID: string;
    CREATIONDATE: string;
    ORGOID: string;
    AOID: string;
    SYSCODE: string;
    STATUS: string;
    RESULT: string;
    PAYLOAD: string;
    APPID: string;
    USERAOID: string;
    QUEUENAME: string;
    SOR: string;
    PROCESSNAME: string;
    REFERENCEID: string;
}

export const initializeTransaction: Transaction = {
    TXID: '',
    CREATIONDATE: '',
    ORGOID: '',
    AOID: '',
    SYSCODE: '',
    STATUS: '',
    RESULT: '',
    PAYLOAD: '',
    APPID: '',
    USERAOID: '',
    QUEUENAME: '',
    SOR: '',
    PROCESSNAME: '',
    REFERENCEID: ''
};



