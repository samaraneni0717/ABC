export interface IACSPermissions {
    resources: [
        {
            delegateEligible: boolean,
            lpa: boolean,
            resourceOid: number,
            parentResourceOid: number,
            viewOrder: number,
            operationModeOid: number,
            categoryOid: number,
            certRequired: boolean,
            createdDate: string,
            countries: string,
            resourceId: string,
            resourceName: string,
            createdBy: string,
            resourceType: string,
            appId: string,
            excluded: boolean }
        ];
    }

export const initialACSPermissions: IACSPermissions = {
        'resources': [
        {
        'delegateEligible': false,
        'lpa': false,
        'resourceOid': 0,
        'parentResourceOid': 0,
        'viewOrder': 0,
        'operationModeOid': 0,
        'categoryOid': 0,
        'certRequired': false,
        'createdDate': '',
        'countries': '',
        'resourceId': '',
        'resourceName': '',
        'createdBy': '',
        'resourceType': '',
        'appId': 'HRIIPortal',
        'excluded': false  } ]
    };
