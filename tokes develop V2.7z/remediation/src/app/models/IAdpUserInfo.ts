export interface IAdpUserInfo {
    UserId: string;
    LastName: string;
    FirstName: string;
    Email: string;
    AoId: string;
    SelectedOrgOid: string;
    OrginalOrgOid: string;
}

export const initialAdpUserInfo: IAdpUserInfo = {
    'UserId': '',
    'LastName': '',
    'FirstName': '',
    'Email': '',
    'AoId': '',
    'SelectedOrgOid': '',
    'OrginalOrgOid': ''
};
