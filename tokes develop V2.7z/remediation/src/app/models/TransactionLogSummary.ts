export interface TransactionLogSummary {
    TotalRecords: number;
    TotalCompleted: number;
    TotalErrors: number;
    TotalCompwErrors: number;
    TotalReceived: number;
    TotalAutoRetries: number;
    TotalManualRetries: number;
    TotalEIMCompleted: number;
    TotalEIMRunning: number;
    TotalOther: number;
}

export const initializeTransLogSummary: TransactionLogSummary = {TotalRecords: 0, TotalCompleted: 0, TotalErrors: 0, TotalCompwErrors: 0,
    TotalReceived: 0, TotalAutoRetries: 0, TotalManualRetries: 0,  TotalEIMCompleted: 0, TotalEIMRunning: 0, TotalOther: 0 };
