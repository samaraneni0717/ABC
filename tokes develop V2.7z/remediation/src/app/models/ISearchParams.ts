export interface SearchParams {
    txid: string;
    orgoid: string;
    aoid: string;
    startdate: string;
    starttime: string;
    enddate: string;
    endtime: string;
    referenceid: string;
    processname: string;
    status: string;
    getlastrecord: number;
}

export const initializeSearchParms: SearchParams = {
    'txid': '',
    'orgoid': '',
    'aoid': '',
    'startdate': '',
    'enddate': '',
    'starttime': '',
    'endtime': '',
    'referenceid': '',
    'processname': '',
    'status': '',
    'getlastrecord': 1
};
