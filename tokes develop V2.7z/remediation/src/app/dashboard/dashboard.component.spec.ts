import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivatedRoute, Router, convertToParamMap} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AppModule } from '../app.module';

import { DashboardComponent } from './dashboard.component';
import { DashboardModule } from './dashboard.module';


import { Transaction, initializeTransaction } from '../models/ITransaction';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';
import { TransactionLogSummary } from '../models/TransactionLogSummary';

import { TransactionDispatcher } from '../services/transactiondispatcher.service';
import { TransactionlogService } from '../services/transactionlog.service';
import { TransactionMockService } from '../services/transaction-mock.service';
import * as mockdata from '../services/transaction-mockdata';

import { callLifecycleHooksChildrenFirst } from '@angular/core/src/view/provider';


describe('RemediationDashboard Component', () => {

    let comp: DashboardComponent;
    let fixture: ComponentFixture<DashboardComponent>;
    let de: DebugElement;
    let el: HTMLElement;


    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [
          AppModule,
          DashboardModule
        ],
        providers: [
          { provide: TransactionlogService, useClass: TransactionMockService }
          ]
      });
    });

    beforeEach(function(done) {
      fixture = TestBed.createComponent(DashboardComponent);
      comp = fixture.debugElement.componentInstance;
      fixture.detectChanges();
      console.log('Before Each run DashboardComponent......');
      done();
    });



    it('should create DashboardComponent component', function(done) {
      console.log('DashboardComponent Test 1......');
      fixture.whenStable().then(() => {
           fixture.detectChanges();
        expect(comp.filterFormModel).toBeDefined();
      });
      done();
    });

    it('should create DashboardComponent and run getTransactions', function(done) {
        console.log('DashboardComponent Test 2......');
        fixture.whenStable().then(() => {
            comp.userInfo.SelectedOrgOid = 'G3BQ0EKGP5Q2MC2V';
            comp.userInfo.OrginalOrgOid = 'FFFFFFFFFFFFFFFF';
          comp.filterFormModel = initializeSearchParms;
          comp.filterFormModel.orgoid = 'G3BQ0EKGP5Q2MC2V';
          comp.filterFormModel.startdate = '04-APR-2018';
          comp.filterFormModel.enddate = '04-10-2018';
          comp.searchTransLog('TestSearch');

          fixture.detectChanges();
          expect(comp.translogsummarydata$).toBeDefined();
          done();
        });
    });
});

