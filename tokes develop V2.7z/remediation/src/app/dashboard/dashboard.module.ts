import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { DashboardComponent } from './dashboard.component';
import { DataCoinModule} from '@synerg/components/data-coin';

import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { RouterModule} from '@angular/router';

import {
    ButtonModule, BusyIndicatorModule, MastheadModule, SecondaryNavModule, TableModule, LeftNavModule,
PopoverModule, TextboxModule, DatePickerModule, FormGroupModule, FormGroupConfig, DateFormatService,
    DropdownListModule, SlideinModule, ModalModule, DualSelectModule, RadioModule, TimePickerModule,
    DropdownListComponent, ToggleSwitchModule, IconComponent, IconModule, CheckboxModule, AlertModule
} from '@synerg/components';

@NgModule({
    imports: [
        CommonModule,
        ButtonModule,
        BusyIndicatorModule,
        FormsModule,
        BrowserModule,
        FormGroupModule,
        TableModule,
        InfiniteScrollModule,
        DatePickerModule,
        TimePickerModule,
        DropdownListModule,
        CheckboxModule,
        RadioModule,
        RouterModule,
        DataCoinModule
    ],
    declarations: [
        DashboardComponent
    ],
    exports: [
        DashboardComponent
    ],
    entryComponents: [
        DashboardComponent
    ],
    providers: []
})
export class DashboardModule {

}
