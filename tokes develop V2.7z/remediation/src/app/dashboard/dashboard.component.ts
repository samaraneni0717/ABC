import { Component, OnInit, ChangeDetectionStrategy, ElementRef, isDevMode } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Http, Response, Request } from '@angular/http';
import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';

import { Store } from '@ngrx/store';
import * as fromRoot from '../ngrx/store';
import { Observable } from 'rxjs/Observable';

import { fromEvent } from 'rxjs/observable/fromEvent';
import { TextboxComponent } from '@synerg/components/textbox';
import { FormGroupModule, ButtonComponent, FormGroupComponent, FormGroupConfig, FormGroupMessage,
  TableComponent, TableRowClickEvent, TableSortEvent, TableCell, TableHeader, TableRow } from '@synerg/components';

import { Transaction, initializeTransaction } from '../models/ITransaction';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';
import { TransactionLogSummary } from '../models/TransactionLogSummary';

import * as util from '../Util/util';
import { TransactionDispatcher } from '../services/transactiondispatcher.service';
import { IAdpUserInfo, initialAdpUserInfo } from '../models/IAdpUserInfo';
import { IACSPermissions, initialACSPermissions } from '../models/IACSPermissions';
import 'rxjs/add/operator/distinctUntilChanged';


@Component({
  selector: 'app-remediation-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit {

  selectedretType = '';
  retTypeList = util.retTypeList;
  filterFormModel: SearchParams = initializeSearchParms;

  userInfo: IAdpUserInfo = initialAdpUserInfo;
  acsInfo: IACSPermissions = initialACSPermissions;

  translogsummarydata$: Observable<TransactionLogSummary>;
  userInfo$: Observable<IAdpUserInfo>;
  isBusy$: Observable<boolean>;
  acsUserCanUnmask = false;

  errorMessages: FormGroupMessage[] = [
    { errorType: 'pattern', errorMessage: '{fieldName} must be MM/DD/YYYY' }
  ];

  constructor(private store: Store<fromRoot.State>, private router: Router, private route: ActivatedRoute,
     private transactionDispatcher: TransactionDispatcher) {
      console.log('DevMode = ' + isDevMode());
      this.setInitialSearchParms();
      this.isBusy$ = store.select(fromRoot.getIsLoading);
      this.translogsummarydata$ = store.select(fromRoot.getAllTransactionSummaryInfo);
      this.userInfo$ = store.select(fromRoot.getUserInfoData);
      this.userInfo$.subscribe(usrinfo => { if (usrinfo) {

        if (usrinfo.SelectedOrgOid ) {
            if (this.setUserInfo(usrinfo) === true) {
              this.searchTransLog('init');
            }

            // Get ACS Permissions when userinfo actually available
            if (this.userInfo.AoId && this.userInfo.OrginalOrgOid ) {
              this.transactionDispatcher.getACSPermissions(this.userInfo.OrginalOrgOid, this.userInfo.AoId);
            }
          }
        }
      });

  }
  ngOnInit() {
    this.selectedretType = util.retTypeList[1];

    if (this.userInfo) {
      this.transactionDispatcher.getUserInfo();
    }
  }

  setUserInfo(usrinfo: IAdpUserInfo): boolean {

    const srchInfo = Object.assign({}, usrinfo);

     this.userInfo = srchInfo;

     return true;
  }

  setACSPermissions(acsinfo: IACSPermissions): boolean {
    const acsPerms = Object.assign({}, acsinfo);
    this.acsInfo = acsPerms;
    return true;
  }

  searchTransLog(evt: any) {
    // add Devmode check for Local Testing allowing any and all orgoids otherwise do not get data
    if (!this.userInfo.SelectedOrgOid && !isDevMode()) {
      return;
    }
    this.filterFormModel.orgoid = this.userInfo.SelectedOrgOid;
    this.transactionDispatcher.getTransactionLog(this.filterFormModel);
  }

  setInitialSearchParms() {
    this.filterFormModel = util.initialDateSearch();
  }

  setRetType(evt: any) {
    this.filterFormModel.getlastrecord = util.retTypeList.indexOf(evt);
  }
}

