import { Injectable } from '@angular/core';
import { TransactionlogService } from '../services/transactionlog.service';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';

import { Store } from '@ngrx/store';
import * as tranStore from '../ngrx/store/transaction.store';
import { TRANSACTION_ACTIONS } from '../ngrx/store/transaction.store';
import { UI_ACTIONS } from '../ngrx/store/ui.store';
import {USRINFO_ACTIONS } from '../ngrx/store/userinfo.store';
import {ACSINFO_ACTIONS } from '../ngrx/store/acspermission.store';

import * as fromRoot from '../ngrx/store';
import { initializeTransaction } from '../models/ITransaction';

@Injectable()
export class TransactionDispatcher {

    constructor(private tranlogsvc: TransactionlogService,  private store: Store<fromRoot.State>) {

    }

    getTransactionLog(filter: SearchParams) {

        this.store.dispatch(
            {
                type: UI_ACTIONS.START_LOADING
            });
        this.tranlogsvc.getTransactionLog(filter).subscribe(transactionData => { if (transactionData) {
            console.log('Data ON SEARCH received total rows = ' + transactionData.length + ' ' + transactionData[0].ORGOID
             + ' ' + transactionData[0].AOID);
            this.store.dispatch(
                {
                    type: TRANSACTION_ACTIONS.REQUEST_TRANSACTIONS,
                    transactionData
                });
          }

          if ( !transactionData ) {
             console.log('Data ON SEARCH returned no rows for search parameters ' + JSON.stringify(filter));

             this.store.dispatch(
                {
                    type: TRANSACTION_ACTIONS.REQUEST_TRANSACTIONS_NONE
                });
          }

          this.store.dispatch(
            {
                type: UI_ACTIONS.STOP_LOADING
            });
           },
              error => {console.log('Error retrieving Transaction log data' + error.errorMessage );
              this.store.dispatch(
                {
                    type: UI_ACTIONS.STOP_LOADING
                });
            }
        );
    }

    getUserInfo() {
        this.tranlogsvc.getUserInfo().subscribe(usrinfo => {if (usrinfo) {
            this.store.dispatch(
                {
                    type: USRINFO_ACTIONS.REQUEST_USRINFO,
                    usrinfo
                }
            );
        }}, error => { console.log('Error during getUserInfo ' + JSON.stringify(error)); } );
    }

    getACSPermissions(orgoid: string, aoid: string) {
        try {
        this.tranlogsvc.getACSPermissions(orgoid, aoid).subscribe(acsinfo => {if (acsinfo) {
            this.store.dispatch(
                {
                    type: ACSINFO_ACTIONS.REQUEST_ACSINFO,
                    acsinfo
                }
            );
        }}, error => { console.log('Error during getACSInfo ' + JSON.stringify(error)); } );
    } catch (e) {
        console.log('Error during ACS call ' + JSON.stringify(e));
    }
    }

    nextTransactions() {
        this.store.dispatch(
            {
                type: TRANSACTION_ACTIONS.REQUEST_NEXT_TRANSACTIONS,
                transactionsPerPage: 15
            }
        );
    }

    sortTransactions(column: string, order: string) {

        this.store.dispatch(
            {
                type: TRANSACTION_ACTIONS.REQUEST_SORT,
                colname: column.toUpperCase(),
                order: order
            }
        );
    }
}
