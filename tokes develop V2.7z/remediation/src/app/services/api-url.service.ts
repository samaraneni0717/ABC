import { Injectable, Inject } from '@angular/core';
import { API_PREFIX } from './api-url.prefix';
@Injectable()
export class ApiUrlService {

    constructor( @Inject(API_PREFIX) private prefix: string) {

    }

    private getPrefix(): string {
        return this.prefix;
    }

    public getPostfix(action: string): string {
        let prefix: string = this.getPrefix();
        let postFix: string;
        if (!prefix.endsWith('/') && !action.startsWith('/')) {
            postFix = prefix + '/' + action;
        } else if (prefix.endsWith('/') && action.startsWith('/')) {
            postFix = prefix + action.substr(1);
        } else {
            postFix = prefix + action;
        }
        return postFix;
    }
}