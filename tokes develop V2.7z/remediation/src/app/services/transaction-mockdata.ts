import { IAdpUserInfo } from "../models/IAdpUserInfo";

export const TenantLogMockResponse: any =
[
    {
        'SOR': 'Vantage',
        'USERAOID': 'G3BS7JQJ5Z10X3MD',
        'STATUS': 'MANUAL RETRY',
        'APPID': 'taas-apigateway-remediation',
        'PROCESSNAME': 'PERSON_INTREGATION',
        'ORGOID': 'G3BQ0EKGP5Q2MC2V',
        'AOID': 'G3RHS7VJ92WY52GB',
        'TXID': '08B94BAB-5845-2C17-6B8E-56A37A19787F',
        'REFERENCEID': '0',
        'SYSCODE': 'c15454',
        'RESULT': 'MANUAL RETRY',
        'PAYLOAD': null,
        'QUEUENAME': null,
        'CREATIONDATE': '02-APR-2018 16:45:08'
    },
    {
        'SOR': 'Vantage',
        'USERAOID': null,
        'STATUS': 'Retry 1',
        'APPID': 'taas-apigateway-remediation',
        'PROCESSNAME': 'PERSON_INTREGATION',
        'ORGOID': 'G3BQ0EKGP5Q2MC2V',
        'AOID': 'G3RHS7VJ92WY52GB',
        'TXID': '08B94BAB-5845-2C17-6B8E-56A37A19787F',
        'REFERENCEID': null,
        'SYSCODE': '10004',
        'RESULT': 'Retry',
        'PAYLOAD': null,
        'QUEUENAME': null,
        'CREATIONDATE': '02-APR-2018 14:56:59'
    },
    {
        'SOR': 'Vantage',
        'USERAOID': null,
        'STATUS': 'Received',
        'APPID': 'taas-apigateway-mq-processor',
        'PROCESSNAME': 'PERSON_INTREGATION',
        'ORGOID': 'G3BQ0EKGP5Q2MC2V',
        'AOID': 'G3RHS7VJ92WY52GB',
        'TXID': '08B94BAB-5845-2C17-6B8E-56A37A19787F',
        'REFERENCEID': null,
        'SYSCODE': '100001',
        'RESULT': ' ',
        'PAYLOAD': '{\'events\':[{\'data\':{\'eventContext\':{\'worker\':{\'associateOID\':\'G3RHS7VJ92WY52GB\'}},\'output\':{\'worker\':{\'associateOID\':\'G3RHS7VJ92WY52GB\',\'businessCommunication\':{\'landline\':{\'itemID\':\'WORK\',\'nameCode\':{\'codeValue\':\'WORK\',\'longName\':\'Work/Office Phone\'},\'extension\':\'6ADSF4A\',\'formattedNumber\':\'7703602539\'}}}}},\'eventID\':\'08B94BAB-5845-2C17-6B8E-56A37A19787F\',\'serviceCategoryCode\':{\'codeValue\':\'hr\'},\'eventNameCode\':{\'codeValue\':\'worker.businessCommunication.landline.change\'},\'eventTitle\':\'Business Phone Number Change\',\'eventSubTitle\':\'7703602539 Ext. 6ADSF4A\',\'eventStatusCode\':{\'codeValue\':\'complete\',\'shortName\':\'Complete\'},\'recordDateTime\':\'2018-03-15T21:05:22.269+0000\',\'creationDateTime\':\'2018-03-15T21:05:22.269+0000\',\'originator\':{\'associateOID\':\'G06KE8HUSZ1HHBJ7\'},\'actor\':{\'associateOID\':\'G06KE8HUSZ1HHBJ7\'},\'links\':[{\'href\':\'/events/hr/v1/worker.business-communication.landline.change/08B94BAB-5845-2C17-6B8E-56A37A19787F\',\'rel\':\'self\'}]}]}',
        'QUEUENAME': 'endpoint.wmq.ADP.ES.TAAS.DI.INBOUND',
        'CREATIONDATE': '02-APR-2018 15:02:17'
    }
];

export const IADPUserInfoMockResponse: IAdpUserInfo = {
    'UserId': '',
    'LastName': '',
    'FirstName': '',
    'Email': '',
    'AoId': 'G0JIH4IIV6J9053Y',
    'SelectedOrgOid': 'G3BQ0EKGP5Q2MC2V',
    'OrginalOrgOid': 'FFFFFFFFFFFFFFFF'

}