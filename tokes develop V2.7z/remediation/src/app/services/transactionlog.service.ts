import { Injectable } from '@angular/core';

import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { Transaction } from '../models/ITransaction';
import { IAdpUserInfo } from '../models/IAdpUserInfo';
import { IACSPermissions } from '../models/IACSPermissions';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';

import { ApiUrlService } from '../services/api-url.service';

import * as utils from '../../app/Util/util';

import { Action } from '@ngrx/store';

@Injectable()
export class TransactionlogService {

  constructor(private httpClient: HttpClient) { }

  public getTransactionLog(filter: SearchParams) {

    try {
      const srchParams = Object.create(filter);

      const adjustedParams = this.adjustSearchParms(srchParams);

      const predicate = this.buildPredicate(adjustedParams);
      const urltranlog = '/taasgateway/api/v1/logging?' + predicate;
      // const urltranlog = 'https://adpvantage-dit.nj.adp.com/taasgateway/api/v1/logging?' + predicate;

      const resp = this.httpClient.get<Transaction[]>(urltranlog);

      return resp;
    } catch (e) {
      console.log('Http Get Error ' + JSON.stringify(e));
    }
  }

  public postManualRetryForTransaction(transactionData: Transaction) {
    try {

      const dataToPost = {AOID: transactionData.AOID,
        TXID: transactionData.TXID,
        SYSCODE: '10004',
        STATUS: 'MANUAL RETRY',
        RESULT: 'MANUAL RETRY',
        PAYLOAD: transactionData.PAYLOAD,
        APPID: transactionData.APPID,
        USERAOID: transactionData.USERAOID,
        SOR: transactionData.SOR,
        PROCESSNAME: transactionData.PROCESSNAME,
        REFERENCEID: transactionData.REFERENCEID
      };

      const jsonData = JSON.stringify(dataToPost);
      const urltranlog = '/taasgateway/api/v1/logging';

      let headrs = new HttpHeaders();
      headrs = headrs.append('Content-Type', 'application/json');
      headrs = headrs.append('ORGOID', transactionData.ORGOID);
      headrs = headrs.append('TXID', transactionData.TXID);
      headrs = headrs.append('ORGOIDOVERRIDE', transactionData.ORGOID);

      const resp = this.httpClient.post<Transaction[]>(urltranlog, jsonData,
        { headers: headrs });
      return resp;
    } catch (e) {
      console.log('Http POST Error ' + JSON.stringify(e));
    }
  }

  adjustSearchParms(parms: SearchParams): SearchParams {
    let beginDate = '';
    let stopDate = '';
    let orgOid = '';

    if (parms.startdate) {
      beginDate = utils.convertDateToDDMMMYYYY(parms.startdate);
    }

    if (parms.enddate) {
      stopDate = utils.convertDateToDDMMMYYYY(parms.enddate);
    }

    if (parms.orgoid) {
      orgOid = parms.orgoid;
    }
    parms.startdate = beginDate;
    parms.enddate = stopDate;
    parms.orgoid = orgOid;

    return parms;

  }


  buildPredicate(srch: SearchParams): string {

    let predicate = 'getlastrecord=' + srch.getlastrecord.toString();

    if (srch.startdate) {
      predicate = predicate + '&' + 'startdate=' + srch.startdate;

      if (srch.starttime) {
        const len = srch.starttime.length - 3;
        const stTimewSeconds = srch.starttime.slice(0, len) + ':00' + srch.starttime.slice(len);
        predicate = predicate + ' ' + stTimewSeconds;
      }
    }

    if (srch.enddate) {
      predicate = predicate + '&' + 'enddate=' + srch.enddate;

      if (srch.endtime) {
        const len = srch.endtime.length - 3;
        const endTimewSeconds = srch.endtime.slice(0, len) + ':00' + srch.endtime.slice(len);
        predicate = predicate + ' ' + endTimewSeconds;
      }
    }

    if (srch.txid) {
      predicate = predicate + '&' + 'txid=' + srch.txid;
    }

    if (srch.aoid) {
      predicate = predicate + '&' + 'aoid=' + srch.aoid;
    }

    if (srch.orgoid) {
      predicate = predicate + '&' + 'orgoid=' + srch.orgoid;
    }

    if (srch.processname) {
      predicate = predicate + '&' + 'processname=' + srch.processname;
    }

    if (srch.referenceid) {
      predicate = predicate + '&' + 'referenceid=' + srch.referenceid;
    }

    if (srch.status) {
      predicate = predicate + '&' + 'status=' + srch.status;
    }

    return predicate;
  }

  public getUserInfo(): Observable<IAdpUserInfo> {

    const url = '/taascommon/Taas.Tenant.Api/v1/Tenant/UserInfo';
    let headrs = new HttpHeaders();
    headrs = headrs.append('Content-Type', 'application/json');
    const resp = this.httpClient.get<IAdpUserInfo>(url, {
      headers: headrs
    });

    return resp;

  }

  public getACSPermissions(orgoid: string, aoid: string): Observable<IACSPermissions> {
    const url = '/taasgateway/api/v1/acs/permissions';

    let headrs = new HttpHeaders();
    headrs = headrs.append('Content-Type', 'application/json');
    headrs = headrs.append('orgoid', orgoid);
    headrs = headrs.append('aoid', aoid);
    headrs = headrs.append('appid', 'HRIIPortal');
    const resp = this.httpClient.get<IACSPermissions>(url, {
      headers: headrs
    });

    return resp;
  }
}
