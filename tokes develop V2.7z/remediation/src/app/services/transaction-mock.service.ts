import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/from';

import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { Transaction } from '../models/ITransaction';
import { SearchParams, initializeSearchParms } from '../models/ISearchParams';
import { IAdpUserInfo } from '../models/IAdpUserInfo';

import { ApiUrlService } from './api-url.service';
import * as mockdata from './transaction-mockdata';

import * as utils from '../../app/Util/util';

import { Action } from '@ngrx/store';

@Injectable()
    export class TransactionMockService {
    constructor (private httpClient: HttpClient) { }

    public getTransactionLog(filter: SearchParams): Observable<Transaction[]> {
        const response: any = mockdata.TenantLogMockResponse;
        return Observable.of(response);
  }

  public postManualRetryForTransaction(transactionData: Transaction): Observable<Transaction> {
    const response: any = mockdata.TenantLogMockResponse[0];
    return Observable.of(response);
  }

  adjustSearchParms(parms: SearchParams): SearchParams {
    let beginDate = '';
    let stopDate = '';

    if (parms.startdate) {
      beginDate = utils.convertDateToDDMMMYYYY(parms.startdate);
    }

    if (parms.enddate) {
      stopDate = utils.convertDateToDDMMMYYYY(parms.enddate);
    }

    parms.startdate = beginDate;
    parms.enddate = stopDate;

    return parms;

  }


  buildPredicate(srch: SearchParams): string {

    let predicate = 'getlastrecord=' + srch.getlastrecord.toString();

    if (srch.startdate) {
      predicate = predicate + '&' + 'startdate=' + srch.startdate;

      if (srch.starttime) {
        const len = srch.starttime.length - 3;
        const stTimewSeconds = srch.starttime.slice(0, len) + ':00' + srch.starttime.slice(len);
        predicate = predicate + ' ' + stTimewSeconds;
      }
    }

    if (srch.enddate) {
      predicate = predicate + '&' + 'enddate=' + srch.enddate;

      if (srch.endtime) {
        const len = srch.endtime.length - 3;
        const endTimewSeconds = srch.endtime.slice(0, len) + ':00' + srch.endtime.slice(len);
        predicate = predicate + ' ' + endTimewSeconds;
      }
    }

    if (srch.txid) {
      predicate = predicate + '&' + 'txid=' + srch.txid;
    }

    if (srch.aoid) {
      predicate = predicate + '&' + 'aoid=' + srch.aoid;
    }

    if (srch.orgoid) {
      predicate = predicate + '&' + 'orgoid=' + srch.orgoid;
    }

    if (srch.processname) {
      predicate = predicate + '&' + 'processname=' + srch.processname;
    }

    if (srch.referenceid) {
      predicate = predicate + '&' + 'referenceid=' + srch.referenceid;
    }

    if (srch.status) {
      predicate = predicate + '&' + 'status=' + srch.status;
    }

    console.log('Predicate = ' + predicate);
    return predicate;
  }

  public getUserInfo(): Observable<IAdpUserInfo> {
    const response: any = mockdata.IADPUserInfoMockResponse;
    return Observable.of(response);
  }
}
