import { Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
    selector: 'app-reason-codes',
    templateUrl: './reason-codes.component.html',
   // styleUrls: ['./reason-codes.component.scss'],
   // providers: [ModalService, ReasonCodesActions, ConfirmService, ConfirmConfig],
    encapsulation: ViewEncapsulation.None,
  })
  export class ReasonCodesComponent implements OnInit {

    reasonCodesEntryResponse:any=[];
    headers = [
        { label: 'CODE ', sort: true, order: 'none', width: "20%", objValue: 'Code' },
        { label: 'DESCRIPTION', sort: true, order: 'none', width: "65%", objValue: 'Description' },
        { label: 'STATUS', sort: true, order: 'none', width: "10%", objValue: 'Status' }
      ];


      ngOnInit() {
        this.getReasonCodes();   
      }
      identify(index: number, reasoncode: any) {
        return reasoncode["RandomNum"]
      }
      
      getReasonCodes(){
        this.reasonCodesEntryResponse=[
            {
              "Category": "REASONCODE",
              "Code": "1",
              "Description": "1",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "10",
              "Status": 0,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "3",
              "Description": "3",
              "Status": 0,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "C1",
              "Description": "C1 des test",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "Code1",
              "Description": "This is Code1C1",
              "Status": 0,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "cutter",
              "Description": "cutter test",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "M1",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "M10",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "M25",
              "Status": 0,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "M31",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "Msa1",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "string",
              "Description": "string",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "STRING",
              "Code": "string",
              "Description": "string",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "Tara",
              "Description": "This was test code for Tara",
              "Status": 1,
              "OperationType": null
            },
            {
              "Category": "REASONCODE",
              "Code": "test bind",
              "Status": 1,
              "OperationType": null
            }
          ]
  }

}