export const environment = {
  production: true,
  prepareForPortal: false
};
