/**
 * Created by mckeowr on 3/8/17.
 */
var RawSource = require('webpack-sources').RawSource;

const OriginalSource = require('webpack-sources').OriginalSource;
/**
 * Patches the generated main module with some Angular tweaks to handle teardown memory issues
 * @constructor
 */
class AngularPatchPlugin {
    constructor(options) {
        this.bundleName = options.bundle + '.js';
        this.portal = options.portal;
    }

    apply(compiler) {
        let bundleFile = this.bundleName;

        compiler.plugin("compilation", (compilation) => {

            compilation.plugin("optimize-chunk-assets", (chunks, callback) => {

                const files = [];
                chunks.forEach((chunk) => files.push.apply(files, chunk.files));
                files.push.apply(files, compilation.additionalChunkAssets);
                files.filter((file) => {
                    console.log('checking file... ' + file)
                    return file === this.bundleName;

                }).forEach((file) => {
                    let asset = compilation.assets[bundleFile];
                    console.log("\nPatching Angular");

                    let JS, map;

                    if(asset.sourceAndMap) {

                        let sourceAndMap = asset.sourceAndMap();
                        map = sourceAndMap.map;
                        let input = sourceAndMap.source;
                        //console.log(inputSourceMap, input);

                        JS = input;
                    } else {
                        JS = compilation.assets[bundleFile].source();
                    }

                    // fix for routing in portal
                    if (this.portal) {
                        console.log('Applying locationSubscription patch')
                        // change the subscription to destroy itself when navigating away
                        let replacement = `
                        this.locationSubscription = /** @type {?} */ (this.location.subscribe(Zone.current.wrap(function(change) {\n
                        try {\n
                            console.log('Comparing hash (' + window.location.hash + ') to: #' + PORTAL_BASE_PATH);
                            if(PORTAL_BASE_PATH && !window.location.hash.startsWith('#' + PORTAL_BASE_PATH)) {
                                console.log('Navigating away from application. Destroying router and navigating to ' + window.location.hash);
                                _this.dispose();
                                return;
                            }\n
                        } catch(e) {\n
                            console.log('Error detecting external navigation', e)\n;
                        }`;

                        JS = JS.replace(/this\.locationSubscription = \/\*\* \@type\s\{\?\}\s\*\/\s\(this\.location\.subscribe\(Zone\.current\.wrap\(function \(change\) {/gi, replacement);
                    }

                    // apply the patched JS code
                    let newSource;
                    if (map) {
                        newSource = new OriginalSource(JS, map);
                    } else {
                        newSource = new RawSource(JS);
                    }

                    compilation.assets[bundleFile] = newSource;

                });
                // let bundleFile = this.bundleName;
                // console.log(compilation.assets[bundleFile]);//.source();
                callback();
            });
        });

    }
}

module.exports = AngularPatchPlugin;
