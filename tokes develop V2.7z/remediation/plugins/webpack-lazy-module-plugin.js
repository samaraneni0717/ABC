
var RawSource = require('webpack-sources').RawSource;


/**
 * wraps the generated code with the prefix and suffixed needed to isolate the app in the portal
 * @constructor
 */
class LazyModulePlugin {
    constructor(options) {
        this.jsonPFunctionName = options.rootTag + 'WebpackJsonp';
    }

    apply(compiler) {
        compiler.plugin('compilation',  (compilation)=> {
            compilation.plugin('optimize-chunk-assets',  (chunks, done) => {
                this.replaceBundleStrings(compilation, chunks);
                done();
            })
        });

        compiler.plugin('this-compilation', function(compilation) {
            compilation.mainTemplate.plugin('require-extensions', function(source, chunk, hash) {
                var buf = [];
                buf.push(source);
                buf.push('');
                buf.push('// override path for loaded modules');
                buf.push(this.requireFn + '.p = typeof getLazyPath === \'function\' ? getLazyPath() : ' + this.requireFn + '.p;');
                return this.asString(buf);
            });
        });
    }

    replaceBundleStrings(compilation, chunks){
        chunks.forEach((chunk) => {
            chunk.files.forEach((fileName) => {
                this.replaceFile(compilation, fileName);
            });
        });
    }

    replaceFile(compilation, fileName){
        let result = compilation.assets[fileName].source();
        if (result.indexOf('webpackJsonp') === 0) {
            result = result.replace('webpackJsonp', 'window[\'' + this.jsonPFunctionName + '\']');
            compilation.assets[fileName] = new RawSource(result);
        } 
    }
    

}

module.exports = {
    LazyModulePlugin: LazyModulePlugin
}
