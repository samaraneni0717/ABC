/**
 * Created by mckeowr on 3/8/17.
 */
const RawSource = require('webpack-sources').RawSource;

/**
 * changes the generated sourcemap to account for the file appended before the JS
 * @param options
 * @constructor
 */
class SourcemapsBannerPlugin {
    constructor(options) {
        this.options = options;
        if (!options || !options.hasOwnProperty('entries') || !Array.isArray(options.entries)) {
            throw new Error("SourcemapsBannerPlugin: You must initialize SourcemapsBannerPlugin with an options object that has a property called 'entries'");
        }
    }

    apply(compiler)
    {

        var padMappings = function (compilation, bundle, prefix) {
            // split the prefix into lines and create an array that includes a ; for each one
            let lines = prefix.toString().split('\n').map(()=> ';');
            // splitting actually gives us one more than we want so we'll pop one off
            lines.pop();

            // we just want t string of ; so we join them here
            let prefixBuffer = lines.join('');

            console.log('\nSourcemapsBannerPlugin: Padding ' + bundle + ' with ' + lines.length + ' line breaks');

            let mapFile = bundle + '.js.map';

            if (!compilation.assets.hasOwnProperty(mapFile)) {
                console.warn('\nSourcemapsBannerPlugin: No matching map file found for bundle name in compilation ' + mapFile);
                console.warn('Found: ', Object.keys(compilation.assets).join(', '));
            } else {
                // here we are patching the value with the updated one
                compilation.assets[mapFile] = new RawSource(compilation.assets[mapFile].source().replace('"mappings":";', '"mappings":";' + prefixBuffer));
            }
        };

        // Setup callback for accessing a compilation:
        compiler.plugin("emit", (compilation, callback) => {

            // console.log('Compilation assets:')
            // console.log(Object.keys(compilation.assets).join('\n'));

            // if the js file is wrapped with a banner, the line numbers in the source map
            // won't match up, so we need to adjust them by padding the 'mappings' to account for the
            // additional lines
            this.options.entries.forEach((entry) => {
                if (!entry.hasOwnProperty('bundle') || !entry.hasOwnProperty('prefix')) {
                    throw new Error('SourcemapsBannerPlugin: Each entry must have "bundle" and "prefix" property');
                }
                padMappings(compilation, entry.bundle, entry.prefix);
            });

            callback();
        });
    }
};

module.exports = SourcemapsBannerPlugin;