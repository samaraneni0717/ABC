import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkitemQueueComponent } from './workitem-queue/workitem-list/workitem-queue.component';
const routes: Routes = [
    {
        path: '',
        component: WorkitemQueueComponent
    },
    {
        path: 'id/:WorkItemId',
        component: WorkitemQueueComponent
    },
    {
        path: 'CobamId/:CobamId',
        component: WorkitemQueueComponent
    },
    {
        path: 'CobamId/:CobamId/UNumber/:UNumber',
        component: WorkitemQueueComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class WorkitemQueueRoutingModule { }
