import { Injectable } from '@angular/core'
import { HttpParams } from '@angular/common/http';

import { ApiService } from '../../Common/services/api.service'

import { environment } from '../../../environments/environment';

@Injectable ({
    providedIn: 'root'
})

export class WorkitemService {
    private WorkitemApiUrl: string = environment.BASEURL + "WorkitemNew";
    
    constructor(private apiService: ApiService) {}

    public Search(filter)
    {
        let httpParams = new HttpParams()
            .set('filter', JSON.stringify(filter ? filter : null));

        return this.apiService.Get<any>(this.WorkitemApiUrl + "/GetResults", httpParams);
    }

    public GetWorkItemHistory(id:number) {
        let httpParams = new HttpParams()
        .set('id', id.toString());

        return this.apiService.Get<any>(this.WorkitemApiUrl + "/GetWorkItemHistory", httpParams);
    }
}