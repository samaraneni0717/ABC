import { WorkitemStatus } from './workitem-status.model'
import { User } from '../../Common/models/user';

export class Workitem {
    UsersList: Array<User>;
    WorkItemStatusList: Array<WorkitemStatus>;
    SelectedWorkitemTypeList: Array<any>;
    SelectedWorkitemStatusList: Array<any>;
    DropDownSettings: any;

    constructor () {
        this.UsersList = [];
        this.WorkItemStatusList = [];
        this.SelectedWorkitemStatusList = [];
        this.SelectedWorkitemTypeList = [];
        this.DropDownSettings = {};
    }
}