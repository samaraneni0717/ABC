export class WorkitemFilter {
   WorkitemType: string = '';
   WorkitemStatus: string = '';
   WorkitemAssignee: string = '';
   WorkitemStartDate: string = '';
   WorkitemEndDate: string = '';
}

export namespace WorkitemFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}