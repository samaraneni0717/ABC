export class WorkitemStatus {
    StatusId: number;
    DisplayText: string;
}