import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router  } from '@angular/router';

import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateFRParserFormatter } from "../../Common/ngb/ngb-date-parser-formatter"

import { WorkitemService } from './../services/workitem.service'
import { AuthService } from '../../Common/Auth/auth-service.service';

import { Workitem } from './../models/workitem.model';
import { WorkitemFilter } from './../models/workitemfilter.model';
import { AgGrid } from '../../Common/ag-grid/ag-grid.model';
import '../../Common/modal/content/modal.less';

@Component({
    selector: 'app-list',
    templateUrl: './list-workitem.component.html',
    styleUrls: ['./list-workitem.component.css'],
    providers: [{provide: NgbDateParserFormatter, useClass: NgbDateFRParserFormatter}]
})

export class WorkitemListComponent implements OnInit {
   
    title = '';
    defaultFilterField = '';

    Filter: any;

    ShowMessage: boolean = false;
    isAuthenticated: boolean = false;

    workitemFilter: any;

    fieldOperators = ["AND", "OR"];

    workitemFilterForm: FormGroup;
    clearColumnIndex: number = 1;

    //Grid Members
    AgGridApi;

    globalResponse: any;
    gridDataSource: any[]; 
    
    objectContainer: Workitem = new Workitem();   

    components =  {
        customFloatingFilter: this.getCustomSelectFilterComponent(),
        'rowCheckSelectionRenderer': this.RowCheckSelectionRenderer,
        'userViewRenderer': this.UserViewRenderer,
        'statusViewRenderer': this.StatusViewRenderer,
        'typeViewRenderer' : this.TypeViewRenderer
    };

    getRowHeight = function() {
        return 30;
    };

    columnDefs = [{}];

    rowData = [{}];

    rowSelection = "single";

    constructor(public workitemService: WorkitemService,
        public authService: AuthService,
        public route: ActivatedRoute,
        public router: Router,
        public formBuilder: FormBuilder) {

        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        }

        this.router.events.subscribe((evt) => {
            if (evt instanceof NavigationEnd) {
                // trick the Router into believing it's last link wasn't previously loaded
                this.router.navigated = false;
                // if you need to scroll back to top, here is the right place
                window.scrollTo(0, 0);
            }
        });
    }

    ngOnInit() { 
        this.title = 'Workitem';
        this.defaultFilterField = '';
        this.Filter = WorkitemFilter;
        this.workitemFilter = new WorkitemFilter();
        this.clearColumnIndex = 1;

         var date = new Date();
         var dateStr = this.getNgbDateFormat(date);

        this.workitemFilterForm = this.formBuilder.group({
           WorkitemAssignee: '',
           WorkitemCreatedStartDate: dateStr,
           WorkitemCreatedEndDate: dateStr
        });

        this.getWorkitemResults(this.workitemFilterForm.value);
    }

    isFullWidth() {
        return true;
    }

    getNgbDateFormat(date) {
        var d = new Date(date);
        var month = d.getMonth()+1;
        var day = d.getDate();
        var year = d.getFullYear();
        //return strOutput;

        return {year: year, month: month, day: day};
    }

    getDateStringFormat(ngbDate) {
        const dateString = Number(ngbDate.month) + "/" + Number(ngbDate.day) + "/" + Number(ngbDate.year);

        return dateString;
    }

    getCustomSelectFilterComponent() {
        function CustomSelectFilter() {
        }
    
        CustomSelectFilter.prototype.init = function (params) {
            //console.log(params);
            this.valueGetter = params.values;
            this.filterText = null;
            this.params = params;
            this.setupGui();
        };
    
        // not called by ag-Grid, just for us to help setup
        CustomSelectFilter.prototype.setupGui = function () {
            var optionHtml: string = "";
            if(this.valueGetter != undefined) {
                this.valueGetter.forEach((key: any) => {
                    optionHtml += '<option _ngcontent-c2="" value="' + key.TypeName + '" ng-reflect-value="' + key.TypeName + '">' + key.TypeName + '</option>';
                });
            }
                this.gui = document.createElement('div');
                this.gui.innerHTML =
                    '<div style="padding: 4px;">' +
                    '<div><select style="margin: 4px 0px 4px 0px;width:110px;" id="Type">'+optionHtml+'</select></div>' +
                    '</div>';
        
                var that = this;
                this.onSelectFilterChanged = function() {
                    that.extractFilterText();
                    var filterInstance = that.params.api.getFilterInstance('WorkitemTypeName');

                    // Set the model for the filter
                    filterInstance.setModel({
                        type: 'euals',
                        filter: this.filterText
                    });

                    // Get grid to run filter operation again
                    that.params.api.onFilterChanged();
                };
        
                this.eFilterText = this.gui.querySelector('#Type');
                this.eFilterText.addEventListener("change", this.onSelectFilterChanged);
            
        };
    
        CustomSelectFilter.prototype.extractFilterText = function () {
            this.filterText = this.eFilterText.value;
        };
    
        CustomSelectFilter.prototype.getGui = function () {
            return this.gui;
        };

        CustomSelectFilter.prototype.onParentModelChanged = function (parentModel) {
            console.log(parentModel);
            if (!parentModel) {
                this.eFilterText.value = '';
                this.currentValue = null;
            } 
            else {
                this.eFilterText.value = parentModel.filter + '';
                this.currentValue = parentModel.filter;
            }
        };
    
        CustomSelectFilter.prototype.doesFilterPass = function (params) {
            var valueGetter = this.valueGetter;
            var value = valueGetter(params);
            var filterValue = this.filterText;
    
            if (this.isFilterActive()){
                if (!value) return false;
                return value === filterValue;
            }
        };
    
        CustomSelectFilter.prototype.isFilterActive = function () {
            return  this.filterText !== null &&
                this.filterText !== undefined &&
                this.filterText !== '' &&
                this.filterText;
        };
    
        CustomSelectFilter.prototype.getModel = function () {
            return this.isFilterActive() ? this.eFilterText.value : null;
        };
    
        CustomSelectFilter.prototype.setModel = function (model) {
            //console.log("setModel");
            this.eFilterText.value = model;
            this.extractFilterText();
        };
    
        

        CustomSelectFilter.prototype.asFloatingFilterText = function (parentModel) {
            //console.log("asFloatingFilterText");
            this.eColumnFloatingFilter.disabled = true;
            if (!parentModel)
                return '';
            // also supporting old filter model for backwards compatibility
            var values = (parentModel instanceof Array) ? parentModel : parentModel.values;
            if (values.length === 0) {
                return '';
            }
            var arrayToDisplay = values.length > 10 ? values.slice(0, 10).concat('...') : values;
            return "(" + values.length + ") " + arrayToDisplay.join(",");
        };
        CustomSelectFilter.prototype.parseAsText = function (model) {
            return this.asFloatingFilterText(model);
        };
        CustomSelectFilter.prototype.asParentModel = function () {
            //console.log("asParentModel");
            if (this.eColumnFloatingFilter.value == null || this.eColumnFloatingFilter.value === '') {
                return {
                    values: [],
                    filterType: 'set'
                };
            }
            return {
                values: this.eColumnFloatingFilter.value.split(","),
                filterType: 'set'
            };
        };
    
        return CustomSelectFilter;
    }

    getWorkitemResults(filter) {
        this.isAuthenticated = true;
        if (this.AgGridApi !== undefined)
            this.AgGridApi.showLoadingOverlay();

        this.ShowMessage = false;
        this.search(filter);
    }

    search(filter) {

        filter.WorkitemCreatedStartDate = this.getDateStringFormat(filter.WorkitemCreatedStartDate);
        filter.WorkitemCreatedEndDate = this.getDateStringFormat(filter.WorkitemCreatedEndDate);

        this.workitemService.Search(filter)
            .subscribe((workitemResponse) => {
                if (workitemResponse != null && workitemResponse.Count == 0) {
                    document.querySelector("#divMessage").className = "alert alert-warning";
                    document.querySelector("#divMessage").innerHTML = "<strong>Warning!</strong> No results found.";
                    this.ShowMessage = true;
                    this.gridDataSource = [];
                }
                else if (workitemResponse != null && workitemResponse.Result != null) {
                    this.gridDataSource = workitemResponse.Result;
                    if(workitemResponse.ColumnDefinitions != null) {
                        this.columnDefs = [
                            {
                                headerName: "",
                                field: "WorkitemID",
                                width:30,
                                headerCheckboxSelection: true,
                                // headerCheckboxSelectionFilteredOnly: true,
                                // checkboxSelection: true,
                                cellRenderer: "rowCheckSelectionRenderer",
                                suppressMenu:true,
                                filter:false, 
                                suppressFilter: true
                            }
                        ];

                        this.objectContainer.UsersList = workitemResponse.WorkitemUserList;
                        this.objectContainer.WorkItemStatusList = workitemResponse.WorkitemStatusList;
                        this.objectContainer.SelectedWorkitemStatusList = workitemResponse.SelectedWorkitemStatusList;
                        this.objectContainer.SelectedWorkitemTypeList = workitemResponse.SelectedWorkitemTypeList;
                        
                        workitemResponse.ColumnDefinitions.forEach(column => {
                            this.columnDefs.push(AgGrid.LoadColumnDefinition(column, this.objectContainer.SelectedWorkitemTypeList)[0]);
                        });
                    }

                    if(document.querySelector("#divMessage") != null)
                        document.querySelector("#divMessage").innerHTML = '';
                    
                    this.ShowMessage = false;
                }
            },
            () => {
                document.querySelector("#divMessage").className = "alert alert-danger";
                document.querySelector("#divMessage").innerHTML = "<strong>Error!</strong> Not able to communicate with Service. Please try Again.";
                this.ShowMessage = true;
                this.gridDataSource = [];
            },
            () => {
                this.rowData = this.gridDataSource;
                
                if(this.AgGridApi !== undefined)
                    this.AgGridApi.hideOverlay();
            })
    }

    onExport() {
        var params = {
            fileName: "Workitem.csv"
        };
        this.AgGridApi.exportDataAsCsv(params);
    }

    onGridReady(params) {
        this.AgGridApi = params;
    }

    onFilterChanged(params) {
        console.log("onFilterChanged", params.api.getFilterModel());
    }

    onAssigneeChange(value) {
        (<FormGroup>this.workitemFilterForm.get('WorkitemAssignee')).patchValue(value);
        this.getWorkitemResults(this.workitemFilterForm.value);
    }

    onDateChange() {
        this.getWorkitemResults(this.workitemFilterForm.value);
    }
    
    onRowDoubleClicked(params) {
        var id: number = params.data.WorkitemID;
        // if (id !== undefined) {
        //     var url: string = '';//CIDURL + 'GetLegal?id=' + id;
        //     window.open(
        //         url,
        //         '_blank'
        //     );
        // }
    }

    notauthorized(){
        this.isAuthenticated = false;
        event.preventDefault();
        this.router.navigate(['notauthorized']);
        return;
    }

    RowCheckSelectionRenderer(params): HTMLInputElement {
        var checkInputElement: HTMLInputElement = document.createElement("input");
        checkInputElement.type = "checkbox";
        checkInputElement.id = "chk" + params.value;
        checkInputElement.value = params.value;
        checkInputElement.disabled = !params.data.IsActive;

        return checkInputElement;
    }

    UserViewRenderer(params): HTMLSelectElement {
        var selectElement: HTMLSelectElement = document.createElement("select");
        selectElement.id = "selectUser" + params.Id;
        selectElement.style.width = "120px";
        selectElement.className = "form-control form-control-sm advanceFilterSize";

        var thisComponent = params.frameworkComponentWrapper.viewContainerRef.injector.view.component;
        
        var selectedUser = thisComponent.objectContainer.UsersList.filter(user => user.UNumber === params.data.Assignee);

        if(selectedUser == null || selectedUser.length == 0) {
            var option = document.createElement('option');
            option.value = params.data.AssigneeName? params.data.AssigneeName : 'Unassigned';
            option.text = params.data.AssigneeName? params.data.AssigneeName : 'Unassigned';
            option.selected = true;
            option.disabled = true;
            selectElement.appendChild(option);
        }
        
        thisComponent.objectContainer.UsersList.forEach(element => {
            if(element.WorkitemTypeId == params.data.WorkitemTypeID) {
                var option = document.createElement('option');
                option.value = element.UserNumber;
                option.text = element.FullName;
                option.selected = (selectedUser !== null && selectedUser.length > 0 && selectedUser[0].UserNumber == element.UserNumber) ? true : false;
                selectElement.appendChild(option);
            }
        });   

        selectElement.disabled = !params.data.IsActive;
        
        selectElement.onchange = function () {
            console.log(params.data);
        }

        return selectElement;
    }

    StatusViewRenderer(params): HTMLSelectElement {
        var selectElement: HTMLSelectElement = document.createElement("select");
        selectElement.id = "selectStatus" + params.Id;
        selectElement.style.width = "120px";
        selectElement.className = "form-control form-control-sm advanceFilterSize";

        var thisComponent = params.frameworkComponentWrapper.viewContainerRef.injector.view.component;
        var list = thisComponent.objectContainer.WorkItemStatusList;    

        var selectedStatus = list.filter(status => status.DisplayText === params.data.WorkitemStatusName);

        if(selectedStatus == null || selectedStatus.length == 0) {
            var option = document.createElement('option');
            option.value = params.data.WorkitemStatusName;
            option.text = params.data.WorkitemStatusName;
            option.selected = true;
            selectElement.appendChild(option);
        }
        
        list.forEach(element => {
            var option = document.createElement('option');
            if(params.data.WorkitemTypeID == element.WorkItem_Type) {
                option.value = element.StatusId;
                option.text = element.DisplayText;
                option.selected = (selectedStatus !== null && selectedStatus.length > 0 && selectedStatus[0].DisplayText == element.DisplayText) ? true : false;
                option.disabled = 
                (element.WorkitemTypeCode !== 'Safekeeping') ?
                    (element.Id == selectedStatus[0].DisplayText) ? false : (params.data.WorkitemTypeID == 6) ?  (element.StatusId == 3) ? (params.data.BusAcctId) ? false : true : false  : false : 
                    (params.data.Assignee == thisComponent.LoggedInUser) ? false : (element.Code == 'Accept' || element.Code == 'Reject') ? true : false;
                selectElement.appendChild(option);
            }
        }); 
        
        selectElement.disabled = !params.data.IsActive;

        selectElement.onchange = function () {
            console.log(params.data);
        }

        return selectElement;
    }

    TypeViewRenderer(params) : HTMLDivElement {
        var divElement: HTMLDivElement = document.createElement("div");

        var imgElement: HTMLImageElement = document.createElement("img");
        imgElement.src = "./assets/Search.PNG";
        imgElement.title = "Click to view information";
        imgElement.style.width = "30px";
        imgElement.style.height = "30px";

        imgElement.onclick = () => {
            if (params.value !== undefined) {
                // History
                // console.log(params.frameworkComponentWrapper.viewContainerRef.injector.view.component);
                // var histDialog = params.frameworkComponentWrapper.viewContainerRef.injector.view.component.dialog;
                // const dialogRef = histDialog.open('template', {
                //     width: '400px', height: '100px'
                // });

                params.frameworkComponentWrapper.viewContainerRef.injector.view.component.openModal(history, params.data.WorkitemID);

                //this.modalService.open('modelWorkitemhistory', params.data.WorkitemID);
            }
        }

        divElement.appendChild(imgElement);

        var spanElement: HTMLSpanElement = document.createElement("span");
        spanElement.innerText = params.data.WorkitemTypeName;

        divElement.appendChild(spanElement);

        return divElement;
    }

    onSelectionChanged(params) {
        var rowCount = params.api.getSelectedNodes().length;

        if(rowCount > 0) {
            params.api.getSelectedNodes().forEach(function(node)
            {
                if(document.querySelector("#chk"+node.data.WorkitemID) != null)
                    (<HTMLInputElement>document.querySelector("#chk"+node.data.WorkitemID)).checked = node.selected;                
            });
        }
        else {
            params.api.forEachNode(function(node) {
                node.setSelected(false);
                if(document.querySelector("#chk"+node.data.WorkitemID) != null)
                  (<HTMLInputElement>document.querySelector("#chk"+node.data.WorkitemID)).checked = node.selected; 
              });
        }
    }

    isRowSelectable = function(rowNode) {
        return rowNode.data ? rowNode.data.IsActive : false;
    };
}