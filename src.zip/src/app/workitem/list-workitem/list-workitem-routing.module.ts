import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkitemListComponent } from './list-workitem.component'

const routes: Routes = [
  {
      path: '/:type',
      component: WorkitemListComponent
  },
  {
    path: '',
    component: WorkitemListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorkitemListRoutingModule { }
