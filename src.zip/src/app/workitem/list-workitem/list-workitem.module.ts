import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { WorkitemListComponent } from './list-workitem.component';
import { WorkitemListRoutingModule } from './list-workitem-routing.module';

import { CustomAgGridModule } from '../../Common/ag-grid/ag-grid.module';

import { ModalComponent } from '../../Common/modal/modal.component';
import { ModalService } from '../../Common/modal/services/modal.service';

@NgModule({
  declarations: [
    WorkitemListComponent,
    ModalComponent
  ],
  entryComponents: [
    WorkitemListComponent,
    ModalComponent
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    NgbModule,
    CustomAgGridModule,
    WorkitemListRoutingModule
  ]
})
export class WorkitemListModule { }
