import { WorkitemQueueModule } from './workitem-queue.module';

describe('WorkitemQueueModule', () => {
  let workitemQueueModule: WorkitemQueueModule;

  beforeEach(() => {
    workitemQueueModule = new WorkitemQueueModule();
  });

  it('should create an instance', () => {
    expect(workitemQueueModule).toBeTruthy();
  });
});
