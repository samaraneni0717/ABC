import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs/Observable';
import { User } from '../../../Common/models/User';

@Injectable({
  providedIn: 'root'
})
export class SafekeepingAttachmentService {
  userDetail: User;
  constructor(private httpClient: HttpClient) {
    console.log('Service instantiated');
  }

  getAttachments(parentId: string): Observable<any> {
    return this.httpClient.get(
      environment.BASEURL + 'Attachment/GetAttachments/?parentId=' + parentId
    );
  }

  getDocument(attachmentID: string): Observable<any> {
    return this.httpClient.get(
      environment.BASEURL +
        'Attachment/GetDocument/?attachmentID=' +
        attachmentID
    );
  }
}
