export class WorkItem {
    Id: number;
    index: number;
    WorkItem_Type: number;
    WorkItem_TypeCode: string;
    WorkItem_Type_DisplayText: string;
    WorkItem_Action: string;
    WorkItemStatus: number;
    WorkItem_Status_DisplayText: string;
    Assignee: string;
    Prev_Assignee: string;
    User_Name: string;
    AcctId: number;
    BusAcctId: number;
    Acct_FullName: string;
    LegalId: number;
    Legal_FullName: string;
    Description: string;
    Comments: string;
    IsTaxProfileReviewRequired: boolean;
    CreatedBy: string;
    CreatedOn: Date;
    ModifiedBy: string;
    ModifiedUser: string;
    ModifiedOn: Date;
    IsActive: boolean;
    IsExpanded: boolean;
    IsSelected: boolean;
    IsFiltered: boolean;
    prev_WorkItemStatus: number;
    prev_IsActive: boolean;
    DescriptionOfIssue: string;
    ShortName: string;

    WorkItemEXT: WorkItemEXT[];
    WorkItemNote: WorkItemNote[];
    CurrentNote: string;
    COBAMNumber: string;
    SF_RequestId: string;
    OriginalWorkItemStatus: number;
    Source: string;
    SF_ObjectName: string;
}

export class WorkItemEXT {
    Id: number;
    WorkItem_Id: number;
    Status: string;
    SubStatus: string;  
    DisplayText: string;  
    HelpText: string;  
    StatusOption: string;  
    SubStatusOption: string;  
    COBAMId: string;    
    COBAMNumber: string;  
    PreviousStatus: string;
    PreviousSubStatus: string; 
    IsActive: boolean;
    HongKongClassification: string;
    ProductGroupMarketCoverage: String;
    APACComments: String;   
}

export class WorkItemNote {
    NotedBy: string;
    NoteOn: Date;
    Note: string;     
}