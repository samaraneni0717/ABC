export class WorkItemHistory {
    Id: number;
    Assignee: string;
    Status: string;
    ChangeDate: Date;
    ChangeOperation: string;
    ChangeByUser: number;
    ChangeByApplication: string;
    ValidationDetails: string;
}
