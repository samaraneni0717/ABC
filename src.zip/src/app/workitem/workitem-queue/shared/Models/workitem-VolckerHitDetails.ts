export class WorkItemVolckerHitDetails{
    LegalId: string;
    External: string;
    ExternalId: string;
    LegalName: string;
    VolckerFlag:string;
    
}