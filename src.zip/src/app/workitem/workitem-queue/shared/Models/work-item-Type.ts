export class WorkItemType {
    Id: number;
    Code: string;
    DisplayText: string;
    Index: number;
    IsSelected: boolean;
    Text: string;
}
