export class WorkItemFilter {
    Type: Array<number>;
    Status: Array<number>;
    Assignee: string;
    searchExpression: string;
    sortExpression: string;
    StartDate: Date;
    EndDate: Date;
    pageSize: number;
    pageNumber: number;
    SearchInDetails = false;
    IsDataForExport = false;
    WorkItemId: string;
    CobamId: string;
    UNumber: string;
}
