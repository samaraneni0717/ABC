export class WorkItemUpdateRequestDetails{
    BusAcctId: number;
    COBAMId: string;
    TableName: string;
    ColumnName: string;
    CurrentValue:string;
    NewValue:string;
    WorkItemGroup: string;
}