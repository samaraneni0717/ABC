export class WorkItemStatus {
    StatusId: number;
    Code: string;
    DisplayText: string;
    StatusIndex: number;
    IsWorkItemActive: boolean;
    WorkItem_Type: number;
    Id: number;
    IsSelected: boolean;
    Text: string;
    lstWorkItem_Type: Array<number>;
    WorkItemType_Code: string;
}
