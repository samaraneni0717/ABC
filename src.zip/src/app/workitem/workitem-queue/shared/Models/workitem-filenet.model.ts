export class FileNetDocInfo {
    DocumentId: string;
    DocumentTitle: number;
    LegalId: number;
    LegalName: number;
    DocumentUrl: string;
    Date: Date;
    DTSDocId: string;
}
