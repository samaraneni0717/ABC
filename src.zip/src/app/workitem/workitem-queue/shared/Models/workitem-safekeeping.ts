export class AttachmentInfo {
  AttachmentID: string;
  FileName: string;
  Description: string;
  CreatedBy: string;
  CreatedDate: Date;
  DocumentData: any;
}
