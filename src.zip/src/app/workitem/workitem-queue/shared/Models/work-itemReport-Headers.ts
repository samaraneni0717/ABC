export class WorkItemReportHeaders {
    ReportId: number;
    ReportName: string;
    ColumnName: string;
    ColumnHeader: string;
}
export class WorkItemReportHeaderDtls {
    lstHeaderDetails: Array<WorkItemReportHeaders> =
        [{ ReportId: 0, ReportName: '', ColumnName: 'Id', ColumnHeader: 'Id' },
        { ReportId: 0, ReportName: '', ColumnName: 'WorkItem_Type_DisplayText', ColumnHeader: 'WorkItem Type' },
        { ReportId: 0, ReportName: '', ColumnName: 'Assignee', ColumnHeader: 'Assigned User' },
        { ReportId: 0, ReportName: '', ColumnName: 'WorkItem_Status_DisplayText', ColumnHeader: 'Status' },
        { ReportId: 0, ReportName: '', ColumnName: 'LegalId', ColumnHeader: 'Legal Id' },
        { ReportId: 0, ReportName: '', ColumnName: 'Legal_FullName', ColumnHeader: 'Legal Name' },
        { ReportId: 0, ReportName: '', ColumnName: 'AcctId', ColumnHeader: 'Account Id' },
        { ReportId: 0, ReportName: '', ColumnName: 'Acct_FullName', ColumnHeader: 'Account Name' },
        { ReportId: 0, ReportName: '', ColumnName: 'CreatedOn', ColumnHeader: 'Created On' },
        { ReportId: 0, ReportName: '', ColumnName: 'ModifiedOn', ColumnHeader: 'Modified On' },
        { ReportId: 0, ReportName: '', ColumnName: 'ModifiedUser', ColumnHeader: 'Modified By' },
        ];
}
export class WorkItemToExport {
    Id: number;
    WorkItem_Type_DisplayText: string;
    Assignee: string;
    WorkItem_Status_DisplayText: string;
    LegalId: number;
    Legal_FullName: string;
    AcctId: number;
    Acct_FullName: string;
    CreatedOn: Date;
    ModifiedOn: Date;
    ModifiedUser: string;
}
