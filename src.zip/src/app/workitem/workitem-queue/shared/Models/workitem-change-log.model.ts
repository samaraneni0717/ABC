export class WorkItemChangeLog {
    Id: number;
    Field: string;
    OldValue: string;
    NewValue: string;
    ChangeDate: Date;
    ChangeOperation: string;
    ChangeByUser: number;
    ChangeByApplication: string;
    ValidationDetails: string;
}