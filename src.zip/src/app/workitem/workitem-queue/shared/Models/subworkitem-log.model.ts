export class SubworkitemLog {
    Id: number;
    Name: string;
    Status: string;
    SubStatus: string;
    ChangeDate: Date;
    ChangeOperation: string;
    ChangeByUser: number;
    ChangeByApplication: string;
}