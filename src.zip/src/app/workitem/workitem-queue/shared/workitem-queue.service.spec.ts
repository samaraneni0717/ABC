import { TestBed, inject } from '@angular/core/testing';

import { WorkitemService } from './workitem-queue.service';

describe('WorkitemService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WorkitemService]
    });
  });

  it('should be created', inject([WorkitemService], (service: WorkitemService) => {
    expect(service).toBeTruthy();
  }));
});
