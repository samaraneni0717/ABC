import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { WorkItem } from './Models/work-item';
import { AlertService } from '../../../Common/services/alert.service';
import { AuthService } from '../../../Common/Auth/auth-service.service';
import { DatePipe } from '@angular/common';
import 'rxjs/add/operator/retry';
import 'rxjs/add/operator/retryWhen';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/scan';
import { WorkItemStatus } from './Models/work-item-status';
import { environment } from '../../../../environments/environment';
import { WorkItemType } from './Models/work-item-Type';
import { Observable } from 'rxjs';
import { User } from '../../../Common/models/User';
import { WorkItemFilter } from './Models/work-item-Filter';

import { UserRole } from 'src/app/Common/models/user-role';


import { ApiService } from '../../../Common/services/api.service';

@Injectable({
    providedIn: 'root'
})
export class WorkitemService {
    param_workItem_Type;
    workitemTypeIdlst = '';
    userRoles: UserRole;
    userDetail: User;
    UserWorkItemList: Array<WorkItemType>;
    WorkItemQueueList: WorkItem[];
    WorkItemQueueListUpdated: WorkItem[];
    WorkItemQueueFilteredList: WorkItem[];
    WorkItemStatus: Array<WorkItemStatus>;
    SelectedWorkItemstatus: Array<WorkItemStatus>;
    WorkItemstatustype: Array<WorkItemStatus>;
    WorkItemQueueSelectedList: Array<WorkItem> = [];
    statusFilters: Array<number>;
    WorkItemFilters: Array<number>;
    workItem_Type_List: Array<number>;
    workItem_Status_List: Array<number>;
    usersLst: Array<string> = [];
    CurrentWorkitem: WorkItem[];
    lstWorkitemUsers: Array<User> = [];
    usersLstToFilter: string;
    date_Start: Date = new Date();
    date_End: Date = new Date();
    loadedTime: Date = new Date();
    IsAMTDashboardSuperUser: boolean = false;
    totalCount;
    filterCondition: WorkItemFilter = new WorkItemFilter();
    constructor(
        private http: Http,
        private alertService: AlertService,
        private apiService: ApiService,
        private auth: AuthService,
        private datePipe: DatePipe) { }

    getlstworkitemByFilter(Param_workItem_Type: any, Param_workItem_Status: any, callingFrom: any = '') {
        this.alertService.clear();
        this.WorkItemQueueFilteredList = null;

        if (callingFrom === 'ngOnInit' && Param_workItem_Type === undefined) {
            this.UserWorkItemList = [];
            this.WorkItemstatustype = [];
            this.workItem_Status_List = undefined;
            this.workItem_Type_List = undefined;
            this.filterCondition.Type = [];
            this.filterCondition.Status = [];
            this.SelectedWorkItemstatus = [];
            this.param_workItem_Type = undefined;
        }

        if (!(Param_workItem_Type === undefined)) {
            this.param_workItem_Type = Param_workItem_Type;
            this.workItem_Type_List = Param_workItem_Type.substring(0, Param_workItem_Type.length).split(',');
            this.UserWorkItemList = [];
        }
        if (!(Param_workItem_Status === undefined)) {
            this.workItem_Status_List = Param_workItem_Status.substring(0, Param_workItem_Status.length).split(',');
            this.WorkItemstatustype = [];
            this.WorkItemStatus = [];
        }

        this.AssignFiltercondition();
        this.getUserMasterData(Param_workItem_Type, Param_workItem_Status);
    }

    CheckUserbyRole(): Observable<any> {
        const myParams = new URLSearchParams();
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'WorkItemSK/GetUserSalesRole', options)
            .pipe(map((response: Response) => {
                console.log(response);
                response.json()
            }));
    }

    GetCOBAMID(workItemId): Observable<any> {
        const myParams = new URLSearchParams();
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        myParams.append('workItemId', workItemId);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'WorkItemSK/GetCOBAMId', options)
            .pipe(map((response: Response) => {
                console.log(response);
                return response.json()
            }));
    }

    getworkitemByFilter() {
        //if(!this.alertService.indLoading)
        //this.alertService.indLoading = true;
        //var user = (this.auth.userDetail && this.auth.userDetail.UNumber) ? this.auth.userDetail.UNumber : this.auth.getLoggedInUser();

        let httpParams = new HttpParams()
            .set('filter', JSON.stringify((this.filterCondition && ((this.filterCondition.Type &&
                this.filterCondition.Type.length > 0) || (this.filterCondition.WorkItemId) || (this.filterCondition.CobamId))) ? this.filterCondition : undefined))
            .set('userNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');


        return this.apiService.Get<any>(environment.BASEURL + 'Workitem', httpParams);

    }

    getMasterData() {
        // if(!this.alertService.indLoading)
        //   this.alertService.indLoading = true;

        this.workitemTypeIdlst = '';
        if (this.filterCondition.Type != null) {
            if (this.filterCondition.Type.length > 0) {
                this.filterCondition.Type.forEach(s => {
                    this.workitemTypeIdlst = this.filterCondition.Type.join(',');
                });
            }
        }
        const httpParams = new HttpParams()
            .set('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '')
            .set('selectedWorkitemTypes', this.workitemTypeIdlst);

        return this.apiService.Get<any>(environment.BASEURL + 'Workitem/GetWorkitemMasterData', httpParams);
    }

    UpdateWorkitemqueue(CurrentItem: WorkItem[]): boolean {
        if (CurrentItem === undefined || CurrentItem.length === 0) {
            this.alertService.warn('Please Select atleast one Workitem ');
            return false;
        }
        else if ((CurrentItem.find(item => ((item.WorkItem_TypeCode === "APAC_Requests" || item.WorkItem_TypeCode === "APAC_CPI_Requests")
            && (item.WorkItem_Status_DisplayText === "Approved" || item.WorkItem_Status_DisplayText === "Reject")
            && (item.Assignee == null || item.Assignee == ""))))) {
            this.alertService.warn('Select an Assignee to Approved/Reject Work Item!');
            return false;
        }
        else {
            CurrentItem.forEach(item => {
                item.IsSelected = false;
                item.prev_WorkItemStatus = item.WorkItemStatus;
                item.prev_IsActive = item.IsActive;
                this.AppendWorkItemNote(item);
                item.ModifiedOn = new Date();
            });
            const headers = new Headers({ 'Content-Type': 'application/json' });
            const options = new RequestOptions({ headers: headers });
            const body = JSON.stringify({ CurrentItem: CurrentItem, strUNumber: this.auth.userDetail.UNumber, externalData: '' });
            this.http.put(environment.BASEURL + 'Workitem', body, options).toPromise()
                .then(this.extractData)
                .catch(this.handleErrorPromise);
            return true;
        }
    }

    AppendWorkItemNote(workItem: WorkItem): any {
        if (workItem.CurrentNote) {
            var newWorkItemNote = { NotedBy: this.auth.userDetail.FullName, NoteOn: new Date(), Note: workItem.CurrentNote };
            if (workItem.WorkItemNote != undefined && workItem.WorkItemNote != null) {
                workItem.WorkItemNote.push(newWorkItemNote);
            }
            else {
                workItem.WorkItemNote = [newWorkItemNote];
            }
            workItem.CurrentNote = '';
        }
    }

    private extractData(_res: Response) {
    }

    handleErrorPromise() {
    }

    GetFileNetDocInfoList(legalId: number) {
        const myParams = new URLSearchParams();
        myParams.append('legalId', legalId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'FileNet', options)
            .pipe(map((response: Response) => response.json()));
    }

    GetDocumentUrl(docId: number): any {
        const myParams = new URLSearchParams();
        myParams.append('DocumentId', docId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'FileNet', options)
            .pipe(map((response: Response) => response.json()));

    }

    GetWorkItemChangeLog(workItemId: number) {
        const myParams = new URLSearchParams();
        myParams.append('ChangeLogId', workItemId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'WorkitemLogHistory', options)
            .pipe(map((response: Response) => response.json()));
    }

    GetWorkItemHistory(workItemId: number) {
        const myParams = new URLSearchParams();
        myParams.append('WorkItemHistoryId', workItemId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'WorkitemLogHistory', options)
            .pipe(map((response: Response) => response.json()));
    }

    GetSubWorkItemLog(subWorkItemId: number) {
        const myParams = new URLSearchParams();
        myParams.append('subWorkItemId', subWorkItemId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'WorkitemLogHistory', options)
            .pipe(map((response: Response) => response.json()));
    }

    GetUpdateRequestWorkItem(workItemId: number) {
        const myParams = new URLSearchParams();
        myParams.append('workItemId', workItemId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'Workitem/GetUpdateRequestWorkItem', options)
            .pipe(map((response: Response) =>
                response.json()));
        // alert(response)));
    }

    GetVolckerHitWorkItem(workItemId: number) {
        const myParams = new URLSearchParams();
        myParams.append('workItemId', workItemId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http.get(environment.BASEURL + 'Workitem/GetVolckerHitWorkItem', options)
            .pipe(map((response: Response) =>
                response.json()));
        // alert(response)));
    }

    getSelectedWorkItemExt(workItemId: number, WorkItem_Type: number) {
        const myParams = new URLSearchParams();
        myParams.append('workItemId', workItemId.toString());
        myParams.append('WorkItem_Type', WorkItem_Type.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http
            .get(environment.BASEURL + 'WorkitemEXT', options)
            .pipe(map((response: Response) => response.json()));
    }

    getWorkItemNotes(workItemId: number) {
        const myParams = new URLSearchParams();
        myParams.append('workItemId', workItemId.toString());
        myParams.append('strUNumber', this.auth.userDetail.UNumber);
        const options = new RequestOptions({ params: myParams });
        return this.http
            .get(environment.BASEURL + 'Workitem/GetWorkItemNote', options)
            .pipe(map((response: Response) => response.json()));
    }

    GetUserWorkitemByFilter() {

        if (!this.UserWorkItemList || (this.filterCondition && this.filterCondition.Type &&
            this.filterCondition.Type.length > 0) ||
            (this.filterCondition && this.filterCondition.WorkItemId) ||
            (this.filterCondition && this.filterCondition.CobamId)) {
            this.getworkitemByFilter().subscribe((WorkIemResults) => {
                if (WorkIemResults != null) {
                    this.totalCount = WorkIemResults.totalCount;
                    if (WorkIemResults.workitemList && WorkIemResults.workitemList.length > 0) {
                        if (!this.WorkItemQueueFilteredList) {
                            this.loadedTime = new Date();
                            this.WorkItemQueueFilteredList = WorkIemResults.workitemList;
                        }
                    } else {
                        this.WorkItemQueueFilteredList = [];
                        this.alertService.warn('No Datafound..');
                    }
                    /* interval(20000).subscribe(x => {
                       this.getlstworkitemByFilter(false);
                     });*/
                } else {
                    this.alertService.warn('Something went wrong please Try Again!');
                }
                //this.alertService.indLoading = false;
            },
                (error) => {
                    console.error(error);
                    this.alertService.warn('Not able to communicate with Service Please try Again');
                    //this.alertService.indLoading = false;
                });
        } else {
            this.WorkItemQueueFilteredList = [];
            this.statusFilters = [];
            this.SelectedWorkItemstatus = [];
        }
    }

    AssignFiltercondition() {
        if (this.UserWorkItemList) {
            if (this.UserWorkItemList && this.UserWorkItemList.length > 0) {
                this.filterCondition.Type = this.UserWorkItemList.
                    filter(o => o.IsSelected === true).map(({ Id }) => Id);
                if (this.filterCondition.Type.length > 0) {
                    if (this.WorkItemstatustype && this.WorkItemstatustype.length > 0) {
                        const selectedStatus = this.SelectedWorkItemstatus.
                            filter(o => o.IsSelected === true);
                        if (selectedStatus && selectedStatus.length > 0) {
                            this.filterCondition.Status = this.SelectedWorkItemstatus.
                                filter(o => o.IsSelected === true).map(({ Id }) => Id);
                        } else {
                            this.filterCondition.Status = [];
                        }
                    }
                }
            }
        }
        return null;
    }

    getWorkItemTypeAndStatus() {
        this.statusFilters = [];
        const selectedstatusIds = this.SelectedWorkItemstatus;
        this.SelectedWorkItemstatus = [];
        this.UserWorkItemList.forEach(element => {
            this.WorkItemstatustype.forEach(o => {
                if (selectedstatusIds !== undefined && this.param_workItem_Type === undefined) {
                    selectedstatusIds.forEach(p => {
                        if (o.StatusId === p.StatusId) {
                            o.IsSelected = p.IsSelected;
                        }
                    });
                }
                if (this.statusFilters.indexOf(o.StatusId) < 0) {
                    this.SelectedWorkItemstatus.push(o);
                    this.statusFilters.push(o.StatusId);
                }
            });
        });
        this.SelectedWorkItemstatus.sort(function (a, b) {
            const nameA = a.StatusIndex.toString().toLowerCase(),
                nameB = b.StatusIndex.toString().toLowerCase();
            if (nameA > nameB) {
                return 1;
            } else if (nameA < nameB) {
                return -1;
            }
            return 0;
        });

    }

    getUserMasterData(Param_workItem_Type: any, Param_workItem_Status: any) {
        if (!(Param_workItem_Type === undefined)) {
            this.workItem_Type_List = Param_workItem_Type.substring(0, Param_workItem_Type.length).split(',');
            this.UserWorkItemList = [];
        }
        if (!(Param_workItem_Status === undefined)) {
            this.workItem_Status_List = Param_workItem_Status.substring(0, Param_workItem_Status.length).split(',');
            this.WorkItemstatustype = [];
        }
        this.lstWorkitemUsers = [];
        this.getMasterData().subscribe((WorkIemResults) => {
            if (WorkIemResults != null) {
                if (WorkIemResults.strUNumber && WorkIemResults.lstUsers
                    && WorkIemResults.lstUsers.length > 0
                    && WorkIemResults.WorkItemDefault && WorkIemResults.WorkItemDefault.length > 0) {
                    if (!this.filterCondition.Type && !this.filterCondition.CobamId) {
                        this.filterCondition.Assignee = WorkIemResults.strUNumber;
                    }
                    this.lstWorkitemUsers = WorkIemResults.lstUsers;

                    this.WorkItemstatustype = [];
                    if (!this.WorkItemstatustype || this.WorkItemstatustype.length === 0) {
                        this.WorkItemstatustype = WorkIemResults.WorkItemStatus;
                        this.WorkItemstatustype.forEach(s => {
                            s.Text = s.DisplayText;
                            s.Id = s.StatusId;
                            if (!(this.workItem_Status_List === undefined) && this.workItem_Status_List.length > 0) {
                                for (const statusitem of this.workItem_Status_List) {
                                    if (s.StatusId == statusitem) {
                                        s.IsSelected = true;
                                        break;
                                    } else {
                                        s.IsSelected = false;
                                    }
                                }
                            } else {
                                s.IsSelected = true;
                            }
                        });

                        if (!(Param_workItem_Status === undefined)) {
                            this.WorkItemstatustype = this.WorkItemstatustype.filter(h => h.IsSelected == true);
                        }
                    }

                    if (!this.UserWorkItemList || this.UserWorkItemList.length === 0) {
                        this.UserWorkItemList = WorkIemResults.WorkItemDefault;

                        this.UserWorkItemList.forEach(s => {
                            s.Text = s.DisplayText;
                            if (!(this.workItem_Type_List === undefined) && this.workItem_Type_List.length > 0) {
                                for (const workitem of this.workItem_Type_List) {
                                    if (s.Id == workitem) {
                                        s.IsSelected = true;
                                        break;
                                    } else {
                                        s.IsSelected = false;
                                    }
                                }
                            } else {
                                s.IsSelected = true;
                            }
                        });

                        if (!(Param_workItem_Type === undefined)) {
                            this.UserWorkItemList = this.UserWorkItemList.filter(h => h.IsSelected == true);
                        }
                    }
                    if (!this.WorkItemStatus || this.WorkItemStatus.length === 0) {
                        this.WorkItemStatus = WorkIemResults.WorkItemStatusAll;
                    }
                    this.getWorkItemTypeAndStatus();
                }

                if (WorkIemResults.lstGroups && WorkIemResults.lstGroups.length > 0) {
                    this.IsAMTDashboardSuperUser = (WorkIemResults.lstGroups[0] == "AMTDashboardSuperUser") ? true : false;
                }
            }
            else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
            if (this.UserWorkItemList) {
                if (this.UserWorkItemList && this.UserWorkItemList.length > 0) {
                    this.filterCondition.Type = this.UserWorkItemList.
                        filter(o => o.IsSelected === true).map(({ Id }) => Id);
                    this.filterCondition.Status = this.WorkItemstatustype.
                        filter(o => o.IsSelected === true).map(({ Id }) => Id);
                }
            }

            this.GetUserWorkitemByFilter();

            this.alertService.indLoading = false;
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
                this.alertService.indLoading = false;
            });
    }

    GetWorkItemStatuslst() {
        this.statusFilters = [];
        this.SelectedWorkItemstatus = [];
        if (this.WorkItemFilters) {
            this.WorkItemFilters.forEach(wit => {
                this.WorkItemStatus.filter(o => o.WorkItem_Type === wit).forEach(ws => {
                    if (this.statusFilters.indexOf(ws.StatusId) < 0) {
                        this.statusFilters.push(ws.StatusId);
                        this.SelectedWorkItemstatus.push(ws);
                    }
                });
            });
        } else {
            this.UserWorkItemList.forEach(wit => {
                this.WorkItemStatus.filter(o => o.WorkItem_Type === wit.Id).forEach(ws => {
                    if (this.statusFilters.indexOf(ws.StatusId) < 0) {
                        this.statusFilters.push(ws.StatusId);
                        ws.Text = ws.DisplayText;
                        ws.IsSelected = true;
                        this.SelectedWorkItemstatus.push(ws);
                    }
                });
            });
        }
        this.SelectedWorkItemstatus.sort(function (a, b) {
            const nameA = a.StatusIndex.toString().toLowerCase(),
                nameB = b.StatusIndex.toString().toLowerCase();
            if (nameA > nameB) {
                return 1;
            } else if (nameA < nameB) {
                return -1;
            }
            return 0;
        });
    }
}