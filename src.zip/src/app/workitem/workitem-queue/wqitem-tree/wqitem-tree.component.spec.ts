import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WQItemTreeComponent } from './wqitem-tree.component';

describe('WQItemTreeComponent', () => {
  let component: WQItemTreeComponent;
  let fixture: ComponentFixture<WQItemTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WQItemTreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WQItemTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
