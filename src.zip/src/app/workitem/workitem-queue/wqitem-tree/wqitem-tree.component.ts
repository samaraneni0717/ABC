import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { AuthService } from "../../../Common/Auth/auth-service.service";
import { WorkitemService } from "../shared/workitem-queue.service";
import { SnackBarService } from "../../../Common/snackbar/snack-bar.service";
import { AlertService } from "../../../Common/services/alert.service";
import { WorkItem } from "../shared/Models/work-item";
import { UserRole } from "../../../Common/models/user-role";
import { environment } from "../../../../environments/environment";
import { Http, RequestOptions, Headers, URLSearchParams } from "@angular/http";
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";
import { debug } from "util";
@Component({
  selector: "app-wqitem-tree",
  templateUrl: "./wqitem-tree.component.html",
  styleUrls: ["./wqitem-tree.component.css"]
})
export class WQItemTreeComponent implements OnInit {
  @Input() filterValue;
  @Input() PageEventFired;
  @ViewChild("workItemParentChkBox") parentchkbox;
  userRoles: UserRole;
  pageEndingIndex: number;
  IsGroupVisibl = true;
  workitemCount;
  pageSize = 20;
  pageStartingIndex = 0;
  IsAscending = false;
  IsType = false;
  IsAssigneeSorted = false;
  IsStatusSorted = false;
  IsLegalSorted = false;
  IsLegalNameSorted = false;
  IsBusAcctSorted = false;
  IsBusAcctNameSorted = false;
  IsCreatedSorted = true;
  IsModifiedSorted = false;
  IsModifiedOn = false;
  IsModifiedBy = false;
  IsBusAcctDescriptionOfIssuesSorted = false;
  IsBusAcctShortNameSorted = false;
  hoverType;
  hoverAssignee;
  hoverStatus;
  hoverLegalId;
  hoverLegalName;
  hoverBusAcctId;
  hoverBUsAcctName;
  hoverCreated;
  hoverBUsAcctShortName;
  hoverBUsAcctDescriptionOfIssues;
  hoverModifiedOn;
  hoverModifiedBy;
  salesperson: boolean;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    public auth: AuthService,
    public _WorkitemService: WorkitemService,
    private SnackService: SnackBarService,
    private alertService: AlertService,
    private http: Http
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = function(){
      return false;
    };

    this.router.events.subscribe((evt) => {
        if (evt instanceof NavigationEnd) {
            // trick the Router into believing it's last link wasn't previously loaded
            this.router.navigated = false;
            // if you need to scroll back to top, here is the right place
            window.scrollTo(0, 0);
        }
    });
  }
  ngOnInit() {
    this.pageEndingIndex = this.pageStartingIndex + this.pageSize;
  }
  BindDetails(ExpandedItem: WorkItem) {
    ExpandedItem.IsExpanded = ExpandedItem.IsExpanded === true ? false : true;
  }
  SelectedUserChanged(Assignthisitem: WorkItem, ChangedEvent: any) {    
    this.GetUpdatedWorkItem(Assignthisitem.Id).subscribe(
      (DbWorkItem: WorkItem) => {
        if (
          DbWorkItem != null &&
          DbWorkItem.Assignee !== Assignthisitem.Assignee
        ) {
          if (
            DbWorkItem.ModifiedBy.toLocaleUpperCase() ===
            Assignthisitem.ModifiedBy.toLocaleUpperCase()
          ) {
            if(Assignthisitem.WorkItem_TypeCode === "APAC_Requests" || Assignthisitem.WorkItem_TypeCode === "APAC_CPI_Requests" || Assignthisitem.WorkItem_TypeCode === "APAC_Renewal" || 
                Assignthisitem.WorkItem_TypeCode === "Regulatory" || Assignthisitem.WorkItem_TypeCode === "CDD" || Assignthisitem.WorkItem_TypeCode === "Tax" || Assignthisitem.WorkItem_TypeCode === "Documentation" || Assignthisitem.WorkItem_TypeCode === "Secondary Review" ||
                    Assignthisitem.WorkItem_TypeCode === "Notification" || Assignthisitem.WorkItem_TypeCode === "Offboarding-CMT" || Assignthisitem.WorkItem_TypeCode === "Update Business Account"  ||
                Assignthisitem.WorkItem_TypeCode === "Update Business Account-Middle Market" || Assignthisitem.WorkItem_TypeCode === "Update Business Account - EMIR Regs" || Assignthisitem.WorkItem_TypeCode === "Notification - Missing Bus Mgr" || Assignthisitem.WorkItem_TypeCode === "BD SEC Exception Registration") {
                //do not change the status
            }
            else if (Assignthisitem.WorkItem_Type !== 6 ) {
              Assignthisitem.WorkItemStatus = 6;
              Assignthisitem.WorkItem_Status_DisplayText = "Open - Assigned";
            }         
            else {
              Assignthisitem.WorkItemStatus = 1;
              Assignthisitem.WorkItem_Status_DisplayText = "Open";
            }
            this.UpdateWorkItem(Assignthisitem);
            Assignthisitem.ModifiedBy = this.auth.userDetail.UNumber;
            Assignthisitem.ModifiedUser = this.auth.userDetail.FullName;
            Assignthisitem.ModifiedOn = new Date();
            Assignthisitem.User_Name = this._WorkitemService.lstWorkitemUsers.filter(
              o => o.UserId === ChangedEvent.value
            )[0].FullName;
            this.SnackService.openSnackBar("Data Updated Sucessfully", "");
          } else {
            this.RefreshWorkItem(Assignthisitem, DbWorkItem);
            this.SnackService.openSnackBar(
              "This workitem is already taken by anotheruser",
              ""
            );
          }
        }
      },
      error => {
        console.error(error);
        this.alertService.clear();
        this.alertService.warn(
          "Not able to communicate with Service Please try Again"
        );
      }
    );
  }
  SelectedsatusChangedItemChanged(UpdateStatus: WorkItem, ChangedEvent: any) {
    this.alertService.clear();
 
    this.GetUpdatedWorkItem(UpdateStatus.Id).subscribe(
      (DbWorkItem: WorkItem) => {
    
        if (DbWorkItem != null) {
          if (
            DbWorkItem.ModifiedBy.toLocaleUpperCase() ===
            UpdateStatus.ModifiedBy.toLocaleUpperCase()
          ) {
            UpdateStatus.IsSelected = true;
            this._WorkitemService.WorkItemStatus.forEach(obj => {
              if (
                obj.StatusId === UpdateStatus.WorkItemStatus &&
                obj.WorkItem_Type === UpdateStatus.WorkItem_Type
              ) {
                if((UpdateStatus.WorkItem_TypeCode	==="APAC_Requests" || UpdateStatus.WorkItem_TypeCode	==="APAC_CPI_Requests") 
                && (obj.DisplayText === "Approved" || obj.DisplayText === "Reject")
                && (UpdateStatus.Assignee == null || UpdateStatus.Assignee == ""))
                {
                  UpdateStatus.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Review").StatusId;
                  this.alertService.warn('Select an Assignee to Approved/Reject Work Item!');
                  return;
                }
                if ((UpdateStatus.WorkItem_TypeCode === "Offboarding-CMT")
                  && (obj.DisplayText === "Accept" || obj.DisplayText === "Reject")
                  && (UpdateStatus.Assignee == null || UpdateStatus.Assignee == "")) {
                  UpdateStatus.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Open").StatusId;            
                  this.alertService.warn('Select an Assignee to Approved/Reject Work Item!');
                  return;
                }

                UpdateStatus.IsActive = obj.IsWorkItemActive;
                UpdateStatus.prev_IsActive = DbWorkItem.IsActive;
                UpdateStatus.WorkItem_Status_DisplayText = obj.DisplayText;
                UpdateStatus.ModifiedBy = this.auth.userDetail.UNumber;
                UpdateStatus.ModifiedUser = this.auth.userDetail.FullName;
                UpdateStatus.ModifiedOn = new Date();
                if (
                  UpdateStatus.WorkItem_Status_DisplayText ===
                  "Open - Unassigned"
                ) {
                  UpdateStatus.Assignee = null;
                  UpdateStatus.User_Name = null;
                }
                // if((UpdateStatus.WorkItem_TypeCode	==="APAC_Requests" || UpdateStatus.WorkItem_TypeCode	==="APAC_CPI_Requests") 
                //     && (UpdateStatus.WorkItem_Status_DisplayText === "Approved" || UpdateStatus.WorkItem_Status_DisplayText === "Reject")
                //     && (UpdateStatus.Assignee == null || UpdateStatus.Assignee == ""))
                // {
                //   this.alertService.warn('Select an Assignee to Work Item!');
                //   UpdateStatus.IsActive = true;
                // }
                // else if((UpdateStatus.WorkItem_TypeCode	==="APAC_Requests" || UpdateStatus.WorkItem_TypeCode	==="APAC_CPI_Requests") 
                // && (UpdateStatus.WorkItem_Status_DisplayText === "Approved" || UpdateStatus.WorkItem_Status_DisplayText === "Reject"))
                // {
                //   UpdateStatus.IsActive = false;
                // }
              }
            });
          } else {
            this.RefreshWorkItem(UpdateStatus, DbWorkItem);
            this.SnackService.openSnackBar(
              "This workitem is already Updated",
              ""
            );
          }
        }
      },
      error => {
        console.error(error);
        this.alertService.clear();
        this.alertService.warn(
          "Not able to communicate with Service Please try Again"
        );
      }
    );
  }
  applyStatusChange(ExpandedItem: WorkItem, changedStatus: number) {
    ExpandedItem.IsSelected = true;
    ExpandedItem.WorkItemStatus = changedStatus;
    this._WorkitemService.WorkItemStatus.forEach(obj => {
      if (
        obj.StatusId === ExpandedItem.WorkItemStatus &&
        obj.WorkItem_Type === ExpandedItem.WorkItem_Type
      ) {
        ExpandedItem.IsActive = obj.IsWorkItemActive;
        ExpandedItem.WorkItem_Status_DisplayText = obj.DisplayText;
      }
    });
    this.SelectedItemChanged(ExpandedItem);
  }
  RefreshWorkItem(item: WorkItem, newitem: WorkItem) {
    item.Assignee = newitem.Assignee;
    item.WorkItemStatus = newitem.WorkItemStatus;
    item.WorkItem_Status_DisplayText = newitem.WorkItem_Status_DisplayText;
    item.User_Name = newitem.User_Name;
    item.ModifiedBy = newitem.ModifiedBy;
    item.ModifiedOn = newitem.ModifiedOn;
    item.ModifiedUser = newitem.ModifiedUser;
    item.IsActive = newitem.IsActive;
    item.Prev_Assignee = newitem.Assignee;
    item.IsSelected = false;
  }
  SelectedItemChanged(ExpandedItem?: WorkItem, changed?) {
    if (ExpandedItem) {
      if (changed) {
        ExpandedItem.IsSelected = !ExpandedItem.IsSelected;
        if (!ExpandedItem.IsSelected) {
          this._WorkitemService.WorkItemStatus.forEach(obj => {
            if (
              obj.StatusId === ExpandedItem.prev_WorkItemStatus &&
              obj.WorkItem_Type === ExpandedItem.WorkItem_Type
            ) {
              ExpandedItem.WorkItem_Status_DisplayText = obj.DisplayText;
              ExpandedItem.IsActive = ExpandedItem.prev_IsActive;
              ExpandedItem.WorkItemStatus = ExpandedItem.prev_WorkItemStatus;
            }
          });
        }
      }
      if (ExpandedItem.IsSelected) {
        this._WorkitemService.WorkItemQueueSelectedList.push(ExpandedItem);
      } else {
        const index: number = this._WorkitemService.WorkItemQueueSelectedList.indexOf(
          ExpandedItem
        );
        if (index !== -1) {
          this._WorkitemService.WorkItemQueueSelectedList.splice(index, 1);
        }
      }
    }
    if (this.parentchkbox) {
      if (this._WorkitemService.WorkItemQueueSelectedList.length === 0) {
        this.parentchkbox.nativeElement.checked = false;
        this.parentchkbox.nativeElement.indeterminate = false;
      } else if (
        this._WorkitemService.WorkItemQueueSelectedList.length ===
        this._WorkitemService.WorkItemQueueFilteredList.length
      ) {
        this.parentchkbox.nativeElement.checked = true;
        this.parentchkbox.nativeElement.indeterminate = false;
      } else {
        this.parentchkbox.nativeElement.checked = false;
        this.parentchkbox.nativeElement.indeterminate = true;
      }
    }
  }
  CheckChangedAll(Source) {
    this._WorkitemService.WorkItemQueueFilteredList.forEach(element => {
      if (element.IsActive) {
        if (Source.srcElement.checked) {
          element.IsSelected = true;
        } else {
          element.IsSelected = false;
        }
      }
    });
  }
  OnPageSizeChanged(pageEvent) {
    if (pageEvent) {
      this._WorkitemService.filterCondition.pageSize = pageEvent.pageSize;
      this._WorkitemService.filterCondition.pageNumber =
        1 + pageEvent.pageIndex;
      this._WorkitemService.getlstworkitemByFilter(undefined, undefined);
    }
  }
  UpdateWorkItem(WorkItemToUpdate: WorkItem) {
    const CurrentItem: WorkItem[] = [];
    CurrentItem.push(WorkItemToUpdate);
    const headers = new Headers({ "Content-Type": "application/json" });
    const options = new RequestOptions({ headers: headers });
    const body = JSON.stringify({
      CurrentItem: CurrentItem,
      strUNumber: this.auth.userDetail.UNumber
    });
    this.http
      .put(environment.BASEURL + "Workitem", body, options)
      .toPromise()
      .catch(this.handleErrorPromise);
  }
  GetUpdatedWorkItem(WorkItemId: number) {
    const myParams = new URLSearchParams();
    myParams.append("WorkItemId", WorkItemId.toString());
    myParams.append("strUNumber", this.auth.userDetail.UNumber);
    const options = new RequestOptions({ params: myParams });
    return this.http
      .get(environment.BASEURL + "Workitem", options)
      .pipe(map((response: Response) => response.json()));
  }
  GetWorkItemStatusbyRole(workItemStatusId: number) {
    const myParams = new URLSearchParams();
    myParams.append("workItemStatusId", workItemStatusId.toString());
    myParams.append("strUNumber", this.auth.userDetail.UNumber);
    const options = new RequestOptions({ params: myParams });
    return this.http
      .get(environment.BASEURL + "WorkItemSK/GetWorkItemStatus", options)
      .pipe(map((response: Response) => response.json()));
  }

  getUserRole():Observable<any>{
    const myParams = new URLSearchParams();
    myParams.append('strUNumber', this.auth.userDetail.UNumber);
    const options = new RequestOptions({ params: myParams });
    return this.http.get(environment.BASEURL + 'WorkItemSK/GetUserSalesRole', options)
      .pipe(map((response: Response) => 
      {
        console.log(response);
        return response.json()
    }));
  }
  DisableStatus() {
      this.getUserRole().subscribe((data) => {
        if(data.result.salesperson = true) {
          this.salesperson = true;
           return true;
        } else {
          this.salesperson = false;
         return false;
        }
        }); 
  }

  private extractData(_res?: Response) {}
  handleErrorPromise(error: Response | any) {}
  sortTheField(sortEvent) {
    this.IsAscending = !this.IsAscending;
  }
  SortButtonClicked(sortEvent) {
    this._WorkitemService.filterCondition.sortExpression = this.IsAscending
      ? "-" + sortEvent.currentTarget.id
      : sortEvent.currentTarget.id;
    this._WorkitemService.getlstworkitemByFilter(undefined, undefined);
    if (sortEvent.currentTarget.id === "WorkItem_Type_DisplayText") {
      this.IsType = true;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "User_Name") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = true;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "WorkItem_Status_DisplayText") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = true;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "LegalId") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = true;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "Legal_FullName") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = true;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "AcctId") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = true;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "Acct_FullName") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = true;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "CreatedOn") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = true;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "ModifiedOn") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = true;
      this.IsModifiedOn = true;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "ModifiedUser") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = true;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "Acct_ShortName") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = false;
      this.IsBusAcctShortNameSorted = true;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    } else if (sortEvent.currentTarget.id === "Acct_DescriptionOfIssues") {
      this.IsType = false;
      this.hoverType = false;
      this.IsAssigneeSorted = false;
      this.hoverAssignee = false;
      this.IsStatusSorted = false;
      this.hoverStatus = false;
      this.IsLegalSorted = false;
      this.hoverLegalId = false;
      this.IsLegalNameSorted = false;
      this.hoverLegalName = false;
      this.IsBusAcctSorted = false;
      this.hoverBusAcctId = false;
      this.IsBusAcctNameSorted = false;
      this.hoverBUsAcctName = false;
      this.IsCreatedSorted = false;
      this.hoverCreated = false;
      this.IsModifiedSorted = false;
      this.IsModifiedOn = false;
      this.hoverModifiedOn = false;
      this.IsModifiedBy = false;
      this.hoverModifiedBy = false;
      this.IsBusAcctDescriptionOfIssuesSorted = true;
      this.IsBusAcctShortNameSorted = false;
      this.hoverBUsAcctShortName = false;
      this.hoverBUsAcctDescriptionOfIssues = false;
    }
    this.IsAscending = !this.IsAscending;
  }
}
