import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { WorkitemQueueDetailsComponent } from './workitem-queue-details.component';
describe('WorkitemQueueDetailsComponent', () => {
  let component: WorkitemQueueDetailsComponent;
  let fixture: ComponentFixture<WorkitemQueueDetailsComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkitemQueueDetailsComponent ]
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(WorkitemQueueDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
