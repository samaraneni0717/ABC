import {
  Component,
  OnInit,
  ViewChild,
  Input,
  DoCheck,
  CUSTOM_ELEMENTS_SCHEMA
} from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { SnackBarService } from '../../../Common/snackbar/snack-bar.service';
import {
  MatSort,
  MatDialog,
  MatTableDataSource,
  MatPaginator
} from '@angular/material';
import { WorkItem, WorkItemEXT } from '../shared/Models/work-item';
import { Http, RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { map } from 'rxjs/operators';
import { FileNetDocInfo } from '../shared/Models/workitem-filenet.model';
import { WorkItemHistory } from '../shared/Models/workitem-history.model';
import { WorkItemChangeLog } from '../shared/Models/workitem-change-log.model';
import { WorkitemService } from '../shared/workitem-queue.service';
import { AlertService } from '../../../Common/services/alert.service';
import { environment } from '../../../../environments/environment';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { isNullOrUndefined } from 'util';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { DetailRequestService } from 'src/app/maintenance-requests/shared/services/mt-detail-request.service';
import { AttachmentInfo } from '../shared/Models/workitem-safekeeping';
import { SafekeepingAttachmentService } from '../shared/workitem-safekeeping.service';
import { WorkItemUpdateRequestDetails } from '../shared/Models/workitem-UpdateRequestDetails';
import { WorkItemVolckerHitDetails } from '../shared/Models/workitem-VolckerHitDetails';
import { SubworkitemLog } from '../shared/Models/subworkitem-log.model';
import { ChangedPath } from 'ag-grid-community';

@Component({
  selector: 'app-workitem-queue-details',
  templateUrl: './workitem-queue-details.component.html',
  styleUrls: ['./workitem-queue-details.component.css']
})
export class WorkitemQueueDetailsComponent implements OnInit, DoCheck {
  @Input() selectedWorkitem: WorkItem;
  modalRef: NgbModalRef;
  // attachmentfiledata: any;
  filenetDisplayedColumns: string[] = [
    'Date',
    'DTSDocId',
    'DocumentTitle',
    'LegalName'
  ];

  attachmentDisplayedColumns: string[] = [
    'FileName',
    'Description',
    'CreatedBy',
    'CreatedDate'
  ];
  changeLogDisplayedColumns: string[] = [
    'Field',
    'OldValue',
    'NewValue',
    'ChangeDate',
    'ChangeOperation',
    'ChangeByApplication',
    'ChangeByUser',
    'ValidationDetails'
  ];
  historyDisplayedColumns: string[] = [
    'Assignee',
    'Status',
    'ChangeDate',
    'ChangeOperation',
    'ChangeByApplication',
    'ChangeByUser'
  ];
  UpdateChangeRequestDisplayedColumns: string[] = [
    'Id',
    'FieldDescription',
    'OldValue',
    'NewValue',
    'ChangeType',
    'ActionCode'
  ];
  SubWorkItemLogDisplayedColumns: string[] = [
      'Name',
      'Status',
      'SubStatus',
      'ChangeDate',
      'ChangeOperation',
      'ChangeByApplication',
      'ChangeByUser'
  ];

  VolckerHitDisplayedColumns: string[] = [
      'LegalId',
      'External',
      'ExternalId',
      'LegalName',
      'VolckerFlag'
  ];


  fileNetDataSource: MatTableDataSource<FileNetDocInfo>;
  attachmentDataSource: MatTableDataSource<AttachmentInfo>;
  @ViewChild(MatPaginator) fileNetPaginator: MatPaginator;
  @ViewChild(MatSort) fileNetSort: MatSort;
  changeLogDataSource: MatTableDataSource<WorkItemChangeLog>;
  @ViewChild(MatPaginator) changeLogPaginator: MatPaginator;
  @ViewChild(MatSort) changeLogSort: MatSort;
  historyDataSource: MatTableDataSource<WorkItemHistory>;
  SubWorkItemLogDataSource: MatTableDataSource<SubworkitemLog>;
  updateRequestDataSource: MatTableDataSource<WorkItemUpdateRequestDetails>;
  VolckerHitDataSource: MatTableDataSource<WorkItemVolckerHitDetails>;
  @ViewChild(MatPaginator) historyPaginator: MatPaginator;
  @ViewChild(MatPaginator) attachmentPaginator: MatPaginator;
  @ViewChild(MatSort) historySort: MatSort;
  @ViewChild(MatPaginator) SubWorkItemLogPaginator: MatPaginator;
  @ViewChild(MatSort) SubWorkItemLogSort: MatSort;

  selectedWorkItemExt;
  UpdateRequestCount;
  UpdateRequestCOBAMTag;
  UpdateRequestCOBAMNumber;
  UpdateRequestNotification;
  isAccountPresentInCID: boolean;
  workitemObject;
  message: string;
  CIDBUSAcct;
  cobamId;
  cobamMaintenanceId;
  attachmentID;
  url: string;
  // url: string = "http://localhost:4500/";
  urlSafe: SafeResourceUrl;
  selectedWorkItemExtLoading: boolean;
  constructor(
    private SnackService: SnackBarService,
    public dialog: MatDialog,
    private http: Http,
    private _WorkitemService: WorkitemService,
    private alertService: AlertService,
    private auth: AuthService,
    private safekeepingAttachmentService: SafekeepingAttachmentService,
    public sanitizer: DomSanitizer
  ) {}
  @ViewChild(MatSort) sortDtl: MatSort;
  ngOnInit() {
      
      this.message = '';
    this.getworkitemExt(
      this.selectedWorkitem.Id,
      this.selectedWorkitem.WorkItem_Type
    );


    if (this.selectedWorkitem.WorkItem_TypeCode == 'Update Business Account' || this.selectedWorkitem.WorkItem_TypeCode == 'Update Business Account-Middle Market' || this.selectedWorkitem.WorkItem_TypeCode == 'Update Business Account-Notification' || this.selectedWorkitem.WorkItem_TypeCode == 'Update Business Account - EMIR Regs') {
        this.getUpdateRequestDetails(this.selectedWorkitem.Id);
    }  

    if (this.selectedWorkitem.WorkItem_TypeCode == 'Volcker_Notification') {
        this.getVolckerHitDetails(this.selectedWorkitem.Id);
    }  

    if (this.selectedWorkitem.WorkItem_TypeCode == 'Regulatory' || this.selectedWorkitem.WorkItem_TypeCode == 'CDD' || this.selectedWorkitem.WorkItem_TypeCode == 'Tax' || this.selectedWorkitem.WorkItem_TypeCode == 'Documentation' || this.selectedWorkitem.WorkItem_TypeCode == 'Secondary Review') {
        this.getWorkItemNotes(this.selectedWorkitem.Id);
    }      

    if (this.selectedWorkitem.WorkItem_TypeCode == 'APAC_Renewal') {
      this.getWorkItemNotes(this.selectedWorkitem.Id);
    }
    if (this.selectedWorkitem.WorkItem_TypeCode == 'BD SEC Exception Registration') {
      this.getWorkItemObjectData(this.selectedWorkitem.Id);
    }
  }
  getWorkItemObjectData(Id: number) {
    this.workitemObject = undefined;
    this.GetWorkItemObject(this.selectedWorkitem.Id).subscribe(
      WorkIemResults => {
        if (WorkIemResults != null) {
          if (WorkIemResults) {
            this.workitemObject = WorkIemResults;
          } else {
            this.workitemObject = 'No Data Available';
          }
        } else {
          this.alertService.warn('Something went wrong please Try Again!');
        }
      },
      error => {
        console.error(error);
        this.alertService.clear();
        this.alertService.warn(
          'Not able to communicate with Service Please try Again'
        );
      }
    );
  }
  getworkitemExt(Id: number, WorkItem_Type: number): any {
      
      this.selectedWorkItemExtLoading = true;
      this._WorkitemService.getSelectedWorkItemExt(Id, WorkItem_Type).subscribe(
      WorkIemResults => {
        if (WorkIemResults != null) {
            if (WorkIemResults) {
                if (this.selectedWorkitem.WorkItem_TypeCode == 'Regulatory' || this.selectedWorkitem.WorkItem_TypeCode == 'CDD' || this.selectedWorkitem.WorkItem_TypeCode == 'Tax' || this.selectedWorkitem.WorkItem_TypeCode == 'Documentation' || this.selectedWorkitem.WorkItem_TypeCode == 'Secondary Review') {
                    //this.selectedWorkItemExtList = WorkIemResults;
                    this.selectedWorkitem.WorkItemEXT = WorkIemResults;
                }
                else {
                    this.selectedWorkItemExt = WorkIemResults[0];
                    this.selectedWorkitem.WorkItemEXT = WorkIemResults;
                }
              
                       
            }
          
          }
        this.selectedWorkItemExtLoading = false;
      },
      error => {
          this.selectedWorkItemExtLoading = false;
        console.error(error);
        this.alertService.clear();
        this.alertService.warn(
          'Not able to communicate with Service Please try Again'
        );
      }
    );
  }
  getWorkItemNotes(Id: number) {
      this._WorkitemService.getWorkItemNotes(Id).subscribe(
          results => {
              if (results) {
                  this.selectedWorkitem.WorkItemNote = results;

              } 
          }, error => {
              console.error(error);
              this.alertService.clear();
              this.alertService.warn(
                  'Not able to communicate with Service, Please try Again'
              );
              this.selectedWorkitem.WorkItemNote = null;             
          }
      );
  }

  getUpdateRequestDetails(Id:number){
    this._WorkitemService.GetUpdateRequestWorkItem(Id).subscribe(
    results => {
      if (results != null) {
        if (results.UpdateDetails && results.UpdateDetails.length > 0) {
        
          this.alertService.clear();
          this.updateRequestDataSource = new MatTableDataSource(results.UpdateDetails);
          this.UpdateRequestCount = results.UpdateDetails[0].WICount; //results.UpdateDetails.length;
          this.UpdateRequestCOBAMTag = 'COBAM Number:';
          this.UpdateRequestCOBAMNumber = results.UpdateDetails[0].COBAMId;
          if (this.UpdateRequestCOBAMNumber == '')
          {
              this.UpdateRequestCOBAMTag = 'POQ Number:';
              this.UpdateRequestCOBAMNumber = results.UpdateDetails[0].BusAcctId;
          }
          this.UpdateRequestNotification = results.UpdateDetails[0].Notification;
         
        } else {
          this.alertService.warn('No Datafound..');
          this.updateRequestDataSource = new MatTableDataSource(null);
          this.UpdateRequestCount=0;

        }
      } else {
        this.alertService.warn('Something went wrong please Try Again!');
        this.updateRequestDataSource = new MatTableDataSource(null);
        this.UpdateRequestCount=0;
      }
    },error => {
      console.error(error);
      this.alertService.clear();
      this.alertService.warn(
        'Not able to communicate with Service, Please try Again'
      );
      this.updateRequestDataSource = new MatTableDataSource(null);
      this.UpdateRequestCount=0;
    }
  );
  }

  getVolckerHitDetails(Id: number) {
      this._WorkitemService.GetVolckerHitWorkItem(Id).subscribe(
          results => {
              if (results != null) {
                  if (results.VolckerDetails && results.VolckerDetails.length > 0) {

                      this.alertService.clear();
                      this.VolckerHitDataSource = new MatTableDataSource(results.VolckerDetails);

                  } else {
                      this.alertService.warn('No Datafound..');
                      this.VolckerHitDataSource = new MatTableDataSource(null);


                  }
              } else {
                  this.alertService.warn('Something went wrong please Try Again!');
                  this.VolckerHitDataSource = new MatTableDataSource(null);
              }
          }, error => {
              console.error(error);
              this.alertService.clear();
              this.alertService.warn(
                  'Not able to communicate with Service, Please try Again'
              );
              this.VolckerHitDataSource = new MatTableDataSource(null);
          }
      );
  }
  OpenBusAcctIdinCID(busAcctId) {
      this.url = this.auth.configuration.CIDURL;// + "GetBusAccount?id=" + busAcctId;
      console.log(this.url);
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);

      window.open(this.url)
  }
  getCobamId(workItemId) {
    this._WorkitemService.GetCOBAMID(workItemId).subscribe(response => {
      this.cobamId = response.result;
    });
  }
  getSelectedWorkItemExt(workItemId: number, WorkItem_Type: number) {
    const myParams = new URLSearchParams();
    myParams.append('workItemId', workItemId.toString());
    myParams.append('WorkItem_Type', WorkItem_Type.toString());
    myParams.append('strUNumber', this.auth.userDetail.UNumber);
    const options = new RequestOptions({ params: myParams });
    return this.http
      .get(environment.BASEURL + 'WorkitemEXT', options)
      .pipe(map((response: Response) => response.json()));
  }

  SelectedSubWorkItemSatusChangedItemChanged(UpdateStatus: WorkItemEXT, ChangedEvent: any) { 
      
      if ((UpdateStatus.Status.indexOf('Pending') > -1 || UpdateStatus.Status.indexOf('Managerial Override') > -1) && (UpdateStatus.SubStatusOption != undefined && UpdateStatus.SubStatusOption != null && UpdateStatus.SubStatusOption != '')) {
          UpdateStatus.SubStatus = '';          
      } 

      if (this.selectedWorkitem.WorkItemEXT.find(item => item.Status.indexOf("Pending") > -1 || (item.Status == undefined || item.Status == null || item.Status == '')))
      {          
          this.selectedWorkitem.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Pending").StatusId;
          this.selectedWorkitem.WorkItem_Status_DisplayText = "Pending";
      }
      else if (this.selectedWorkitem.WorkItemEXT.find(item => item.Status.indexOf('Pending') == -1 && item.Status.indexOf('Managerial Override') == -1 && (item.SubStatusOption != undefined && item.SubStatusOption != null && item.SubStatusOption != '') && (item.SubStatus == undefined || item.SubStatus == null || item.SubStatus == ''))) {
          this.selectedWorkitem.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Pending").StatusId;
          this.selectedWorkitem.WorkItem_Status_DisplayText = "Pending";
      }
      else {
          this.selectedWorkitem.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Complete").StatusId;
          this.selectedWorkitem.WorkItem_Status_DisplayText = "Complete";
      }   
  }
  SelectedSubWorkItemSubSatusChangedItemChanged(UpdateSubStatus: WorkItemEXT, ChangedEvent: any) {
      
      if (this.selectedWorkitem.WorkItemEXT.find(item => item.Status.indexOf("Pending") > -1 || (item.Status == undefined || item.Status == null || item.Status == ''))) {
          this.selectedWorkitem.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Pending").StatusId;
          this.selectedWorkitem.WorkItem_Status_DisplayText = "Pending";
      }
      else if (this.selectedWorkitem.WorkItemEXT.find(item => item.Status.indexOf('Pending') == -1 && item.Status.indexOf('Managerial Override') == -1 && (item.SubStatusOption != undefined && item.SubStatusOption != null && item.SubStatusOption != '') && (item.SubStatus == undefined || item.SubStatus == null || item.SubStatus == ''))) {
          this.selectedWorkitem.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Pending").StatusId;
          this.selectedWorkitem.WorkItem_Status_DisplayText = "Pending";
      }
      else {
          this.selectedWorkitem.WorkItemStatus = this._WorkitemService.WorkItemStatus.find(s => s.DisplayText == "Complete").StatusId;
          this.selectedWorkitem.WorkItem_Status_DisplayText = "Complete";
      }
  }

  SelectedHongkongClassificationChanged(workItem: WorkItem, ChangedEvent: any) {
    workItem.IsSelected = true;
  }

  SelectedProductGroupMarCoverageChanged(workItem: WorkItem, ChangedEvent: any) {
    workItem.IsSelected = true;
  }
  
  CheckIfAccountEcistInCID(txtvalue): any {
    if (
      txtvalue &&
      txtvalue.fromElement &&
      txtvalue.fromElement.value &&
      txtvalue.fromElement.value.length > 0 &&
      (this.CIDBUSAcct ? this.CIDBUSAcct : '') !== txtvalue.fromElement.value
    ) {
      this.CIDBUSAcct = txtvalue.fromElement.value;
      this.iscountExistsInCID(this.CIDBUSAcct).subscribe(
        AccountPresent => {
          if (AccountPresent === true) {
            this.selectedWorkitem.BusAcctId = txtvalue.fromElement.value;
            this.selectedWorkItemExt.bus_a_id_c = txtvalue.fromElement.value;
            this.isAccountPresentInCID = true;
            this.message = '';
          } else {
            if (AccountPresent === false) {
              this.message = 'Account Is not present in CID Please Check Again';
            } else {
              this.message = AccountPresent.toString();
            }
            this.isAccountPresentInCID = false;
            this.selectedWorkitem.BusAcctId = null;
            this.SnackService.openSnackBar(this.message, '');
          }
        },
        error => {
          console.error(error);
          this.alertService.clear();
          this.alertService.warn(
            'Not able to communicate with Service Please try Again'
          );
        }
      );
    }
  }
  iscountExistsInCID(workItemId: number) {
    const myParams = new URLSearchParams();
    myParams.append('Id', workItemId.toString());
    myParams.append('strUNumber', this.auth.userDetail.UNumber);
    const options = new RequestOptions({ params: myParams });
    return this.http
      .get(
        environment.BASEURL + 'WorkItemEXT/GETCheckIfAccountExistsInCID',
        options
      )
      .pipe(map((response: Response) => response.json()));
  }
  ngDoCheck() {}
  openSnackBar() {
    this.SnackService.openSnackBar('Data Updated Sucessfully', '');
  }
  openFilenet(template): void {
    const dialogRef = this.dialog.open(template, {
      width: '250px'
    });
  }
  openWorkItemHIstory(template): void {
    const dialogRef = this.dialog.open(template, {
      width: '800px'
    });
  }

  onNoClick(): void {
    this.dialog.closeAll();
  }
  openModalObject(template) {
    this.getWorkItemObjectData(this.selectedWorkitem.Id);
    const dialogRef = this.dialog.open(template, {
      width: '60%'
    });
  }
  GetWorkItemObject(workItemId: number) {
    const myParams = new URLSearchParams();
    myParams.append('WorkItemIdForObj', workItemId.toString());
    myParams.append('strUNumber', this.auth.userDetail.UNumber);
    const options = new RequestOptions({ params: myParams });
    return this.http
      .get(environment.BASEURL + 'WorkItem', options)
      .pipe(map((response: Response) => response.json()));
  }

  openModal(template, modalType, oldItemId): void {
    if (modalType === 1 && this.selectedWorkitem.LegalId > 0) {
      // FileNet
      this.alertService.indLoading = true;
      this._WorkitemService
        .GetFileNetDocInfoList(this.selectedWorkitem.LegalId)
        .subscribe(
          docResults => {
            if (docResults != null) {
              if (
                docResults.fileNetDocInfoList &&
                docResults.fileNetDocInfoList.length > 0
              ) {
                this.alertService.clear();
                this.fileNetDataSource = new MatTableDataSource(
                  docResults.fileNetDocInfoList
                );
                this.fileNetDataSource.paginator = this.fileNetPaginator;
                this.fileNetDataSource.sort = this.fileNetSort;
              } else {
                this.alertService.warn('No Datafound..');
                this.fileNetDataSource = new MatTableDataSource(null);
              }
            } else {
              this.alertService.warn('Something went wrong please Try Again!');
              this.fileNetDataSource = new MatTableDataSource(null);
              }
            this.alertService.indLoading = false;
          },
          error => {
            console.error(error);
            this.alertService.clear();
            this.alertService.warn(
              'Not able to communicate with Service, Please try Again'
            );
            this.fileNetDataSource = new MatTableDataSource(null);
            this.alertService.indLoading = false;
          }
        );
      const dialogRef = this.dialog.open(template, {
        width: '60%'
      });
    } else if (modalType === 2 && this.selectedWorkitem.Id > 0) {
      // Change Log
        this.alertService.indLoading = true;
      this._WorkitemService
        .GetWorkItemChangeLog(this.selectedWorkitem.Id)
        .subscribe(
          results => {
            if (results != null) {
              if (results.changeLog && results.changeLog.length > 0) {
                this.alertService.clear();

                this.changeLogDataSource = new MatTableDataSource(
                  results.changeLog
                );
                this.changeLogDataSource.paginator = this.changeLogPaginator;
                this.changeLogDataSource.sort = this.changeLogSort;
              } else {
                this.alertService.warn('No Datafound..');
                this.changeLogDataSource = new MatTableDataSource(null);
              }
            } else {
              this.alertService.warn('Something went wrong please Try Again!');
              this.changeLogDataSource = new MatTableDataSource(null);
              }
            this.alertService.indLoading = false;
          },
          error => {
            console.error(error);
            this.alertService.clear();
            this.alertService.warn(
              'Not able to communicate with Service, Please try Again'
            );
            this.changeLogDataSource = new MatTableDataSource(null);
            this.alertService.indLoading = false;
          }
        );

      const dialogRef = this.dialog.open(template, {
        width: '80%'
      });
    } else if (modalType === 3 && this.selectedWorkitem.Id > 0) {
      // History
        this.alertService.indLoading = true;
      let dataWorkItem = this.selectedWorkitem.Id;
      if (!isNullOrUndefined(oldItemId)) {
        dataWorkItem = oldItemId;
      }

      this._WorkitemService.GetWorkItemHistory(dataWorkItem).subscribe(
        results => {
          if (results != null) {
            if (results.history && results.history.length > 0) {
              this.alertService.clear();

              this.historyDataSource = new MatTableDataSource(results.history);
              this.historyDataSource.paginator = this.historyPaginator;
              this.historyDataSource.sort = this.historySort;
            } else {
              this.alertService.warn('No Datafound..');
              this.historyDataSource = new MatTableDataSource(null);
            }
          } else {
            this.alertService.warn('Something went wrong please Try Again!');
            this.historyDataSource = new MatTableDataSource(null);
            }
          this.alertService.indLoading = false;
        },
        error => {
          console.error(error);
          this.alertService.clear();
          this.alertService.warn(
            'Not able to communicate with Service, Please try Again'
          );
          this.historyDataSource = new MatTableDataSource(null);
          this.alertService.indLoading = false;
        }
      );

      const dialogRef = this.dialog.open(template, {
        width: '60%'
      });
    } else if (modalType === 4) {
      // History
      this.url = 'http://localhost:4500/';
      this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);

      const dialogRef = this.dialog.open(template, {
        width: '60%'
      });
    }
  }


  openModalSubWorkItemLog(template, selectedSubWI: WorkItemEXT) {
      this.alertService.indLoading = true;
      this._WorkitemService.GetSubWorkItemLog(selectedSubWI.Id).subscribe(
          results => {
              if (results != null) {
                  if (results.subWorkItemLog && results.subWorkItemLog.length > 0) {
                      this.alertService.clear();

                      this.SubWorkItemLogDataSource = new MatTableDataSource(results.subWorkItemLog);
                      this.SubWorkItemLogDataSource.paginator = this.SubWorkItemLogPaginator;
                      this.SubWorkItemLogDataSource.sort = this.SubWorkItemLogSort;
                  } else {
                      this.alertService.warn('No Datafound..');
                      this.SubWorkItemLogDataSource = new MatTableDataSource(null);
                  }
              } else {
                  this.alertService.warn('Something went wrong please Try Again!');
                  this.SubWorkItemLogDataSource = new MatTableDataSource(null);
              }
              this.alertService.indLoading = false;
          },
          error => {
              console.error(error);
              this.alertService.clear();
              this.alertService.warn(
                  'Not able to communicate with Service, Please try Again'
              );
              this.SubWorkItemLogDataSource = new MatTableDataSource(null);
              this.alertService.indLoading = false;
          }
      );

      const dialogRef = this.dialog.open(template, {
          width: '80%'
      });
  }

  openAttachmentModel(template, workItemId): void {
    this._WorkitemService.GetCOBAMID(workItemId).subscribe(response => {
      this.cobamMaintenanceId = response.result.COBAMMaintenanceId;
      if (this.cobamMaintenanceId !== null) {
        this.getAttachments(this.cobamMaintenanceId);
        const dialogRef = this.dialog.open(template, {
          width: '60%'
        });
      }
    });
  }

  getAttachments(cobamMaintenanceId): void {
    this.safekeepingAttachmentService
      .getAttachments(cobamMaintenanceId)
      .subscribe(data => {
        if (data != null) {
          if (data.attachments && data.attachments.length > 0) {
            console.log('The data is ', data.attachments);
            this.alertService.clear();
            this.attachmentDataSource = new MatTableDataSource(
              data.attachments
            );
            this.attachmentDataSource.paginator = this.attachmentPaginator;
          } else {
            this.alertService.warn('No Datafound..');
            this.attachmentDataSource = new MatTableDataSource(null);
          }
        }
      });
  }

  getdocument(attachmentID): void {
      window.open(environment.BASEURL + "Attachment/GetDocument/?attachmentID="+ attachmentID, "_blank");
  }

  selectDocumentrow(value: any) {

    console.log('AttachmentID', value.AttachmentID);
    this.attachmentID = value.AttachmentID;
    if (this.attachmentID != null) {
      this.getdocument(this.attachmentID);
    }
  }
  OpenSKLink(template,workItemTypeCode,workItemId,status){
      this.url =  this.auth.configuration.SKUtilityURL +"#/Safekeeping/WorkItem/"+workItemTypeCode+"/"+workItemId+"/"+status+"/"+this.auth.userDetail.UNumber;
      //this.url =  "http://localhost:4200/#"+"/Safekeeping/WorkItem/"+workItemTypeCode+"/"+workItemId+"/"+status+"/"+this.auth.userDetail.UNumber;
      console.log(this.url);
        this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);
  
        const dialogRef = this.dialog.open(template, {
            width: '80%'
        });
}
  ViewCOBAMId(template, workItemId) {
    this._WorkitemService.GetCOBAMID(workItemId).subscribe(response => {
      this.cobamId = response.result.COBAMId;
      const dialogRef = this.dialog.open(template, {
        width: '20%'
      });
    });
  }
/*
  OpenFileNetUrl(docId): void {
    if (docId) {
      const myPopup = window.open('', 'FileNetDoc_' + docId);
      let docUrl = '';
      this._WorkitemService.GetDocumentUrl(docId).subscribe(
        result => {
          if (result != null) {
            if (result.docUrl) {
              this.alertService.clear();

              docUrl = result.docUrl;
            } else {
              this.alertService.warn('No Datafound..');
            }
          } else {
            this.alertService.warn('Something went wrong, please Try Again!');
          }
        },
        error => {
          console.error(error);
          this.alertService.clear();
          this.alertService.warn(
            'Not able to communicate with Service, Please try Again'
          );
        },
        () => {
          // when complete

          myPopup.location.href = docUrl;
        }
      );
    }
  }
    */

  OpenFileNetUrl(docId): void {
      window.open(environment.BASEURL + "FileNet/?DocumentId=" + docId, "_blank");
  }

  openAPACDetails(requestId, COBAMNumber): void {
    if (COBAMNumber.substring(0, 1) == 'M') {
      window.open(
        environment.BASEURL + '#/maintenance/detail?id=' + requestId + '&requestType=Legal Changes&requestSubType=Hong Kong Classification%20Refresh',
        '_blank'
      );
    } else {
      window.open(
        this.auth.configuration.SALESFORCEURL.substring(
          0,
          this.auth.configuration.SALESFORCEURL.length - 5
        ) + requestId,
        '_blank'
      );
    }
  }

  openMiFIDDetails(requestId, COBAMNumber): void {
      if (COBAMNumber.substring(0, 1) == 'M') {
          window.open(
            this.auth.configuration.COBAMURL + '#/maintenance/detail?requestType=MiFID Categorization Change&requestSubType=MiFID Categorization Change&id=' + requestId,
              '_blank'
          );
      } else {
          window.open(
              this.auth.configuration.SALESFORCEURL.substring(
                  0,
                  this.auth.configuration.SALESFORCEURL.length - 5
              ) + requestId,
              '_blank'
          );
      }
  }

  OpenCOBAMPage(selectedWorkitem: WorkItem, ChangedEvent: any) {
      if (selectedWorkitem.SF_ObjectName == 'COBAM__c') {
          window.open(
              this.auth.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_Tab&cashRequestId=' + selectedWorkitem.SF_RequestId,
              '_blank'
          );
      }
      else if (selectedWorkitem.SF_ObjectName == 'SPOQ_DocumentationRequest__c') {
          window.open(
              this.auth.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_Tab&noncashRequestId=' + selectedWorkitem.SF_RequestId,
              '_blank'
          );
      }
      else {
          window.open(
              this.auth.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_Tab&cashRequestId=' + selectedWorkitem.SF_RequestId,
              '_blank'
          );
      }
  }

  

}
