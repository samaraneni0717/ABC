import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WorkitemService } from '../shared/workitem-queue.service';
import { MatDatepickerInputEvent } from '@angular/material';
import { SnackBarService } from '../../../Common/snackbar/snack-bar.service';
import { FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { PageEvent } from '@angular/material';
import { AuthService } from '../../../Common/Auth/auth-service.service';
import { ExcelService } from '../../../Common/services/excel.service';
import { WorkItemToExport } from '../shared/Models/work-itemReport-Headers';
import { AlertService } from 'src/app/Common/services/alert.service';
@Component({
    selector: 'app-workitem-queue',
    templateUrl: './workitem-queue.component.html',
    styleUrls: ['./workitem-queue.component.css']
})
export class WorkitemQueueComponent implements OnInit {
    WorkItemId = this.route.snapshot.paramMap.get('WorkItemId');
    CobamId = this.route.snapshot.paramMap.get('CobamId');
    UNumber = this.route.snapshot.paramMap.get('UNumber');
    WorkItemType = this.route.snapshot.queryParams['workItem_Type'];
    WorkItemStatus = this.route.snapshot.queryParams['workItem_Status'];
    WorkItemAssigneeType = this.route.snapshot.queryParams['workItem_AssigneeType'];
    Requestor: 'COBAM';
    PreviousSelectedItem;
    WitemslstAfterFilter;
    Indeterminate = '';
    PageEventFired = 0;
    filters: Array<string> = [];
    workItem_Type_List: Array<number>;
    workItem_Status_List: Array<number>;
    usersLst: Array<string> = [];
    lstWorkItemToExport: Array<WorkItemToExport>;
    workItemTypeFilter: string;
    pageEvent: PageEvent;
    DefaultWorkItemAction = 'Accept';
    DefaultAssignee = 'Self';
    previousSearchValue;
    isFilterchange = false;
    FormControl_date_From = new FormControl(new Date());
    FormControl_date_To = new FormControl((new Date()));
    constructor(private _WorkitemService: WorkitemService,
        private route: ActivatedRoute, private _SnackBarService: SnackBarService,
        private datePipe: DatePipe, public auth: AuthService,
        private router: Router, private excelService: ExcelService, private alertService: AlertService) {
    }
    ngOnInit() {
        if (this.WorkItemType != null) {
            if (!(this.WorkItemType === undefined)) {
                this.workItem_Type_List = this.WorkItemType.substring(0, this.WorkItemType.length).split(',');
                this._WorkitemService.filterCondition.Type = this.workItem_Type_List;
            }
            if (!(this.WorkItemStatus === undefined)) {
                this.workItem_Status_List = this.WorkItemStatus.substring(0, this.WorkItemStatus.length).split(',');
                this._WorkitemService.filterCondition.Status = this.workItem_Status_List;
            }
            const Curdate = new Date();
            Curdate.setFullYear(Curdate.getFullYear() - 1);
            this._WorkitemService.filterCondition.StartDate = Curdate;
            this._WorkitemService.date_Start = Curdate;
            this.FormControl_date_From = new FormControl(Curdate);
            if (!(this.WorkItemAssigneeType === undefined)) {
                if (this.WorkItemAssigneeType === 'Myself') {
                    this._WorkitemService.filterCondition.Assignee = this.auth.getLoggedInUser();
                } else if (this.WorkItemAssigneeType === 'My_Team') {
                    this.DefaultAssignee = 'My_Team';
                    this._WorkitemService.filterCondition.Assignee = 'My_Team';
                } else {
                    this.DefaultAssignee = 'All';
                    this._WorkitemService.filterCondition.Assignee = 'SuperUser';
                }
            }
        }
        else if (this.WorkItemId != undefined && this.WorkItemId != null && this.WorkItemId != '') {
            this.DefaultAssignee = 'All';
            const Curdate = new Date();
            Curdate.setFullYear(Curdate.getFullYear() - 1);
            this._WorkitemService.filterCondition.StartDate = Curdate;
            this.FormControl_date_From = new FormControl(Curdate);

            this._WorkitemService.filterCondition.WorkItemId = this.WorkItemId;
            this._WorkitemService.filterCondition.Assignee = null;
        }
        else if (this.CobamId != undefined && this.CobamId != null && this.CobamId != '') {
            this.DefaultAssignee = 'All';
            const Curdate = new Date();
            Curdate.setFullYear(Curdate.getFullYear() - 1);
            this._WorkitemService.filterCondition.StartDate = Curdate;
            this.FormControl_date_From = new FormControl(Curdate);

            this._WorkitemService.filterCondition.CobamId = this.CobamId;
            this._WorkitemService.filterCondition.UNumber = this.UNumber;
            this._WorkitemService.filterCondition.Assignee = null;
        }
        else {
            this._WorkitemService.filterCondition.WorkItemId = null;
            this._WorkitemService.filterCondition.CobamId = null;
            this._WorkitemService.filterCondition.UNumber = null;
            this._WorkitemService.filterCondition.Assignee = this.auth.getLoggedInUser();
            const Curdate = new Date();
            this._WorkitemService.filterCondition.StartDate = new Date(this.datePipe.transform(Curdate, 'yyyy-MM-dd'));
        }
        this._WorkitemService.getlstworkitemByFilter(this.WorkItemType, this.WorkItemStatus, 'ngOnInit');
    }

    WorkItemQueue_Click(_WorkItemQueue) {
        console.log(_WorkItemQueue);
    }
    onDateChange(type: string, event: MatDatepickerInputEvent<Date>) {
        if (type === 'date_From') {
            this._WorkitemService.filterCondition.StartDate = new Date(this.datePipe.transform(event.value, 'yyyy-MM-dd'));
        } else if (type === 'date_To') {
            this._WorkitemService.filterCondition.EndDate = new Date(this.datePipe.transform(event.value, 'yyyy-MM-dd'));
        }
        this._WorkitemService.getlstworkitemByFilter(this.WorkItemType, this.WorkItemStatus);
    }
    UpdatekitemqueueDtls() {
        if (this._WorkitemService.UpdateWorkitemqueue(this._WorkitemService.WorkItemQueueFilteredList.filter
            (WqItem => WqItem.IsSelected === true))) {
            this._SnackBarService.openSnackBar('Data Updated Sucessfully', '');
        }
        this.PageEventFired = ++this.PageEventFired;
    }
    applyFilterByText(filterFieldValue: string) {
        if (this._WorkitemService.filterCondition && ((!this.previousSearchValue && filterFieldValue !== '')
            && (this.previousSearchValue !== filterFieldValue))
            && (this._WorkitemService.filterCondition.searchExpression ?
                this._WorkitemService.filterCondition.searchExpression : '' !==
                filterFieldValue.toLowerCase())) {
            this.applyFilter(filterFieldValue.trim().toLowerCase());
        }
    }
    applyFilterByKey(filterFieldValue: string) {
        if (this._WorkitemService.WorkItemQueueFilteredList
            && filterFieldValue.length > 2 || filterFieldValue.length === 0) {
            this.applyFilter(filterFieldValue.trim().toLowerCase());
        }
    }
    applyFilter(filterFieldValue: string) {
        this.previousSearchValue = filterFieldValue.trim().toLowerCase();
        this._WorkitemService.filterCondition.pageNumber = 1;
        this._WorkitemService.filterCondition.searchExpression = filterFieldValue.trim().toLowerCase();
        this._WorkitemService.getlstworkitemByFilter(this.WorkItemType, this.WorkItemStatus);
    }
    checkChangedAssignee(event: any, type: string) {
        if (!this.isFilterchange) {
            this._WorkitemService.statusFilters = [];
        }
        this._WorkitemService.filterCondition.Assignee = event.srcElement.id === 'Self' ? this.auth.userDetail.UNumber :
            event.srcElement.id === 'My_Team' ? 'My_Team' :
                event.srcElement.id === 'UnAssigned' ? '' : null;
        this._WorkitemService.getlstworkitemByFilter(this.WorkItemType, this.WorkItemStatus);
    }
    UpdateFilterData(filteredStatus) {
        this._WorkitemService.getlstworkitemByFilter(this.WorkItemType, this.WorkItemStatus);
    }
    NavigateBackToDashboard() {
        this.router.navigate(['../dashboard']);
    }
    ReturnQuerystringIndicator() {
        return true;
    }
    ExportExcel() {
        this._WorkitemService.filterCondition.IsDataForExport = true;
        this._WorkitemService.getworkitemByFilter().subscribe((WorkIemResultstoExport) => {
            if (WorkIemResultstoExport && WorkIemResultstoExport.workitemList && WorkIemResultstoExport.workitemList.length > 0) {
                this.lstWorkItemToExport = [];
                WorkIemResultstoExport.workitemList.forEach(w => {
                    this.lstWorkItemToExport.push({
                        Id: w.Id
                        , WorkItem_Type_DisplayText: w.WorkItem_Type_DisplayText
                        , Assignee: w.User_Name
                        , WorkItem_Status_DisplayText: w.WorkItem_Status_DisplayText
                        , LegalId: w.LegalId
                        , Legal_FullName: w.Legal_FullName
                        , AcctId: w.AcctId
                        , Acct_FullName: w.Acct_FullName
                        , CreatedOn: w.CreatedOn
                        , ModifiedOn: w.ModifiedOn
                        , ModifiedUser: w.ModifiedUser
                    }
                    );
                });
                this.excelService.exportAsExcelFile(this.lstWorkItemToExport, 'WorkItemExport');
                this.alertService.indLoading = false;
            } else {
                this.alertService.indLoading = false;
                this._SnackBarService.openSnackBar('No Data To Export', '');
            }
        },
            (error) => {
                this.alertService.indLoading = false;
                console.error(error);
                this._SnackBarService.openSnackBar('Not able to communicate with Service Please try Again', '');
            });
        this._WorkitemService.filterCondition.IsDataForExport = false;
    }
}