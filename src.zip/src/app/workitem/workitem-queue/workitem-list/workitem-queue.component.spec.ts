import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkitemQueueComponent } from './workitem-queue.component';

describe('WorkitemQueueComponent', () => {
  let component: WorkitemQueueComponent;
  let fixture: ComponentFixture<WorkitemQueueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkitemQueueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkitemQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
