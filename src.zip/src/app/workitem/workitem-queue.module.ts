import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WorkitemQueueRoutingModule } from './workitem-queue-routing.module';
import { WorkitemQueueComponent } from './workitem-queue/workitem-list/workitem-queue.component';
import { CdkTableModule } from '@angular/cdk/table';
import { WorkitemQueueDetailsComponent } from './workitem-queue/workitem-detail/workitem-queue-details.component';
import { WQItemTreeComponent } from './workitem-queue/wqitem-tree/wqitem-tree.component';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import {
  MatButtonModule,
  MatInputModule,
  MatSidenavModule,
  MatMenuModule,
  MatToolbarModule,
  MatTooltipModule,
  MatIconModule,
  MatCardModule,
  MatProgressBarModule,
  MatSelectModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatCheckboxModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,
  MatTreeModule,
  MatExpansionModule,
  MatRadioModule,
  MatGridListModule,
  MatDividerModule,
  MatListModule,
  MatSlideToggleModule,
  MatProgressSpinnerModule
} from '@angular/material';
import { CommonModuleModule } from '../Common/common-module/common-module.module';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
@NgModule({
  imports: [
    CommonModule,
    WorkitemQueueRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatTreeModule,
    MatExpansionModule,
    MatRadioModule,
    MatGridListModule,
    MatDividerModule,
    MatListModule,
    MatSlideToggleModule,
    PerfectScrollbarModule,
    MatProgressSpinnerModule,
    CommonModuleModule
  ],
  exports: [
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    CdkTableModule,
    MatPaginatorModule,
    MatTreeModule,
    MatExpansionModule,
    MatRadioModule,
    MatGridListModule,
    MatSlideToggleModule,
    PerfectScrollbarModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  declarations: [WorkitemQueueComponent, WorkitemQueueDetailsComponent, WQItemTreeComponent],
  providers: [DatePipe, { provide: PERFECT_SCROLLBAR_CONFIG, useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG }]
})
export class WorkitemQueueModule { }
