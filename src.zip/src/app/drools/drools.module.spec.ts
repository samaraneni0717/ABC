import { DroolsModule } from './drools.module';

describe('DroolsModule', () => {
  let droolsModule: DroolsModule;

  beforeEach(() => {
    droolsModule = new DroolsModule();
  });

  it('should create an instance', () => {
    expect(droolsModule).toBeTruthy();
  });
});
