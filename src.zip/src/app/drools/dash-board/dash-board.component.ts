import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { Router, NavigationExtras } from '@angular/router';
import { AlertService } from 'src/app/Common/services/alert.service';

import { DroolsService } from '../service/drools.service';
import { DroolsInput } from '../model/drools-input.model';

import { CashAccountServiceService } from '../service/cash-account-service.service';
import { CashAccount } from '../model/cash-account.model';

import { Subscription } from 'rxjs';




@Component({
    selector: 'app-dash-board',
    templateUrl: './dash-board.component.html',
    styleUrls: ['./dash-board.component.css']
})
export class DashBoardComponent implements OnInit {
    droolsInput: DroolsInput;
    cashAccount: CashAccount;
    formFields: QuestionBase<any>[] = [];
    reqForm: FormGroup;
    showAlert = false;
    isProcessing = false;
    showResponse = false;
    payLoad: any;
    errorMessage: string;
    CDDWorkItem: string;
    TaxWorkItem: string;
    RegulationWorkItem: string;
    cobamId: string;
    private subscriptions: Subscription[] = [];


    constructor(
        private qcs: QuestionControlService,
        private droolsService: DroolsService,
        private alertService: AlertService,
        private cashAccountService: CashAccountServiceService,
        private route: ActivatedRoute,
    ) { }

    initializeModels() {
        this.droolsInput = {
            Facts: null,
            targetRulePackage: ''
        };
        this.cashAccount = this.cashAccountService.cashAccountInput();
    }

    ngOnInit(): void {
        this.cobamId = this.route.snapshot.paramMap.get("cobamId");
        this.initializeModels();
        this.formFields = this.cashAccountService.buildFields();
        this.reqForm = this.qcs.toFormGroup(this.formFields);

    }


    ProcessRules() {
        this.showResponse = false;
        this.isProcessing = true;
        this.setDroolsInputToSave();
        this.payLoad = JSON.stringify(this.droolsInput);
        console.log(this.payLoad);
        this.droolsService.ProcessDrools(this.payLoad).subscribe(
            response => {
                //debugger;
                response = JSON.parse(JSON.stringify(response));

                if (response.data.length > 0) {
                    console.log('The data from drools is : ', response.data);
                    this.RenderOutput(response.data);
                    this.isProcessing = false;
                    this.showAlert = false;
                } else {
                    this.isProcessing = false;
                    this.showAlert = true;
                    this.errorMessage = response.data.errorCode + ' ' + response.data.errorMessage;
                }
            },
            error => {
                this.isProcessing = false;
                console.error(error);
                this.alertService.clear();
                this.alertService.warn(
                    'Not able to communicate with Service, Please try Again'
                );
            }
        );
    }

    setDroolsInputToSave() {
        let keysArr = [];
        keysArr = Object.keys(this.reqForm.controls);
        keysArr.forEach(key => {
            this.cashAccount[key] = this.reqForm.get(key).value;
        });

        this.droolsInput.Facts = [this.cashAccount];
        this.droolsInput.targetRulePackage = 'AccountScopingRP';
    }

    RenderOutput(response): any {
        this.CDDWorkItem = response[0].CDDWorkItem;
        this.TaxWorkItem = response[0].TaxWorkItem;
        this.RegulationWorkItem = response[0].RegulationWorkItem;
        this.showResponse = true;
    }


}
