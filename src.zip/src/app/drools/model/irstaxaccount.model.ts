export class IRSTaxAccount {
    TaxPayID: number;
    PaymentType: string = '';
    PaymentDetail: string ='';
    DocID: string ='';
    Chapter3_61Entity: string='';
    Chapter61TaxClassification: string='';
    Chapter3RecipientCode: string='';
    Chapter4RecipientCode: string='';
    TefraValue: string='';
    
    InformationReturn: string;
    TRID: string;
    IncomeCode: string;       
    ExemptionCode: string; 
    ITTCode: string; 
    PayeeCode: string; 
    SecurityID: string; 
    IRSBox: string; 
}
