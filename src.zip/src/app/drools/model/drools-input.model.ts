import { CashAccount } from "./cash-account.model";
import { IRSTaxAccount } from "./irstaxaccount.model";

export interface DroolsInput {
    Facts: CashAccount[];
    targetRulePackage: string;
}

export interface IRSTaxInput {
    Facts: IRSTaxAccount[];
    targetRulePackage: string;
}
