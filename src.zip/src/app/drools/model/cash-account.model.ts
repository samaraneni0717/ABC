export interface CashAccount {
    BuildType: string;
    ProductType: string;
    Desk: string;
    IsSafekeepingRequired: string;
    WFSEntity: string;
    ProductSubType: string;
    SettlementType: string;
    External: string;
    LIQBuildType: string; 
    WFSPrepareCreditSupport: string;

    CDDWorkItem: string;
    TaxWorkItem: string;
    RegulationWorkItem: string;  
    DocumentationWorkItem: string;
    SecondaryReviewWorkItem: string;

    CDDWorkItemId: string;
    TaxWorkItemId: string;
    RegulationWorkItemId: string;
    DocumentationWorkItemId: string;
    SecondaryReviewWorkItemId: string;

    LegalName: string;
    BAName: string;
    BAShortName: string;
    Source: string;
    SFObjectName: string;
    

}
