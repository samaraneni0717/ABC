import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModuleModule } from '../Common/common-module/common-module.module';

import { DroolsRoutingModule } from './drools-routing.module';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { IRSTaxComputationComponent } from './irstaxcomputation/irstaxcomputation.component';
import { MatTabsModule, MatButtonModule, MatInputModule, MatSidenavModule, MatMenuModule, MatToolbarModule, MatTooltipModule, MatIconModule, MatCardModule, MatProgressBarModule, MatSelectModule, MatProgressSpinnerModule, MatListModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
      DroolsRoutingModule,
      FormsModule,
      ReactiveFormsModule,
      MatTabsModule,
      DroolsRoutingModule,
      CommonModuleModule,
      MatButtonModule,
      MatInputModule,
      MatSidenavModule,
      MatMenuModule,
      MatToolbarModule,
      MatTooltipModule,
      MatIconModule,
      MatCardModule,
      MatProgressBarModule,
      MatSelectModule,
      MatProgressBarModule,
      MatProgressSpinnerModule,
      MatTabsModule,
      MatListModule,
    ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  declarations: [DashBoardComponent, IRSTaxComputationComponent]
})
export class DroolsModule { }