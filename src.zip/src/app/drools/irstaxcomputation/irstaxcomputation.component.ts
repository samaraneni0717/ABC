import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { Router, NavigationExtras } from '@angular/router';
import { AlertService } from 'src/app/Common/services/alert.service';

import { DroolsService } from '../service/drools.service';
import { IRSTaxInput } from '../model/drools-input.model';

import { CashAccountServiceService } from '../service/cash-account-service.service';
import { IRSTaxAccount } from '../model/irstaxaccount.model';

import { Subscription } from 'rxjs';

@Component({
    selector: 'app-irstaxcomputation',
    templateUrl: './irstaxcomputation.component.html'
})
export class IRSTaxComputationComponent implements OnInit {

    droolsInput: IRSTaxInput;
    irsTaxAccount: IRSTaxAccount;
    formFields: QuestionBase<any>[] = [];
    reqForm: FormGroup;
    showAlert = false;
    isProcessing = false;
    showResponse = false;
    payLoad: any;
    errorMessage: string;
    CDDWorkItem: string;
    TaxWorkItem: string;
    RegulationWorkItem: string;
    cobamId: string;

    constructor(
        private droolsService: DroolsService,
        private alertService: AlertService,
        private route: ActivatedRoute,
    ) { }

    ngOnInit(): void {
        this.cobamId = this.route.snapshot.paramMap.get("cobamId");
        this.initializeModels();
        //this.formFields = this.cashAccountService.buildFields();
        //this.reqForm = this.qcs.toFormGroup(this.formFields);

    }

    initializeModels() {
        this.droolsInput = {
            Facts:null,
            targetRulePackage: ''
        };
    }

    irsTaxAccountInput(): any {
        var input = [];

        this.droolsService.GetIRSTaxComputation()
        .subscribe((response) => {
            if (response != null && response.Count > 0) {
                response.Result.forEach(item => {
                    input.push({
                        TaxPayID: item.TaxPayID,
                        PaymentType: item.PaymentType,
                        PaymentDetail: item.PaymentDetail,
                        DocID: item.DocID,
                        Chapter3_61Entity: item.Chapter3_61Entity,
                        Chapter61TaxClassification: item.Chapter61TaxClassification,
                        Chapter3RecipientCode: item.Chapter3RecipientCode,
                        Chapter4RecipientCode: item.Chapter4RecipientCode,
                        TefraValue: item.TefraValue
                    });
                });
            }
        });

        this.droolsInput.Facts = input;
        this.droolsInput.targetRulePackage = 'IRSTaxComputationScopingRP';
        return this.droolsInput;
    }

    ProcessRules() {
        this.showResponse = false;
        this.isProcessing = true;
        
        
        var input = [];

        this.droolsService.GetIRSTaxComputation()
        .subscribe((response) => {
            if (response != null && response.Count > 0) {
                response.Result.forEach(item => {
                    input.push({
                        TaxPayID: item.TaxPayID,
                        PaymentType: item.PaymentType,
                        PaymentDetail: item.PaymentDetail,
                        DocID: item.DocID,
                        Chapter3_61Entity: item.Chapter3_61Entity,
                        Chapter61TaxClassification: item.Chapter61TaxClassification,
                        Chapter3RecipientCode: item.Chapter3RecipientCode,
                        Chapter4RecipientCode: item.Chapter4RecipientCode,
                        TefraValue: item.TefraValue
                    });
                });
                this.droolsInput.Facts = input;
                this.droolsInput.targetRulePackage = 'IRSTaxComputationScopingRP';

                if(this.droolsInput.Facts != null && this.droolsInput.Facts.length > 0)
                {
                    this.droolsService.ProcessIRSTaxComputation(JSON.stringify(this.droolsInput)).subscribe(
                        response => {
                            response = JSON.parse(JSON.stringify(response));
                            if (response.data.length > 0) {
                                console.log('The data from drools is : ', response.data);
                                //this.RenderOutput(response.data);
                                this.isProcessing = false;
                                this.showAlert = false;
                            } else {
                                this.isProcessing = false;
                                this.showAlert = true;
                                this.errorMessage = response.data.errorCode + ' ' + response.data.errorMessage;
                            }
                        },
                        error => {
                            this.isProcessing = false;
                            console.error(error);
                            this.alertService.clear();
                            this.alertService.warn(
                                'Not able to communicate with Service, Please try Again'
                            );
                        }
                    );
                }
            }
        });
    }
}