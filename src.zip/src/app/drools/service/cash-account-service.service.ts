import { Injectable } from '@angular/core';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { DropdownQuestion } from '../../Common/dynamic-form-models/question-dropdown';

@Injectable({
  providedIn: 'root'
})
export class CashAccountServiceService {
    cashAccountInput(): any {
        return {
            BuildType:'',
            ProductType: '',
            Desk: '',
            IsSafekeepingRequired: '',
            WFSEntity: '',
            ProductSubType: '',
            SettlementType: '',
            External: '',
            LIQBuildType: '',     
            WFSPrepareCreditSupport:''      
        };
    }

    buildFields(): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new DropdownQuestion({
                key: 'BuildType',
                label: 'Build Type',
                order: 100,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'New Bus Acc Only', value: 'New Bus Acc Only' },
                    { key: 'New Legal & Bus Acc', value: 'New Legal & Bus Acc' },                    
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'ProductType',
                label: 'Product Type',
                order: 200,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Fixed Income', value: 'Fixed Income' },
                    { key: 'Equities', value: 'Equities' },
                    { key: 'FCM', value: 'FCM' },
                    { key: 'Swaps', value: 'Swaps' },
                    { key: 'Agency', value: 'Agency' },
                    { key: 'Loan Sales', value: 'Loan Sales' },
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'Desk',
                label: 'Desk',
                order: 300,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'ABF Desk', value: 'ABF Desk' },
                    { key: 'CPE Desk', value: 'CPE Desk' },                   
                    { key: 'Generalist Desk', value: 'Generalist Desk' },
                    { key: 'High Grade Desk', value: 'High Grade Desk' },
                    { key: 'High Yield Desk', value: 'High Yield Desk' },
                    { key: 'Institutional Rates', value: 'Institutional Rates' },
                    { key: 'MM FI Desk', value: 'MM FI Desk' },
                    { key: 'Muni Sales Desk', value: 'Muni Sales Desk' },
                    { key: 'Short Duration Sales', value: 'Short Duration Sales' },
                    { key: 'Equity Desk', value: 'Equity Desk' },
                    { key: 'Special Equity Desk', value: 'Special Equity Desk' },
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'IsSafekeepingRequired',
                label: 'Is Safekeeping Required',
                order: 400,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'WFSEntity',
                label: 'WFS Entity',
                order: 500,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'WFBNA-US', value: 'WFBNA-US' },
                    { key: 'WFSLLC-US', value: 'WFSLLC-US' },
                    { key: 'WFSC-LTD', value: 'WFSC-LTD' },
                    { key: 'WFSIL', value: 'WFSIL' },
                    
                    
                    
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'ProductSubType',
                label: 'Product Sub Type',
                order: 600,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Cash', value: 'Cash' },
                    { key: 'CDS', value: 'CDS' },
                    { key: 'IRS', value: 'IRS' },
                    { key: 'Futures', value: 'Futures' },
                    { key: 'Overnight Repo', value: 'Overnight Repo' },
                    { key: 'Interest Rate', value: 'Interest Rate' },
                    
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'SettlementType',
                label: 'Settlement Type',
                order: 700,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Extended', value: 'Extended' },
                    { key: 'Regular', value: 'Regular' },
                    
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'External',
                label: 'External',
                order: 800,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'BRWFB', value: 'BRWFB' },
                    { key: 'BRWFL', value: 'BRWFL' },
                    { key: 'BRWFS', value: 'BRWFS' },
                    { key: 'GDD (exclusively)', value: 'GDD (exclusively)' },
                    
                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'LIQBuildType',
                label: 'LIQ Build Type',
                order: 700,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Lender', value: 'Lender' },
                    { key: 'Borrower', value: 'Borrower' },
                    { key: 'Guarantor', value: 'Guarantor' },

                ],
                defaultOption: '',
            }),
            new DropdownQuestion({
                key: 'WFSPrepareCreditSupport',
                label: 'WFS Prepare Credit Support',
                order: 800,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'true', value: 'true' },
                    { key: 'false', value: 'false' },
                ],
                defaultOption: '',
            }),
            
        ];
        return questions.sort((a, b) => a.order - b.order);
    }
}

