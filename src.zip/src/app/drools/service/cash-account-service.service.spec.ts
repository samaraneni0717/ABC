import { TestBed, inject } from '@angular/core/testing';

import { CashAccountServiceService } from './cash-account-service.service';

describe('CashAccountServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CashAccountServiceService]
    });
  });

  it('should be created', inject([CashAccountServiceService], (service: CashAccountServiceService) => {
    expect(service).toBeTruthy();
  }));
});
