import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs/Observable';
import { tap } from 'rxjs/operators';

import { ApiService } from '../../Common/services/api.service'

@Injectable({
    providedIn: 'root'
})
export class DroolsService {

    constructor(private httpClient: HttpClient, private apiService: ApiService) {

    }

    ProcessDrools(body: any): Observable<any> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers, withCredentials: true };
        return this.httpClient.post(
            //'http://dtc940d662a9bf6:9199/drools-api/execute'
            //'http://wdvww99a0295:9199/drools-api/execute'
            environment.BASEURL + 'Drools/Execute'
            , body
            , options
        );

        //return this.apiService.Post<any>(environment.BASEURL + 'Drools/Execute', body, null, headers);

        // let httpParams = new HttpParams()
        //     .set('request', JSON.stringify(filter ? filter : undefined))
        //     .set('requestType', requestType)
        //     .set('user', user);

        // return this.apiService.Get<any>(this.SearchApiUrl, httpParams);
    }

    ProcessIRSTaxComputation(body: any): Observable<any> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers, withCredentials: true };

        return this.httpClient.post(
            environment.BASEURL + 'Drools/ExecuteIRSTaxComputation'
            , body
            , options
        );
        //return this.apiService.Post<any>(environment.BASEURL + 'Drools/ExecuteIRSTaxComputation', body, null, headers);
    }

    GetIRSTaxComputation() : Observable<any> {
        let url = environment.BASEURL + 'Drools/GetIRSTaxComputationFacts'; 
        return this.apiService.Get<any>(url);
    }
}
