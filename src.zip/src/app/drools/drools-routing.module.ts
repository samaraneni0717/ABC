import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashBoardComponent} from './dash-board/dash-board.component';
import { IRSTaxComputationComponent } from './irstaxcomputation/irstaxcomputation.component';

const routes: Routes = [
    {
        path: 'dashboard',
        component: DashBoardComponent
    },
    {
        path: 'irstaxcomputation',
        component: IRSTaxComputationComponent
    },
    {
        path: 'execute/:cobamId',
        component: DashBoardComponent
    },
    {
        path: '',
        component: DashBoardComponent
    },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DroolsRoutingModule { }
