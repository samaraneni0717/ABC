import { NgModule } from '@angular/core';
import { AgGridModule } from 'ag-grid-angular/main'
import { CommonModule } from '@angular/common'
import { ReactiveFormsModule, FormsModule} from '@angular/forms';

import { SearchComponent } from './search.component';
import { SearchRoutingModule } from './search-routing.module';

import { CustomAgGridModule } from '../Common/ag-grid/ag-grid.module';


@NgModule({
  declarations: [
    SearchComponent
  ],
  entryComponents: [
    SearchComponent
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    CustomAgGridModule,
    SearchRoutingModule,
    AgGridModule.withComponents([SearchComponent, CustomAgGridModule])
  ]
})
export class SearchModule { }
