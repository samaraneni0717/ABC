export class BusUnitFilter {
    BusUnitID: string = '';
    BusUnitName: string ='';
    BusUnitShortName: string='';
    BusUnitStatus: string = '';
    BusUnitEffectiveDate: Date = new Date();
    SystemAcctID: string = '';
    SystemAcctShortName: string = '';
    SystemAcctName: string = '';
}

export namespace BusUnitFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}