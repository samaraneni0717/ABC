export class LegalEntityFilter {
    LegalID: string = '';
    ShortName: string ='';
    TaxID: string ='';
    SSN: string='';
    Status: string='';
    AlternateTaxID: string='';
    FullName: string='';
    AMLScope: string='';
    ClientType: string='';
    SubType: string='';
    LegalType: string='';
    RestrictedLegalReason: string='';
    RestrictedLegalStatus: string='';
}

export namespace LegalEntityFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}