export class BusAcctExternalFilter {
    BusAcctExternalKey: string = '';
    BusAcctExternalStatus: string = '';
    BusAcctExternalSystem: string = '';
    BusAcctID: string = '';
    BusAcctName: string = '';
    BusAcctShortName: string = '';
    LegalID: string = '';
    LegalShortName: string = '';
    LegalFullName: string = '';
    TaxID: string = '';
    SSN: string = '';
    DepositoryNumber: string = '';
    BusinessUnitID: string = '';
    BusinessUnitName: string = '';
    SystemAcctID: string = '';
    SystemAcctName: string = '';
    BusAcctMode: string = '';
}

export namespace BusAcctExternalFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}