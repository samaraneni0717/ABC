export interface SearchFields {  
    headerName: string,
    field: string,
    cellRenderer: string,
    suppressMenu:boolean,
    filter:boolean, 
    suppressFilter: boolean,
    width: number,
    tooltipField: string,
    valueGetter: any,
    filterParams: any
}