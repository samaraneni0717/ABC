export class BusAcctDeliveryFilter {
    BusAcctID: string = '';
    BusAcctName: string = '';
    BusAcctShortName: string = '';
    LegalID: string = '';
    LegalShortName: string = '';
    LegalFullName: string = '';
    DepositoryNumber: string = '';
    DepositoryName: string = '';
    DepositoryGroup: string = '';
    DTCParticipantNumber: string = '';
    ProductType: string = '';
    SettlementType: string = '';
    InternalAcctNumber: string = '';
    DCOAcctNumber: string = '';
    ABANumber: string = '';
    BankName: string = '';
    SubAcct: string = '';
    OCCFirmNumber: string = ''
}

export namespace BusAcctDeliveryFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}