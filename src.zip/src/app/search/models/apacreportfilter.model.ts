export class APACReportFilter {
    BusAcctID: string = '';
    BusAcctName: string = '';
    HongKongInvClass: string = '';
    LegalID: string = '';
    LegalFullName: string = '';
    CPILetterCompletedDate: string = '';
    MonthsUntilRenewal: string = '';
}

export namespace APACReportFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}