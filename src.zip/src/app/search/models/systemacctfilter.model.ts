export class SystemAccountFilter {
    LegalID: string = '';
    LegalShortName: string ='';
    LegalFullName: string='';
    SystemAcctID: string = '';
    SystemAcctShortName: string = '';
    SystemAcctName: string = '';
    SystemAcctStatus: string = '';
    SystemAcctOpenDate: Date = new Date();
    SystemAcctEffectiveDate: Date = new Date();
}

export namespace SystemAccountFilter {
    export function GetProperties<T>(obj: T) {
        const objectKeys = Object.keys(obj) as Array<keyof T>;
        return objectKeys;
    }
}