import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

export namespace Search {

    export function UpdateForm(searchFilterForm: FormGroup, propertyName: string, propertyValue: string, index: number): FormGroup {
        if (propertyName == "fieldType")
            (<FormArray>searchFilterForm.get('filters')).at(index).patchValue({ fieldType: propertyValue });
        else if (propertyName == "fieldOperator")
            (<FormArray>searchFilterForm.get('filters')).at(index).patchValue({ fieldOperator: propertyValue });
        else if (propertyName == "fieldDataType")
            (<FormArray>searchFilterForm.get('filters')).at(index).patchValue({ fieldDataType: propertyValue });

        return searchFilterForm;
    }

    export function GetCleanedString(input): string {
        return input.replace(/"/g, '');
    }

}

export enum SearchTextType {
   equals = "Equals",
   notEqual = "Not equal",
   startsWith = "Starts with",
   endsWith = "Ends with",
   contains = "Contains",
   notContains = "Not contains"
}

export enum SearchNumberType {
    equals = "Equals",
    notEqual = "Not equal",
    lessThan = "Less than",
    lessThanOrEqual = "Less than or equals",
    greaterThan = "Greater than",
    greaterThanOrEqual = "Greater than or equals"
   //  InRange = "In range"
 }

export namespace SearchNumberType {
    export function values() {
        return Object.keys(SearchNumberType).filter(
            (type) => isNaN(<any>type) && type !== 'values'
        );
    }
}

export namespace SearchTextType {
    export function values() {
        return Object.keys(SearchTextType).filter(
            (type) => isNaN(<any>type) && type !== 'values'
        );
    }
}