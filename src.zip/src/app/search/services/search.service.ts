import { Injectable } from '@angular/core'
import { HttpParams } from '@angular/common/http';

import { ApiService } from '../../Common/services/api.service'

import { environment } from '../../../environments/environment';

@Injectable ({
    providedIn: 'root'
})

export class SearchService {
    private SearchApiUrl: string = environment.BASEURL + "search/GetResults";
    
    constructor(private apiService: ApiService) {}

    public Search(filter, requestType: string)
    {
        let httpParams = new HttpParams()
            .set('request', JSON.stringify(filter ? filter : undefined))
            .set('requestType', requestType);

        return this.apiService.Get<any>(this.SearchApiUrl, httpParams);
    }
}