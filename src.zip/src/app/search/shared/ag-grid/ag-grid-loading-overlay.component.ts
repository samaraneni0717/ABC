import { Component, Input } from '@angular/core';
import { ILoadingOverlayAngularComp } from "ag-grid-angular";

@Component({
    selector: 'app-loading-overlay',
    template: `<div class="spinner-border">` +
              `</div>`
})
export class AgGridLoadingOverlay implements ILoadingOverlayAngularComp {

    agInit(): void {
    }
}