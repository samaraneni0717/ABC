import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from "ag-grid-angular";

@Component({
    selector: 'app-no-rows-overlay',
    template: `<div>` +
              `   <i> {{this.params.noRowsMessageFunc()}} </i>` +
              `</div>`
})
export class AgGridNoRowsOverlay implements INoRowsOverlayAngularComp {
    public params: any;

    agInit(params): void {
        this.params = params;
    }
}