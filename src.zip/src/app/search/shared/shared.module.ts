import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'

import { AgGridLoadingOverlay } from "./ag-grid/ag-grid-loading-overlay.component";
import { AgGridNoRowsOverlay } from "./ag-grid/ag-grid-no-rows-overlay.component";

@NgModule ({
    imports: [
        CommonModule
    ],

    declarations: [
        AgGridLoadingOverlay,
        AgGridNoRowsOverlay
    ],

    exports: [
        AgGridLoadingOverlay,
        AgGridNoRowsOverlay
    ],

    entryComponents: [
        AgGridLoadingOverlay,
        AgGridNoRowsOverlay
    ]
})

export class SharedModule { }