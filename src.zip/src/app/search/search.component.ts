import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router, ParamMap  } from '@angular/router';
import * as angular from "angular";

import { SearchService } from './services/search.service';
import { AuthService } from '../Common/Auth/auth-service.service';

import { BusAcctExternalFilter } from './models/busacctexternalfilter.model';
import { BusAcctDeliveryFilter } from './models/busacctdeliveryfilter.model';
import { LegalEntityFilter } from './models/legalentityfilter.model';
import { SystemAccountFilter } from './models/systemacctfilter.model';
import { BusUnitFilter } from './models/busunitfilter.model';

import { AgGrid } from '../Common/ag-grid/ag-grid.model';

import { SearchTextType, SearchNumberType, Search } from './models/search.model';

import { environment } from 'src/environments/environment';
import { APACReportFilter } from './models/apacreportfilter.model';

@Component({
    selector: 'app-list',
    templateUrl: './search.component.html'
})

export class SearchComponent implements OnInit {  
    
    SearchType = '';
    title = '';
    defaultFilterField = 'BusAcctShortName';

    SearchNumberType = SearchNumberType;
    SearchTextType = SearchTextType;  
    Search = Search;
    Filter: any;

    ShowMessage: boolean = false;
    isAuthenticated: boolean = false;

    searchFilter: any;

    fieldOperators = ["AND", "OR"];

    searchFilterForm: FormGroup;
    clearColumnIndex: number = 1;

    //Grid Members
    AgGridApi;

    globalResponse: any;
    gridDataSource: any[];  

    components = { };

    columnDefs = [{}];

    rowData = [{}];

    rowSelection = "single";

    constructor(public searchService: SearchService,
        public authService: AuthService,
        public route: ActivatedRoute,
        public router: Router,
        public formBuilder: FormBuilder) {

        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        }

        this.router.events.subscribe((evt) => {
            if (evt instanceof NavigationEnd) {
                // trick the Router into believing it's last link wasn't previously loaded
                this.router.navigated = false;
                // if you need to scroll back to top, here is the right place
                window.scrollTo(0, 0);
            }
        });
    }

    getSearchResults(filter) {
        if(this.AgGridApi !== undefined)
            this.AgGridApi.showLoadingOverlay();
        
            this.ShowMessage = false;
            this.SearchType = this.SearchType !== null ? this.SearchType : "busacctexternal";

            if(this.SearchType == "apacreport") {
                this.authService.hasAPACReportAccess().subscribe(result => {
                    if (result != null && result.hasAPACReportAccess) {
                        this.isAuthenticated = true;
                        this.search(filter);
                    }
                    else{
                        return this.notauthorized();
                    }
                });
            }
            else{
                this.authService.checkCIDBrowserAccess()
                    .subscribe((userInfo)=> {
                        if (userInfo != null && userInfo.HasCIDBrowserAccess) {
                        this.isAuthenticated = true;
                        this.search(filter);
                    }
                    else {
                        return this.notauthorized();
                    } 
                });
            }
    }

    search(filter){
        this.searchService.Search(filter, this.SearchType)
            .subscribe((searchResponse) => {
                if (searchResponse != null && searchResponse.Count == 0) {
                    document.querySelector("#divMessage").className = "alert alert-warning";
                    document.querySelector("#divMessage").innerHTML = "<strong>Warning!</strong> No results found.";
                    this.ShowMessage = true;
                    this.gridDataSource = [];
                }
                else if (searchResponse != null && searchResponse.Result != null) {
                    console.log(searchResponse);
                    this.gridDataSource = searchResponse.Result;
                    if(searchResponse.ColumnDefinitions != null) {
                        this.setDefaultColumnDef(this.SearchType);
                        
                        searchResponse.ColumnDefinitions.forEach(column => {
                            this.columnDefs.push(AgGrid.LoadColumnDefinition(column)[0]);
                        });
                    }

                    document.querySelector("#divMessage").innerHTML = '';
                    this.ShowMessage = false;
                }
            },
            (error) => {
                document.querySelector("#divMessage").className = "alert alert-danger";
                document.querySelector("#divMessage").innerHTML = "<strong>Error!</strong> Not able to communicate with Service. Please try Again.";
                this.ShowMessage = true;
                this.gridDataSource = [];
            },
            () => {
                this.rowData = this.gridDataSource;

                if(this.AgGridApi !== undefined)
                    this.AgGridApi.hideOverlay();
            })
    }

    setDefaultColumnDef(type : string) {
        if(type == "busacctexternal" || type == "busacctdelivery" || type == "apacreport") {
            this.columnDefs = [{
                headerName: "View",
                field: "BusAcctID",
                cellRenderer: "busAcctViewClickRenderer",
                suppressMenu:true,
                filter:false, 
                suppressFilter: true,
                width: 80,
                tooltipField: "Click here to view Business Account details"
            }];
        }
        else {
            this.columnDefs = [];
        }
    }

    onExport() {
        var params = {
            fileName: this.SearchType + ".csv"
        };
        this.AgGridApi.exportDataAsCsv(params);
    }

    onGridReady(params) {
        this.AgGridApi = params;
    }

    onFilterChanged(params) {
        console.log(params.api.getFilterModel());
    }

    AlternateTaxIdRenderer(params) : HTMLElement {
        var spanElement: HTMLSpanElement = document.createElement("span");
        var output:string = params.data.AlternateTaxID;
        
        spanElement.textContent = output.replace(/ *, */g, '<br>');
        return spanElement;
    }

    BusAcctViewClickRenderer(params): HTMLElement {
        var anchorElement: HTMLAnchorElement = document.createElement("a");
        
        var thisComponent = params.frameworkComponentWrapper.viewContainerRef.injector.view.component;

        let CIDURL = thisComponent.authService.configuration.CIDURL;
        
        anchorElement.onclick = function () {
            if (params.value !== undefined) {
                var url: string =  CIDURL + 'GetBusAccount?id=' + params.value;
                window.open(
                    url,
                    '_blank'
                );
            }
        }

        var imageElement: HTMLImageElement = document.createElement("img");
        imageElement.src = "./assets/cid/level3_icon.png";
        imageElement.title = "Click to open Business Account";

        anchorElement.appendChild(imageElement);

        return anchorElement;
    }

    onRowDoubleClicked(params) {
        if(this.SearchType == "busacctexternal" || this.SearchType == "busacctdelivery" || this.SearchType == "legalentity" || this.SearchType == "apacreport") {
            var id: number = params.data.LegalID;
            let CIDURL = this.authService.configuration.CIDURL;
            if (id !== undefined) {
                var url: string = CIDURL + 'GetLegal?id=' + id;
                window.open(
                    url,
                    '_blank' 
                );
            }
        }
    }

    onFieldNameChange(value, index) {
        var fieldName: string = Search.GetCleanedString(JSON.stringify(value));
        var type: string = (fieldName !== undefined && 
            fieldName !== "LegalID" && 
            fieldName !== "BusAcctID" && 
            fieldName !== "ABANumber" && 
            fieldName !== "BusUnitID" && 
            fieldName !== "TaxID" && 
            fieldName !== "AlternateTaxID" && 
            fieldName !== "SystemAcctID" && 
            fieldName !== "SSN") ? "contains" : "equals";

        this.loadFieldType(fieldName, type, index);
    }

    onFieldOperatorChange(value, index) {
        var fieldOperator: string = Search.GetCleanedString(JSON.stringify(value));
        if (fieldOperator !== "") {
            this.onAddFilterButtonClick(index);
        }
        else {
            Search.UpdateForm(this.searchFilterForm, "fieldOperator", "", index);
        }
    }

    addFilterFormGroup(): FormGroup {
        return this.formBuilder.group({
            fieldName: [this.defaultFilterField],
            fieldType: ['contains'],
            fieldValue: [''],
            fieldTo: [''],
            fieldOperator: ['']
        });
    }

    addFilterFormGroupWithValue(name: string, type: string, value: string, operator: string): FormGroup {
        return this.formBuilder.group({
            fieldName: [name],
            fieldType: [type],
            fieldValue: [value],
            fieldTo: [''],
            fieldOperator: [operator]
        });
    }

    notauthorized(){
        this.isAuthenticated = false;
        event.preventDefault();
        this.router.navigate(['notauthorized']);
        return;
    }

    ngOnInit() { 

        this.SearchType = this.route.snapshot.queryParams['type'];
        this.SearchType = (this.SearchType !== null && this.SearchType !== undefined)? this.SearchType : "busacctexternal";

        if(this.SearchType == "apacreport") {
            this.authService.hasAPACReportAccess().subscribe(result => {
                if (result != null && result.hasAPACReportAccess) {
                    console.log(result.hasAPACReportAccess);
                    this.title = "APAC Report";
                    this.defaultFilterField = "BusAcctID";
                    this.Filter = APACReportFilter;
                    this.searchFilter = new APACReportFilter();
                    this.components = {'busAcctViewClickRenderer': this.BusAcctViewClickRenderer };
                    this.clearColumnIndex = 0;

                    this.searchFilterForm = this.formBuilder.group({
                        filters: this.formBuilder.array([
                            this.addFilterFormGroup()
                        ])
                    });

                    this.loadFieldType(this.defaultFilterField, "contains", 0);
                    this.onSubmit();
                }
                else{
                    return this.notauthorized();
                }
              });
        }
        else{
            this.authService.checkCIDBrowserAccess()
            .subscribe((userInfo)=> {
                if (userInfo != null && userInfo.HasCIDBrowserAccess) {
                    this.isAuthenticated = true;
            
                    if(this.SearchType != null)
                    {
                        if(this.SearchType == "busacctdelivery") {
                            this.title = 'Business Account/Delivery';
                            this.defaultFilterField = 'BusAcctShortName';
                            this.Filter = BusAcctDeliveryFilter;
                            this.searchFilter = new BusAcctDeliveryFilter();
                            this.components = {'busAcctViewClickRenderer': this.BusAcctViewClickRenderer };
                            this.clearColumnIndex = 1;
                        }
                        else if(this.SearchType == "legalentity") {
                            this.title = 'Legal/Client';
                            this.defaultFilterField = 'ShortName';
                            this.Filter = LegalEntityFilter;
                            this.searchFilter = new LegalEntityFilter();
                            this.components = {'alternateTaxIdRenderer': this.AlternateTaxIdRenderer };
                            this.clearColumnIndex = 0;
                        }
                        else if(this.SearchType == "systemaccount") {
                            this.title = "System Account";
                            this.defaultFilterField = "SystemAcctShortName";
                            this.Filter = SystemAccountFilter;
                            this.searchFilter = new SystemAccountFilter();
                            this.clearColumnIndex = 0;
                        }
                        else if(this.SearchType == "busunit") {
                            this.title = "Buiness Unit";
                            this.defaultFilterField = "BusUnitShortName";
                            this.Filter = BusUnitFilter;
                            this.searchFilter = new BusUnitFilter();
                            this.clearColumnIndex = 0;
                        }
                        else if(this.SearchType == "apacreport") {
                            this.title = "APAC Report";
                            this.defaultFilterField = "BusAcctID";
                            this.Filter = APACReportFilter;
                            this.searchFilter = new APACReportFilter();
                            this.components = {'busAcctViewClickRenderer': this.BusAcctViewClickRenderer };
                            this.clearColumnIndex = 0;
                        }
                        else {
                            this.title = 'Business Account/External';
                            this.defaultFilterField = 'BusAcctShortName';
                            this.Filter = BusAcctExternalFilter;
                            this.searchFilter = new BusAcctExternalFilter();
                            this.components = {'busAcctViewClickRenderer': this.BusAcctViewClickRenderer };
                            this.clearColumnIndex = 1;
                        }
                    }   
                    
                    this.searchFilterForm = this.formBuilder.group({
                        filters: this.formBuilder.array([
                            this.addFilterFormGroup()
                        ])
                    });

                    this.loadFieldType(this.defaultFilterField, "contains", 0);
                    
                    if(this.SearchType == "apacreport"){
                        this.onSubmit();
                    }
                }
                else {
                    return this.notauthorized();
                    // this.isAuthenticated = false;
                    // event.preventDefault();
                    // this.router.navigate(['notauthorized']);
                    // return;
                }
            });
        }
        this.loadFieldType(this.defaultFilterField, "contains", 0);

    }

    onAddFilterButtonClick(index: number): void {
        var count: number = (<FormArray>this.searchFilterForm.get('filters')).length;
        if ((index + 1) == count) {
            (<FormArray>this.searchFilterForm.get('filters')).push(this.addFilterFormGroup());

            this.loadFieldType(this.defaultFilterField, "contains", (index + 1));
        }
    }

    loadFieldType(fieldName: string, fieldType: string, index: number): void {
        angular.element(document).ready(function () {
            var optionHtml: string = "";
            if (fieldName !== undefined && (
                fieldName == "LegalID" ||
                fieldName == "BusAcctID" || 
                fieldName == "ABANumber" || 
                fieldName == "SystemAcctID" || 
                fieldName == "BusUnitID")) 
            {
                SearchNumberType.values().forEach((key: string) => {
                    optionHtml += '<option _ngcontent-c2="" value="' + key + '" ng-reflect-value="' + key + '">' + SearchNumberType[key] + '</option>';
                });
            }
            else if (fieldName == "TaxID" || fieldName == "AlternateTaxID" || fieldName == "SSN") {
                optionHtml += '<option _ngcontent-c2="" value="Equals" ng-reflect-value="Equals">Equal</option>';
            }
            else {
                SearchTextType.values().forEach((key: string) => {
                    optionHtml += '<option _ngcontent-c2="" value="' + key + '" ng-reflect-value="' + key + '">' + SearchTextType[key] + '</option>';
                });
            }

            //Set FieldName html
            if (document.querySelector("#drpFieldName" + index) !== null) {
                (<HTMLSelectElement>document.querySelector("#drpFieldName" + index)).value = fieldName;
            }

            //Set FieldType html
            if (document.querySelector("#drpFieldType" + index) !== null) {
                (<HTMLSelectElement>document.querySelector("#drpFieldType" + index)).innerHTML = optionHtml;
                (<HTMLSelectElement>document.querySelector("#drpFieldType" + index)).value = fieldType;
            }
            
            //Clear FieldValue 
            if (document.querySelector("#txtFieldValue" + index) !== null) {
                (<HTMLInputElement>document.querySelector("#txtFieldValue" + index)).value = "";
            }
        });

        if(this.searchFilterForm !== undefined)
            this.searchFilterForm = Search.UpdateForm(this.searchFilterForm, "fieldType", fieldType, index);
    }

    fillForm(searchType: string, searchValue: string, fields: string[]): void {
        var fieldCount: number = fields.length;

        var type: string = (searchType == "Number") ? "Equals" : "contains";
        var operand: string = (fieldCount == 1) ? "" : "OR";

        if(fields[0] == "All") {
            this.searchFilterForm = this.formBuilder.group({
                filters: this.formBuilder.array([
                    this.addFilterFormGroupWithValue(fields[0], type, searchValue, operand)
                ])
            });
            this.loadFieldType(fields[0], type, 0);
        }
        else {
            this.searchFilterForm = this.formBuilder.group({
                filters: this.formBuilder.array([
                    this.addFilterFormGroupWithValue(fields[0], type, searchValue, operand)
                ])
            });

            this.loadFieldType(fields[0], type, 0);

            for (var i = 1; i < fieldCount; i++) {
                operand = (i == (fieldCount - 1)) ? "" : operand;
                (<FormArray>this.searchFilterForm.get('filters')).push(this.addFilterFormGroupWithValue(fields[i], type, searchValue, operand));
                this.loadFieldType(fields[i], type, i);
            }
        }
    }

    onRemoveFilterButtonClick(filterIndex: number): void {
        (<FormArray>this.searchFilterForm.get('filters')).removeAt(filterIndex);
        var count: number = (<FormArray>this.searchFilterForm.get('filters')).length;
        if(count == 1) {
            this.searchFilterForm = Search.UpdateForm(this.searchFilterForm, "fieldOperator", "", 0);
            (<HTMLSelectElement>document.querySelector("#drpFieldOperator" + 0)).value = "";
        }
    }

    onSubmit(): void {
        if(this.SearchType == "apacreport"){
            this.getSearchResults(this.searchFilterForm.value);
        }
        else{
            var filterCount: number = (<FormArray>this.searchFilterForm.get('filters')).length;
            var isValid: boolean = true;
            var isValidText: boolean = true;
            var isValidOperator: boolean = true;
            var isFilterExceeded: boolean = false;

            if (filterCount > 10) {
                isValid = false;
                isFilterExceeded = true;
            }

            if (isValid) {
                for (var i = 0; i < filterCount; i++) {
                    if ((<FormArray>this.searchFilterForm.get('filters')).at(i).get('fieldValue').value.trim() == "") {
                        isValid = false;
                        isValidText = false;
                    }

                    var operand: string = (<FormArray>this.searchFilterForm.get('filters')).at(i).get('fieldOperator').value.trim();

                    if (((filterCount - 1) != i) && operand == "") {
                        isValid = false;
                        isValidOperator = false;
                    }
                }
            }

            if (isValid) {
                document.querySelector("#divMessage").innerHTML = "";
                this.ShowMessage = false;

                //(<HTMLInputElement>document.querySelector("#txtBasicSearch")).value = "";
                this.getSearchResults(this.searchFilterForm.value);
            }
            else {
                var errorMessage: string = "<strong>Error! </strong><br/>";
                if (isFilterExceeded) {
                    errorMessage += "Search criteria exceeded. Only 10 criterias are allowed. Please remove filters";
                }
                if (!isValidText) {
                    errorMessage += "Please enter search term.<br/>";
                }
                if (!isValidOperator) {
                    errorMessage += "Please select search operand.<br/>";
                }

                document.querySelector("#divMessage").className = "alert alert-danger";
                document.querySelector("#divMessage").innerHTML = errorMessage;
                this.ShowMessage = true;
            }
        }
    }

    onBasicSearchClick(): void {
        var searchText: string = (<HTMLInputElement>document.querySelector("#txtBasicSearch")).value.trim();

        if (searchText !== "") {
            document.querySelector("#divMessage").innerHTML = "";
            this.ShowMessage = false;

            this.searchFilterForm.reset();

            this.fillForm("Text", searchText, new Array("All"));
            
            this.getSearchResults(this.searchFilterForm.value);
        }
        else {
            document.querySelector("#divMessage").className = "alert alert-danger";
            document.querySelector("#divMessage").innerHTML = "<strong>Error!</strong> Please enter search term.";
            this.ShowMessage = true;
        }
    }

    onKeyDown(event) {
        if (event.keyCode == 13) {
            this.onBasicSearchClick();
        }
    }

    onReset(): void {
        //Clear grid data
        this.AgGridApi.setRowData([]);

        //Clear all form array except at position 1
        var count: number = (<FormArray>this.searchFilterForm.get('filters')).length;
        for (var i = count - 1; i > 0; i--) {
            this.onRemoveFilterButtonClick(i);
        }

        //Clear form array at position 1
        (<FormArray>this.searchFilterForm.get('filters')).removeAt(0);

        //Reload default form array
        (<FormArray>this.searchFilterForm.get('filters')).push(this.addFilterFormGroup());

        //Reload fieldType
        this.loadFieldType(this.defaultFilterField, "contains", 0);

        this.ShowMessage = false;
    }

    getFormControls() {
        return (<FormArray>this.searchFilterForm.get('filters'));
    }

    getFieldNames() {
        return this.Filter.GetProperties(this.searchFilter);
    }
}