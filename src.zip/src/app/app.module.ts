import {
  CommonModule,
  HashLocationStrategy,
  LocationStrategy
} from '@angular/common';
import {
  NgModule,
  CUSTOM_ELEMENTS_SCHEMA,
  NO_ERRORS_SCHEMA
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  NgbModule,
  NgbAccordionModule,
  NgbDropdownModule,
  NgbCollapseModule
} from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MatSnackBarModule, MatIconModule } from '@angular/material';
import { MatMenuModule } from '@angular/material/menu';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { CommonModuleModule } from './Common/common-module/common-module.module';
import { AuthService } from './Common/Auth/auth-service.service';
import { AlertService } from './Common/services/alert.service';
import { QuestionControlService } from './Common/dynamic-form-services/question-control.service';
import { AuthGuard } from './Common/Auth/auth-guard';
import { RoleGuard } from './Common/Role/role-guard';
import { Data } from './Common/shared/data';
import { AppComponent } from './app.component';
import { NotAuthorizedComponent } from './notauthorized/not-authorized.component';
import { PageNotFoundComponent } from './pagenotfound/page-not-found.component';



@NgModule({
  declarations: [AppComponent, NotAuthorizedComponent, PageNotFoundComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    NgbModule.forRoot(),
    AngularFontAwesomeModule,
    NgbCollapseModule.forRoot(),
    NgbDropdownModule.forRoot(),
    NgbAccordionModule.forRoot(),
    AppRoutingModule,
    MatSnackBarModule,
    MatMenuModule,
    MatIconModule,
    CommonModuleModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  exports: [MatSnackBarModule],
  providers: [
    Data,
    QuestionControlService,
    AuthService,
    RoleGuard,
    AuthGuard,
    AlertService,
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
