import { AppComponent } from "./app.component";
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from "@angular/http";
import { HttpClientModule } from '@angular/common/http';
import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";

import { AppRoutingModule } from './app-routing.module';

// Chartist Import (for data visualization) 
import { ChartistModule } from 'ng-chartist';

// Import Lottie for Animations
import { LottieAnimationViewModule } from 'ng-lottie';

// Material Imports
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CdkTableModule } from '@angular/cdk/table';
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule, MatDialogRef } from "@angular/material/dialog";
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from "@angular/material/tabs";
import { MatNativeDateModule, MatTableModule, MatSortModule, MatDialog, DateAdapter } from '@angular/material';
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatListModule } from "@angular/material/list";

// NGRX Effects
import { EffectsModule } from '@ngrx/effects';
import { BreakerEffects } from './core/effects/breakers.effect';

// NGRX Store
import { StoreModule } from '@ngrx/store';
import { breakersReducer } from './core/store/reducers/breakers.reducer';
import { MpiActionCreator } from './core/store/mpiActionCreator.service';

// Container Components
import { BreakersComponent } from "./components/breakers/breakers.component";
import { BreakerViewComponent } from "./components/breaker-view/breaker-view.component";
import { LoginComponent } from "./components/login/login.component";
import { SubscribersComponent } from './components/subscribers/subscribers.component';

// Presentational components
import { BreakerPanelComponent } from "./core/p-components/breaker-panel/breaker-panel.component";
import { BreakerTableComponent } from './core/p-components/breaker-table/breaker-table.component';
import { DailyEnergyUsageComponent } from "./core/p-components/daily-energy-usage/daily-energy-usage.component";
import { DailyEnergyUsageByGroupComponent } from "./core/p-components/daily-energy-usage-by-group/daily-energy-usage-by-group.component";
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { EditButtonComponent } from "../app/core/p-components/buttons/edit-button/edit-button.component";
import { ExportButtonComponent } from "../app/core/p-components/buttons/export-button/export-button.component";
import { ModalComponent } from "./core/p-components/modal/modal.component";
import { NavbarComponent } from './core/p-components/navbar/navbar.component';
import { RecentUsageChartsComponent } from "./core/p-components/recent-usage-charts/recent-usage-charts.component";
import { TabGroupComponent } from "./core/p-components/tab-group/tab-group.component";
import { IndividualTabComponent } from "./core/p-components/tab-group/individual-tab/individual-tab.component";
import { TotalEnergyGraphComponent } from "./core/p-components/total-energy-graph/total-energy-graph.component";
import { SubscribersChooseModalComponent } from './core/p-components/subscribers-choose-modal/subscribers-choose-modal.component';

// Guards
import { LoginActivateGuard } from './core/guards/login-activate.guard';

// Pipes and Custom Pipes
import { convert } from "../app/core/pipes/convert.pipe";
import { DatePipe } from "@angular/common";
import { DecimalPipe } from "@angular/common";
import { statusChange } from "../app/core/pipes/status.pipe";
import { nullToDash } from "../app/core/pipes/dash.pipe";

// Effects
import { TwentyFourHourHistoryEffects } from "./core/effects/twentyFourHourHistory.effect";
import { TotalEnergyEffects } from "./core/effects/totalEnergy.effect";

// Reducers
import { groupsReducer } from "./core/store/reducers/groups.reducer";
import { twentyFourHourHistoryReducer } from "./core/store/reducers/twentyFourHourHistory.reducer";
import { twentyFourHourHistoryByGroupReducer } from "./core/store/reducers/twentyFourHourHistoryByGroup.reducer";
import { totalDailyEnergyReducer } from "./core/store/reducers/totalDailyEnergy.reducer";
import { totalWeeklyEnergyReducer } from "./core/store/reducers/totalWeeklyEnergy.reducer";
import { totalMonthlyEnergyReducer } from "./core/store/reducers/totalMonthlyEnergy.reducer";
import { totalDailyEnergyByGroupReducer } from "./core/store/reducers/totalDailyEnergyByGroup.reducer";
import { totalWeeklyEnergyByGroupReducer } from "./core/store/reducers/totalWeeklyEnergyByGroup.reducer";
import { totalMonthlyEnergyByGroupReducer } from "./core/store/reducers/totalMonthlyEnergyByGroup.reducer";

// Services
import { DataAccess } from "./core/services/dataAccess.service";
import { EnvironmentVariables } from "./core/services/envionment.service";
import { Login } from "./core/services/login.service";


@NgModule({
  declarations: [
    AppComponent,
    BreakersComponent,
    BreakerPanelComponent,
    BreakerTableComponent,
    BreakerViewComponent,
    convert,
    DailyEnergyUsageComponent,
    DailyEnergyUsageByGroupComponent,
    DashboardComponent,    
    EditButtonComponent,
    ExportButtonComponent,
    LoginComponent,
    ModalComponent,
    NavbarComponent,
    nullToDash,
    RecentUsageChartsComponent,
    statusChange,
    TotalEnergyGraphComponent,
    TabGroupComponent,
    IndividualTabComponent,
    SubscribersComponent,
    SubscribersChooseModalComponent
  ],
  entryComponents: [
    ModalComponent,
    SubscribersChooseModalComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    CdkTableModule,
    ChartistModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    StoreModule.forRoot({ 
      breakers: breakersReducer, 
      groups: groupsReducer,
      twentyFourHourHistory: twentyFourHourHistoryReducer, 
      twentyFourHourHistoryByGroup: twentyFourHourHistoryByGroupReducer,
      totalDailyEnergy: totalDailyEnergyReducer,
      totalWeeklyEnergy: totalWeeklyEnergyReducer, 
      totalMonthlyEnergy: totalMonthlyEnergyReducer,
      totalDailyEnergyByGroup: totalDailyEnergyByGroupReducer,
      totalWeeklyEnergyByGroup: totalWeeklyEnergyByGroupReducer, 
      totalMonthlyEnergyByGroup: totalMonthlyEnergyByGroupReducer 
    }),
    EffectsModule.forRoot([
      BreakerEffects, 
      TwentyFourHourHistoryEffects, 
      TotalEnergyEffects]
    ),
    LottieAnimationViewModule.forRoot(),
    MatIconModule, 
    MatInputModule,   
    MatCheckboxModule,
    MatNativeDateModule,    
    MatDatepickerModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatSelectModule,
    MatTabsModule,
    MatTableModule,
    MatTooltipModule,
    MatSortModule,
    ReactiveFormsModule,
    MatListModule
  ],
  providers: [
    DataAccess,
    DatePipe,
    DecimalPipe,
    MpiActionCreator,
    Login,
    LoginActivateGuard,
    EnvironmentVariables  
  ],
  schemas: [NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule {}

