import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { BusAcctGroupFilter } from '../Models/BusAcctGroupFilter';
import { RequestOptions } from '@angular/http';


@Injectable()
export class CollectionUIDataService {

    filterCondition: BusAcctGroupFilter = new BusAcctGroupFilter();
    constructor(private httpClient: HttpClient) {
        console.log('Service instantiated');
    }

    getBusAcctGroupUIData(): Observable<any> {
        return this.httpClient.get(environment.BASEURL + 'Collection/GetBusinessAcctGroup/1');
    }
    getBusAcctCollectionUIData(groupId: number): Observable<any> {
        return this.httpClient.get(environment.BASEURL + 'Collection/GetBusinessAcctCollection/' + groupId);
    }

    getNewPageInfo(paramObj: BusAcctGroupFilter): Observable<any> {
        let pgParams = new HttpParams();

        pgParams  = pgParams.set('busAcctGroupFilter', JSON.stringify(paramObj ? paramObj : undefined));
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Collection/GetBusinessAcctGroups/1', options);
    }

    updateTableSelection(paramObj) {
       let pgParams = new HttpParams();

        pgParams  = pgParams.set('busAcctGroup', JSON.stringify(paramObj ? paramObj : undefined));
        const options = {
            params: pgParams
        };
       // console.log('The post params are', options);
        return this.httpClient.post(environment.BASEURL + 'Collection/UpdateGroupStatus/1', paramObj, options);
    }
}
