import {NgModule} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CollectionUITableComponent} from './components/collection-table/collection-ui-table.component';
import {
    MatGridListModule
// tslint:disable-next-line:import-spacing
}
from '@angular/material';
import { CollectionUIShellComponent } from './containers/collection-ui-shell/collection-ui-shell.component';
const routes: Routes = [
    {
        path: '',
        component: CollectionUIShellComponent
    }
];


@NgModule({
    imports: [RouterModule.forChild(routes),
        MatGridListModule
    ],
    exports: [RouterModule,
        MatGridListModule]
})
export class CollectionUIRoutingModule {
}
