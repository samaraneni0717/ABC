export class BusAcctGroupFilter {
    searchExpression?: string;
    sortExpression?: string;
    pageNumber: number;
    pageSize: number;
    searchColumn: string;
}
