import { Component, OnInit } from '@angular/core';
import { CollectionUIDataService } from '../../services/collection-ui-data.service';
import { RequestOptions } from '@angular/http';
import { SnackBarService } from '../../../Common/snackbar/snack-bar.service';
import { AlertService } from '../../../Common/services/alert.service';
import { BusAcctGroupFilter } from '../../Models/BusAcctGroupFilter';

@Component({
    selector: 'app-collection-ui-shell',
    templateUrl: './collection-ui-shell.component.html'


})
export class CollectionUIShellComponent implements OnInit {

    PageEventFired: number;
    IsAscending: any;
    ShowChild = false;
    collectionTableData: any;
    tabledetailList = [];
    showDetails = false;
    putPayload: any;
    displayObj = {
        businessPurpose: '',
        businessAccountId: '',
        GroupId: 0
    };
    tablePaginationModel = {
        totalCount: 0

    };
    isLoading = false;
    objBusAccountGroupFilter: BusAcctGroupFilter;
    constructor(private collectionUIDataService: CollectionUIDataService, private _SnackBarService: SnackBarService,
        private alertService: AlertService) { }
    ngOnInit(): void {
        this.loadGridData();
    }

    loadGridData() {
        this.isLoading = true;
        this.collectionUIDataService.getBusAcctGroupUIData().subscribe((data) => {
            if (data && data.businessAccountGroupList) {
                console.log('The data from backend is', data);
                this.tablePaginationModel.totalCount = data.totalCount;
                this.collectionTableData = data.businessAccountGroupList;
                if (this.collectionTableData && this.collectionTableData.length >= 0) {
                    this.displayObj.businessPurpose = this.collectionTableData[0].BusinessPurpose;
                    this.displayObj.businessAccountId = this.collectionTableData[0].BusinessAccountId;
                    this.displayObj.GroupId = this.collectionTableData[0].GroupId;
                        this.collectionUIDataService.getBusAcctCollectionUIData(this.collectionTableData[0].GroupId)
                        .subscribe((detailsData) => {
                            if (detailsData && detailsData.businessAccountCollList) {
                                console.log('second api call data', detailsData);
                                this.tabledetailList = detailsData.businessAccountCollList;
                                this.ShowChild = true;
                                this.isLoading = false;
                            }
                        });
                }

            }
        },
            (error) => {
                console.error(error);
                this.alertService.clear();
                this.alertService.warn('Not able to communicate with Service Please try Again');
                this.isLoading = false;
            });
    }


    getDetailList(selectedItem: any): any {
        this.isLoading = true;
        this.collectionUIDataService.getBusAcctCollectionUIData(selectedItem.GroupId).subscribe((detailsData) => {
            if (detailsData && detailsData.businessAccountCollList) {
                this.isLoading = false;
                this.showDetails = false;
                this.tabledetailList = detailsData.businessAccountCollList;
                this.displayObj.businessPurpose = selectedItem.BusinessPurpose;
                this.displayObj.businessAccountId = selectedItem.BusinessAccountId;
                this.displayObj.GroupId = selectedItem.GroupId;
            }
        });
    }
    collectionUiRowSelectionEmit(groupId): void {
        this.tabledetailList = this.getDetailList(groupId);
    }

    getNewPageInfo(event) {
        if (event) {
            this.objBusAccountGroupFilter = new BusAcctGroupFilter;
            this.objBusAccountGroupFilter.pageNumber = 1 + event.pageIndex;
            this.isLoading = true;
            this.collectionUIDataService.getNewPageInfo(this.objBusAccountGroupFilter).subscribe((data) => {
                if (data) {
                    console.log(data);
                    this.collectionTableData = data.businessAccountGroupList;
                    this.isLoading = false;
                }
            },
                (error) => {
                    console.error(error);
                    this.alertService.clear();
                    this.alertService.warn('Not able to communicate with Service Please try Again');
                    this.isLoading = false;
                });
        }

    }

    getFilterResults(event) {
        if (event) {
            this.objBusAccountGroupFilter = new BusAcctGroupFilter();
            this.objBusAccountGroupFilter.searchExpression = event.searchExpression;
            this.objBusAccountGroupFilter.searchColumn = event.searchColumn;
            this.collectionUIDataService.getNewPageInfo(this.objBusAccountGroupFilter).subscribe((data) => {
                if (data) {
                    console.log(data);
                    this.collectionTableData = data.businessAccountGroupList;
                }
            },
                (error) => {
                    console.error(error);
                    this.alertService.clear();
                    this.alertService.warn('Not able to communicate with Service Please try Again');
                });

        }
    }

    refreshData() {
        this.loadGridData();
    }


    updateThePostPayload(event) {
        this.putPayload = event;
    }

}


