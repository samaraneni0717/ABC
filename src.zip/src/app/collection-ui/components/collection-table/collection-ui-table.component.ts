import { Component, OnInit, ViewChild, Input, DoCheck, OnChanges, EventEmitter, Output } from '@angular/core';
import { map } from 'rxjs/operators';
import { Http, RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { CollectionTableDetailsComponent } from '../collection-table-details/collection-table-details.component';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { DatePipe } from '@angular/common';



@Component({
    selector: 'app-collection-ui-table',
    templateUrl: './collection-ui-table.component.html',
    styleUrls: ['./collection-ui-table.component.css']

})
export class CollectionUITableComponent implements OnInit, OnChanges {

    @Input() tableData: any;
    @Output() rowClicked = new EventEmitter<void>();
    @Output() pageChanged = new EventEmitter();
    @Output() searchEventClicked = new EventEmitter();
    @Output() filterEventKeyUp = new EventEmitter();
    IsAscending: Boolean = false;

    @Input() paginationObj: any;

    _CollectionTable = {
        Collectionlist: []
    };

    businessAccountId: number;
    businessPurpose: string;
    originalList = [];
    filteredList = [];

    constructor(private http: Http, private datePipe: DatePipe) {
    }
    ngOnInit() {

    }


    ngOnChanges(): void {
        this._CollectionTable.Collectionlist = this.tableData;
        this.originalList = this.tableData;
    }

    fetchDetails(selectedItem: any) {
        this.businessPurpose = selectedItem.BussinessPurpose;
        this.businessAccountId = selectedItem.BussinessAccountId;
        this.rowClicked.emit(selectedItem);
    }


    OnPageSizeChanged(pageEvent) {
        if (pageEvent) {
            this.pageChanged.emit(pageEvent);
        }
    }

    statusChanged(item: any, event) {
        console.log('the selected item is', item);
        console.log('the selected value is', event);
        this.searchEventClicked.emit(item);

    }

    applyFilter(searchExpression: any, searchColumn) {
        if (searchColumn === 'CreateDateTime' && searchExpression !== null) {
            searchExpression = new Date(this.datePipe.transform(searchExpression, 'yyyy-MM-dd'));
        }
        const item = {};
        item['searchColumn'] = searchColumn;
        item['searchExpression'] = searchExpression;
        this.filterEventKeyUp.emit(item);
    }

}
