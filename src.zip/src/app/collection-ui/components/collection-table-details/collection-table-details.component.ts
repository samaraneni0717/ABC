import { Component, OnInit, Input, OnChanges, Output } from '@angular/core';
import { EventEmitter } from 'events';

@Component({
    selector: 'app-collection-table-details',
    templateUrl: './collection-table-details.component.html',
    styleUrls: ['./collection-table-details.component.css']
})
export class CollectionTableDetailsComponent implements OnInit, OnChanges {

    @Input() detailList = [];
    @Input() headerObj: any;
    @Input() isAddNew = false;
    businessAccountId: number;
    businessPurposeId: number;
    originalList: any[];
    _BusAcctCollectionTable = {
        Collectionlist: []
    };
    constructor(
    ) {
    }
    ngOnInit() {
    }

    ngOnChanges(): void {
        this._BusAcctCollectionTable.Collectionlist = this.detailList;
        this.originalList = this._BusAcctCollectionTable.Collectionlist;
        if (this._BusAcctCollectionTable.Collectionlist.length > 0) { this.isAddNew = false; }
    }


    addNew() {
        this.isAddNew = true;
        this.businessPurposeId = null;
        this.businessAccountId = null;
    }
}
