import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollectionTableDetailsComponent } from './collection-table-details.component';

describe('CollectionTableDetailsComponent', () => {
  let component: CollectionTableDetailsComponent;
  let fixture: ComponentFixture<CollectionTableDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollectionTableDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionTableDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
