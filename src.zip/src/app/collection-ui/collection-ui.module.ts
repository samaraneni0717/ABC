import {NgModule} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import {CollectionUITableComponent} from './components/collection-table/collection-ui-table.component';
import { CollectionUIRoutingModule } from './collection-ui-routing.module';
import { CollectionTableDetailsComponent } from './components/collection-table-details/collection-table-details.component';
import {
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatTreeModule,
    MatExpansionModule,
    MatRadioModule,
    MatGridListModule,
    MatDividerModule,
    MatListModule,
    MatSlideToggleModule,
    MatProgressSpinnerModule
  } from '@angular/material';
import { CollectionUIShellComponent } from './containers/collection-ui-shell/collection-ui-shell.component';
import { CollectionUIDataService } from './services/collection-ui-data.service';

@NgModule({
    imports: [CollectionUIRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatInputModule,
        MatSidenavModule,
        MatMenuModule,
        MatToolbarModule,
        MatTooltipModule,
        MatIconModule,
        MatCardModule,
        MatProgressBarModule,
        MatSelectModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatCheckboxModule,
        MatTableModule,
        MatSortModule,
        MatPaginatorModule,
        MatTreeModule,
        MatExpansionModule,
        MatRadioModule,
        MatGridListModule,
        MatDividerModule,
        MatListModule,
        MatSlideToggleModule,
        MatProgressSpinnerModule, ],
        exports: [
            MatButtonModule,
            MatInputModule,
            MatSidenavModule,
            MatMenuModule,
            MatToolbarModule,
            MatTooltipModule,
            MatIconModule,
            MatCardModule,
            MatProgressBarModule,
            MatSelectModule,
            MatDatepickerModule,
            MatNativeDateModule,
            MatCheckboxModule,

            CommonModule,
            MatPaginatorModule,
            MatTreeModule,
            MatExpansionModule,
            MatRadioModule,
            MatGridListModule,
            MatSlideToggleModule,

          ],
    declarations: [CollectionUITableComponent, CollectionTableDetailsComponent, CollectionUIShellComponent],
    providers: [CollectionUIDataService]
})
export class CollectionUIModule {
}
