import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { AuthService } from '../../Common/Auth/auth-service.service';
import { User } from '../../Common/models/user';
import { HttpParams } from '@angular/common/http';
import { ApiService } from '../../Common/services/api.service';

@Injectable({
    providedIn: 'root'
})

export class DashboardService {
    userDetail: User;
    UserWorkItemList;

    constructor(public auth: AuthService, private apiService: ApiService) { }

    getUserRole(): Observable<any> {
        const httpParams = new HttpParams()
            .set('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');
        return this.apiService.Get<any>(environment.BASEURL + 'User/IsAMTDashboardSuperUser', httpParams);

    }

    GetWorkitemTypeListByUser(UNumber: string): Observable<any> {
        let httpParams = new HttpParams()
            .set('user', UNumber);

        return this.apiService.Get<any>(environment.BASEURL + 'Workitem/GetWorkitemTypeListByUser', httpParams);
    }

    GetDashboardData(UNumber: string, WorkitemTypeIdlst: string, TeamMemberlst: string): Observable<any> {
        const httpParams = new HttpParams()
            .set('strUNumber', UNumber)
            .set('WorkitemTypeIdlst', WorkitemTypeIdlst.toString())
            .set('TeamMemberLst', TeamMemberlst.toString());
        return this.apiService.Get<any>(environment.BASEURL + 'COBAMDashboard/GetDashboardData', httpParams);
    }

    GetAdminDashboardData(UNumber: string): Observable<any> {
        const httpParams = new HttpParams()
            .set('strUNumber', UNumber);
        return this.apiService.Get<any>(environment.BASEURL + 'COBAMDashboard/GetAdminDashboardData', httpParams);
    }
}