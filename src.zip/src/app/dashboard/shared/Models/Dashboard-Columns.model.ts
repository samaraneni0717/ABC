export class DashboardInfo {
  Pending_workitemType_ID: string;
  Pending_workitemType_Name: string;
  Pending_Count: string;
  Inprogress_workitemType_ID: string;
  Inprogress_workitemType_Name: string;
  inprogress_Count: string;
  Notification_workitemType_ID: string;
  Notification_workitemType_Name: string;
  Notification_Count: string;
  Historical_workitemType_ID: string;
  Historical_workitemType_Name: string;
}

export class AdminDashboardInfo {
  Pending_workitemType_ID: string;
  Pending_workitemType_Name: string;
  Pending_Count: string;
  Inprogress_workitemType_ID: string;
  Inprogress_workitemType_Name: string;
  inprogress_Count: string;
  Completed_workitemType_ID: string;
  Completed_workitemType_Name: string;
  Completed_Count: string;
  Historical_workitemType_ID: string;
  Historical_workitemType_Name: string;
}
