import { Component, OnInit, Input, Inject, OnDestroy } from "@angular/core";
import { DashboardService } from "../shared/dashboard.service";
import { Count } from "../shared/dashboard-count-model";
import { DOCUMENT } from "@angular/common";
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { DashboardInfo, AdminDashboardInfo } from '../shared/Models/Dashboard-Columns.model';
import { Subscription, timer } from 'rxjs/';
import { switchMap } from 'rxjs/operators';
import { AlertService } from "src/app/Common/services/alert.service";



@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})
export class DashboardComponent implements OnInit, OnDestroy {
  public count: Count;
  showAdmin:boolean = true;
  LoggedInUser: string;
  isAdminUser = false;
  showAdminView = false;
  showNonAdminView = false;
  isDashboardLoading = false;
  pendingCount: number;
  historicalCount: number;
  inProgressCount: number;
  workitemTypeIdlst = '';
  TeamMemberlst = '';
  private networkID: string;
  private returnType: any;
  salesperson: boolean;
  DashboardDataSource: MatTableDataSource<DashboardInfo>;
  AdminDashboardDataSource: MatTableDataSource<AdminDashboardInfo>;
  UserWorkItemList;
  subscription: Subscription;
  DashboardDisplayedColumns: string[] = [
    'Pending_workitemType_Name',
    'Pending_Count',
    'Inprogress_workitemType_Name',
    'inprogress_Count',
    'Notification_workitemType_Name',
    'Notification_Count',
    'Historical_workitemType_Name'
  ];
  AdminDashboardDisplayedColumns: string[] = [
    'Pending_workitemType_Name',
    'Pending_Count',
    'Inprogress_workitemType_Name',
    'inprogress_Count',
    'Completed_workitemType_Name',
    'Completed_Count'
  ];

  constructor(
    @Inject(DOCUMENT) private document: any,
    private dashboardService: DashboardService,
    private router: Router,
    private route: ActivatedRoute,
    public alertService: AlertService
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
  }

  this.router.events.subscribe((evt) => {
      if (evt instanceof NavigationEnd) {
          // trick the Router into believing it's last link wasn't previously loaded
          this.router.navigated = false;
          // if you need to scroll back to top, here is the right place
          window.scrollTo(0, 0);
      }
  });
  }
 

  ngOnInit() {
    this.showAdmin = (this.route.snapshot.queryParams['admin'] == undefined) ? true : JSON.parse(this.route.snapshot.queryParams['admin']);

    if(!this.showAdmin) {
      this.showAdminView = false;
      this.showNonAdminView = true;
      this.DisplayDashboard();
    }
    else {
      this.isDashboardLoading = true;
      this.dashboardService.getUserRole().subscribe(
        (userInfo) => {
          if (userInfo != null) {
            this.isAdminUser = userInfo.IsAdmin;
            this.LoggedInUser = userInfo.UNumber;
            if (this.isAdminUser === true) {
              this.showAdminView = true;
              this.showNonAdminView = false;
              this.DisplayAdminDashboardData();
            } else {
              this.showAdminView = false;
              this.showNonAdminView = true;
              this.DisplayDashboard();
            }
            this.alertService.indLoading = false;
          }       
        },
        (error) => {
            console.error(error);
            this.alertService.warn('Not able to communicate with Service Please try Again');
            this.alertService.indLoading = false;
        }
      );
    }
  }


DisplayDashboard() {
    this.dashboardService.GetWorkitemTypeListByUser(this.LoggedInUser).subscribe(WorkIemResults => {
      if (WorkIemResults != null) {
        if (WorkIemResults.Result && WorkIemResults.Result.length > 0) {
            WorkIemResults.Result.forEach(s => {
              if (this.workitemTypeIdlst.indexOf(',' + s.Id + ',') === -1) {
                this.workitemTypeIdlst = this.workitemTypeIdlst + s.Id + ',';
              }
            });
        }
      }
       this.BindDashboardData();
    });
  }
BindDashboardData() {
  this.subscription = timer(0, 30000).pipe(
    switchMap(() => this.dashboardService.GetDashboardData(this.LoggedInUser, this.workitemTypeIdlst, this.TeamMemberlst))
  )
   .subscribe((data) => {
    if (data != null) {
      if (data.result && data.result.length > 0) {
        this.DashboardDataSource = new MatTableDataSource(
          data.result
        );
      } else {
        console.log('No data found');
        this.DashboardDataSource = new MatTableDataSource(null);
      }
      this.isDashboardLoading = false;
    }
    });
}

DisplayAdminDashboardData() {
  this.subscription = timer(0, 30000).pipe(
    switchMap(() => this.dashboardService.GetAdminDashboardData(this.LoggedInUser))
  )
   .subscribe((data) => {
    if (data != null) {
      if (data.result && data.result.length > 0) {
        // console.log('The data is ', data.result);
        this.AdminDashboardDataSource = new MatTableDataSource(
          data.result
        );
      } else {
        console.log('No data found');
        this.AdminDashboardDataSource = new MatTableDataSource(null);
      }
      this.isDashboardLoading = false;
    }
    });
}
  OpenworkitemQueue(workitemtypeid, statuslist, AssigneeType): void {
    this.router.navigate(['../workitem'], {
      queryParams: {
        workItem_Type: workitemtypeid,
        workItem_Status: statuslist,
        workItem_AssigneeType: AssigneeType,
      }
    });

  }
  ngOnDestroy() {
    if(this.subscription != undefined)
    this.subscription.unsubscribe();
  }
}
