import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { SafekeepingHeaderRoutingModule } from './safekeeping-header-routing.module';
// import { SafekeepingHeaderComponent } from './safekeeping-header/safekeeping-header.component';
// import { SafekeepingDashboardComponent } from './safekeeping-dashboard/safekeeping-dashboard.component'

import { DashboardHeaderRoutingModule } from './dashboard-header-routing.module';
import { DashboardHeaderComponent } from './dashboard-header/dashboard-header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CdkTableModule } from '@angular/cdk/table';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import {
  MatButtonModule,
  MatInputModule,
  MatSidenavModule,
  MatMenuModule,
  MatToolbarModule,
  MatTooltipModule,
  MatIconModule,
  MatCardModule,
  MatProgressBarModule,
  MatSelectModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatCheckboxModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,
  MatTreeModule,
  MatExpansionModule,
  MatRadioModule,
  MatGridListModule,
  MatDividerModule,
  MatListModule,
  MatSlideToggleModule,
  MatProgressSpinnerModule
} from '@angular/material';
import { CommonModuleModule } from '../Common/common-module/common-module.module';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
@NgModule({
  imports: [
    CommonModule,
    DashboardHeaderRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatTreeModule,
    MatExpansionModule,
    MatRadioModule,
    MatGridListModule,
    MatDividerModule,
    MatListModule,
    MatSlideToggleModule,
    PerfectScrollbarModule,
    MatProgressSpinnerModule,
    CommonModuleModule
  ],
  exports: [
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    CdkTableModule,
    MatPaginatorModule,
    MatTreeModule,
    MatExpansionModule,
    MatRadioModule,
    MatGridListModule,
    MatSlideToggleModule,
    PerfectScrollbarModule
  ],
  declarations: [DashboardHeaderComponent, DashboardComponent],
 // providers: [DatePipe, { provide: PERFECT_SCROLLBAR_CONFIG, useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG }]
})
export class DashboardHeaderModule { }
