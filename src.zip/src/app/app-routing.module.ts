import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BreakersComponent } from './components/breakers/breakers.component';
import { BreakerViewComponent } from "./components/breaker-view/breaker-view.component";
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { LoginComponent } from './components/login/login.component';
import { SubscribersComponent } from './components/subscribers/subscribers.component';

import { LoginActivateGuard } from './core/guards/login-activate.guard'

const routes: Routes = [

  { path:'', redirectTo: 'dashboard', pathMatch: 'full' }, 
  { path: 'login', component: LoginComponent },
  { path: 'breakers', component: BreakersComponent, canActivate: [LoginActivateGuard] },
  { path: 'breaker/:id', component: BreakerViewComponent, canActivate: [LoginActivateGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [LoginActivateGuard]},
  { path: 'subscribers', component: SubscribersComponent, canActivate: [LoginActivateGuard]},
  // Catch all will be redirected to login
  { path: '**', redirectTo: 'login', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
