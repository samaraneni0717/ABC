import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotAuthorizedComponent } from './notauthorized/not-authorized.component';
import { PageNotFoundComponent } from './pagenotfound/page-not-found.component';

const routes: Routes = [
    { path: 'onboarding', loadChildren: './onboarding-requests/onboarding-requests.module#OnboardingRequestsModule' },
    { path: 'offboarding', loadChildren: './offboarding-requests/offboarding-requests.module#OffboardingRequestsModule' },
    { path: 'maintenance', loadChildren: './maintenance-requests/maintenance-requests.module#MaintenanceRequestsModule' },
    { path: 'workitem', loadChildren: './workitem/workitem-queue.module#WorkitemQueueModule' },
    { path: 'workitem/Status/:StatusCode', loadChildren: './workitem/workitem-queue.module#WorkitemQueueModule' },
    { path: 'Settings', loadChildren: './admin/admin.module#AdminModule' },
    { path: 'collection-ui', loadChildren: './collection-ui/collection-ui.module#CollectionUIModule' },
    { path: 'safekeeping-dashboard', loadChildren: './safekeeping/safekeeping-header.module#SafekeepingHeaderModule' },
    { path: 'dashboard', loadChildren: './dashboard/dashboard-header.module#DashboardHeaderModule' },
    { path: 'search', loadChildren: './search/search.module#SearchModule' },
    { path: 'workitemlist', loadChildren: './workitem/list-workitem/list-workitem.module#WorkitemListModule' },
    { path: 'drools', loadChildren: './drools/drools.module#DroolsModule' },
    { path: 'notauthorized', component: NotAuthorizedComponent },
    {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
    },
    { path: '**', component: PageNotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
