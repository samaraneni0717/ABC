import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../Common/Auth/auth-service.service';
import { DashboardService } from '../shared/dashboard.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDatepickerInputEvent } from '@angular/material';
import { SnackBarService } from '../../Common/snackbar/snack-bar.service';
import { FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { PageEvent } from '@angular/material';
import { ExcelService } from '../../Common/services/excel.service';
import { AlertService } from 'src/app/Common/services/alert.service';


@Component({
  selector: 'app-safekeeping-header',
  templateUrl: './safekeeping-header.component.html',
  styleUrls: ['./safekeeping-header.component.css']
})
export class SafekeepingHeaderComponent implements OnInit {

  constructor(public auth: AuthService) { }

  ngOnInit() {
  }

}
