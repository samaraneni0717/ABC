import { Component, OnInit, Input, Inject } from "@angular/core";
import { DashboardService } from "../shared/dashboard.service";
import { environment } from 'src/environments/environment';
import { Count } from "../shared/dashboard-count-model";
import { AuthService } from "../../Common/Auth/auth-service.service";
import { getCurrentDebugContext } from "@angular/core/src/view/services";
import { DOCUMENT } from '@angular/common';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: "app-safekeeping-dashboard",
  templateUrl: "./safekeeping-dashboard.component.html",
  styleUrls: ["./safekeeping-dashboard.component.css"]
})
export class SafekeepingDashboardComponent implements OnInit {
  public count: Count;
  pendingCount: number;
  historicalCount: number;
  inProgressCount: number;
  private networkID: string;
  private returnType: any;
  salesperson: boolean;
  constructor(
    @Inject(DOCUMENT) private document: any,
    private dashboardService: DashboardService,
    public auth: AuthService,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  ngOnInit() {
// debugger;
      this.dashboardService.getUserRole().
                  subscribe((data) => {
                        if (data.result.SalesPerson === true) {
                          this.salesperson = true;
                          const Pending_workitemTypelst = 'Safekeeping Renewal';
                          const Pending_workitemstatuslst = 'Open - Assigned';
                          const Historic_workitemTypelst = 'Safekeeping,Safekeeping Renewal';
                          const Historic_workitemstatuslst = 'Accept,Reject,Closed';
                          // this.returnType =2;
                          this.dashboardService.getCountbyUserStatus(Pending_workitemTypelst, Pending_workitemstatuslst, 
                                Historic_workitemTypelst, Historic_workitemstatuslst).
                                subscribe((data) => {
                                  console.log(data);
                                    this.pendingCount = data.result.pendingCount;
                                     this.historicalCount = data.result.historicalCount;
                                      this.inProgressCount = data.result.inProgressCount;
                            });
                        } else if (data.result.SalesManager === true || data.result.ManagerDelegate === true) {
                          this.salesperson = false;
                          // this.returnType = 1;
                          const Pending_workitemTypelst = 'Safekeeping,Safekeeping Renewal';
                          const Pending_workitemstatuslst = 'Open - Assigned';
                          const Historic_workitemTypelst = 'Safekeeping,Safekeeping Renewal';
                          const Historic_workitemstatuslst = 'Accept,Reject,Closed';
                          this.dashboardService.getCountbyUserStatus(Pending_workitemTypelst, Pending_workitemstatuslst, 
                            Historic_workitemTypelst, Historic_workitemstatuslst).
                                subscribe((data) => {
                                  console.log(data);
                                    this.pendingCount = data.result.pendingCount;
                                     this.historicalCount = data.result.historicalCount;
                                      this.inProgressCount = data.result.inProgressCount;
                            });
                        } else {
                              this.salesperson = true;
                              this.pendingCount = 0;
                              this.historicalCount = 0;
                              this.inProgressCount = 0;
                            }
                  });
      }
  openWorkItemWindow(Param_workItem_Type: any, Param_workItem_Status: any) {
    // const url = environment.COBAMURL;
    this.dashboardService.GetWorkitemTypeIdAndWorkitemStatusID(Param_workItem_Type, Param_workItem_Status).
                                subscribe((data) => {
                                    // const action = url + '#/workitem?workItem_Type=' + data.WorkitemTypeIDs +
                                    //  '&workItem_Status=' + data.WorkitemStatusIDs + '' ;
                                    // window.open(action, '_blank');
                                    // this.document.location.href = action;
                                    // this.router.navigate(['../workitem', { workItem_Type: data.WorkitemTypeIDs,
                                    //  workItem_Status: data.WorkitemStatusIDs }], { relativeTo: this.route });
                                    this.router.navigate(['../workitem'], { queryParams: { workItem_Type: data.WorkitemTypeIDs,
                                        workItem_Status: data.WorkitemStatusIDs } });
                            });
  }
}
