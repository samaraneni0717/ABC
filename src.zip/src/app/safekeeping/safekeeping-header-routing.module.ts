import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SafekeepingHeaderComponent } from './safekeeping-header/safekeeping-header.component';
const routes: Routes = [
  {
      path: '',
      component: SafekeepingHeaderComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SafekeepingHeaderRoutingModule { }
