export class Count{
    pendingCount: number;
    historicalCount: number;
    inProgressCount: number;
}