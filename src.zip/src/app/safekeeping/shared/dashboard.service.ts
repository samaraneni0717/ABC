import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod,URLSearchParams } from '@angular/http';
import { AlertService } from '../../Common/services/alert.service';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../../Common/Auth/auth-service.service';
import { User } from '../../Common/models/user';
import { Count } from "../shared/dashboard-count-model";
import { HttpParams } from '@angular/common/http';
import { ApiService } from '../../Common/services/api.service'

@Injectable({
    providedIn: 'root'
  })

export class DashboardService {
    userDetail: User;

    constructor(private http: Http,  public auth: AuthService, private apiService: ApiService) { }
    getCountbyUserStatus(Pending_workitemTypelst: any, Pending_workitemstatuslst: any,
                         Historic_workitemTypelst: any, Historic_workitemstatuslst: any ): Observable<any> {
        const  httpParams = new HttpParams()
        .set('strUNumber', this.auth.userDetail.UNumber)
        .set('Pending_workitemTypelst', Pending_workitemTypelst)
        .set('Pending_workitemstatuslst', Pending_workitemstatuslst)
        .set('Historic_workitemTypelst', Historic_workitemTypelst)
        .set('Historic_workitemstatuslst', Historic_workitemstatuslst);
        return this.apiService.Get<any>(environment.BASEURL + 'WorkItemSK/GetCountbyUserStatus', httpParams);
    }

    getUserRole(): Observable<any> {
        const  httpParams = new HttpParams()
        .set('strUNumber', this.auth.userDetail.UNumber);
        return this.apiService.Get<any>(environment.BASEURL + 'WorkItemSK/GetUserSalesRole', httpParams);
      }

      GetWorkitemTypeIdAndWorkitemStatusID(WorkitemTypedisplaytextlst: string, WorkitemStatusdisplaytextlst: string) : Observable<any>{
          const  httpParams = new HttpParams()
          .set('strUNumber', this.auth.userDetail.UNumber)
          .set('WorkitemTypedisplaytextlst', WorkitemTypedisplaytextlst.toString())
          .set('WorkitemStatusdisplaytextlst', WorkitemStatusdisplaytextlst.toString());
          return this.apiService.Get<any>(environment.BASEURL + 'WorkItemSK/GetWorkitemTypeIdAndWorkitemStatusID', httpParams);
      }
}