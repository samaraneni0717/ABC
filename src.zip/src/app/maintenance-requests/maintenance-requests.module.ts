import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import { MaintenanceRequestsRoutingModule } from './maintenance-requests-routing.module';
import { SubmittedRequestComponent } from './submitted-request/submitted-request.component';
import { DetailRequestComponent } from './detail-request/detail-request.component';
import { SavedRequestComponent } from './saved-request/saved-request.component';
import { CommonModuleModule } from '../Common/common-module/common-module.module';
import { MtDetailRequestComponent } from './mt-detail-request/mt-detail-request.component';
import { CdkTableModule } from '@angular/cdk/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import {
  MatButtonModule,
  MatGridListModule,
  MatInputModule,
  MatSidenavModule,
  MatMenuModule,
  MatToolbarModule,
  MatTooltipModule,
  MatIconModule,
  MatCardModule,
  MatProgressBarModule,
  MatSelectModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatCheckboxModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,
  MatProgressSpinnerModule
} from '@angular/material';

import { MtDetailRequestsFlagComponent } from './mt-detail-requests-flag-grid/mt-detail-requests-flag-grid.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MtDetailRequestsFundIDsGridComponent } from './mt-detail-requests-fund-ids-grid/mt-detail-requests-fund-ids-grid.component';
import { MtDetailRequestsCIDLEIDComponent } from './mt-detail-requests-cidleid-grid/mt-detail-requests-cidleid-grid.component';
import { AgGridModule } from 'ag-grid-angular';
import { CustomAgGridModule } from '../Common/ag-grid/ag-grid.module';
import { MaintenanceRequestComponent } from './maintenance-requests/maintenance-requests.component';

@NgModule({
  imports: [
    CommonModule,
    MaintenanceRequestsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatTabsModule,
    MatListModule,
    CommonModuleModule,
    CustomAgGridModule,
    MatGridListModule,
    AgGridModule.withComponents([
      MaintenanceRequestComponent,
      CustomAgGridModule
    ])
  ],
  exports: [
    MatButtonModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    CdkTableModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatTabsModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  declarations: [
    SubmittedRequestComponent,
    SavedRequestComponent,
    MtDetailRequestComponent,
    DetailRequestComponent,
    MtDetailRequestsFlagComponent,
    MtDetailRequestsFundIDsGridComponent,
    MtDetailRequestsCIDLEIDComponent,
    MaintenanceRequestComponent
    // ChatterComponent, SafePipe,
    // AttachmentComponent
  ]
})
export class MaintenanceRequestsModule { }
