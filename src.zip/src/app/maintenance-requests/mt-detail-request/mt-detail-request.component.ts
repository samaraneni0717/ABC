import {
    Component,
    OnInit,
    ViewEncapsulation,
    ViewChild,
    OnDestroy,
    ChangeDetectorRef,
    Input,
    OnChanges
} from '@angular/core';
import { MaintenanceRequest } from '../../Common/models/Maintenance-request.model';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { DetailRequestService } from '../shared/services/mt-detail-request.service';
import { MatDialog } from '@angular/material';
import { AlertService } from '../../Common/services/alert.service';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment';
import { Router, NavigationExtras } from '@angular/router';
import {
    MaintenanceRequestParentInput,
    MaintenanceRequestDetailInputs,
    MaintenanceRequestInput,
    MaintenanceRequestOutput,
    MaintenanceRequestDetailOutputs,
    CallbackRequestInput,
    CallbackRequestOutput
} from '../Models';
import { MaintenanceRequestInputService } from '../shared/services/MaintenanceRequestInput.service';
import { MtDetailRequestsFlagComponent } from '../mt-detail-requests-flag-grid/mt-detail-requests-flag-grid.component';
import { MtDetailRequestsFundIDsGridComponent } from '../mt-detail-requests-fund-ids-grid/mt-detail-requests-fund-ids-grid.component';
import { MtDetailRequestsCIDLEIDComponent } from '../mt-detail-requests-cidleid-grid/mt-detail-requests-cidleid-grid.component';
import { Subscription } from 'rxjs';
import { CallbackThirdPartyInputService } from '../shared/services/callbackThirdParty.service';
import { Address } from '../Models/address.model';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';

@Component({
    selector: 'app-mt-detail-request',
    templateUrl: './mt-detail-request.component.html',
    styleUrls: ['./mt-detail-request.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class MtDetailRequestComponent implements OnInit, OnChanges, OnDestroy {
    @Input() maintenanceReqTypeVal: any;
    @Input() maintenanceReqSubTypeVal: any;
    @Input() maintenanceReqIdVal: any;
    mtRequestDetailInputs: any[] = [];
    @ViewChild(MtDetailRequestsFlagComponent)
    mtReqFlagGridList: MtDetailRequestsFlagComponent;
    @ViewChild(MtDetailRequestsFundIDsGridComponent)
    mtReqFundIdGridList: MtDetailRequestsFundIDsGridComponent;
    @ViewChild(MtDetailRequestsCIDLEIDComponent)
    mtReqCIDLEIDGridList: MtDetailRequestsCIDLEIDComponent;
    mtRequestDetaiIntputs: MaintenanceRequestDetailInputs[];
    isSave = false;
    maintenanceRequests: MaintenanceRequest[] = [];
    formFields: QuestionBase<any>[] = [];
    SearchFormFields: QuestionBase<any>[] = [];
    reqForm: FormGroup;
    SearchForm: FormGroup;
    payLoad: any;
    busAcctId: number;
    userAction: string;
    legalId: number;
    workitemCount = 0;
    dataSource;
    showStatusMsg = false;
    maintenanceTableData: any;
    showGridList = false;
    formControl: any;
    isSearchLoading = false;
    mtReqId = this.route.snapshot.queryParams['id'];
    maintenanceReqType = this.route.snapshot.queryParams['requestType'];
    maintenanceReqSubType = this.route.snapshot.queryParams['requestSubType'];
    showAlert = false;
    isFormSave = false;
    errorMessage: string;
    showUpdateButton = false;
    showAttachFilesTab = false;
    showFlagDetailsMsg = false;
    showFlagDetailsGrid = false;
    showCIDLEIDMsg = false;
    showCIDLEIDGrid = false;
    showFundsIdsGrid = false;
    showFundsIdsMsg = false;
    showChatterTab = false;
    showCallbackHistoryTab = false;
    callbackId = '';
    CallbackTableData: any;
    showSaveButton = false;
    showEditButton = false;
    showSubmitButton = false;
    showPOQButton = false;
    showSKFeeDiscountButton = false;
    canOpenPOQWindow = false;
    disableSendEmailButton = true;
    showSendEmailButton = false;
    middlemarketval: boolean;
    isSaveLoading = false;
    reqStatus: string;
    cobamRole: string;
    searchTitle = '';
    searchBtnName = '';
    wireBAID = '';
    displayedColumns: any[];
    legalAddressTable = new Array<Address>();
    tempLegalTableObj = new Address();
    maintenanceRequestParentInput: MaintenanceRequestParentInput;
    maintenanceRequestInput: MaintenanceRequestInput;
    maintenanceRequestOutput: MaintenanceRequestOutput;
    maintenanceRequestDetailOutputs: MaintenanceRequestDetailOutputs[];
    currentUserName = '';
    currentUserId = '';
    callbackRequestInput: CallbackRequestInput;
    callbackRequestOutput: CallbackRequestOutput;
    thirdpartyType = '';
    thirdpartyApprovalStatus = 'Third Party Exception - Approval required';
    isValidMaintenanceSalesforceUser = false;
    showAPACCommentsHistoryTab = false;
    APACCommentsHistoryTableData: any;
    // Model Variables
    searchDialogRef: any;

    private subscriptions: Subscription[] = [];

    constructor(
        private qcs: QuestionControlService,
        private detailRequestService: DetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private datePipe: DatePipe,
        private mtinput: MaintenanceRequestInputService,
        private cdRef: ChangeDetectorRef,
        private callbackInputService: CallbackThirdPartyInputService,
        private router: Router,
        private authService: AuthService
    ) { }

    ngOnChanges(): void {
        if (this.maintenanceReqIdVal) {
            this.mtReqId = this.maintenanceReqIdVal;
        }
        if (this.maintenanceReqTypeVal) {
            this.maintenanceReqType = this.maintenanceReqTypeVal;
        }
        if (this.maintenanceReqSubTypeVal) {
            this.maintenanceReqSubType = this.maintenanceReqSubTypeVal;
        }
    }

    initializeModels() {
        this.maintenanceRequestParentInput = {
            MaintenanceRequestInput: null,
            MaintenanceRequestDetailInputs: [],
            CallbackThirdPartyRequestInput: null,
            UserAction: ''
        };
        this.maintenanceRequestInput = this.mtinput.MaintenanceRequestInput();
        this.callbackRequestInput = this.callbackInputService.CallbackThirdPartyInput();
    }

    ngOnInit() {
        this.detailRequestService.logIn();
        this.isSaveLoading = true;
        this.initializeModels();

        this.detailRequestService.getCurrentUser().subscribe(data => {
            if (data) {
                //debugger;
                this.currentUserId = data.Id;
                this.currentUserName = data.Name;
                this.cobamRole = data.COBAM_Role__c;
                console.log(this.cobamRole);
                if (!(this.cobamRole === 'Requester' || this.cobamRole === 'Tax Profile II' ||
                    this.cobamRole === 'Requester NonCash' || this.cobamRole === 'AML KYC' ||
                    this.cobamRole === 'Requester Maintenance' || this.cobamRole === 'Requester FX' ||
                    this.cobamRole === 'Maintenance' || this.cobamRole === 'DCOT' ||
                    this.cobamRole === 'Account Approval' || this.cobamRole === 'Tax Withholding' ||
                    this.cobamRole === 'Client Services' || this.cobamRole === 'APAC Markets Compliance' || this.authService.HasRequesterMaintenanceAccess)) {
                    this.router.navigate(['notauthorized']);
                }
                if ((this.cobamRole === 'Requester' || this.cobamRole === 'Tax Profile II' ||
                    this.cobamRole === 'Requester NonCash' || this.cobamRole === 'AML KYC' ||
                    this.cobamRole === 'Requester Maintenance' || this.cobamRole === 'Requester FX' ||
                    this.cobamRole === 'Maintenance' || this.cobamRole === 'DCOT' ||
                    this.cobamRole === 'Account Approval' || this.cobamRole === 'Tax Withholding' ||
                    this.cobamRole === 'APAC Markets Compliance' || this.cobamRole === 'Client Services')) {
                    this.isValidMaintenanceSalesforceUser = true;
                }
                // if (this.authService.HasRequesterMaintenanceAccess) {
                //     this.cobamRole = 'Requester Maintenance';
                // }
                this.BuildPage(this.cobamRole);
            }
            else if (this.authService.HasRequesterMaintenanceAccess) {
                this.currentUserId = this.authService.getLoggedInUser();
                this.currentUserName = this.authService.userDetail.FullName;
                this.cobamRole = 'Requester Maintenance';

                this.BuildPage(this.cobamRole);
            }
            else {
                this.router.navigate(['notauthorized']);
            }
        });
    }

    BuildPage(cobamRole) {
        this.formFields = this.detailRequestService.buildFields(
            this.maintenanceReqType,
            this.maintenanceReqSubType
        );
        this.formFields = this.detailRequestService.buildCommonFields(
            this.maintenanceReqType,
            this.maintenanceReqSubType,
            cobamRole,
            this.formFields,
            'Draft'
        );
        this.reqForm = this.qcs.toFormGroup(this.formFields);

        this.enableDisableQueueStatus(cobamRole, 'Draft');
        this.showhidetabsbuttons();
        if (this.maintenanceReqSubType === 'Wire Changes') {
            this.setDisplayModeForCallbackTHirdParty();
            this.subscriptions.push(
                this.reqForm
                    .get('Status__c')
                    .valueChanges.subscribe(() =>
                        this.setDisplayModeForCallbackTHirdParty()
                    )
            );
        }
        this.isSaveLoading = false;

        if (this.mtReqId != null && this.mtReqId !== '') {
            this.showSaveButton = false;
            this.populateForm(this.mtReqId);
            this.isSave = true;
        }

        //if (
        //    this.reqForm.get('Maintenance_Request_Type__c').value ===
        //    'MiFID Categorization Change'
        //) {
        //    this.reqForm.get('WFS_Booking_Entity__c').disable();
        //    this.reqForm.get('MiFID_II_Client_Categorization__c').disable();
        //}
        if (this.maintenanceReqSubType === 'Hong Kong Classification Refresh') {
            this.enableDisableProductGroupMarketField();
            this.subscriptions.push(
                this.reqForm
                    .get('Hong_Kong_Classification__c')
                    .valueChanges.subscribe(() =>
                        this.enableDisableProductGroupMarketField()
                    )
            );
        }

        if (
            this.maintenanceReqType === 'Business Account Level Changes' &&
            this.maintenanceReqSubType === 'Flag/Tag Updates'
        ) {
            this.showFlagDetailsMsg = true;
            this.showFlagDetailsGrid = true;
        } else if (
            this.maintenanceReqType === 'Legal Changes' &&
            this.maintenanceReqSubType === 'Legal Mergers'
        ) {
            this.showCIDLEIDMsg = true;
            this.showCIDLEIDGrid = true;
        } else if (
            this.maintenanceReqType === 'Business Account Level Changes' &&
            this.maintenanceReqSubType === 'Fund Mergers (LIQ)'
        ) {
            this.showFundsIdsGrid = true;
            this.showFundsIdsMsg = true;
        }
        this.cdRef.detectChanges();
    }

    enableDisableQueueStatus(cobamRole?: string, currentStatus?: string): void {
debugger
        this.reqStatus = currentStatus;
        switch (currentStatus) {
            case 'Draft':
            case 'Closed - Approved':
            case 'Closed - Rejected':
            case 'Closed - Inactive':
            case 'Submitted':
            case 'Approved in CID Staging':
            case 'Closed':
                this.reqForm.get('Status__c').disable();
                break;
            case 'Open - Unassigned':
            case 'Pending - Inprogress':
            case 'Pending - Front Office':
            case 'Pending - Research Required':
            case 'Pending - Waiting on COG':
            case 'Account Set-up Review in CID & BPS':
            case 'Review security in Taxonomy & BPS':
            case 'Review transaction in BPS':
            case 'Calculate & send adjust to settlements':
            case 'DDA Funded':
            case 'Re-Open':
                if (
                    cobamRole === 'Maintenance' ||
                    cobamRole === 'DCOT' ||
                    cobamRole === 'Account Approval' ||
                    cobamRole === 'Tax Withholding'
                ) {
                    this.reqForm.get('Status__c').enable();
                } else {
                    this.reqForm.get('Status__c').disable();
                }
                break;
            default:
                this.reqForm.get('Status__c').disable();
                break;
        }
    }

    setDefaultValueForCallbackTHirdParty(): void {
        if (
            this.reqForm.get('Is_this_Wire_a_Third_Party_payment__c') &&
            this.reqForm.get('Is_this_Wire_a_Third_Party_payment__c').value === 'Yes'
        ) {
            if (this.reqForm.get('third_Party_form_Completed_By__c')) {
                this.reqForm.controls['third_Party_form_Completed_By__c'].setValue(
                    this.currentUserName
                );
            }

            if (this.reqForm.get('third_Party_Exception_Approval_Status__c')) {
                this.reqForm.controls[
                    'third_Party_Exception_Approval_Status__c'
                ].setValue(this.thirdpartyApprovalStatus);
            }
            if (this.reqForm.get('third_Party_Request_Type__c')) {
                this.reqForm.controls['third_Party_Request_Type__c'].setValue(
                    this.thirdpartyType
                );
            }
        }
    }

    enableDisableProductGroupMarketField(): void {
        if (
            this.reqForm.get('Hong_Kong_Classification__c').value ==
            'Corporate Professional Investor'
        ) {
            this.reqForm.controls['Product_group_Market_coverage__c'].enable();
            this.reqForm.controls['Product_group_Market_coverage__c'].setValue(['Macro - ON Exchange']);
        } else {
            this.reqForm.controls['Product_group_Market_coverage__c'].setValue(['']);
            this.reqForm.controls['Product_group_Market_coverage__c'].disable();
        }
    }

    setDisplayModeForCallbackTHirdParty(): void {
        if (this.cobamRole === 'Client Services') {
            if (this.reqForm.get('Notes__c')) {
                this.reqForm.get('Notes__c').disable();
            }
            if (this.reqForm.get('callback_Status__c')) {
                this.reqForm.get('callback_Status__c').enable();
            }
            if (this.reqForm.get('callback_Time__c')) {
                this.reqForm.get('callback_Time__c').enable();
            }
        } else {
            if (this.reqForm.get('Notes__c')) {
                this.reqForm.get('Notes__c').enable();
            }
            if (this.reqForm.get('callback_Status__c')) {
                this.reqForm.get('callback_Status__c').disable();
            }
            if (this.reqForm.get('callback_Time__c')) {
                this.reqForm.get('callback_Time__c').disable();
            }
        }

        if (this.reqForm.get('third_Party_Exception_Approval_Status__c')) {
            this.reqForm.get('third_Party_Exception_Approval_Status__c').disable();
        }

        if (
            this.reqForm.get('Status__c') &&
            this.reqForm.get('Status__c').value === 'Draft'
        ) {
            this.reqForm.get('third_Party_Request_Type__c').enable();
            this.reqForm.get('beneficiary_ID_Type__c').enable();
            this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').enable();
            this.reqForm.get('intermediary_Bank_ID_Type__c').enable();
            this.reqForm.get('source_Type__c').enable();
        } else {
            this.reqForm.get('third_Party_Request_Type__c').disable();
            this.reqForm.get('beneficiary_ID_Type__c').disable();
            this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').disable();
            this.reqForm.get('intermediary_Bank_ID_Type__c').disable();
            this.reqForm.get('source_Type__c').disable();
        }
    }

    openSearchModal(template, value: string): void {
        this.showStatusMsg = false; // hiding helptext
        if (value !== '[object Event]' && value !== '[object MouseEvent]') {
            this.searchTitle = value;
            if (this.maintenanceReqSubType === 'Wire Changes') {
                this.wireBAID = this.reqForm.get('BA_ID__c').value;
            }
            if (this.cobamRole !== 'Client Services') {
                this.searchDialogRef = this.dialog.open(template, {
                    width: '80%',
                    height: '90%'
                });
            }
        }

        console.log('The type of template is', value);
    }

    onAutocompleteSelctionChange(controlName: string) {
        if (controlName === 'Assigned_To__r') {
            if (this.reqForm.get('Status__c').value === 'Open - Unassigned') {
                this.reqForm.get('Status__c').setValue('Pending - Inprogress');
            }
        }
    }
    onOptionsinlineSelectionChange(template, value: string) {
        if (value === 'New_Wires__c') {
            if (this.reqForm.get('New_Wires__c').value === 'No') {
                this.searchTitle = 'Wire';
                this.wireBAID = this.reqForm.get('BA_ID__c').value;
                const dialogRef = this.dialog.open(template, {
                    width: '80%'
                });
            }
        } else if (value === 'Is_this_Wire_a_Third_Party_payment__c') {
            (async () => {
                await this.delay(5000);
                this.setDefaultValueForCallbackTHirdParty();
            })();
        }
    }
    onHongKongClassificationSelctionChange(controlName: string) {
        if (controlName === 'Hong_Kong_Classification__c') {
            this.enableDisableProductGroupMarketField();
        }
    }

    delay(ms: number) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    onModalClose() {
        this.showGridList = false;
        this.searchDialogRef.close();
    }
    getLegalAdressData(): void {
        this.detailRequestService
            .GetCounterpartyAddressList(this.legalId, '"')
            .subscribe(data => {
                if (data) {
                    data.oAddress.forEach((item, index) => {
                        const iteratorObj: Address = {
                            Address1: '',
                            Address2: '',
                            Address3: '',
                            Address4: '',
                            City: '',
                            State: '',
                            CountryCode: '',
                            Zip: '',
                            CanadianProvince: '',
                            CanadianPostal: '',
                            AddressFormat: ''
                        };
                        for (const prop in item) {
                            if (iteratorObj.hasOwnProperty(prop)) {
                                iteratorObj[prop] = item[prop];
                            }
                        }
                        this.legalAddressTable.push(iteratorObj);
                    });
                    console.log('The table values', this.legalAddressTable);
                }
            });
    }

    selectRowData(value: any, legalTemplate: any): void {
        if (this.searchTitle === 'MIFID Business Account') {
            this.onModalClose();
            this.legalId = value.LegalId;
            this.getLegalAdressData();
            console.warn('The legal ID', this.legalId);
            const dialogRef = this.dialog.open(legalTemplate, {
                width: '40%'
            });
        }
        if (this.maintenanceReqSubType === 'Hong Kong Classification Refresh') {
            this.populateAPACHongKongDetails(value);
        }
        if (this.searchTitle === 'Salesperson/Trader') {
            this.populateSPTR(value);
        } else if (this.searchTitle === 'Wire') {
            this.populateWire(value);
        } else if (this.searchTitle === 'Marketer') {
            this.populateMarketer(value);
        } else {
            this.isSave = false;
            this.showAlert = false;
            Object.keys(this.reqForm.controls).forEach(item => {
                switch (item) {
                    case 'CID_LEID__c':
                        this.reqForm.controls[item].setValue(value.LegalId);
                        break;
                    case 'BA_ID__c':
                        this.reqForm.controls[item].setValue(value.AccountId);
                        break;
                    case 'Legal_Name__c':
                        this.reqForm.controls[item].setValue(value.LegalFullName);
                        break;
                    case 'Business_Acct_Fund_Name__c':
                        this.reqForm.controls[item].setValue(value.AccountName);
                        break;
                    case 'External_Name__c':
                        this.reqForm.controls[item].setValue(value.ExternalSystem);
                        break;
                    case 'External_ID__c':
                        this.reqForm.controls[item].setValue(value.ExternalId);
                        break;
                    case 'Middle_Market_Indicator__c':
                        this.reqForm.controls[item].setValue(value.middlemarket);
                        break;
                    case 'MiFID_II_Risk_Reducing__c':
                        this.reqForm.controls[item].setValue(value.MiFIDII_RiskReducing);
                        break;
                    case 'MiFID_II_Investment_Firm__c':
                        this.reqForm.controls[item].setValue(value.MiFIDIIInvestmentFirm);
                        break;
                    case 'MiFID_II_Central_Bank__c':
                        this.reqForm.controls[item].setValue(value.MiFIDIICentralBank);
                        break;
                    case 'MiFID_II_Client_Categorization__c':
                        this.reqForm.controls[item].setValue(value.MiFIDIIClientCategorization);
                        break;
                }
            });
            if (!(this.searchTitle === 'MIFID Business Account')) {
                this.onModalClose();
            }
            this.showhidetabsbuttons();
            //if (
            //    this.reqForm.get('Maintenance_Request_Type__c').value ===
            //    'MiFID Categorization Change'
            //) {
            //    this.reqForm.get('WFS_Booking_Entity__c').enable();
            //}
        }
    }
    populateWire(value: any): void {
        this.isSave = false;
        this.showAlert = false;
        this.thirdpartyType = !value.ThirdPartyApprovalRequired
            ? value.RequestType
            : '';
        this.thirdpartyApprovalStatus = !value.ThirdPartyApprovalRequired
            ? value.ThirdPartyExceptionApprovalStatus
            : 'Third Party Exception - Approval required';
        Object.keys(this.reqForm.controls).forEach(item => {
            switch (item) {
                case 'third_Party_Exception_Approval_Status__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.ThirdPartyExceptionApprovalStatus
                            : 'Third Party Exception - Approval required'
                    );
                    break;
                case 'third_Party_Request_Type__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired ? value.RequestType : ''
                    );
                    break;
                case 'supervisor_Principal_Comments__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.SupervisoryPrincipalComment
                            : null
                    );
                    break;
                case 'third_Party_Desk_Head_App_ID__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.ThirdPartyApprovalSupervisoryPrincipalEmpKeyId
                            : null
                    );
                    break;
                case 'existing_Thirdparty__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                    );
                    break;

                case 'third_Party_form_Completed_Date__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.ThirdPartyFormCompletedDate
                            : null
                    );
                    break;
                case 'third_Party_Approval_Timestamp__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.ThirdPartyApprovalTimestampInternal
                            : null
                    );
                    break;
                case 'third_Party_Desk_Head_Approval__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.ThirdPartyApproverSupervisoryPrincipalName
                            : null
                    );
                    break;

                case 'telephone__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired ? value.ThirdPartyTelephone : null
                    );
                    break;
                case 'business_Unit_Requesting_Exception__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.BusinessUnitRequestingException
                            : null
                    );
                    break;
                case 'policy_Exception_Justification__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired
                            ? value.PolicyExceptionJustification
                            : null
                    );
                    break;
                case 'fax__c':
                    this.reqForm.controls[item].setValue(
                        !value.ThirdPartyApprovalRequired ? value.ThirdPartyfax : null
                    );
                    break;

                case 'sequenceId__c':
                    this.reqForm.controls[item].setValue(value.SequenceId);
                    break;
                case 'other_Instructions__c':
                    this.reqForm.controls[item].setValue(value.OtherInstr);
                    break;
                case 'routing_Number_Intermediary_Bank_ID__c':
                    this.reqForm.controls[item].setValue(value.IntermediaryBankID);
                    break;

                case 'intermediary_Bank_Name__c':
                    this.reqForm.controls[item].setValue(value.IntermediaryBankName);
                    break;
                case 'intermediary_Bank_ID_Type__c':
                    this.reqForm.controls[item].setValue(
                        value.IntermediaryBankIDType != null
                            ? value.IntermediaryBankIDType
                            : ''
                    );
                    break;
                case 'account_Number_Bank_FI_ID__c':
                    this.reqForm.controls[item].setValue(value.BeneficiaryBankID);
                    break;
                case 'bank_FI_Name__c':
                    this.reqForm.controls[item].setValue(value.BeneficiaryBankName);
                    break;
                case 'beneficiary_Bank_Financial_Institution_O__c':
                    this.reqForm.controls[item].setValue(
                        value.BeneficiaryBankIDType !== null
                            ? value.BeneficiaryBankIDType
                            : ''
                    );
                    break;
                case 'beneficiary_ID__c':
                    this.reqForm.controls[item].setValue(value.BeneficiaryID);
                    break;
                case 'beneficiary_Name__c':
                    this.reqForm.controls[item].setValue(value.BeneficiaryName);
                    break;
                case 'beneficiary_ID_Type__c':
                    this.reqForm.controls[item].setValue(
                        value.BeneficiaryIDType != null && value.BeneficiaryIDType !== 'ABA'
                            ? value.BeneficiaryIDType
                            : ''
                    );
                    break;
            }
        });

        this.onModalClose();
        this.showhidetabsbuttons();
    }

    populateSPTR(value: any): void {
        this.isSave = false;
        this.showAlert = false;
        this.detailRequestService
            .getIndividualSalesPerson(value.EmployeeKeyId)
            .subscribe(
                data => {
                    if (data) {
                        data = JSON.parse(JSON.stringify(data));
                        Object.keys(this.reqForm.controls).forEach(item => {
                            switch (item) {
                                case 'supervisor__c':
                                    this.reqForm.controls[item].setValue(data.result.MgrName);
                                    break;
                                case 'supervisor_Email__c':
                                    this.reqForm.controls[item].setValue(data.result.MgrEmail);
                                    break;
                                case 'supervisor_Id__c':
                                    this.reqForm.controls[item].setValue(data.result.MgrEmpKeyId);
                                    break;
                                case 'delegate_Id__c':
                                    this.reqForm.controls[item].setValue(
                                        data.result.DelegateMgrEmpKeyId
                                    );
                                    break;
                                case 'delegate_Email__c':
                                    this.reqForm.controls[item].setValue(
                                        data.result.DelegateMgrEmail
                                    );
                                    break;

                                case 'SPTR_Email__c':
                                    this.reqForm.controls[item].setValue(value.emailAddress);
                                    break;
                                case 'Branch_Location__c':
                                    this.reqForm.controls[item].setValue(value.BranchLocation);
                                    break;
                                case 'SalesCategoryType__c':
                                    this.reqForm.controls[item].setValue(value.SalesCategoryType);
                                    break;

                                case 'SalesCategoryId__c':
                                    this.reqForm.controls[item].setValue(value.SalesCategoryId);
                                    break;
                                case 'SalesCategory__c':
                                    this.reqForm.controls[item].setValue(value.SalesCategory);
                                    break;
                                case 'SalesPerson_Percent__c':
                                    this.reqForm.controls[item].setValue(value.Percentage);
                                    break;
                                case 'SalesPerson_GroupName__c':
                                    this.reqForm.controls[item].setValue(value.SalesGroup);
                                    break;
                                case 'Marketer__c':
                                    this.reqForm.controls[item].setValue(value.SPName);
                                    break;
                                case 'SalesPerson__ui':
                                    this.reqForm.controls[item].setValue(
                                        value.SPName +
                                        ' (' +
                                        value.SalesGroup +
                                        '-' +
                                        value.Percentage +
                                        '%)'
                                    );
                                    break;
                                case 'SalesPerson_Emp_Key_Id__c':
                                    this.reqForm.controls[item].setValue(value.EmployeeKeyId);
                                    break;
                            }
                        });
                    }
                    this.onModalClose();
                    this.showhidetabsbuttons();
                },
                error => {
                    console.error(error);
                    this.isSearchLoading = false; // stop spinner
                    this.alertService.clear();
                    this.alertService.warn(
                        'Not able to communicate with Service Please try Again'
                    );
                }
            );
    }
    populateMarketer(value: any): void {
        this.isSave = false;
        this.showAlert = false;
        Object.keys(this.reqForm.controls).forEach(item => {
            switch (item) {
                case 'Marketer__c':
                    this.reqForm.controls[item].setValue(
                        value.FirstName + ' ' + value.LastName
                    );
                    break;
                case 'Branch_Location__c':
                    this.reqForm.controls[item].setValue(value.BranchLocation);
                    break;
            }
        });
        this.onModalClose();
        this.showhidetabsbuttons();
    }
    populateAPACHongKongDetails(value: any): void {
        this.alertService.clear();

        this.detailRequestService.getAPACDetails(value.LegalId).subscribe(data => {
            if (data) {
                data = JSON.parse(JSON.stringify(data.resultAPACDetails));
                if (!data.IsAPACLegal) {
                    this.isSaveLoading = false;
                    this.showAlert = true;
                    this.errorMessage = 'This is not an APAC Legal!';
                    this.initializeModels();
                }
                else {
                    Object.keys(this.reqForm.controls).forEach(item => {
                        switch (item) {
                            case 'Hong_Kong_Classification__c':
                                this.reqForm.controls[item].setValue(data.HongKongInvClass);
                                break;
                            case 'Product_group_Market_coverage__c':
                                if (data.ProdMrkCoverage != '') {
                                    this.reqForm.controls[item].setValue(data.ProdMrkCoverage.split(';'));
                                }
                                //this.reqForm.controls[item].setValue(data.ProdMrkCoverage);
                                break;
                            case 'APAC_Comments__c':
                                this.reqForm.controls[item].setValue(data.APACComments);
                                break;
                        }
                    });
                }
            }
        });
    }
    // populateChangesForCoverage(value: any): void {
    //     this.alertService.clear();

    //     this.detailRequestService.getChangesForCoverageDetails(value.LegalId).subscribe(data => {
    //         if (data) {
    //             data = JSON.parse(JSON.stringify(data.resultAPACDetails));                
    //             Object.keys(this.reqForm.controls).forEach(item => {
    //                 switch (item) {
    //                     case 'Sales_Coverage_Start_Date__c':
    //                         this.reqForm.controls[item].setValue(data.HongKongInvClass);
    //                         break;
    //                     case 'Sales_Coverage_End_Date__c':
    //                         if (data.ProdMrkCoverage != '') {
    //                             this.reqForm.controls[item].setValue(data.ProdMrkCoverage);
    //                         }
    //                         break;
    //                     case 'SalesPerson_GroupName__c':
    //                         this.reqForm.controls[item].setValue(data.APACComments);
    //                         break;
    //                 }
    //             });
    //         }
    //     });
    // }
    populateForm(mtReqId) {
        this.isSaveLoading = true;
        this.detailRequestService.GetMaintenanceRequestDetails(mtReqId).subscribe(
            data => {
                if (data) {
                    data = JSON.parse(JSON.stringify(data));
                    this.maintenanceRequestOutput = data.MaintenanceRequestOutput;

                    this.callbackRequestOutput = data.CallbackThirdPartyRequestOutput;
                    this.maintenanceRequestDetailOutputs =
                        data.MaintenanceRequestDetailOutputs;
                    this.formFields = this.detailRequestService.buildCommonFields(
                        this.maintenanceReqType,
                        this.maintenanceReqSubType,
                        this.cobamRole,
                        this.formFields,
                        this.maintenanceRequestOutput.Status__c
                    );
                    for (const prop of Object.keys(this.maintenanceRequestOutput)) {
                        if (this.reqForm.controls[prop]) {
                            if (prop === 'CreatedDate') {
                                this.reqForm.controls[prop].setValue(
                                    new Date(
                                        this.datePipe.transform(
                                            this.maintenanceRequestOutput[prop],
                                            'MM/dd/yyyy h:mm a'
                                        )
                                    ).toLocaleString()
                                );
                            } else if (prop === 'Owner') {
                                this.reqForm.controls[prop].setValue(
                                    this.maintenanceRequestOutput[prop].Name
                                );
                            } else if (prop === 'FX_Specific_Products__c') {
                                this.reqForm.controls['FX_Specific_Products__c'].setValue(
                                    this.maintenanceRequestOutput[prop].split(';')
                                );
                            } else if (prop === 'WFS_Booking_Entity__c') {
                                this.reqForm.controls['WFS_Booking_Entity__c'].setValue(
                                    this.maintenanceRequestOutput[prop].split(';')
                                );
                            }
                            else if (prop === 'Product_group_Market_coverage__c' && this.maintenanceRequestOutput[prop] != null) {
                                this.reqForm.controls['Product_group_Market_coverage__c'].setValue(
                                    this.maintenanceRequestOutput[prop].split(';')
                                );
                            } else if (prop === 'RequestedBy__r') {
                                if (
                                    this.maintenanceRequestOutput[prop].Desk__c != null &&
                                    this.maintenanceRequestOutput[prop].Desk__c !== undefined
                                ) {
                                    this.reqForm.controls[prop].setValue(
                                        this.maintenanceRequestOutput[prop].Desk__c
                                    );
                                }
                            } else {
                                this.reqForm.controls[prop].setValue(
                                    this.maintenanceRequestOutput[prop]
                                );
                            }
                        }
                    }
                    if (
                        this.maintenanceReqSubType === 'Wire Changes' &&
                        this.callbackRequestOutput != undefined &&
                        this.callbackRequestOutput != null
                    ) {
                        this.callbackId = this.callbackRequestOutput.Id;
                        this.reloadCallbackHistory();

                        (async () => {
                            await this.delay(5000);
                            this.populateCallbackOutput();
                            this.enableDisableQueueStatus(
                                this.cobamRole,
                                this.maintenanceRequestOutput.Status__c
                            );
                            this.showhidetabsbuttons();
                            this.isSaveLoading = false;
                        })();
                    } else {
                        this.enableDisableQueueStatus(
                            this.cobamRole,
                            this.maintenanceRequestOutput.Status__c
                        );
                        this.showhidetabsbuttons();
                        this.isSaveLoading = false;
                    }
                    if (this.maintenanceReqSubType === 'Hong Kong Classification Refresh') {
                        this.reloadAPACCommetsHistory();
                    }
                    //if (
                    //    this.reqForm.get('Maintenance_Request_Type__c').value ===
                    //    'MiFID Categorization Change'
                    //) {
                    //    this.reqForm.get('WFS_Booking_Entity__c').enable();
                    //    this.reqForm.get('MiFID_II_Client_Categorization__c').enable();
                    //}
                    //if (this.cobamRole !== 'Tax Withholding' && (this.maintenanceReqSubType === 'Tax Withholding Reversal' && (this.reqForm.get('Status__c').value === 'Closed' || this.reqForm.get('Status__c').value === 'DDA Funded'))) {
                    if (this.maintenanceReqSubType === 'Tax Withholding Reversal') {
                        if (this.cobamRole === 'Tax Withholding') {
                            if (this.reqForm.get('Status__c').value !== 'Closed' && this.reqForm.get('Status__c').value !== 'DDA Funded') {
                                this.reqForm.get('Closed_Reason__c').setValue('');
                                this.reqForm.get('EFTPS_ID__c').setValue('');
                                this.reqForm.get('Closed_Reason__c').disable();
                                this.reqForm.get('EFTPS_ID__c').disable();
                            }
                            else if (this.reqForm.get('Status__c').value === 'Closed') {
                                this.reqForm.get('Closed_Reason__c').disable();
                                this.reqForm.get('EFTPS_ID__c').disable();
                            }
                            else if (this.reqForm.get('Status__c').value === 'DDA Funded') {
                                this.reqForm.get('Closed_Reason__c').enable();
                                this.reqForm.get('EFTPS_ID__c').enable();
                            }
                        }
                        else {
                            this.reqForm.get('Closed_Reason__c').disable();
                            this.reqForm.get('EFTPS_ID__c').disable();
                        }

                        //}
                    }
                    if (this.maintenanceReqSubType === 'Tax Withholding Reversal') {
                        this.subscriptions.push(
                            this.reqForm
                                .get('Status__c')
                                .valueChanges.subscribe(() =>
                                    this.OnStatusChangeForTaxWithholdingReversal()
                                )
                        );
                    }
                    if (this.maintenanceReqSubType === 'Safekeeping Updates') {
                        if (this.reqForm.controls['SalesPerson__ui']) {
                            this.reqForm.controls['SalesPerson__ui'].setValue(
                                (this.maintenanceRequestOutput['Marketer__c'] != null
                                    ? this.maintenanceRequestOutput['Marketer__c']
                                    : '') +
                                ' (' +
                                (this.maintenanceRequestOutput['SalesPerson_GroupName__c'] != null
                                    ? this.maintenanceRequestOutput['SalesPerson_GroupName__c']
                                    : '') +
                                '-' +
                                (this.maintenanceRequestOutput['SalesPerson_GroupName__c'] != null
                                    ? this.maintenanceRequestOutput['SalesPerson_GroupName__c']
                                    : '') +
                                '%)'
                            );
                        }
                    }
                    console.warn('The data is', this.reqForm);
                }
            },
            error => {
                console.error(error);
                this.isSaveLoading = false; // stop spinner
                this.alertService.clear();
                this.alertService.warn(
                    'Not able to communicate with Service Please try Again'
                );
            }
        );
    }
    onOptionsDropDownSelectionChange(value: string) {
        if (value === 'MiFID_II_Client_Categorization__c'
            || value === 'MiFID_II_Investment_Firm__c'
            || value === 'MiFID_II_Central_Bank__c') {
            this.maintenanceRequestInput.MifIDChange = true;
        }
    }

    OnStatusChangeForTaxWithholdingReversal(): void {
        if (this.cobamRole === 'Tax Withholding' && this.reqForm.dirty && (this.reqForm.get('Status__c').value === 'Closed' || this.reqForm.get('Status__c').value === 'DDA Funded')) {
            this.reqForm.get('Closed_Reason__c').enable();
        }
        else if (this.cobamRole === 'Tax Withholding' && !this.reqForm.dirty && this.reqForm.get('Status__c').value === 'DDA Funded') {
            this.reqForm.get('Closed_Reason__c').enable();
            this.reqForm.get('EFTPS_ID__c').enable();
        }
        else {
            this.reqForm.get('Closed_Reason__c').disable();
            this.reqForm.get('EFTPS_ID__c').disable();
        }
    }
    closeErrorMsg() {
        this.showAlert = false;
    }
    selectLegalRowData(item: any): void {
        console.log('The item selected', item);

        this.isSave = false;
        this.showAlert = false;
        Object.keys(this.reqForm.controls).forEach(prop => {
            switch (prop) {
                case 'Address_Line1__c':
                    this.reqForm.controls[prop].setValue(item.Address1);
                    break;
                case 'Address_Line2__c':
                    this.reqForm.controls[prop].setValue(item.Address2);
                    break;
                case 'Country__c':
                    this.reqForm.controls[prop].setValue(item.CountryCode);
                    break;
                case 'City__c':
                    this.reqForm.controls[prop].setValue(item.City);
                    break;
                case 'Zip__c':
                    this.reqForm.controls[prop].setValue(item.Zip);
                    break;
                case 'Canada_Province__c':
                    this.reqForm.controls[prop].setValue(item.CanadianProvince);
                    break;
                case 'Postal_Code__c':
                    this.reqForm.controls[prop].setValue(item.CanadianPostal);
                    break;
            }
        });
        this.onModalClose();
        this.showhidetabsbuttons();
    }
    showhidetabsbuttons() {
        const payLoad = JSON.parse(JSON.stringify(this.reqForm.value));
        this.showEditButton = false;
        if (
            this.reqStatus === 'Draft' &&
            payLoad['Name'] != null &&
            payLoad['Name'] !== '' &&
            payLoad['Maintenance_Request_Sub_Type__c'] !== 'Update POQ'
        ) {
            this.showUpdateButton = false;
            if (this.isValidMaintenanceSalesforceUser) {
                this.showAttachFilesTab = true;
                this.showChatterTab = true;
            }
            this.showSaveButton = true;
            this.showSubmitButton = true;
        } else if (
            this.reqStatus === 'Draft' &&
            (payLoad['Name'] == null || payLoad['Name'] === '')
        ) {
            this.showSaveButton = true;
            this.showUpdateButton = false;
            this.showAttachFilesTab = false;
            this.showChatterTab = false;
        } else if (
            this.reqStatus !== 'Draft' &&
            this.reqStatus !== 'Submitted' &&
            this.reqStatus !== 'Approved in CID Staging' &&
            this.reqStatus !== 'Closed - Approved' &&
            this.reqStatus !== 'Closed - Inactive' &&
            this.reqStatus !== 'Closed' &&
            payLoad['Name'] != null &&
            payLoad['Name'] !== '' &&
            (this.cobamRole === 'Maintenance' ||
                this.cobamRole === 'DCOT' ||
                this.cobamRole === 'Account Approval' ||
                this.cobamRole === 'Tax Withholding' ||
                this.cobamRole === 'Client Services')
        ) {
            if (this.maintenanceReqType === 'MiFID Categorization Change' && this.maintenanceReqSubType === 'MiFID Categorization Change'){
                this.showSaveButton = false;
            }
            else{
                this.showSaveButton = true;
            }
            this.showUpdateButton = false;
            if (this.isValidMaintenanceSalesforceUser) {
                this.showAttachFilesTab = true;
                this.showChatterTab = true;
            }
        } else if (
            payLoad['Status__c'] === 'Submitted' ||
            this.reqForm.get('Status__c').value === 'Submitted' ||
            payLoad['Status__c'] === 'Approved in CID Staging' ||
            this.reqForm.get('Status__c').value === 'Approved in CID Staging'
        ) {
            this.showSaveButton = false;
            this.showUpdateButton = false;

            if (this.isValidMaintenanceSalesforceUser) {
                this.showAttachFilesTab = true;
                this.showChatterTab = true;
            }
            // if (this.chattertabauthorizeduser === true) {
            //     this.showChatterTab = true;
            // }
        } else {
            this.showSaveButton = false;
            this.showUpdateButton = false;
            this.showSubmitButton = false;

            if (this.isValidMaintenanceSalesforceUser) {
                this.showAttachFilesTab = true;
                this.showChatterTab = true;
            }
            // if (this.chattertabauthorizeduser === true) {
            //     this.showChatterTab = true;
            // }
        }

        if (
            this.maintenanceReqType === 'Update POQ' &&
            this.maintenanceReqSubType === 'Update POQ' &&
            payLoad['Name'] !== '' &&
            payLoad['Name'] !== null &&
            !(
                payLoad['Status__c'] === 'Submitted' ||
                this.reqForm.get('Status__c').value === 'Submitted' ||
                payLoad['Status__c'] === 'Approved in CID Staging' ||
                this.reqForm.get('Status__c').value === 'Approved in CID Staging'
            )
        ) {
            this.showUpdateButton = true;
            this.showSaveButton = true;
            this.showSubmitButton = false;
        }

        if (
            this.maintenanceReqSubType === 'Wire Changes' &&
            (this.cobamRole === 'Maintenance' ||
                this.cobamRole === 'Account Approval') &&
            this.maintenanceRequestOutput != null &&
            this.maintenanceRequestOutput.Assigned_To__r !== undefined &&
            this.maintenanceRequestOutput.Assigned_To__r !== null &&
            (this.reqForm.get('callback_Status__c').value ===
                'Callback Complete - Client Validated' ||
                this.reqForm.get('callback_Status__c').value ===
                'Callback - Supervisory Principal Approved') &&
            (this.reqForm.get('Is_this_Wire_a_Third_Party_payment__c').value ===
                'No' ||
                (this.reqForm.get('Is_this_Wire_a_Third_Party_payment__c').value ===
                    'Yes' &&
                    this.reqForm.get('third_Party_Exception_Approval_Status__c').value ===
                    'Third Party Exception - Supervisory Principal Approved')) &&
            (this.reqStatus !== 'Draft' &&
                this.reqStatus !== 'Submitted' &&
                this.reqStatus !== 'Approved in CID Staging' &&
                this.reqStatus !== 'Closed - Approved' &&
                this.reqStatus !== 'Closed - Rejected' &&
                this.reqStatus !== 'Closed - Inactive')
        ) {
            this.showPOQButton = true;
        } else {
            this.showPOQButton = false;
        }

        if (
            this.maintenanceReqSubType === 'Wire Changes' &&
            this.cobamRole === 'Client Services' &&
            this.callbackRequestOutput != null &&
            this.callbackRequestOutput.callback_Analyst__r !== undefined &&
            this.callbackRequestOutput.callback_Analyst__r != null &&
            this.reqForm.get('callback_Status__c').value ===
            'Callback Performed - No Answer'
        ) {
            this.showSendEmailButton = true;
            if (
                this.callbackRequestOutput.third_Party_Exception_Approval_Status__c !==
                'Third Party Exception - Supervisory Principal Rejected' &&
                this.callbackRequestOutput.callback_Status__c ===
                'Callback Performed - No Answer'
            ) {
                this.disableSendEmailButton = false;
            } else {
                this.disableSendEmailButton = true;
            }
        } else {
            this.showSendEmailButton = false;
        }
        if (this.maintenanceReqType === 'MiFID Categorization Change' &&
            this.maintenanceReqSubType === 'MiFID Categorization Change'
            && this.cobamRole === 'DCOT' && (this.maintenanceRequestOutput != null && this.maintenanceRequestOutput.Assigned_To__r != null)) {
            this.showUpdateButton = false;
        }

        if (
            this.maintenanceReqSubType !== 'Update POQ' &&
            (this.cobamRole === 'Requester' ||
                this.cobamRole === 'Tax Profile II' ||
                this.cobamRole === 'Requester NonCash' ||
                this.cobamRole === 'AML KYC' ||
                this.cobamRole === 'Requester Maintenance' ||
                this.cobamRole === 'Requester FX' ||
                this.authService.HasRequesterMaintenanceAccess) &&
            (this.reqStatus === 'Closed - Rejected' ||
                (this.callbackRequestOutput !== undefined &&
                    this.callbackRequestOutput !== null &&
                    this.callbackRequestOutput.callback_Status__c ===
                    'Callback Performed - Technical Error'))
        ) {
            this.showEditButton = true;
        }

        if (
            this.maintenanceReqSubType === 'Wire Changes' &&
            this.reqStatus !== 'Draft' &&
            this.callbackId !== ''
        ) {
            this.showCallbackHistoryTab = true;
        } else {
            this.showCallbackHistoryTab = false;
        }

        if (this.maintenanceReqSubType === 'Safekeeping Updates') {
            if (this.reqStatus === 'Draft' && payLoad['Name'] !== '' && payLoad['Name'] !== null) {
                this.detailRequestService.getSafeKeepingFlag(payLoad['BA_ID__c']).subscribe(data => {
                    if (data) {
                        this.showSKFeeDiscountButton = data.skFlag;
                    } else {
                        this.showSKFeeDiscountButton = false;
                    }
                });
            }
            if (this.reqStatus === 'Closed - Rejected') {
                this.showEditButton = false;
            }
            if (this.cobamRole === 'Maintenance' ||
                this.cobamRole === 'DCOT' ||
                this.cobamRole === 'Account Approval' ||
                this.cobamRole === 'Tax Withholding' ||
                this.cobamRole === 'Client Services') {
                this.showSaveButton = false;
                this.showSKFeeDiscountButton = false;
            }
        }

        if (
            this.reqStatus === 'Draft' &&
            this.maintenanceReqSubType === 'Changes for Coverage'
        ) {
            this.showUpdateButton = false;
            this.showSaveButton = true;
            if (this.mtReqId != null && this.mtReqId !== '') {
                this.showSubmitButton = true;
                if (this.isValidMaintenanceSalesforceUser) {
                    this.showAttachFilesTab = true;
                    this.showChatterTab = true;
                }
            }
            
        }

        if (this.maintenanceReqType === 'MiFID Categorization Change' &&
            this.maintenanceReqSubType === 'MiFID Categorization Change'
            && this.reqStatus === 'Closed - Rejected') {
            this.showUpdateButton = false;
            this.showSubmitButton = false;
            this.showSaveButton = false;
            this.showEditButton = false;
        }

        if (this.maintenanceReqSubType === 'Hong Kong Classification Refresh') {
            this.showAPACCommentsHistoryTab = true;
        } else {
            this.showAPACCommentsHistoryTab = false;
        }
    }
    editDetails() {
        if (this.reqStatus === 'Closed - Rejected') {
            this.reqForm.get('Status__c').setValue('Draft');
        }
        this.showSubmitButton = true;
        this.showSaveButton = true;
        this.showEditButton = false;
    }
    saveDetailsservice() {
        let keysArr = [];
        keysArr = Object.keys(this.reqForm.controls);
        keysArr.forEach(key => {
            if (this.maintenanceRequestInput[key] !== undefined) {
                this.maintenanceRequestInput[key] = this.reqForm.get(key).value;
            }
            if (this.callbackRequestInput[key] !== undefined) {
                this.callbackRequestInput[key] = this.reqForm.get(key).value;
            }
        });
        if (this.maintenanceRequestInput['FX_Specific_Products__c']) {
            this.maintenanceRequestInput['FX_Specific_Products__c'] = this.maintenanceRequestInput['FX_Specific_Products__c'].join(';');
        }
        if (this.maintenanceRequestInput['WFS_Booking_Entity__c']) {
            this.maintenanceRequestInput['WFS_Booking_Entity__c'] = this.maintenanceRequestInput['WFS_Booking_Entity__c'].join(';');
        }
        if (this.maintenanceRequestInput['Product_group_Market_coverage__c']) {
            this.maintenanceRequestInput['Product_group_Market_coverage__c'] = this.maintenanceRequestInput['Product_group_Market_coverage__c'].join(';');
        }
        if (
            this.maintenanceRequestInput.ChangeLegalAcctOrBusAcctData__c ===
            'Business Account'
        ) {
            this.maintenanceRequestInput.CID_LEID__c = '';
            this.maintenanceRequestInput.Legal_Name__c = '';
        } else if (
            this.maintenanceRequestInput.ChangeLegalAcctOrBusAcctData__c ===
            'Legal Account'
        ) {
            this.maintenanceRequestInput.Business_Acct_Fund_Name__c = '';
            this.maintenanceRequestInput.BA_ID__c = '';
        }
        if (this.maintenanceReqSubType === 'Wire Changes') {
            this.manageCallbakcThirdPartyFields();
        }
        this.maintenanceRequestParentInput.MaintenanceRequestInput = this.maintenanceRequestInput;
        this.maintenanceRequestParentInput.MaintenanceRequestDetailInputs = this.mtRequestDetaiIntputs;
        this.maintenanceRequestParentInput.UserAction = this.userAction;
        this.payLoad = JSON.stringify(this.maintenanceRequestParentInput);
        this.detailRequestService.AddMaintenanceRequest(this.payLoad).subscribe(
            data => {
                if (!data.startsWith('Error')) {
                    console.log('The data from backend is', data);
                    this.mtReqId = data;
                    this.isSave = true;
                    this.isSaveLoading = false;
                    this.populateForm(this.mtReqId);
                    this.showAlert = false;
                } else {
                    this.isSaveLoading = false;
                    this.showAlert = true;
                    this.errorMessage = data.replace('Error', '');
                    this.initializeModels();
                }
            },
            error => {
                this.isSaveLoading = false;
                console.error(error);
                this.alertService.clear();
                this.alertService.warn(
                    'Not able to communicate with Service Please try Again'
                );
                this.initializeModels();
            }
        );
    }
    populateCallbackOutput(): void {
        this.thirdpartyApprovalStatus = this.callbackRequestOutput.third_Party_Exception_Approval_Status__c;
        this.thirdpartyType = this.callbackRequestOutput.third_Party_Request_Type__c;
        for (const prop of Object.keys(this.callbackRequestOutput)) {
            if (
                this.reqForm.controls[prop] ||
                prop === 'third_Party_form_Completed_By__r'
            ) {
                if (prop === 'third_Party_form_Completed_By__r') {
                    this.reqForm.controls['third_Party_form_Completed_By__c'].setValue(
                        this.callbackRequestOutput['third_Party_form_Completed_By__r'] !=
                            null
                            ? this.callbackRequestOutput['third_Party_form_Completed_By__r']
                                .Name
                            : this.currentUserName
                    );
                } else if (prop === 'beneficiary_ID_Type__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput['beneficiary_ID_Type__c'] != null
                            ? this.callbackRequestOutput['beneficiary_ID_Type__c']
                            : ''
                    );
                } else if (prop === 'beneficiary_Bank_Financial_Institution_O__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput[
                            'beneficiary_Bank_Financial_Institution_O__c'
                        ] != null
                            ? this.callbackRequestOutput[
                            'beneficiary_Bank_Financial_Institution_O__c'
                            ]
                            : ''
                    );
                } else if (prop === 'third_Party_Request_Type__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput['third_Party_Request_Type__c'] != null
                            ? this.callbackRequestOutput['third_Party_Request_Type__c']
                            : ''
                    );
                } else if (prop === 'third_Party_Exception_Approval_Status__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput[
                            'third_Party_Exception_Approval_Status__c'
                        ] != null
                            ? this.callbackRequestOutput[
                            'third_Party_Exception_Approval_Status__c'
                            ]
                            : ''
                    );
                } else if (prop === 'intermediary_Bank_ID_Type__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput['intermediary_Bank_ID_Type__c'] != null
                            ? this.callbackRequestOutput['intermediary_Bank_ID_Type__c']
                            : ''
                    );
                } else if (prop === 'source_Type__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput['source_Type__c'] != null
                            ? this.callbackRequestOutput['source_Type__c']
                            : ''
                    );
                } else if (prop === 'third_Party_Approval_Timestamp__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput.ThirdPartyApprovalTimestampInternal != ''
                            ? this.callbackRequestOutput.ThirdPartyApprovalTimestampInternal
                            : null
                    );
                } else if (prop === 'desk_Head_Callback_Exception_App_Time__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput
                            .DeskHeadCallbackExceptionAppTimeInternal != ''
                            ? this.callbackRequestOutput
                                .DeskHeadCallbackExceptionAppTimeInternal
                            : null
                    );
                } else if (prop === 'callback_Time__c') {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput.callback_Time__c != ''
                            ? this.callbackRequestOutput.callback_Time__c
                            : null
                    );
                } else {
                    this.reqForm.controls[prop].setValue(
                        this.callbackRequestOutput[prop]
                    );
                }
            }
        }
        if (this.reqForm.controls['SalesPerson__ui']) {
            this.reqForm.controls['SalesPerson__ui'].setValue(
                (this.maintenanceRequestOutput['Marketer__c'] != null
                    ? this.maintenanceRequestOutput['Marketer__c']
                    : '') +
                ' (' +
                (this.maintenanceRequestOutput['SalesPerson_GroupName__c'] != null
                    ? this.maintenanceRequestOutput['SalesPerson_GroupName__c']
                    : '') +
                '-' +
                (this.maintenanceRequestOutput['SalesPerson_GroupName__c'] != null
                    ? this.maintenanceRequestOutput['SalesPerson_GroupName__c']
                    : '') +
                '%)'
            );
        }
    }

    reloadCallbackHistory() {
        if (
            this.callbackId !== '' &&
            this.maintenanceRequestOutput.Status__c !== 'Draft'
        ) {
            this.detailRequestService
                .GetCallbackTrackingHistory(this.callbackId)
                .subscribe(
                    data => {
                        if (data) {
                            this.CallbackTableData = data.result;
                        }
                    },
                    error => { }
                );
        }
    }
    reloadAPACCommetsHistory() {
        // if (
        //     this.maintenanceRequestOutput.Id !== '' &&
        //     this.maintenanceRequestOutput.Status__c !== 'Draft'
        // ) {
            this.detailRequestService
                .GetAPACCommentsHistory(this.maintenanceRequestOutput.Id)
                .subscribe(
                    data => {
                        if (data) {
                            this.APACCommentsHistoryTableData = data.result;
                        }
                    },
                    error => { }
                );
        //}
    }
    saveDetails() {
        this.isSaveLoading = true;
        this.userAction = 'SAVE';
        if (this.mtReqId != null && this.mtReqId !== '') {
            this.updateDetailsService();
        } else {
            this.saveDetailsservice();
        }
    }
    updateaccount() {
        this.isSaveLoading = true;

        if (this.maintenanceReqType === 'MiFID Categorization Change' &&
            this.maintenanceReqSubType === 'MiFID Categorization Change'
            && this.cobamRole === 'DCOT') {
            this.userAction = 'SAVE';
        }
        else {
            this.userAction = 'SUBMIT';
        }
        this.canOpenPOQWindow = true;
        this.updateDetailsService();
        this.showSaveButton = false;
        this.showUpdateButton = false;
        this.showAttachFilesTab = true;
        this.showChatterTab = true;
    }
    submitaccount() {
        if (this.maintenanceReqType === 'MiFID Categorization Change' && this.maintenanceReqSubType === 'MiFID Categorization Change') {
            //soft check for MiFID Categorization change       
            alert('Please attach documentation to support the requested MiFID change.');
        }
        this.isSaveLoading = true;
        this.userAction = 'SUBMIT';
        this.updateDetailsService();
    }
    openPOQForWire() {
        if (
            this.maintenanceRequestOutput.Id &&
            this.maintenanceRequestOutput.BA_ID__c
        ) {
            const url = this.authService.configuration.POQURL; //environment.POQURL; 
            const isMiFIDRequest = 'false';
            const isWireRequest = 'true';
            const action =
                url +
                '/createpoq/UpdatePOQMain.aspx?isMaintenenceRequest=true&BusAcctId=' +
                this.maintenanceRequestOutput.BA_ID__c +
                '&sfdcRecId=' +
                this.maintenanceRequestOutput.Id +
                '&isMiFIDRequest=' +
                isMiFIDRequest +
                '&isWireRequest=' +
                isWireRequest;
            window.open(
                action,
                '_blank',
                'toolbar=yes,scrollbars=yes,resizable=yes,top=5,left=5,width=1500,height=900'
            );
        }
    }
    SendEmailForApproval() {
        if (this.callbackRequestOutput.Id) {
            this.isSaveLoading = true;
            this.detailRequestService
                .SendEmailForApproval(this.callbackRequestOutput.Id)
                .subscribe(
                    data => {
                        this.isSaveLoading = false;
                        if (data && !data.startsWith('Error')) {
                            this.showAlert = false;
                            alert(data);
                        } else {
                            this.showAlert = true;
                            this.errorMessage = data.replace('Error', '');
                        }
                    },
                    error => {
                        this.alertService.clear();
                        this.alertService.warn(
                            'Not able to communicate with Service Please try Again'
                        );
                        this.isSaveLoading = false;
                    }
                );
        }
    }
    openPOQWindow(mtReqId, busAcctId): void {
        const url = this.authService.configuration.POQURL; //environment.POQURL;
        let isMiFIDRequest = 'false';
        if (this.maintenanceReqType === 'MiFID Categorization Change' && this.maintenanceReqSubType === 'MiFID Categorization Change') {
            isMiFIDRequest = 'true'
        }
        const action =
            url +
            '/createpoq/UpdatePOQMain.aspx?isMaintenenceRequest=true&BusAcctId=' +
            busAcctId +
            '&sfdcRecId=' +
            mtReqId +
            '&isMiFIDRequest=' +
            isMiFIDRequest;

        window.open(
            action,
            '_blank',
            'toolbar=yes,scrollbars=yes,resizable=yes,top=5,left=5,width=1500,height=900'
        );
    }
    updateDetailsService() {
        let keysArr = [];
        keysArr = Object.keys(this.reqForm.controls);
        keysArr.forEach(key => {
            if (this.maintenanceRequestInput[key] !== undefined) {
                this.maintenanceRequestInput[key] = this.reqForm.get(key).value;
            }

            if (this.callbackRequestInput[key] !== undefined) {
                this.callbackRequestInput[key] = this.reqForm.get(key).value;
            }
        });
        if (this.maintenanceRequestInput['FX_Specific_Products__c']) {
            this.maintenanceRequestInput['FX_Specific_Products__c'] = this.maintenanceRequestInput['FX_Specific_Products__c'].join(';');
        }
        if (this.maintenanceRequestInput['WFS_Booking_Entity__c']) {
            this.maintenanceRequestInput['WFS_Booking_Entity__c'] = this.maintenanceRequestInput['WFS_Booking_Entity__c'].join(';');
        }
        if (this.maintenanceRequestInput['Product_group_Market_coverage__c']) {
            this.maintenanceRequestInput['Product_group_Market_coverage__c'] = this.maintenanceRequestInput['Product_group_Market_coverage__c'].join(';');
        }
        if (this.maintenanceReqSubType === 'Wire Changes') {
            this.manageCallbakcThirdPartyFields();
        }
        if (this.maintenanceReqSubType === 'Tax Withholding Reversal' && this.cobamRole === 'Tax Withholding' && !(this.reqForm.get('Status__c').value === 'Closed' || this.reqForm.get('Status__c').value === 'DDA Funded')) {
            this.maintenanceRequestInput.Closed_Reason__c = '';
            this.maintenanceRequestInput.EFTPS_ID__c = '';
        }

        this.maintenanceRequestParentInput.MaintenanceRequestInput = this.maintenanceRequestInput;
        this.maintenanceRequestParentInput.MaintenanceRequestInput.Id = this.mtReqId;
        if (this.maintenanceReqSubType === 'Flag/Tag Updates') {
            this.mtReqFlagGridList.displayFlagGridNormalList.forEach(
                x => (x.Flag__c = x.Flag__c === '--None--' ? '' : x.Flag__c)
            );
        }
        this.maintenanceRequestParentInput.MaintenanceRequestDetailInputs =
            this.mtReqFlagGridList && this.mtReqFlagGridList.displayFlagGridNormalList
                ? this.mtReqFlagGridList.displayFlagGridNormalList
                : this.mtReqFundIdGridList &&
                    this.mtReqFundIdGridList.displayFundGridNormalList
                    ? this.mtReqFundIdGridList.displayFundGridNormalList
                    : this.mtReqCIDLEIDGridList &&
                        this.mtReqCIDLEIDGridList.displayLEIDGridNormalList
                        ? this.mtReqCIDLEIDGridList.displayLEIDGridNormalList
                        : null;
        this.maintenanceRequestParentInput.MaintenanceRequestInput.CreatedDate = null;
        this.maintenanceRequestParentInput.UserAction = this.userAction;
        this.payLoad = JSON.stringify(this.maintenanceRequestParentInput);
        this.detailRequestService.UpdateMaintenanceRequest(this.payLoad).subscribe(
            data => {
                if (data && !data.startsWith('Error')) {
                    this.isSaveLoading = false;
                    this.populateForm(this.mtReqId);
                    this.showAlert = false;
                    this.showSubmitButton = false;
                    this.showSaveButton = false;
                    this.showSKFeeDiscountButton = false;
                    if (
                        ((this.maintenanceReqType === 'Update POQ' &&
                            this.maintenanceReqSubType === 'Update POQ') || (this.maintenanceReqType === 'MiFID Categorization Change' &&
                                this.maintenanceReqSubType === 'MiFID Categorization Change')) &&
                        this.canOpenPOQWindow
                    ) {
                        this.openPOQWindow(
                            this.maintenanceRequestOutput.Id,
                            this.maintenanceRequestOutput.BA_ID__c
                        );
                    }
                } else {
                    this.isSaveLoading = false;
                    this.showAlert = true;
                    this.errorMessage = data.replace('Error', '');
                    this.initializeModels();
                }
            },
            error => {
                console.error(error);
                this.alertService.clear();
                this.alertService.warn(
                    'Not able to communicate with Service Please try Again'
                );
                this.isSaveLoading = false;
                this.initializeModels();
            }
        );
    }

    manageCallbakcThirdPartyFields() {
        if (
            this.callbackRequestOutput != undefined &&
            this.callbackRequestOutput != null &&
            this.callbackRequestOutput.Id !== null &&
            this.callbackRequestOutput.Id !== ''
        ) {
            this.callbackRequestInput.Id = this.callbackRequestOutput.Id;
        }
        if (
            this.maintenanceRequestInput.Is_this_Wire_a_Third_Party_payment__c ===
            undefined ||
            this.maintenanceRequestInput.Is_this_Wire_a_Third_Party_payment__c ===
            null ||
            this.maintenanceRequestInput.Is_this_Wire_a_Third_Party_payment__c ===
            'No'
        ) {
            this.callbackRequestInput.third_Party_form_Completed_Date__c = null;
            this.callbackRequestInput.third_Party_Exception_Approval_Status__c = '';
            this.callbackRequestInput.third_Party_form_Completed_By__c = '';
            this.callbackRequestInput.fax__c = '';
            this.callbackRequestInput.telephone__c = '';
            this.callbackRequestInput.policy_Exception_Justification__c = '';
            this.callbackRequestInput.business_Unit_Requesting_Exception__c = '';
            this.callbackRequestInput.third_Party_Desk_Head_Approval__c = '';
            this.callbackRequestInput.third_Party_Approval_Timestamp__c = null;
            this.callbackRequestInput.existing_Thirdparty__c = '';
            this.callbackRequestInput.third_Party_Request_Type__c = '';
            this.callbackRequestInput.supervisor_Principal_Comments__c = '';
            this.callbackRequestInput.third_Party_Desk_Head_App_ID__c = '';
        } else if (
            this.maintenanceRequestInput.Is_this_Wire_a_Third_Party_payment__c ===
            'Yes' &&
            this.maintenanceRequestInput.Status__c == 'Draft'
        ) {
            this.callbackRequestInput.third_Party_form_Completed_By__c = this.currentUserId;
            if (
                this.callbackRequestInput.existing_Thirdparty__c != undefined &&
                this.callbackRequestInput.existing_Thirdparty__c != null &&
                this.callbackRequestInput.existing_Thirdparty__c
                    .toString()
                    .toLocaleLowerCase() === 'false'
            ) {
                this.callbackRequestInput.third_Party_form_Completed_Date__c = null;
            }
        } else if (
            this.maintenanceRequestInput.Is_this_Wire_a_Third_Party_payment__c ===
            'Yes'
        ) {
            this.callbackRequestInput.third_Party_form_Completed_By__c = this.callbackRequestOutput.third_Party_form_Completed_By__c;
            this.callbackRequestInput.third_Party_form_Completed_Date__c = null;
        }

        if (
            this.cobamRole === 'Client Services' &&
            this.callbackRequestInput.callback_Status__c ===
            'Callback Performed - Technical Error'
        ) {
            this.maintenanceRequestInput.Status__c = 'Closed - Rejected';
        }
        if (
            this.callbackRequestInput.beneficiary_Bank_Financial_Institution_O__c ===
            'Routing Number (ABA)'
        ) {
            this.callbackRequestInput.intermediary_Bank_ID_Type__c = '';
            this.callbackRequestInput.intermediary_Bank_Name__c = '';
            this.callbackRequestInput.routing_Number_Intermediary_Bank_ID__c = '';
        }
        this.callbackRequestInput.desk_Head_Callback_Exception_App_Time__c = null;

        if (
            this.reqForm.get('callback_Analyst__r').value != undefined &&
            this.reqForm.get('callback_Analyst__r').value != null
        ) {
            this.callbackRequestInput.callback_Analyst__c = this.reqForm.get(
                'callback_Analyst__r'
            ).value.Id;
        }
        this.maintenanceRequestParentInput.CallbackThirdPartyRequestInput = this.callbackRequestInput;
    }

    multiSelectionHandler(event) {
        if (event['controlName'] === 'WFS_Booking_Entity__c') {
            if (event.value.length < 4) {
                if (
                    event.value.length > 2 &&
                    event.value.filter(x => x === 'WFSLLC - US').length === 1 &&
                    event.value.filter(x => x === 'WFBNA - US').length === 1
                ) {
                    alert('You can select only two values WFSLLC - US and WFBNA - US');
                    this.reqForm.get('WFS_Booking_Entity__c').setValue(null);
                } else if (
                    event.value.length > 1 &&
                    !(
                        event.value.filter(x => x === 'WFSLLC - US').length === 1 &&
                        event.value.filter(x => x === 'WFBNA - US').length === 1
                    )
                ) {
                    alert('Please select only one WFS Entity value');
                    this.reqForm.get('WFS_Booking_Entity__c').setValue(null);
                }
            } else {
                alert(
                    'The multiple selection made is not a valid combination. The only combination allowed is WFSLLC-US and WFBNA-US.Please select a valid WFS Entity'
                );
                this.reqForm.get('WFS_Booking_Entity__c').setValue(null);
            }

            if (
                event.value.filter(x => x === 'WFBNA - US').length === 1 &&
                //&& !isFieldEmpty(mainReqModelRow.Branch_Location__c)
                this.reqForm
                    .get('Branch_Location__c')
                    .value()
                    .toLowerCase() !== 'london' &&
                this.reqForm
                    .get('Branch_Location__c')
                    .value()
                    .toLowerCase() !== 'dublin'
            ) {
                alert(
                    'The Request doesn’t qualify for MiFID II Categorization, please review the request details.'
                );
            }

            if (
                event.value.length > 0 &&
                event.value.filter(x => x === 'WFSIL').length <= 0 &&
                event.value.filter(x => x === 'WFBNA - LB').length <= 0 &&
                event.value.filter(x => x === 'WFBNA - US').length <= 0
            ) {
                alert(
                    'The Request doesn’t qualify for MiFID II Categorization, please review the account details.'
                );
            }

            if (event['controlName'] === 'Product_group_Market_coverage') {
              this.reqForm.get('Product_group_Market_coverage__c').setValue('');
              event.value.forEach(key => {
                this.reqForm
                  .get('Product_group_Market_coverage__c')
                  .setValue(
                    this.reqForm.get('Product_group_Market_coverage__c').value + key + ';'
                  );
              });
            }

        }
    }

    openSKUtility() {
        if (this.maintenanceReqSubType === 'Safekeeping Updates'
            && this.maintenanceRequestOutput.Id
            && this.maintenanceRequestOutput.BA_ID__c
            && this.currentUserId) {
            const url = this.authService.configuration.SKUtilityURL; //environment.SKUtilityURL;
            const action = url +
                '#/Safekeeping/COBAM/' +
                this.maintenanceRequestOutput.Id +
                '/' +
                this.detailRequestService.getLoggedInUser()
                + '/maintenance';
            console.log(action);
            window.open(
                action,
                '_blank',
                'toolbar=yes,scrollbars=yes,resizable=yes,top=5,left=5,width=1500,height=900'
            );
        }
    }

    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
        this.subscriptions = [];
    }
}
