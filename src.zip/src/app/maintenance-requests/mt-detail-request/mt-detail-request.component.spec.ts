import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MtDetailRequestComponent } from './mt-detail-request.component';

describe('DetailRequestComponent', () => {
  let component: MtDetailRequestComponent;
  let fixture: ComponentFixture<MtDetailRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MtDetailRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MtDetailRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
