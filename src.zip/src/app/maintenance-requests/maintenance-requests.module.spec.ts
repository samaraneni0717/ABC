import { MaintenanceRequestsModule } from './maintenance-requests.module';

describe('MaintenanceRequestsModule', () => {
  let maintenanceRequestsModule: MaintenanceRequestsModule;

  beforeEach(() => {
    maintenanceRequestsModule = new MaintenanceRequestsModule();
  });

  it('should create an instance', () => {
    expect(maintenanceRequestsModule).toBeTruthy();
  });
});
