import { Component, OnInit } from '@angular/core';
import { MaintenanceRequestsService } from '../shared/services/mainteance-requests.service';
import { MatDialog } from '@angular/material';
import { FormGroup } from '@angular/forms';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { AgGrid } from 'src/app/Common/ag-grid/ag-grid.model';
import { IGetRowsParams, IDatasource, GridOptions, GridApi } from 'ag-grid-community';
import { CobamSearchInput } from '../Models/CobamSearchInput';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AgGridLoadingOverlay } from 'src/app/Common/ag-grid/ag-grid-loading-overlay.component';
import { AgGridNoRowsOverlay } from 'src/app/Common/ag-grid/ag-grid-no-rows-overlay.component';


@Component({
  selector: 'app-maintenance-requests',
  templateUrl: './maintenance-requests.component.html',
  styleUrls: ['./maintenance-requests.component.css']
})
export class MaintenanceRequestComponent implements OnInit {
  gridApi: GridApi;
  defaultColDef = {
    sortable: true,
    resizable: true,
  };
  gridOptions: GridOptions = {
    pagination: true,
    rowModelType: 'infinite',
    cacheBlockSize: 25,
    paginationPageSize: 25,
    enableServerSideSorting: true,
    enableServerSideFilter: true,
  };
  sortValue = '';
  idlist = '';
  showAlert = false;
  mtRequestForm: FormGroup;
  formFields: QuestionBase<any>[] = [];
  requestType;
  requestSubType;
  isProcessingRequest = false;
  requestId;
  columnDefs: any[] = [];
  rowData = [{}];
  AgGridApi;
  rowParams: IGetRowsParams;
  fileName = 'Maintenance';
  showDeleteButton = false;
  errorMessage: string;
  payLoad: any;
  mtReqIds: any;
  mtRequestNumber: string;
  cobamSearchInput: CobamSearchInput;
  frameworkComponents = {
    agGridLoadingOverlay: AgGridLoadingOverlay,
    agGridNoRowsOverlay: AgGridNoRowsOverlay
  };
  loadingOverlayComponent = 'agGridLoadingOverlay';
  loadingOverlayComponentParams = { loadingMessage: 'Loading...' };
  noRowsOverlayComponent = 'agGridNoRowsOverlay';
  noRowsOverlayComponentParams = {
    noRowsMessageFunc: function () {
      return '';
    }
  };

  onSelectionChanged(event) {
    if (event.api.getSelectedNodes().length > 0) {
      this.mtReqIds = '';
      this.mtRequestNumber = '';
      event.api.getSelectedNodes().forEach(element => {
        this.mtReqIds += element.data.Id + ',';
        this.mtRequestNumber += element.data.Name + ', ';
      });
      this.mtReqIds = this.mtReqIds.substring(0, this.mtReqIds.length - 1);
      this.mtRequestNumber = this.mtRequestNumber.substring(0, this.mtRequestNumber.length - 2);
      this.showDeleteButton = true;
    } else {
      this.showDeleteButton = false;
    }
  }

  ngOnInit() {
    this.cobamSearchInput = this.assignDefaultValues();
    this.formFields = this.mrs.buildRequestFormFields();
    this.mtRequestForm = this.qcs.toFormGroup(this.formFields);
  }

  // tslint:disable-next-line:member-ordering
  dataSource: IDatasource = {
    getRows: (params: IGetRowsParams) => {
      this.gridApi.showLoadingOverlay();
      this.apiService(params).subscribe(response => {
        if (!this.authservice.HasRequesterMaintenanceAccess) {
          this.router.navigate(['notauthorized']);
        }
        params.successCallback(
          response['requestDetails'] as any[],
          null
        );
        this.gridApi.hideOverlay();
      },
        error => {
          console.error(error);
          this.alertService.clear();
          this.alertService.warn(
            'Not able to communicate with Service Please try Again'
          );
        }
      );
    }
  };

  constructor(private mrs: MaintenanceRequestsService, private dialog: MatDialog,
    private qcs: QuestionControlService, private authservice: AuthService, private router: Router, private alertService: AlertService) {

    this.mrs.getMaintenanceColumnDefinations().subscribe(response => {
      this.columnDefs = [{
        headerName: '',
        checkboxSelection: true,
        width: 30,
        suppressMenu: true,
        suppressFilter: true,
        filter: false,
      }];
      if (response && (response as any).columnDefs) {
        ((response as any).columnDefs as any[]).forEach(column => {
          this.columnDefs.push(AgGrid.LoadColumnDefinition(column)[0]);
        });
      }
    });
  }

  isRowSelectable(rowNode) {
    const aa = rowNode.data ? rowNode.data.Status__c === 'Draft' : false;
    return aa;
  }

  assignDefaultValues(): CobamSearchInput {
    const cobamObj = new CobamSearchInput();
    cobamObj.SortedList = '';
    cobamObj.SearchText = '';
    return cobamObj;
  }
  apiService(params) {
    if (params.sortModel.length > 0) {
      params.sortModel.forEach(item => this.sortValue = this.sortValue + item.colId + ' ' + item.sort + ' NULLS LAST' + ',');
    }
    this.cobamSearchInput.SortedList = this.sortValue.substring(0, this.sortValue.length - 1);
    this.cobamSearchInput.SearchText = params.filterModel;
    this.cobamSearchInput.PageSize = 25;
    this.cobamSearchInput.Endrow = params.endRow;
    this.payLoad = JSON.parse(JSON.stringify(this.cobamSearchInput));
    console.log(this.payLoad);
    return this.mrs.getMaintenanceRequests(this.payLoad);
  }
  onRowDoubleClicked(maintenancetemplate, event: any) {
    this.requestId = event.data.Id;
    this.requestType = event.data.Maintenance_Request_Type__c;
    this.requestSubType = event.data.Maintenance_Request_Sub_Type__c;
    const dialogRef = this.dialog.open(maintenancetemplate, {
      width: '95%',
      height: '95%'
    });
  }
  onGridReady(params: any) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.gridApi.setDatasource(this.dataSource);
  }

  Deleterow() {
    if (confirm('Are you sure you want to delete selected requests (' + this.mtRequestNumber + ' )? ')) {
      this.isProcessingRequest = true;
      if (this.mtReqIds.length > 0) {
        this.mrs.deleteMaintenanceRequests(this.mtReqIds).subscribe((data) => {
          if (data.indexOf('Error') <= -1) {
            this.isProcessingRequest = false;
            this.showAlert = true;
            this.errorMessage = 'Records deleted Successfully';
          } else {
            this.isProcessingRequest = false;
            this.showAlert = true;
            this.errorMessage = 'One or more records deletion failed';
          }
          this.mtReqIds = '';
          this.gridApi.setDatasource(this.dataSource);
          this.showDeleteButton = false;
        },
          error => {
            console.error(error);
            this.isProcessingRequest = false;
            this.alertService.clear();
            this.alertService.warn(
              'Not able to communicate with Service Please try Again'
            );
          });
      }
    }
  }
  closeErrorMsg() {
    this.showAlert = false;
  }
  onExport() {
    const params = {
      fileName: this.fileName + '.csv'
    };
    this.gridApi.exportDataAsCsv(params);
  }
  openModal(template): void {
    const dialogRef = this.dialog.open(template, {
      width: '40%',
      height: '40%',
      disableClose: true
    });
  }
  onModalClose() {
    this.dialog.closeAll();
    this.gridApi.setDatasource(this.dataSource);
    this.formFields = this.mrs.buildRequestFormFields();
    this.mtRequestForm = this.qcs.toFormGroup(this.formFields);
  }

  continueClick(maintenancetemplate: any, value: any) {
    Object.keys(this.mtRequestForm.controls).forEach(prop => {
      switch (prop) {
        case 'MaintenanceType':
          this.requestType = this.mtRequestForm.controls[prop].value;
          break;
        case 'MaintenanceSubType':
          this.requestSubType = this.mtRequestForm.controls[prop].value;
          break;
      }
      this.requestId = '';
    });
    const dialogRef = this.dialog.open(maintenancetemplate, {
      width: '95%',
      height: '95%',
      disableClose: true
    });
  }
}



