import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MtDetailRequestsFundIDsGridComponent } from './mt-detail-requests-fund-ids-grid.component';

describe('MtDetailRequestsFundIDsGridComponent', () => {
  let component: MtDetailRequestsFundIDsGridComponent;
  let fixture: ComponentFixture<MtDetailRequestsFundIDsGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MtDetailRequestsFundIDsGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MtDetailRequestsFundIDsGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
