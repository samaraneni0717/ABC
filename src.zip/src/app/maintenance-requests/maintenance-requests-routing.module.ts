import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SubmittedRequestComponent } from './submitted-request/submitted-request.component';
import { SavedRequestComponent } from './saved-request/saved-request.component';
import { MtDetailRequestComponent } from './mt-detail-request/mt-detail-request.component';
import { ChatterComponent } from '../Common/chatter/chatter.component';
import { MtDetailRequestsFlagComponent } from './mt-detail-requests-flag-grid/mt-detail-requests-flag-grid.component';
import { MtDetailRequestsFundIDsGridComponent } from './mt-detail-requests-fund-ids-grid/mt-detail-requests-fund-ids-grid.component';
import { MtDetailRequestsCIDLEIDComponent } from './mt-detail-requests-cidleid-grid/mt-detail-requests-cidleid-grid.component';
import { CallbackHistoryComponent } from '../Common/callback-history/callback-history.component';
import { MaintenanceRequestComponent } from './maintenance-requests/maintenance-requests.component';
const routes: Routes = [
  {
    path: 'submitted',
    component: SubmittedRequestComponent
  },
  {
    path: 'saved',
    component: SavedRequestComponent
  },
  {
    path: 'detail',
    component: MtDetailRequestComponent
  },
  {
    path: 'detail/:id',
    component: MtDetailRequestComponent
  },
  {
    path: 'chatter',
    component: ChatterComponent
  },
  {
    path: 'grid',
    component: MtDetailRequestsFlagComponent
  },
  {
    path: 'FundIdsgrid',
    component: MtDetailRequestsFundIDsGridComponent
  },
  {
    path: 'maintenance',
    component: MaintenanceRequestComponent
  },
  {
    path: 'CIDLEIdsgrid',
    component: MtDetailRequestsCIDLEIDComponent
  },
  {
    path: '',
    component: MaintenanceRequestComponent
  },
  {
    path: 'callbackhistory',
    component: CallbackHistoryComponent
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MaintenanceRequestsRoutingModule { }
