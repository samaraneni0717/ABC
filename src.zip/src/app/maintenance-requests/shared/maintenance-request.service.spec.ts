import { TestBed, inject } from '@angular/core/testing';

import { MaintenanceRequestService } from './maintenance-request.service';

describe('MaintenanceRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
        providers: [MaintenanceRequestService]
    });
  });

    it('should be created', inject([MaintenanceRequestService], (service: MaintenanceRequestService) => {
    expect(service).toBeTruthy();
  }));
});
