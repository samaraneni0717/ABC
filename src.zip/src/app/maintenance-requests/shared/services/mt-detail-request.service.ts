import { Injectable } from '@angular/core';
import { TextboxQuestion } from '../../../Common/dynamic-form-models/question-textbox';
import { QuestionBase } from '../../../Common/dynamic-form-models/question-base';
import { OptionsQuestion } from '../../../Common/dynamic-form-models/Question-Options';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { TextAreaQuestion } from 'src/app/Common/dynamic-form-models/question-textarea';
import { AutoCompleteQuestion } from 'src/app/Common/dynamic-form-models/question-autocomplete';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs/Observable';
import { SingleCheckboxQuestion } from 'src/app/Common/dynamic-form-models/question-single-checkbox';
import { LabelQuestion } from 'src/app/Common/dynamic-form-models/question-label';
import { OptionsInlineQuestion } from 'src/app/Common/dynamic-form-models/Question-OptionsInline';
import { DatePickerQuestion } from 'src/app/Common/dynamic-form-models/question-date-picker';
import { tap } from 'rxjs/operators';
import { HiddenQuestion } from 'src/app/Common/dynamic-form-models/question-hidden';
import { MultiselectQuestion } from 'src/app/Common/dynamic-form-models/question-multiselect';
import { ApiService } from '../../../Common/services/api.service';
import { User } from '../../../Common/models/User';
import { AlertService } from '../../../Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';

@Injectable({
    providedIn: 'root'
})
export class DetailRequestService {
    userDetail: User;
    constructor(private httpClient: HttpClient, private apiService: ApiService
        , private alertService: AlertService, private authService: AuthService) {
        console.log('Service instantiated');
    }

    logInUser(): Observable<User> {

        const url: string = environment.BASEURL + 'User';

        return this.apiService.Get<User>(url);
    }

    logIn() {
        this.logInUser().retryWhen((err) => err.delay(5000)).subscribe((userdtls: User) => {
            if (userdtls != null) {
                this.userDetail = userdtls;
                localStorage.setItem('LoggedInUser', this.userDetail.UNumber);
                console.log(this.userDetail.UNumber);
            } else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
            });
    }

    getLoggedInUser() {
        return localStorage.getItem('LoggedInUser');
    }

    getCurrentUser(): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL + 'Maintenance/currentUser'
        );
        // return this.httpClient.get(
        //     environment.BASEURL + 'Maintenance/currentUser'
        // );
    }

    buildFields(maintenanceType?: string, maintenanceSubType?: string): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        switch (maintenanceType) {
            case 'Business Account Level Changes':
                switch (maintenanceSubType) {
                    case 'Address Change':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '420',
                                label: '',
                                order: 420,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Business Account Re-mapping':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 210,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 220,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 310,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 320,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new OptionsQuestion({
                                key: 'changing_relationship__c',
                                label: 'What relationship is changing?',
                                order: 400,
                                disabled: false,
                                options: [
                                    { key: 'Beneficial Owner', value: 'Beneficial Owner' },
                                    { key: 'Advisor', value: 'Advisor' },
                                    { key: 'Both', value: 'Both' }
                                ],
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'New_Beneficial_Owner__c',
                                label: 'New Beneficial Owner',
                                order: 410,
                                disabled: false,
                                // showWhen: {
                                //   key: 'changing_relationship__c',
                                //   value: 'BO',
                                // }
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'changing_relationship__c',
                                                value: 'Beneficial Owner'
                                            },
                                            {
                                                // tslint:disable-next-line:quotemark
                                                id: "changing_relationship__c",
                                                value: "Both"
                                            }
                                        ]
                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ],
                                mandatory: true
                            }),
                            new TextboxQuestion({
                                key: 'New_Advisor__c',
                                label: 'New Advisor',
                                order: 420,
                                disabled: false,
                                // showWhen: {
                                //   key: 'changing_relationship__c',
                                //   value: 'A',
                                // }
                                relation: [
                                    {
                                        action: "VISIBLE",
                                        connective: "OR",
                                        when: [
                                            {
                                                id: "changing_relationship__c",
                                                value: "Advisor"
                                            },
                                            {
                                                id: "changing_relationship__c",
                                                value: "Both"
                                            }
                                        ]
                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ],
                                mandatory: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Flag/Tag Updates':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '430',
                                label: '',
                                order: 430,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            }),
                        ];
                        return questions;
                    case 'Fund Mergers (LIQ)':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '200',
                                label: '',
                                order: 200,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '210',
                                label: '',
                                order: 210,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 220,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Fund Updates':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'LoanIQ_ID__c',
                                label: 'LoanIQ ID',
                                order: 200,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Legal_Name__c',
                                label: 'Customer Name',
                                order: 210,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 220,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Interested Parties':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Statement Preferences':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Safekeeping Updates':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 310,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'Legal ID',
                                order: 320,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 210,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 220,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'SPTRSearch',
                                label: 'Sales Person/Trader Search',
                                order: 300,
                                searchable: true,
                                disabled: false,
                                template: 'Salesperson/Trader',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: 'SalesPerson__ui',
                                label: 'Salesperson/Trader',
                                order: 400,
                                mandatory: true,
                                disabled: true,
                            }),
                            new TextAreaQuestion({
                                key: 'SalesPerson_Emp_Key_Id__c',
                                label: 'SalesPerson_Emp_Key_Id__c',
                                order: 4000,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'Marketer__c',
                                label: 'Marketer__c',
                                order: 4001,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesPerson_GroupName__c',
                                label: 'SalesPerson_GroupName__c',
                                order: 4002,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesPerson_Percent__c',
                                label: 'SalesPerson_Percent__c',
                                order: 4003,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesCategory__c',
                                label: 'SalesCategory__c',
                                order: 4004,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesCategoryId__c',
                                label: 'SalesCategoryId__c',
                                order: 4005,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesCategoryType__c',
                                label: 'SalesCategoryType__c',
                                order: 4006,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'Branch_Location__c',
                                label: 'Branch_Location__c',
                                order: 4007,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SPTR_Email__c',
                                label: 'SPTR_Email__c',
                                order: 4008,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            })
                        ];
                        return questions;
                    case 'MiFID II Risk Reducing':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Business Account Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 210,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 220,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new OptionsQuestion({
                                key: 'MiFID_II_Risk_Reducing__c',
                                label: 'MiFID II Risk Reducing?',
                                order: 300,
                                disabled: false,
                                options: [
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                                mandatory: true
                            }),

                            new LabelQuestion({
                                key: '310',
                                label: '',
                                order: 310,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '320',
                                label: '',
                                order: 320,
                                disabled: true
                            })
                        ];
                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Externals':
                switch (maintenanceSubType) {
                    case 'Add Concert account(s)':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'X2MA_Broadridge_Parent__c',
                                label: '2MA Broadridge # (Parent)',
                                order: 200,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Subsequent_2MA_Broadridge_Child__c',
                                label: 'Subsequent 2MA Broadridge # (Child)',
                                order: 210,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 220,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Add new external(s)':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false,
                                mandatory: true
                            })
                        ];
                        return questions;
                    case 'Add PRECISE account(s)':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false,
                                mandatory: true
                            })
                        ];
                        return questions;
                    case 'Tax Withholding Reversal':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                    LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Requestor_Name__c',
                                label: 'Requestor Name',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Business Acct / Fund Name',
                                order: 300,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 270,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                        A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new LabelQuestion({
                                key: 'RequestedBy__r',
                                label: 'Requestor Desk',
                                order: 330,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Security_Identifier__c',
                                label: 'Security Identifier',
                                order: 330,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 410,
                                disabled: true
                            }),
                            new DropdownQuestion({
                                key: 'Reason_Code__c',
                                label: 'Reason Code',
                                order: 520,
                                disabled: false,
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Reversal based on record date versus payment date', value: 'Reversal based on record date versus payment date' },
                                    { key: 'Reversal based on research', value: 'Reversal based on research' },
                                    { key: 'Refund Client from 21000', value: 'Refund Client from 21000' },
                                    { key: 'Refund 21000 from 20000', value: 'Refund 21000 from 20000' },
                                    { key: 'Fund DDA', value: 'Fund DDA' }
                                ],
                                defaultOption: '',
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'CUSIP__c',
                                label: 'CUSIP',
                                order: 500,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'SEC_ID__c',
                                label: 'SEC ID',
                                order: 530,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new DatePickerQuestion({
                                key: 'Payment_Date__c',
                                label: 'Payment Date',
                                order: 510,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new DropdownQuestion({
                                key: 'Closed_Reason__c',
                                label: 'Closed Reason',
                                order: 530,
                                disabled: false,
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Account set-up issue', value: 'Account set-up issue' },
                                    { key: 'Broadridge Messaging issue', value: 'Broadridge Messaging issue' },
                                    { key: 'Security build issue', value: 'Security build issue' },
                                    { key: 'Foreign Partnership blended rate update', value: 'Foreign Partnership blended rate update' },
                                    { key: 'External client wanted record date versus payment date', value: 'External client wanted record date versus payment date' },
                                    { key: 'IRS Deposit', value: 'IRS Deposit' },
                                    { key: 'No action needed', value: 'No action needed' }
                                ],
                                defaultOption: '',
                                mandatory: true
                            }),
                            new TextboxQuestion({
                                key: 'EFTPS_ID__c',
                                label: 'EFTPS ID',
                                order: 550,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: "VISIBLE",
                                        when: [
                                            {
                                                id: 'Closed_Reason__c',
                                                value: 'IRS Deposit'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Tax Withholding'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 700,
                                disabled: false
                            })
                        ];
                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Instructions':
                switch (maintenanceSubType) {
                    case 'DVP Instructions':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: true,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '430',
                                label: '',
                                order: 430,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false,
                                mandatory: true
                            })
                        ];
                        return questions;
                    case 'Payment Instructions':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '430',
                                label: '',
                                order: 430,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false,
                                mandatory: true
                            })
                        ];
                        return questions;
                    case 'Wire Changes':
                        questions = [

                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),

                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Business Account Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account'
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),

                            new LabelQuestion({
                                key: 'SPTRSearch',
                                label: 'Salesperson/Trader  Search',
                                order: 300,
                                searchable: true,
                                disabled: false,
                                template: 'Salesperson/Trader'
                            }),

                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),

                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),

                            new LabelQuestion({
                                key: 'SalesPerson__ui',
                                label: 'Salesperson/Trader',
                                order: 400,
                                mandatory: true,
                                disabled: true,
                            }),
                            new TextboxQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),

                            new LabelQuestion({
                                key: '430',
                                label: '',
                                order: 430,
                                disabled: true,
                            }),

                            new OptionsInlineQuestion({
                                key: 'New_Wires__c',
                                label: 'New Wires',
                                options: [
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                                order: 500,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]

                            }),
                            new OptionsInlineQuestion({
                                key: 'Is_Payment_pending__c',
                                label: 'Is Payment pending?',
                                options: [
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                                order: 510,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),


                            new OptionsInlineQuestion({
                                key: 'Is_this_Wire_a_Third_Party_payment__c',
                                label: 'Is this Wire a Third Party payment?',
                                options: [
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A third party instruction is any instruction where the beneficiary listed in the instruction is a 
                  different entity than the customer. Any instruction that lists a beneficiary with a different name than 
                  the customer should be flagged as a third party.`,
                                order: 520,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),



                            new SingleCheckboxQuestion({
                                key: 'I_have_read_the_definition_of_what_a_3rd__c',
                                label: 'I have read the definition of what a 3rd party wire is',
                                value: false,
                                order: 530,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ],

                                    }
                                ]
                            }),

                            new LabelQuestion({
                                key: 'WireSearch',
                                label: 'Existing Wire  Search',
                                order: 600,
                                searchable: true,
                                template: 'Wire',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'New_Wires__c',
                                                value: 'No'
                                            }
                                        ],

                                    }
                                ]
                            }),
                            new DatePickerQuestion({
                                key: 'Payment_Date__c',
                                label: 'Payment Date',
                                order: 610,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_Payment_pending__c',
                                                value: 'Yes'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        when: [
                                            {
                                                id: 'Is_Payment_pending__c',
                                                value: 'Yes'
                                            }
                                        ]
                                    }
                                ]
                            }),

                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 620,
                                disabled: true
                            }),


                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 700,
                                disabled: false
                            }),

                            new AutoCompleteQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_Analyst__r',
                                label: 'Callback Analyst',
                                order: 800,
                                value: '',
                                api: 'Maintenance/users/',
                                filterCriteria: 'Client Services',
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Client Services'
                                            },
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [

                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - No Answer"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Technical Error"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback - Supervisory Principal Approved"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Possible Fraud"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Complete - Client Validated"
                                            },


                                        ]
                                    }


                                ]
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_810',
                                label: 'Counterparty Contact That Provided The Wire Instructions',
                                value: '',
                                order: 810,
                                disabled: true,
                                col: 6,
                                css: 'title'
                            }),
                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_Status__c',
                                label: 'Callback Status',
                                value: 'Callback Required',
                                order: 900,
                                col: 6,
                                mandatory: true,
                                options: [
                                    { key: 'Callback Required', value: 'Callback Required' },
                                    { key: 'Callback Performed - No Answer', value: 'Callback Performed - No Answer' },
                                    { key: 'Callback Complete - Client Validated', value: 'Callback Complete - Client Validated' },
                                    { key: 'Callback Performed - Technical Error', value: 'Callback Performed - Technical Error' },
                                    { key: 'Callback Performed - Possible Fraud', value: 'Callback Performed - Possible Fraud' },
                                    { key: 'Callback - Supervisory Principal Approved', value: 'Callback - Supervisory Principal Approved' },
                                    { key: 'Callback - Supervisory Principal Rejected', value: 'Callback - Supervisory Principal Rejected' },
                                ],


                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_Name1__c',
                                label: 'Name 1',
                                order: 910,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_Phone1__c',
                                label: 'Phone 1',
                                order: 920,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1000',
                                label: 'Beneficiary',
                                value: '',
                                order: 1000,
                                disabled: true,
                                col: 6,
                                css: 'title'
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1001',
                                label: 'Counterparty Contact For Callbacks',
                                value: '',
                                order: 1001,
                                disabled: true,
                                col: 6,
                                css: 'title'
                            }),

                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'beneficiary_ID_Type__c',
                                label: 'Beneficiary Account Type',
                                order: 1100,
                                col: 6,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: '\"GENERAL LEDGER\" - Beneficiary\'s account with beneficiary bank- WFBNA only. \n \"UNSPECIFIED\" - used for other scenarios such as ABA instructions',

                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'DDA', value: 'DDA' },
                                    { key: 'General Ledger', value: 'General Ledger' },
                                    { key: 'UNSPECIFIED', value: 'UNSPECIFIED' }
                                ],
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    }


                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_for_CB_Name1__c',
                                label: 'Name 1',
                                order: 1110,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_CB_Phone_1__c',
                                label: 'Phone 1',
                                order: 1120,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'beneficiary_Name__c',
                                label: 'Beneficiary Name',
                                order: 1200,
                                col: 6,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Name on recipient account',

                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_CB_Name_2__c',
                                label: 'Name 2',
                                order: 1210,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },

                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_CB_Phone_2__c',
                                label: 'Phone 2',
                                order: 1220,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },

                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'beneficiary_ID__c',
                                label: 'Account # (Beneficiary Bank ID)',
                                order: 1300,
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_CB_Name_3__c',
                                label: 'Name 3',
                                order: 1310,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },

                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'counterparty_Contact_CB_Phone_3__c',
                                label: 'Phone 3',
                                order: 1320,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },

                                ]
                            }),

                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1400',
                                label: 'Beneficiary Bank/Financial Institution /Other',
                                value: '',
                                order: 1400,
                                disabled: true,
                                col: 6,
                                css: 'title'
                            }),
                            new SingleCheckboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'two_distinct_individuals_confirm_instruc__c',
                                label: 'Two distinct individuals to provide and separately confirm the instructions are not available for this client',
                                value: false,
                                order: 1410,
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ],

                                    }
                                ]
                            }),
                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'beneficiary_Bank_Financial_Institution_O__c',
                                label: 'Beneficiary Bank/Financial Institution/Other ID Type',
                                order: 1500,
                                col: 6,
                                defaultOption: '',
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: '\"ROUTING NUMBER (ABA)\" - 9 digit code for US banks. \n \"ACCOUNT NUMBER (DDA)\" - The beneficiary bank\'s account #. \n  \"GENERAL LEDGER\" - The beneficiary bank\'s account #- WFBNA only. \n \"UNSPECIFIED\" - used for other scenarios such as ABA instructions',

                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Routing Number (ABA)', value: 'Routing Number (ABA)' },
                                    { key: 'Account Number (DDA)', value: 'Account Number (DDA)' },
                                    { key: 'General Ledger', value: 'General Ledger' },
                                    { key: 'Unspecified', value: 'Unspecified' }
                                ],
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    }


                                ]
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1400',
                                label: 'Callback Verification',
                                value: '',
                                order: 1510,
                                disabled: true,
                                col: 6,
                                css: 'title'
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'bank_FI_Name__c',
                                label: 'Bank/FI Name',
                                order: 1600,
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_Verification_Contact_Name__c',
                                label: 'Contact Name',
                                order: 1610,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Client Services'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [

                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - No Answer"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Technical Error"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback - Supervisory Principal Approved"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Possible Fraud"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Complete - Client Validated"
                                            },


                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_Verification_Contact_Number__c',
                                label: 'Contact Number',
                                order: 1620,
                                col: 3,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Client Services'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [

                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - No Answer"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Technical Error"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback - Supervisory Principal Approved"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Possible Fraud"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Complete - Client Validated"
                                            },


                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'account_Number_Bank_FI_ID__c',
                                label: 'Account Number (Bank/FI ID)',
                                order: 1700,
                                col: 6,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'If DDA selected in Bene Account Type, then include DDA Acct #; if ABA selected then input routing number',

                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new DatePickerQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_Date_Time__c',
                                label: 'Callback Date/Time',
                                order: 1710,
                                col: 3,
                                hasTime: true,
                                template: 'callback_Time__c',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Client Services'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [

                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - No Answer"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Technical Error"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback - Supervisory Principal Approved"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Possible Fraud"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Complete - Client Validated"
                                            },


                                        ]
                                    }
                                ]
                            }),

                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'No_Of_Attempts__c',
                                label: 'No Of Attempts',
                                order: 1720,
                                col: 3,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '1730',
                                label: '',
                                order: 1730,
                                col: 6,
                                disabled: true,

                            }),


                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'Callback_Notes__c',
                                label: 'Callback Notes',
                                order: 1740,
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Client Services'
                                            }
                                        ]

                                    },

                                ]
                            }),


                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1500',
                                label: 'Intermediary Bank Routing Details',
                                value: '',
                                order: 1800,
                                disabled: true,
                                col: 6,
                                css: 'title',
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: ''
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Account Number (DDA)'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'General Ledger'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Unspecified'
                                            },
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1810',
                                label: '',
                                value: '',
                                order: 1810,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: ''
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Account Number (DDA)'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'General Ledger'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Unspecified'
                                            },
                                        ]
                                    }
                                ]
                            }),
                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'intermediary_Bank_ID_Type__c',
                                label: 'Intermediary Bank ID Type',
                                order: 1900,
                                col: 6,
                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Routing Number (ABA)', value: 'Routing Number (ABA)' },

                                ],
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    },
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: ''
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Account Number (DDA)'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'General Ledger'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Unspecified'
                                            },
                                        ]
                                    }


                                ]
                            }),


                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'intermediary_Bank_Name__c',
                                label: 'Intermediary Bank Name',
                                order: 2000,
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: ''
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Account Number (DDA)'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'General Ledger'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Unspecified'
                                            },
                                        ]
                                    }
                                ]
                            }),

                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'routing_Number_Intermediary_Bank_ID__c',
                                label: 'Routing Number (Intermediary Bank ID)',
                                order: 2015,
                                col: 6,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: ''
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Account Number (DDA)'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'General Ledger'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Unspecified'
                                            },
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1810',
                                label: '',
                                value: '',
                                order: 2020,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: ''
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Account Number (DDA)'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'General Ledger'
                                            },
                                            {
                                                id: 'beneficiary_Bank_Financial_Institution_O__c',
                                                value: 'Unspecified'
                                            },
                                        ]
                                    }
                                ]
                            }),

                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'callback_1500',
                                label: 'Other Instructions',
                                value: '',
                                order: 2200,
                                disabled: true,
                                col: 6,
                                css: 'title'
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '2200',
                                label: '',
                                value: '',
                                order: 2210,
                                disabled: true,
                                col: 6,

                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'other_Instructions__c',
                                label: 'Other Instructions',
                                order: 2211,
                                col: 6,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Use this field for further credit, reference # and other data for which there are no fields above. Please do not use this field for data which has a designated field above',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]

                                    },

                                ]
                            }),

                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'source_Type__c',
                                label: 'Source Type',
                                order: 2230,
                                col: 6,
                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'E-Mail', value: 'E-Mail' },
                                    { key: 'Fax', value: 'Fax' },
                                    { key: 'Mail', value: 'Mail' },
                                    { key: 'Other', value: 'Other' },

                                ],
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    }


                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'verification_Source__c',
                                label: 'Verification Source',
                                order: 2250,
                                col: 6,
                                relation: [

                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'User_Role',
                                                value: 'Client Services'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [

                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - No Answer"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Technical Error"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback - Supervisory Principal Approved"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Performed - Possible Fraud"
                                            },
                                            {
                                                id: "callback_Status__c",
                                                value: "Callback Complete - Client Validated"
                                            },


                                        ]


                                    }

                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'source_Type_Other__c',
                                label: 'Source Type Other',
                                order: 2260,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'source_Type__c',
                                                value: 'Other'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'source_Type__c',
                                                value: 'Other'
                                            }
                                        ]


                                    }

                                ]
                            }),


                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '2280',
                                label: '',
                                value: '',
                                order: 2280,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'source_Type__c',
                                                value: ''
                                            },
                                            {
                                                id: 'source_Type__c',
                                                value: 'Fax'
                                            },
                                            {
                                                id: 'source_Type__c',
                                                value: 'E-Mail'
                                            },
                                            {
                                                id: 'source_Type__c',
                                                value: 'Mail'
                                            }
                                        ]

                                    },


                                ]

                            }),



                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '2310',
                                label: 'Exception Approval',
                                value: '',
                                order: 2310,
                                disabled: true,
                                col: 6,
                                css: 'title',
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback Performed - No Answer'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Approved'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Rejected'
                                            },
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '2311',
                                label: '',
                                value: '',
                                order: 2310,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback Performed - No Answer'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Approved'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Rejected'
                                            },
                                        ]
                                    }
                                ]
                            }),


                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'desk_Head_Approver_Name__c',
                                label: 'Supervisory Principal Approver Name',
                                order: 2340,
                                col: 6,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback Performed - No Answer'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Approved'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Rejected'
                                            },
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'desk_Head_Callback_Exception_App_Time__c',
                                label: 'Supervisory Principal Callback Exception Approval Timestamp',
                                order: 2350,
                                col: 6,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback Performed - No Answer'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Approved'
                                            },
                                            {
                                                id: 'callback_Status__c',
                                                value: 'Callback - Supervisory Principal Rejected'
                                            },
                                        ]
                                    }
                                ]
                            }),



                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '2700',
                                label: 'Third Party Exception',
                                value: '',
                                order: 2700,
                                disabled: true,
                                col: 6,
                                css: 'title',
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },


                                ]

                            }),
                            new LabelQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: '2710',
                                label: '',
                                value: '',
                                order: 2710,
                                disabled: true,
                                col: 6,
                                css: 'title',
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },


                                ]

                            }),

                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_form_Completed_By__c',
                                label: 'Form Completed By',
                                order: 2800,
                                col: 6,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },


                                ]

                            }),

                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'telephone__c',
                                label: 'Telephone',
                                order: 2810,
                                col: 6,

                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    }

                                ]
                            }),
                            new DatePickerQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_form_Completed_Date__c',
                                label: 'Form Completion Date',
                                order: 2900,
                                col: 6,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    }


                                ]

                            }),

                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'fax__c',
                                label: 'Fax',
                                order: 2910,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },

                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'business_Unit_Requesting_Exception__c',
                                label: 'Business Unit Requesting Exception',
                                order: 3000,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    }

                                ]
                            }),
                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_Request_Type__c',
                                label: 'Request Type',
                                order: 3010,
                                col: 6,
                                defaultOption: '',
                                mandatory: true,
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'One-Off', value: 'One-Off' },
                                    { key: 'Annual', value: 'Annual' },


                                ],
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },



                                ]
                            }),
                            new TextboxQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'policy_Exception_Justification__c',
                                label: 'Policy Exception Justification',
                                order: 3100,
                                col: 6,

                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]


                                    }

                                ]
                            }),
                            new DropdownQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_Exception_Approval_Status__c',
                                label: 'Exception Approval Status',
                                value: 'Third Party Exception - Approval required',
                                order: 3110,
                                col: 6,
                                disabled: true,
                                options: [
                                    { key: 'Third Party Exception - Approval required', value: 'Third Party Exception - Approval required' },
                                    { key: 'Third Party Exception - Supervisory Principal Approved', value: 'Third Party Exception - Supervisory Principal Approved' },
                                    { key: 'Third Party Exception - Supervisory Principal Rejected', value: 'Third Party Exception - Supervisory Principal Rejected' },

                                ],
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },



                                ]

                            }),

                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_Desk_Head_Approval__c',
                                label: 'Supervisory Principal Approver Name',
                                value: '',
                                order: 3200,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },



                                ]

                            }),

                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_Approval_Timestamp__c',
                                label: 'Approval Timestamp',
                                value: '',
                                order: 3210,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },


                                ]

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'supervisor_Principal_Comments__c',
                                label: 'Supervisor Principal Comments',
                                value: '',
                                order: 3300,
                                disabled: true,
                                col: 6,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        when: [
                                            {
                                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                                value: 'Yes'
                                            }
                                        ]

                                    },


                                ]

                            }),


                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SalesPerson_Emp_Key_Id__c',
                                label: 'Supervisor Principal Comments',
                                order: 4000,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'Marketer__c',
                                label: 'Marketer__c',
                                order: 4001,
                                displayNone: true

                            }),

                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SalesPerson_GroupName__c',
                                label: 'SalesPerson_GroupName__c',
                                order: 4002,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SalesPerson_Percent__c',
                                label: 'SalesPerson_Percent__c',
                                order: 4003,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SalesCategory__c',
                                label: 'SalesCategory__c',
                                order: 4004,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SalesCategoryId__c',
                                label: 'SalesCategoryId__c',
                                order: 4005,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SalesCategoryType__c',
                                label: 'SalesCategoryType__c',
                                order: 4006,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'Branch_Location__c',
                                label: 'Branch_Location__c',
                                order: 4007,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'SPTR_Email__c',
                                label: 'SPTR_Email__c',
                                order: 4008,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'supervisor__c',
                                label: 'supervisor__c',
                                order: 4009,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'supervisor_Email__c',
                                label: 'supervisor_Email__c',
                                order: 4010,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'supervisor_Id__c',
                                label: 'supervisor_Id__c',
                                order: 4011,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'delegate_Id__c',
                                label: 'delegate_Id__c',
                                order: 4012,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'delegate_Email__c',
                                label: 'delegate_Email__c',
                                order: 4014,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'sequenceId__c',
                                label: 'sequenceId__c',
                                order: 4015,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'existing_Thirdparty__c',
                                label: 'existing_Thirdparty__c',
                                order: 4016,
                                displayNone: true

                            }),
                            new TextAreaQuestion({
                                rowGroupBy: 'CALLBACK',
                                key: 'third_Party_Desk_Head_App_ID__c',
                                label: 'third_Party_Desk_Head_App_ID__c',
                                order: 4017,
                                displayNone: true

                            }),


                        ];

                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Legal Changes':
                switch (maintenanceSubType) {
                    case 'Legal Mergers':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '200',
                                label: '',
                                order: 200,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '210',
                                label: '',
                                order: 210,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 220,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Legal Name Changes':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '300',
                                label: '',
                                order: 300,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'New_Legal_Name__c',
                                label: 'New Legal Name',
                                order: 310,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: '320',
                                label: '',
                                order: 320,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Tax ID Changes':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '300',
                                label: '',
                                order: 300,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'New_Tax_ID__c',
                                label: 'New Tax ID',
                                order: 310,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: '320',
                                label: '',
                                order: 320,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Update Legal Hierarchy':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'LoanIQ_ID__c',
                                label: 'LOAN IQ ID',
                                order: 200,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'New_Parent_Customer_ID__c',
                                label: 'New Parent Customer ID',
                                order: 210,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 220,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Hong Kong Classification Refresh':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: true,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }), 
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new DropdownQuestion({
                                key: 'Hong_Kong_Classification__c',
                                label: 'Hong Kong Classification',
                                order: 230,
                                disabled: true,
                                mandatory: true,
                                options: [
                                    { key: 'Institutional Professional Investor', value: 'Institutional Professional Investor' },
                                    { key: 'Corporate Professional Investor', value: 'Corporate Professional Investor' }
                                ]
                                // ,
                                // relation: [
                                //     {
                                //         action: 'ENABLE',
                                //         when: [
                                //             {
                                //                 id: 'Status__c',
                                //                 value: 'Draft'
                                //             }
                                //         ]
                                //     }
                                // ]
                            }),
                            new MultiselectQuestion({
                                key: 'Product_group_Market_coverage__c',
                                label: 'Product group/Market coverage',
                                order: 240,
                                disabled: true,
                                options: [
                                    { key: 'Macro - ON Exchange', value: 'Macro - ON Exchange' },
                                    { key: 'Macro - OFF Exchange', value: 'Macro - OFF Exchange' },
                                    { key: 'Spread - ON Exchange', value: 'Spread - ON Exchange' },
                                    { key: 'Spread - OFF Exchange', value: 'Spread - OFF Exchange' },
                                    { key: 'Structured', value: 'Structured' }
                                ]
                                // ,
                                // relation: [
                                //     {
                                //         action: 'ENABLE',
                                //         connective: 'AND',
                                //         when: [
                                //             {
                                //                 id: 'Hong_Kong_Classification__c',
                                //                 value: 'Corporate Professional Investor'
                                //             },
                                //             {
                                //                 id: 'Status__c',
                                //                 value: 'Draft'
                                //             }
                                //         ]
                                //     }
                                // ]
                            }),
                            new SingleCheckboxQuestion({
                                label: 'CPI Letter - Complete?',
                                value: false,
                                order: 250,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'APAC_Comments__c',
                                label: 'APAC Comments',
                                order: 260,
                                disabled: false,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Enter comments for Hong Kong Classification selection`
                            }),
                            new LabelQuestion({
                                key: 'APAC_Status__c',
                                label: 'APAC Status',
                                order: 280,
                                disabled: true,
                            }),
                        ];
                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Miscellaneous/Other':
                switch (maintenanceSubType) {
                    case 'LoanNet Mapping':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '300',
                                label: '',
                                order: 300,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'WCIS_ID__c',
                                label: 'WCIS ID',
                                order: 310,
                                disabled: false
                            }),
                            new TextboxQuestion({
                                key: 'New_Tax_ID__c',
                                label: 'Tax ID',
                                order: 320,
                                disabled: false
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Other':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '300',
                                label: '',
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '310',
                                label: '',
                                order: 310,
                                disabled: false
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 320,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Prime - Form 1 Schedule A Update':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: true,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Prime Broker Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: false
                            }),
                            new TextboxQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 300,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 310,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Internal_Number__c',
                                label: 'Internal Number',
                                order: 320,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'DTC__c',
                                label: 'DTC',
                                order: 400,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Institution_ID__c',
                                label: 'Institution ID',
                                order: 410,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Agent_Bank__c',
                                label: 'Agent Bank',
                                order: 420,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),

                            new LabelQuestion({
                                key: '450',
                                label: '',
                                order: 450,
                                disabled: true,
                            }),
                            new TextboxQuestion({
                                key: 'Bus_Unit__c',
                                label: 'Bus Unit',
                                order: 500,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Add_ID__c',
                                label: 'Add ID',
                                order: 510,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Form_150_on_File__c',
                                label: 'Form 150 on file',
                                order: 520,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: '530',
                                label: '',
                                order: 530,
                                disabled: true,
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 600,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Prime - PB Int\'l/BD Credit letter update':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: true,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Prime Broker Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Full legal name of the counterparty`
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: false
                            }),
                            new TextboxQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 300,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 310,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Agent_Bank__c',
                                label: 'Agent Bank',
                                order: 320,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Institution_ID__c',
                                label: 'Institution ID',
                                order: 400,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: '410',
                                label: '',
                                order: 410,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '420',
                                label: '',
                                order: 420,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '430',
                                label: '',
                                order: 430,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 600,
                                disabled: false
                            })
                        ];
                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Regulatory Changes':
                switch (maintenanceSubType) {
                    case 'AML data update':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new DropdownQuestion({
                                key: 'ChangeLegalAcctOrBusAcctData__c',
                                label: 'Change Legal Account Data or Business Account Data?',
                                order: 200,
                                disabled: false,
                                defaultOption: 'N',
                                options: [
                                    { key: 'N', value: '--None--' },
                                    { key: 'Business Account', value: 'Business Account' },
                                    { key: 'Legal Account', value: 'Legal Account' }
                                ],
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 210,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 220,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Business Account Search',
                                order: 300,
                                searchable: true,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'ChangeLegalAcctOrBusAcctData__c',
                                                value: 'Business Account'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'ChangeLegalAcctOrBusAcctData__c',
                                                value: 'Business Account'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'ChangeLegalAcctOrBusAcctData__c',
                                                value: 'Business Account'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: '330',
                                label: '',
                                order: 330,
                                disabled: true,
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 400,
                                searchable: true,
                                template: 'Legal',
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'ChangeLegalAcctOrBusAcctData__c',
                                                value: 'Legal Account'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: 'Legal_Name__c',
                                label: 'LegalName',
                                order: 410,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'ChangeLegalAcctOrBusAcctData__c',
                                                value: 'Legal Account'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 420,
                                disabled: true,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'ChangeLegalAcctOrBusAcctData__c',
                                                value: 'Legal Account'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: '430',
                                label: '',
                                order: 430,
                                disabled: true,
                            }),
                            new DropdownQuestion({
                                key: 'PoliticallyExposedPerson__c',
                                label: 'Are any of the Entity\'s key executives or owners classified as a Politically Exposed Person (PEP)?',
                                order: 440,
                                disabled: false,
                                mandatory: true,
                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                            }),
                            new DropdownQuestion({
                                key: 'IsNonUSExeOrAffiliates__c',
                                label: 'Does this entity have any executives or affiliates that are Non-US persons?',
                                order: 500,
                                disabled: false,
                                mandatory: true,
                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                            }),
                            new DropdownQuestion({
                                key: 'IsInternetGamblingBussiness__c',
                                label: 'Does the entity engage in any internet gambling business?',
                                order: 600,
                                disabled: false,
                                mandatory: true,
                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                            }),
                            new DropdownQuestion({
                                key: 'HighRiskEntity__c',
                                // tslint:disable-next-line:max-line-length
                                label: 'Does this entity have affiliates, subsidiaries, or operations in higher risk countries, or do they conduct transactions in higher risk countries?',
                                order: 700,
                                disabled: false,
                                mandatory: true,
                                defaultOption: '',
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Yes', value: 'Yes' },
                                    { key: 'No', value: 'No' }
                                ],
                            }),
                            // new TextAreaQuestion({
                            //   key: 'Notes__c',
                            //   label: 'Notes',
                            //   order: 800,
                            //   disabled: false
                            // })
                        ];
                        return questions;
                    case 'DCOT - AML And Ops Risk':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'LegalSearch',
                                label: 'Legal Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Legal',
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '300',
                                label: '',
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '310',
                                label: '',
                                order: 310,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: '320',
                                label: '',
                                order: 320,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Sales Coverage':
                switch (maintenanceSubType) {
                    case 'Create a New Sales Rep Code':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                    A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 700,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'DCOT - Coverage Admin RM/AU':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 210,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 220,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                    A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: '420',
                                label: '',
                                order: 420,
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'Correct_RM__c',
                                label: 'Correct RM',
                                order: 300,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextboxQuestion({
                                key: 'Correct_A_U__c',
                                label: 'Correct A/U',
                                order: 310,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new DatePickerQuestion({
                                key: 'Change_Coverage_Start_Date__c',
                                label: 'Change Coverage Start Date',
                                order: 320,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 500,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Update Existing Rep Code':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'Name',
                                label: 'Request Number',
                                order: 120,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'CreatedDate',
                                label: 'Created Date',
                                order: 130,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Legal Name',
                                order: 210,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'CID_LEID__c',
                                label: 'CID LEID',
                                order: 220,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Owner',
                                label: 'Owner ID',
                                order: 230,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 310,
                                disabled: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Middle_Market_Indicator__c',
                                label: 'Middle Market Indicator',
                                value: false,
                                order: 300,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 320,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'External_Name__c',
                                label: 'External Name',
                                order: 410,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'External_ID__c',
                                label: 'External ID',
                                order: 420,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: '400',
                                label: '',
                                order: 400,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Notes__c',
                                label: 'Notes',
                                order: 700,
                                disabled: false
                            })
                        ];
                        return questions;
                    case 'Changes for Coverage':
                        questions = [
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance SubType',
                                value: maintenanceSubType,
                                order: 110,
                                disabled: true
                            }),
                            new LabelQuestion({
                                key: 'BASearch',
                                label: 'Bus Acct Search',
                                order: 200,
                                searchable: true,
                                disabled: false,
                                mandatory: true,
                                template: 'Business Account',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: 'SalesCoverageGroupSearch',
                                label: 'Sales Coverage Group Search',
                                order: 210,
                                searchable: true,
                                disabled: false,
                                mandatory: true,
                                template: 'Salesperson/Trader',
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new LabelQuestion({
                                key: 'BA_ID__c',
                                label: 'BA ID',
                                order: 220,
                                isTooltipPresent: true,
                                disabled: true,
                                typeOfTooltip: 'help',
                                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                    A BA ID must be entered by the Facilitator in order to close any new business account request.`
                            }),
                            new TextAreaQuestion({
                                key: 'Business_Acct_Fund_Name__c',
                                label: 'Bus Account Name',
                                order: 230,
                                disabled: true
                            }),
                            new DatePickerQuestion({
                                key: 'Sales_Coverage_Start_Date__c',
                                label: 'Sales Coverage Start Date',
                                order: 240,
                                disabled: false,
                                mandatory: true,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new DatePickerQuestion({
                                key: 'Sales_Coverage_End_Date__c',
                                label: 'Sales Coverage End Date',
                                order: 250,
                                disabled: false,
                                relation: [
                                    {
                                        action: 'ENABLE',
                                        when: [
                                            {
                                                id: 'Status__c',
                                                value: 'Draft'
                                            }
                                        ]
                                    }
                                ]
                            }),
                            new TextAreaQuestion({
                                key: 'SalesPerson_GroupName__c',
                                label: 'Sales Group Name',
                                order: 260,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesPerson_Emp_Key_Id__c',
                                label: 'SalesPerson EmpKey Id',
                                order: 270,
                                displayNone: true
                            }),
                            new TextAreaQuestion({
                                key: 'SalesCategoryId__c',
                                label: 'SalesCategoryId__c',
                                order: 280,
                                displayNone: true
                            })
                        ];
                        return questions;
                    default:
                        questions = [
                            new LabelQuestion({
                                key: 'Maintenance_Request_Type__c',
                                label: 'Maintenance Type',
                                value: maintenanceType,
                                order: 100,
                                disabled: true
                            }),
                            new TextAreaQuestion({
                                key: 'Legal_Name__c',
                                label: 'Maintenance Template',
                                value: 'Invalid Maintenance Template',
                                order: 110,
                                disabled: true,
                                isTooltipPresent: true,
                                typeOfTooltip: 'help',
                                tooltipText: 'Full legal name of the counterparty'
                            }),
                            new LabelQuestion({
                                key: 'Maintenance_Request_Sub_Type__c',
                                label: 'Maintenance Sub Type',
                                value: maintenanceSubType,
                                order: 200,
                                disabled: true
                            }),
                        ];
                        return questions;
                }
            case 'Update POQ':
            case '':
                questions = [
                    new LabelQuestion({
                        key: 'Maintenance_Request_Type__c',
                        label: 'Maintenance Type',
                        value: maintenanceType,
                        order: 100,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Legal_Name__c',
                        label: 'Legal Name',
                        order: 110,
                        disabled: true,
                        isTooltipPresent: true,
                        typeOfTooltip: 'help',
                        tooltipText: 'Full legal name of the counterparty'
                    }),
                    new LabelQuestion({
                        key: 'CID_LEID__c',
                        label: 'CID LEID',
                        order: 120,
                        disabled: true,
                        isTooltipPresent: true,
                        typeOfTooltip: 'help',
                        tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
                    }),
                    new TextAreaQuestion({
                        key: 'CreatedDate',
                        label: 'Created Date',
                        order: 130,
                        disabled: true
                    }),

                    new LabelQuestion({
                        key: 'Maintenance_Request_Sub_Type__c',
                        label: 'Maintenance Sub Type',
                        value: maintenanceType,
                        order: 200,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Business_Acct_Fund_Name__c',
                        label: 'Business Acct / Fund Name',
                        order: 210,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'BA_ID__c',
                        label: 'BA ID',
                        order: 220,
                        isTooltipPresent: true,
                        disabled: true,
                        typeOfTooltip: 'help',
                        tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
            A BA ID must be entered by the Facilitator in order to close any new business account request.`
                    }),
                    new LabelQuestion({
                        key: 'Name',
                        label: 'Request Number',
                        order: 230,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'BASearch',
                        label: 'Business Account Search',
                        order: 300,
                        searchable: true,
                        disabled: false,
                        template: 'Business Account'
                    }),

                    new SingleCheckboxQuestion({
                        key: 'Middle_Market_Indicator__c',
                        label: 'Middle Market Indicator',
                        value: false,
                        order: 320,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Owner',
                        label: 'Owner ID',
                        order: 330,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Notes__c',
                        label: 'Notes',
                        order: 400,
                        disabled: false
                    })
                ];
                return questions;
            case 'MiFID Categorization Change':
                questions = [
                    new TextAreaQuestion({
                        key: 'Maintenance_Request_Type__c',
                        label: 'Maintenance Type',
                        value: maintenanceType,
                        order: 100,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Legal_Name__c',
                        label: 'Legal Name',
                        order: 110,
                        disabled: true,
                        isTooltipPresent: true,
                        typeOfTooltip: 'help',
                        tooltipText: 'Full legal name of the counterparty'
                    }),
                    new LabelQuestion({
                        key: 'CID_LEID__c',
                        label: 'CID LEID',
                        order: 120,
                        disabled: true,
                        isTooltipPresent: true,
                        typeOfTooltip: 'help',
                        tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID 
                LEID must be entered by the Facilitator in order to close any new legal account build request.`
                    }),
                    new TextAreaQuestion({
                        key: 'CreatedDate',
                        label: 'Created Date',
                        order: 130,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Maintenance_Request_Sub_Type__c',
                        label: 'Maintenance Sub Type',
                        value: maintenanceType,
                        order: 200,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Business_Acct_Fund_Name__c',
                        label: 'Business Acct / Fund Name',
                        order: 210,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'BA_ID__c',
                        label: 'BA ID',
                        order: 220,
                        isTooltipPresent: true,
                        disabled: true,
                        typeOfTooltip: 'help',
                        tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
              A BA ID must be entered by the Facilitator in order to close any new business account request.`
                    }),
                    new LabelQuestion({
                        key: 'Name',
                        label: 'Maintenance Request Number',
                        order: 230,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'BASearch',
                        label: 'Business Account Search',
                        order: 300,
                        searchable: true,
                        template: 'MIFID Business Account'
                    }),
                    //new MultiselectQuestion({
                    //    key: 'WFS_Booking_Entity__c',
                    //    label: 'WFS Booking Entity',
                    //    order: 320,
                    //    defaultOption: 'None Selected',
                    //    mandatory: true,
                    //    options: [
                    //        { key: 'WFSIL', value: 'WFSIL' },
                    //        { key: 'WFSJ', value: 'WFSJ' },
                    //        { key: 'WFSAL', value: 'WFSAL' },
                    //        { key: 'WFSLLC - Singapore Branch', value: 'WFSLLC - Singapore Branch' },
                    //        { key: 'WFSLLC - US', value: 'WFSLLC - US' },
                    //        { key: 'WFBNA - US', value: 'WFBNA - US' },
                    //        { key: 'WFBNA - LB', value: 'WFBNA - LB' },
                    //        { key: 'WFSC LTD', value: 'WFSC LTD' },
                    //        { key: 'WFSC Prime Services', value: 'WFSC Prime Services' },
                    //        { key: 'WFBNA - Canada Branch', value: 'WFBNA - Canada Branch' },
                    //    ],
                    //}),
                    //new LabelQuestion({
                    //    key: 'Marketer',
                    //    label: 'Marketer',
                    //    order: 320,
                    //    searchable: true,
                    //    template: 'Marketer'
                    //}),
                    new TextAreaQuestion({
                        key: 'Owner',
                        label: 'Owner ID',
                        order: 320,
                        disabled: true
                    }),
                    new TextboxQuestion({
                        key: 'Customer_Email__c',
                        label: 'Customer Email',
                        order: 330,
                        disabled: false,
                        mandatory: true
                    }),
                    //new SingleCheckboxQuestion({
                    //    key: 'Middle_Market_Indicator__c',
                    //    label: 'Middle Market Indicator',
                    //    value: false,
                    //    order: 410,
                    //    disabled: true
                    //}),
                    //new TextAreaQuestion({
                    //    key: 'Marketer__c',
                    //    label: 'Marketer',
                    //    order: 420,
                    //    disabled: true
                    //}),
                    new DropdownQuestion({
                        key: 'MiFID_II_Client_Categorization__c',
                        label: 'MiFID II Client Categorization :',
                        defaultOption: '',
                        options: [
                            { key: '', value: 'Please Select' },
                            { key: 'Per Se Professional Client', value: 'Per Se Professional Client' },
                            { key: 'Elective Professional Client', value: 'Elective Professional Client' },
                            { key: 'Per Se Eligible Counterparty', value: 'Per Se Eligible Counterparty' },
                            { key: 'Elective Eligible Counterparty', value: 'Elective Eligible Counterparty' },
                        ],
                        order: 500
                    }),
                    new DropdownQuestion({
                        key: 'MiFID_II_Investment_Firm__c',
                        label: 'MiFID II Investment Firm :',
                        defaultOption: '',
                        options: [
                            { key: '', value: 'Please Select' },
                            { key: 'Yes', value: 'Yes' },
                            { key: 'No', value: 'No' }
                        ],
                        order: 501
                    }),
                    new DropdownQuestion({
                        key: 'MiFID_II_Central_Bank__c',
                        label: 'MiFID II Central Bank :',
                        defaultOption: '',
                        options: [
                            { key: '', value: 'Please Select' },
                            { key: 'No', value: 'No' },
                            { key: 'Yes', value: 'Yes' }

                        ],
                        order: 502
                    }),
                    //new LabelQuestion({
                    //    key: 'Branch_Location__c',
                    //    label: 'Branch Location',
                    //    order: 500,
                    //    disabled: true
                    //}),
                    new LabelQuestion({
                        key: '520',
                        label: '',
                        order: 520,
                        disabled: true
                    }),
                    //new MultiselectQuestion({
                    //    key: 'FX_Specific_Products__c',
                    //    label: 'FX Specific Products',
                    //    order: 530,
                    //    defaultOption: 'None Selected',
                    //    mandatory: true,
                    //    typeOfTooltip: 'help',
                    //    isTooltipPresent: true,
                    //    tooltipText: '* This product requires a tax form for onboarding purposes. ** If this client is an option only client, please contact your DoCO rep.',
                    //    options: [
                    //        { key: 'FX EYD', value: 'FX EYD' },
                    //        { key: 'FX Forward*', value: 'FX Forward*' },
                    //        { key: 'FX NDF*', value: 'FX NDF*' },
                    //        { key: 'FX Option**', value: 'FX Option**' },
                    //        { key: 'FX SWAP*', value: 'FX SWAP*' },
                    //        { key: 'FX Window Forward*', value: 'FX Window Forward*' },
                    //    ],
                    //}),

                    new LabelQuestion({
                        key: 'Address_Line1__c',
                        label: 'Address Line1',
                        order: 600,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'Address_Line2__c',
                        label: 'Address Line2',
                        order: 630,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'City__c',
                        label: 'City',
                        order: 640,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'Country__c',
                        label: 'Country',
                        order: 650,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'Zip__c',
                        label: 'Zip',
                        order: 700,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'Canada_Province__c',
                        label: 'Canada Province',
                        order: 710,
                        disabled: true
                    }),
                    new LabelQuestion({
                        key: 'Postal_Code__c',
                        label: 'Postal Code',
                        order: 720,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Notes__c',
                        label: 'Notes',
                        order: 800,
                        disabled: false
                    }),
                ];
                return questions;
            default:
                questions = [
                    new LabelQuestion({
                        key: 'Maintenance_Request_Type__c',
                        label: 'Maintenance Type',
                        value: maintenanceType,
                        order: 100,
                        disabled: true
                    }),
                    new TextAreaQuestion({
                        key: 'Legal_Name__c',
                        label: 'Maintenance Template',
                        value: 'Invalid Maintenance Template',
                        order: 110,
                        disabled: true,
                        isTooltipPresent: true,
                        typeOfTooltip: 'help',
                        tooltipText: 'Full legal name of the counterparty'
                    }),
                    new LabelQuestion({
                        key: 'Maintenance_Request_Sub_Type__c',
                        label: 'Maintenance Sub Type',
                        value: maintenanceSubType,
                        order: 200,
                        disabled: true
                    }),
                ];
                return questions;
        }
    }

    buildBASearchFields(value: string): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        if (value === 'Business Account') {
            questions = [
                new TextboxQuestion({
                    key: 'legalId',
                    label: 'Legal Id :',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'busAcctId',
                    label: 'Business Account Id :',
                    order: 110
                }),
                new TextboxQuestion({
                    key: 'acctShortName',
                    label: 'Short Name :',
                    order: 200
                }),
                new TextboxQuestion({
                    key: 'busAcctName',
                    label: 'Account Name :',
                    order: 210
                }),
                new DropdownQuestion({
                    key: 'systemCode',
                    label: 'System Code :',
                    options: [
                        { key: '', value: '--None--' },
                        { key: 'BRWFB', value: '(BRWFB) BROADRIDGE-WELLS FARGO BANK NA' },
                        { key: 'BRWFS', value: '(BRWFS) BROADRIDGE-WELLS FARGO SECURITIES' }
                    ],
                    order: 220
                }),
                new TextboxQuestion({
                    key: 'externalId',
                    label: 'External Id :',
                    order: 230
                }),
                new OptionsInlineQuestion({
                    key: 'srchAction',
                    label: 'Search :',
                    defaultOption: 'S',
                    options: [
                        { key: 'S', value: 'Starts With' },
                        { key: 'C', value: 'Contains' }
                    ],
                    order: 250
                }),
                new DropdownQuestion({
                    key: 'limitRow',
                    label: 'Limit Results :',
                    defaultOption: 25,
                    options: [{ key: 25, value: 25 },
                    { key: 50, value: 50 },
                    { key: 100, value: 100 },
                    { key: 150, value: 150 },
                    { key: 200, value: 200 },
                    { key: 250, value: 250 },
                    { key: 300, value: 300 }],
                    order: 270
                })
            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'Legal' || value === 'SPOQLegal') {
            questions = [
                new TextboxQuestion({
                    key: 'searchValue',
                    label: 'Search(Name,Tax ID,SSN) :',
                    order: 100,

                }),
                new DropdownQuestion({
                    key: 'searchBy',
                    label: 'Search By :',
                    defaultOption: 0,
                    options: [
                        { key: 0, value: 'Name' },
                        { key: 1, value: 'TaxID' },
                        { key: 2, value: 'SSN' },
                        { key: 3, value: 'WCIS ID' }
                    ],
                    order: 120
                }),
                new OptionsInlineQuestion({
                    key: 'searchType',
                    label: 'Search Type :',
                    defaultOption: 'StartsWith',
                    options: [
                        { key: 'StartsWith', value: 'StartsWith' },
                        { key: 'Contains', value: 'Contains' }
                    ],
                    order: 200
                }),
                new OptionsInlineQuestion({
                    key: 'LegalType ',
                    label: 'Legal Type :',
                    defaultOption: 'I',
                    options: [
                        { key: 'I', value: 'Institutional' },
                        { key: 'In', value: 'Individual' }
                    ],
                    order: 210
                }),
                new DropdownQuestion({
                    key: 'searchLimit',
                    label: 'Limit Results :',
                    defaultOption: 25,
                    options: [{ key: 25, value: 25 },
                    { key: 50, value: 50 },
                    { key: 100, value: 100 },
                    { key: 150, value: 150 },
                    { key: 200, value: 200 },
                    { key: 250, value: 250 },
                    { key: 300, value: 300 }],
                    order: 270
                })
            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'AddLegal') {
            questions = [
                new TextboxQuestion({
                    key: 'searchValue',
                    label: 'Search(Prefix,Alert Acronym) :',
                    order: 100
                }),
            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'Marketer' || value === 'Marketer Associate/Analyst') {
            questions = [
                new TextboxQuestion({
                    key: 'lastName',
                    label: 'Last Name:',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'firstName',
                    label: 'First Name:',
                    value: '',
                    order: 120
                }),
                new TextboxQuestion({
                    key: 'emplId',
                    label: 'Employee Id :',
                    order: 200
                }),
                new TextboxQuestion({
                    key: 'empKeyId',
                    label: 'Employee Key :',
                    order: 220
                }),
                new DropdownQuestion({
                    key: 'LimitResults',
                    label: 'Limit Results',
                    defaultOption: 25,
                    options: [{ key: 25, value: 25 },
                    { key: 50, value: 50 },
                    { key: 100, value: 100 },
                    { key: 150, value: 150 },
                    { key: 200, value: 200 },
                    { key: 250, value: 250 },
                    { key: 300, value: 300 }],
                    order: 300
                })
            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'MIFID Business Account') {
            questions = [
                new TextboxQuestion({
                    key: 'legalId',
                    label: 'Legal Id :',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'busAcctId',
                    label: 'Business Account Id :',
                    order: 110
                }),
                new TextboxQuestion({
                    key: 'acctShortName',
                    label: 'Short Name :',
                    order: 200
                }),
                new TextboxQuestion({
                    key: 'busAcctName',
                    label: 'Account Name :',
                    order: 210
                }),
                //new DropdownQuestion({
                //    key: 'systemCode',
                //    label: 'System Code :',
                //    defaultOption: 'CMR',
                //    options: [
                //        { key: 'CMR', value: '(CMR) INTERNATIONAL/FX' },
                //    ],
                //    disabled: true,
                //    order: 220
                //}),
                new TextboxQuestion({
                    key: 'externalId',
                    label: 'External Id :',
                    order: 230
                }),
                new OptionsInlineQuestion({
                    key: 'srchAction',
                    label: 'Search :',
                    defaultOption: 'S',
                    options: [
                        { key: 'S', value: 'Starts With' },
                        { key: 'C', value: 'Contains' }
                    ],
                    order: 250
                }),
                new DropdownQuestion({
                    key: 'limitRow',
                    label: 'Limit Results :',
                    defaultOption: 25,
                    options: [{ key: 25, value: 25 },
                    { key: 50, value: 50 },
                    { key: 100, value: 100 },
                    { key: 150, value: 150 },
                    { key: 200, value: 200 },
                    { key: 250, value: 250 },
                    { key: 300, value: 300 }],
                    order: 270
                })
            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'Legal Address') {
            questions = [
                new TextboxQuestion({
                    key: 'legalId',
                    label: 'Legal Id :',
                    value: '',
                    order: 100
                })];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'Salesperson/Trader') {
            questions = [
                new TextboxQuestion({
                    key: 'salesGroup',
                    label: 'Group Name:',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'salesPersonPotName',
                    label: 'Sales Person/Pot Name:',
                    value: '',
                    order: 120
                }),
                new TextboxQuestion({
                    key: 'salesCategory',
                    label: 'Category  :',
                    order: 200
                }),
                new TextboxQuestion({
                    key: 'salesCategoryType',
                    label: 'Category Type :',
                    order: 220
                }),
                new DropdownQuestion({
                    key: 'LimitResults',
                    label: 'Limit Results',
                    defaultOption: 25,
                    options: [{ key: 25, value: 25 },
                    { key: 50, value: 50 },
                    { key: 100, value: 100 },
                    { key: 150, value: 150 },
                    { key: 200, value: 200 },
                    { key: 250, value: 250 },
                    { key: 300, value: 300 }],
                    order: 300
                })
            ];
            return questions.sort((a, b) => a.order - b.order);
        }
        else if (value === 'Wire') {
            questions = [
                new TextboxQuestion({
                    key: 'baId',
                    label: 'Business Account ID:',
                    value: '',
                    order: 100
                }),

            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'Expense Code') {
            questions = [
                new TextboxQuestion({
                    key: 'code',
                    label: 'Code:',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'category',
                    label: 'Category:',
                    value: 'EXPENSECODE',
                    order: 100,
                    disabled: true,
                }),

            ];
            return questions.sort((a, b) => a.order - b.order);
        } else if (value === 'Primary SIC') {
            questions = [
                new TextboxQuestion({
                    key: 'code',
                    label: 'Code:',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'category',
                    label: 'Category:',
                    value: 'PRIMARYSIC',
                    order: 100,
                    disabled: true,
                }),

            ];
            return questions.sort((a, b) => a.order - b.order);
        }
        else if(value === 'Relationship Manager' || value === 'Relationship Associate'
            || value === 'Credit Officer/Underwriter' || value === 'Cross Sell Referral'
            || value === 'Treasury Management Sales Consultant' || value === 'OLS Specialist'
            || value === 'ITM' || value === 'DoCO-CPMG Contact'){
            questions = [
                new TextboxQuestion({
                    key: 'lastName',
                    label: 'Last Name:',
                    value: '',
                    order: 100
                }),
                new TextboxQuestion({
                    key: 'firstName',
                    label: 'First Name:',
                    value: '',
                    order: 120
                }),
                new TextboxQuestion({
                    key: 'emplId',
                    label: 'Employee Id :',
                    order: 200
                }),
                new TextboxQuestion({
                    key: 'AU',
                    label: 'AU:',
                    order: 220
                }),
                new DropdownQuestion({
                    key: 'LimitResults',
                    label: 'Limit Results',
                    defaultOption: 25,
                    options: [{ key: 25, value: 25 },
                    { key: 50, value: 50 },
                    { key: 100, value: 100 },
                    { key: 150, value: 150 },
                    { key: 200, value: 200 },
                    { key: 250, value: 250 },
                    { key: 300, value: 300 }],
                    order: 300
                })
            ];
            return questions.sort((a, b) => a.order - b.order);
        }

    }
    buildFundGridFields() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new TextboxQuestion({
                key: 'Fund_ID__c',
                label: 'Fund ID (LIQ ID)',
                order: 100
            }),
            new SingleCheckboxQuestion({
                key: 'Indicate_Surviving__c',
                label: 'Indicate Surviving ID',
                order: 200
            }),
        ];
        return questions.sort((a, b) => a.order - b.order);
    }
    buildLeidGridFields() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new TextboxQuestion({
                key: 'CID_LEID__c',
                label: 'CID LEID for Account',
                order: 100
            }),
            new SingleCheckboxQuestion({
                key: 'Indicate_Surviving__c',
                label: 'Indicate Surviving Account',
                order: 200
            }),
        ];
        return questions.sort((a, b) => a.order - b.order);
    }

    buildGridFields() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new DropdownQuestion({
                key: 'Flag__c',
                label: 'Flag',
                defaultOption: '--None--',
                order: 100,
                options: [{ key: '--None--', value: '--None--' },
                { key: 'Brass Tag', value: 'Brass Tag' },
                { key: 'MEI', value: 'MEI' },
                { key: 'MIS', value: 'MIS' },
                { key: 'Options Levels', value: 'Options Levels' },
                { key: 'Sweep Code', value: 'Sweep Code' }],
            }),
            new TextboxQuestion({
                key: 'Current_Flag_Tag_Name__c',
                label: 'Current Flag/Tag Name',
                order: 200
            }),
            new TextboxQuestion({
                key: 'New_Flag_Tag_Name__c',
                label: 'New Flag/Tag Name',
                order: 300
            }),
        ];
        return questions.sort((a, b) => a.order - b.order);
    }

    buildCommonFields(maintenanceType?: string, maintenanceSubType?: string, cobamRole?: string,
        formFields?: QuestionBase<any>[], requestStatus?: string): QuestionBase<any>[] {
        let statusOrder: number = 0, assignedToOrder: number = 0;
        let options: any = [];
        switch (requestStatus) {
            case 'Draft':
                if (cobamRole === 'Requester' || cobamRole === 'Requester NonCash' || cobamRole === 'Tax Profile II'
                    || cobamRole === 'AML KYC' || cobamRole === 'Requester FX' || cobamRole === 'Requester Maintenance' || 
                    (this.authService.HasRequesterMaintenanceAccess && (cobamRole === 'Maintenance' || cobamRole === 'DCOT' ||
                        cobamRole === 'Account Approval' || cobamRole === 'Tax Withholding' ||
                        cobamRole === 'Client Services'
                    )))
                    options = [{ key: 'Draft', value: 'Draft' }];
                break;
            case 'Open - Unassigned':
                options =
                    [
                        { key: 'Open - Unassigned', value: 'Open - Unassigned' },
                        { key: 'Pending - Inprogress', value: 'Pending - Inprogress' }
                    ];
                break;
            case 'Pending - Inprogress':
                if (cobamRole === 'Maintenance' || cobamRole === 'DCOT' || cobamRole === 'Account Approval'
                    || cobamRole === 'Requester' || cobamRole === 'Requester NonCash' || cobamRole === 'Tax Profile II'
                    || cobamRole === 'AML KYC' || cobamRole === 'Requester FX' || cobamRole === 'Requester Maintenance' || cobamRole === 'Client Services') {
                    options =
                        [
                            { key: 'Pending - Inprogress', value: 'Pending - Inprogress' },
                            { key: 'Pending - Front Office', value: 'Pending - Front Office' },
                            { key: 'Pending - Research Required', value: 'Pending - Research Required' },
                            { key: 'Pending - Waiting on COG', value: 'Pending - Waiting on COG' },
                            { key: 'Closed - Approved', value: 'Closed - Approved' },
                            { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                            { key: 'Closed - Inactive', value: 'Closed - Inactive' }
                        ];
                } else if (cobamRole === 'Tax Withholding' || cobamRole === 'Requester' || cobamRole === 'Requester NonCash'
                    || cobamRole === 'Tax Profile II' || cobamRole === 'AML KYC' || cobamRole === 'Requester FX'
                    || cobamRole === 'Requester Maintenance' || cobamRole === 'Client Services') {
                    options =
                        [
                            { key: 'Pending - Inprogress', value: 'Pending - Inprogress' },
                            { key: 'Closed', value: 'Closed' },
                            { key: 'Account Set-up Review in CID & BPS', value: 'Account Set-up Review in CID & BPS' },
                            { key: 'Review security in Taxonomy & BPS', value: 'Review security in Taxonomy & BPS' },
                            { key: 'Review transaction in BPS', value: 'Review transaction in BPS' },
                            { key: 'Calculate & send adjust to settlements', value: 'Calculate & send adjust to settlements' },
                            { key: 'DDA Funded', value: 'DDA Funded' }
                        ];
                }
                break;
            case 'Pending - Front Office':
            case 'Pending - Research Required':
            case 'Pending - Waiting on COG':
                options =
                    [
                        { key: 'Pending - Inprogress', value: 'Pending - Inprogress' },
                        { key: 'Pending - Front Office', value: 'Pending - Front Office' },
                        { key: 'Pending - Research Required', value: 'Pending - Research Required' },
                        { key: 'Pending - Waiting on COG', value: 'Pending - Waiting on COG' },
                        { key: 'Closed - Approved', value: 'Closed - Approved' },
                        { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                        { key: 'Closed - Inactive', value: 'Closed - Inactive' }
                    ];
                break;
            case 'Account Set-up Review in CID & BPS':
            case 'Review security in Taxonomy & BPS':
            case 'Review transaction in BPS':
            case 'Calculate & send adjust to settlements':
            case 'DDA Funded':
                options =
                    [
                        { key: 'Closed', value: 'Closed' },
                        { key: 'Account Set-up Review in CID & BPS', value: 'Account Set-up Review in CID & BPS' },
                        { key: 'Review security in Taxonomy & BPS', value: 'Review security in Taxonomy & BPS' },
                        { key: 'Review transaction in BPS', value: 'Review transaction in BPS' },
                        { key: 'Calculate & send adjust to settlements', value: 'Calculate & send adjust to settlements' },
                        { key: 'DDA Funded', value: 'DDA Funded' }
                    ];
                break;
            case 'Closed - Approved':
                options =
                    [
                        { key: 'Closed - Approved', value: 'Closed - Approved' },
                        { key: 'Re-Open', value: 'Re-Open' }
                    ];
                break;
            case 'Closed - Rejected':
                options =
                    [
                        { key: 'Draft', value: 'Draft' },
                        { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                        { key: 'Re-Open', value: 'Re-Open' }
                    ];
                break;
            case 'Closed - Inactive':
                options =
                    [
                        { key: 'Closed - Inactive', value: 'Closed - Inactive' },
                        { key: 'Re-Open', value: 'Re-Open' }
                    ];
                break;
            case 'Submitted':
                options = [{ key: 'Submitted', value: 'Submitted' }];
                break;
            case 'Approved in CID Staging':
                options = [{ key: 'Approved in CID Staging', value: 'Approved in CID Staging' }];
                break;
            case 'Closed':
                options = [{ key: 'Closed', value: 'Closed' }];
                break;
            case 'Re-Open':
                if (cobamRole === 'Maintenance' || cobamRole === 'DCOT' || cobamRole === 'Account Approval'
                    || cobamRole === 'Requester' || cobamRole === 'Requester NonCash' || cobamRole === 'Tax Profile II'
                    || cobamRole === 'AML KYC' || cobamRole === 'Requester FX' || cobamRole === 'Requester Maintenance' || cobamRole === 'Client Services') {
                    options =
                        [
                            { key: 'Pending - Inprogress', value: 'Pending - Inprogress' },
                            { key: 'Re-Open', value: 'Re-Open' }
                        ];
                }
                else if (cobamRole === 'Tax Withholding' || cobamRole === 'Requester' || cobamRole === 'Requester NonCash'
                    || cobamRole === 'Tax Profile II' || cobamRole === 'AML KYC' || cobamRole === 'Requester FX'
                    || cobamRole === 'Requester Maintenance' || cobamRole === 'Client Services') {
                    options =
                        [
                            { key: 'Pending - Inprogress', value: 'Pending - Inprogress' },
                            { key: 'Closed', value: 'Closed' },
                            { key: 'Account Set-up Review in CID & BPS', value: 'Account Set-up Review in CID & BPS' },
                            { key: 'Review security in Taxonomy & BPS', value: 'Review security in Taxonomy & BPS' },
                            { key: 'Review transaction in BPS', value: 'Review transaction in BPS' },
                            { key: 'Calculate & send adjust to settlements', value: 'Calculate & send adjust to settlements' },
                            { key: 'DDA Funded', value: 'DDA Funded' },
                            { key: 'Re-Open', value: 'Re-Open' }
                        ];
                }
                break;
            default:
                if (cobamRole === 'Requester' || cobamRole === 'Requester NonCash' || cobamRole === 'Tax Profile II'
                    || cobamRole === 'AML KYC' || cobamRole === 'Requester FX' || cobamRole === 'Requester Maintenance')
                    options = [{ key: 'Draft', value: 'Draft' }];
                break;
        }
        switch (maintenanceType) {
            case 'Business Account Level Changes':
                switch (maintenanceSubType) {
                    case 'Address Change':
                    case 'Business Account Re-mapping':
                    case 'Flag/Tag Updates':
                    case 'Fund Mergers (LIQ)':
                    case 'Fund Updates':
                    case 'Interested Parties':
                    case 'Statement Preferences':
                    case 'Safekeeping Updates':
                    case 'MiFID II Risk Reducing':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Externals':
                switch (maintenanceSubType) {
                    case 'Add Concert account(s)':
                    case 'Add new external(s)':
                    case 'Add PRECISE account(s)':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    case 'Tax Withholding Reversal':
                        statusOrder = 420;
                        assignedToOrder = 680;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Instructions':
                switch (maintenanceSubType) {
                    case 'DVP Instructions':
                    case 'Payment Instructions':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    case 'Wire Changes':
                        statusOrder = 330;
                        assignedToOrder = 630;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Legal Changes':
                switch (maintenanceSubType) {
                    case 'Legal Mergers':
                    case 'Legal Name Changes':
                    case 'Tax ID Changes':
                    case 'Update Legal Hierarchy':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    case 'Hong Kong Classification Refresh':
                        statusOrder = 270;
                        assignedToOrder = -1;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Miscellaneous/Other':
                switch (maintenanceSubType) {
                    case 'LoanNet Mapping':
                    case 'Other':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    case 'Prime - Form 1 Schedule A Update':
                    case 'Prime - PB Int\'l/BD Credit letter update':
                        statusOrder = 330;
                        assignedToOrder = 580;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Regulatory Changes':
                switch (maintenanceSubType) {
                    case 'AML data update':
                        statusOrder = 230;
                        assignedToOrder = 720;
                        break;
                    case 'DCOT - AML And Ops Risk':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Sales Coverage':
                switch (maintenanceSubType) {
                    case 'Create a New Sales Rep Code':
                    case 'DCOT - Coverage Admin RM/AU':
                    case 'Update Existing Rep Code':
                    case 'Changes for Coverage':
                        statusOrder = 330;
                        assignedToOrder = 480;
                        break;
                    default:
                        statusOrder = 0;
                        assignedToOrder = 0;
                        break;
                }
                break;
            case 'Update POQ':
            case '':
                statusOrder = 340;
                assignedToOrder = 380;
                break;
            case 'MiFID Categorization Change':
                statusOrder = 430;
                assignedToOrder = 580;
                break;
            default:
                statusOrder = 0;
                assignedToOrder = 0;
                break;
        }
        let queueStatusQuestion = new DropdownQuestion({
            key: 'Status__c',
            label: 'Queue Status',
            value: requestStatus,
            order: statusOrder,
            options: options
        });
        let assignedToQuestion = new AutoCompleteQuestion({
            key: 'Assigned_To__r',
            label: 'Assigned To',
            order: assignedToOrder,
            value: '',
            api: 'Maintenance/users/',
            filterCriteria: maintenanceSubType === 'Wire Changes' ? 'Maintenance, Account Approval, DCOT' : maintenanceSubType === 'Tax Withholding Reversal' ? 'Tax Withholding' : 'Maintenance, Account Approval, DCOT',
            relation: [
                {
                    action: "VISIBLE",
                    connective: "OR",
                    when: [
                        {
                            id: "Status__c",
                            value: "Open - Unassigned"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Inprogress"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Front Office"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Research Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Waiting on COG"
                        },
                        {
                            id: "Status__c",
                            value: "Account Set-up Review in CID & BPS"
                        },
                        {
                            id: "Status__c",
                            value: "Review security in Taxonomy & BPS"
                        },
                        {
                            id: "Status__c",
                            value: "Review transaction in BPS"
                        },
                        {
                            id: "Status__c",
                            value: "Calculate & send adjust to settlements"
                        },
                        {
                            id: "Status__c",
                            value: "DDA Funded"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Approved"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Rejected"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Inactive"
                        },
                        {
                            id: "Status__c",
                            value: "Closed"
                        },
                        {
                            id: "Status__c",
                            value: "Re-Open"
                        },
                    ]
                },
                {
                    action: 'ENABLE',
                    connective: 'AND',
                    when: [
                        {
                            id: 'User_Role',
                            value: 'Maintenance'
                        },
                        {
                            id: 'User_Role',
                            value: 'Unknown'
                        },
                        {
                            id: 'User_Role',
                            value: 'DCOT'
                        },
                        {
                            id: 'User_Role',
                            value: 'Unknown'
                        },
                        {
                            id: 'User_Role',
                            value: 'Account Approval'
                        },
                        {
                            id: 'User_Role',
                            value: 'Unknown'
                        },
                        {
                            id: 'User_Role',
                            value: 'Tax Withholding'
                        }
                    ]
                },
                {
                    action: 'REQUIRED',
                    connective: 'OR',
                    when: [

                        {
                            id: "Status__c",
                            value: "Pending - Inprogress"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Front Office"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Research Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Waiting on COG"
                        },
                        {
                            id: "Status__c",
                            value: "Account Set-up Review in CID & BPS"
                        },
                        {
                            id: "Status__c",
                            value: "Review security in Taxonomy & BPS"
                        },
                        {
                            id: "Status__c",
                            value: "Review transaction in BPS"
                        },
                        {
                            id: "Status__c",
                            value: "Calculate & send adjust to settlements"
                        },
                        {
                            id: "Status__c",
                            value: "DDA Funded"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Approved"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Rejected"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Inactive"
                        },
                        {
                            id: "Status__c",
                            value: "Closed"
                        },
                        {
                            id: "Status__c",
                            value: "Re-Open"
                        },
                    ]
                }

            ]
        });
        formFields = formFields.filter(question => question.key !== 'Status__c'
            && question.key !== 'User_Role' && question.key !== 'Assigned_To__r');
        formFields.push(queueStatusQuestion,
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }));
        if (maintenanceSubType !== 'Hong Kong Classification Refresh' && maintenanceSubType !== 'MiFID II Risk Reducing'
            && maintenanceSubType !== 'Safekeeping Updates') formFields.push(assignedToQuestion);
        return formFields.sort((a, b) => a.order - b.order);
    }


    getCIDBusinessAccounts(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'busAcctdetails',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Maintenance/GetCIDBusinessAccounts/', options);
    }
    GetCommonCounterpartyList(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'legaldetails',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Maintenance/GetCommonCounterpartyList/', options);
    }
    SearchLegalFromCCR(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'legaldetails',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Maintenance/SearchLegalFromCCR/', options);
    }
    GetSPOQMarketer(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'marketerdetails',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Maintenance/GetSPOQMarketer/', options);
    }

    GetEmployees(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'emaployeeFilter',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Lookup/GetEmployees/', options);
    }

    GetMarketerAnalyst(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'emaployeeFilter',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Lookup/GetMarketerAnalyst/', options);
    }

    GetMaintenanceRequestDetails(MaintenanceReqId: string): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL +
            'Maintenance/GetMaintenanceRequest/?id=' +
            MaintenanceReqId
        );
    }
    AddMaintenanceRequest(paramObj: any): Observable<any> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers };
        const body = JSON.stringify({ MaintenanceRequestParent: paramObj });
        return this.httpClient.post(
            environment.BASEURL + 'Maintenance/AddMaintenanceRequest/'
            , body
            , options
        );
    }
    UpdateMaintenanceRequest(paramObj: any): Observable<any> {

        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers };
        const body = JSON.stringify({ MaintenanceRequestParent: paramObj });

        return this.httpClient.put(
            environment.BASEURL + 'Maintenance/UpdateMaintenanceRequest/'
            , body
            , options
        );

    }
    GetCounterpartyAddressList(legalid: number, addressType: string): Observable<any> {

        // tslint:disable-next-line:max-line-length
        return this.httpClient.get(environment.BASEURL + 'Maintenance/GetCounterpartyAddressList/?legalid=' + legalid + '&addressType=' + addressType);
    }
    getSalesGroupLookup(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'salesgroupdetails',
            JSON.stringify(paramObj ? paramObj : undefined)
        );
        const options = {
            params: pgParams
        };
        return this.httpClient.get(environment.BASEURL + 'Maintenance/GetSalesGroupLookup/', options);
    }

    getIndividualSalesPerson(empKeyId: number): Observable<any> {

        return this.httpClient.get(
            environment.BASEURL +
            'Maintenance/GetIndividualSalesPerson/?EmpKeyId=' +
            empKeyId
        );

    }

    getAPACDetails(legalId: number): Observable<any> {

        return this.httpClient.get(
            environment.BASEURL +
            'Maintenance/GetAPACDetails/?legalId=' +
            legalId
        );

    }

    getSafeKeepingFlag(busAcctId: number): Observable<any> {

        return this.httpClient.get(
            environment.BASEURL +
            'Maintenance/GetSafeKeepingFlag/?busAcctId=' +
            busAcctId
        );

    }

    getPaymentList(paramObj: any): Observable<any> {

        if (paramObj.baId)
            return this.httpClient.get(
                environment.BASEURL +
                'Maintenance/GetPaymentList/?baId=' +
                paramObj.baId
            );
        else null;
    }

    getCOBAMLookup(paramObj: any): Observable<any> {
        if (paramObj.code && paramObj.category)
            return this.apiService.Get(
                environment.BASEURL + 'Lookup/cobamLookup/?code=' + paramObj.code + '&category=' + paramObj.category
            );
        else null;
    }

    SendEmailForApproval(callbackId: any): Observable<any> {

        let pgParams = new HttpParams();
        pgParams = pgParams.set(
            'callbackId',
            callbackId
        );
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers, params: pgParams };

        return this.httpClient.post(
            environment.BASEURL + 'Maintenance/SendEmailForApproval/'
            , null
            , options
        );

    }

    GetCallbackTrackingHistory(callbackId: string): Observable<any> {
        return this.httpClient.get(
            environment.BASEURL +
            'Maintenance/GetCallbackTrackingHistory/?id=' +
            callbackId
        );
    }
    GetAPACCommentsHistory(parentId: string): Observable<any> {
        return this.apiService.Get(environment.BASEURL + 'Maintenance/GetAPACCommentHistory/?id=' + parentId);
    }
    GetAttachments(parentId: string): Observable<any> {
        return this.httpClient.get(environment.BASEURL + 'Attachment/GetAttachments/?parentId=' + parentId);
    }
}
