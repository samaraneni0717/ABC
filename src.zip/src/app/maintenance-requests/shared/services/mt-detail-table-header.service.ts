import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class DetailTableHeaderService {
  getTableHeaders(buttontype: string): any[] {
    switch (buttontype) {
      case 'POQ':
        return [
          { headerName: 'Account Id', apiColumnName: 'AccountId' },
          { headerName: 'Short Name', apiColumnName: 'ShortName' },
          { headerName: 'Account Name', apiColumnName: 'AccountName' },
          { headerName: 'Long Name', apiColumnName: 'LongName' },
          { headerName: 'Account Mode', apiColumnName: 'AccountMode' },
          { headerName: 'External System', apiColumnName: 'ExternalSystem' },
          { headerName: 'External Id', apiColumnName: 'ExternalId' },
          { headerName: 'External Name', apiColumnName: 'ExternalName' },
          { headerName: 'External Status', apiColumnName: 'ExternalStatus' },
          { headerName: 'Group Name', apiColumnName: 'GroupName' },
          { headerName: 'Category Type', apiColumnName: 'CategoryType' },
          { headerName: 'Category Id', apiColumnName: 'CategoryId' },
          { headerName: 'Category Name', apiColumnName: 'CategoryName' },
          {
            headerName: 'Trading Category Name',
            apiColumnName: 'TradingCategoryName'
          },
          { headerName: 'Legal Id', apiColumnName: 'LegalId' },
          { headerName: 'Legal Shortname', apiColumnName: 'LegalShortName' },
          { headerName: 'Legal Fullname', apiColumnName: 'LegalFullName' }
        ];
      case 'WCIS':
        return [
          { headerName: 'Prefix', apiColumnName: 'Prefix' },
          { headerName: 'Legal Id', apiColumnName: 'LegalId' },
          {
            headerName: 'Counterparty Name',
            apiColumnName: 'LegalFullName'
          },
          { headerName: 'Alert Acronym', apiColumnName: 'AlertAcronym' },
          { headerName: 'Doc Level', apiColumnName: 'DocLevel' },
          { headerName: 'Address Line 1', apiColumnName: 'AddressLine1' },
          { headerName: 'Address Line 2', apiColumnName: 'AddressLine2' },
          { headerName: 'City', apiColumnName: 'City' },
          { headerName: 'State', apiColumnName: 'State' },
          { headerName: 'Zip', apiColumnName: 'ZipCode' }
        ];
      case 'LE':
      case 'SPOQLegal':
        return [
          { headerName: 'Legal Name', apiColumnName: 'LegalFullName' },
          { headerName: 'Legal Id', apiColumnName: 'LegalId' },
          { headerName: 'Type', apiColumnName: 'LegalType' },
          { headerName: 'SSN', apiColumnName: 'SSN' },
          { headerName: 'Tax Id', apiColumnName: 'TaxId' },
          { headerName: 'Address Line 1', apiColumnName: 'AddressLine1' },
          { headerName: 'Address Line 2', apiColumnName: 'AddressLine2' },
          { headerName: 'City', apiColumnName: 'City' },
          { headerName: 'State', apiColumnName: 'State' },
          { headerName: 'Zip', apiColumnName: 'ZipCode' },
          { headerName: 'Country', apiColumnName: 'Country' },
          { headerName: 'ICIS Id', apiColumnName: 'ClientId' },
          { headerName: 'Branch', apiColumnName: 'BranchLocationName' },
          { headerName: 'DUNS Number', apiColumnName: 'DUNSNbr' }
        ];
      case 'Sales':
        return [
          { headerName: 'Group Name', apiColumnName: '' },
          { headerName: 'Sales Person/Pot Name', apiColumnName: '' },
          { headerName: 'All Sales Person For Group', apiColumnName: '' },
          { headerName: 'Category', apiColumnName: '' },
          { headerName: 'Category Type', apiColumnName: '' },
          { headerName: 'Branch Location', apiColumnName: '' }
        ];
      case 'MR':
      case 'Marketer Associate/Analyst':
        return [
          { headerName: 'Last Name', apiColumnName: 'LastName' },
          { headerName: 'First Name', apiColumnName: 'FirstName' },
          { headerName: 'Employee Key', apiColumnName: 'EmpKeyId' },
          { headerName: 'Employee Id', apiColumnName: 'EmpId' },
          { headerName: 'Email Address', apiColumnName: 'EmailAddress' },
          { headerName: 'Phone Number', apiColumnName: 'PhoneNumber' },
          { headerName: 'Status', apiColumnName: 'Status' },
          { headerName: 'Employee Status', apiColumnName: 'EmployeeStatus' },
          { headerName: 'Branch Location', apiColumnName: 'BranchLocation' }
          ];
      case 'SPTR':
          return [
              { headerName: 'Group Name', apiColumnName: 'SalesGroup' },
              { headerName: 'Sales Person/Pot Name', apiColumnName: 'SalesPersonPotName' },
              { headerName: 'All Sales Person For Group', apiColumnName: 'AllSalesPersonPotNameForGroupName' },
              { headerName: 'Category', apiColumnName: 'SalesCategory' },
              { headerName: 'Category Type', apiColumnName: 'SalesCategoryType' },
              { headerName: 'Branch Location', apiColumnName: 'BranchLocation' },
          ];
      case 'Wire':
          return [
              { headerName: 'Beneficiary ID Type', apiColumnName: 'BeneficiaryIDType' },
              { headerName: 'Beneficiary Name', apiColumnName: 'BeneficiaryName' },
              { headerName: 'Beneficiary ID', apiColumnName: 'BeneficiaryID' },
              { headerName: 'Beneficiary Bank ID Type', apiColumnName: 'BeneficiaryBankIDType' },
              { headerName: 'Beneficiary Bank Name', apiColumnName: 'BeneficiaryBankName' },
              { headerName: 'Beneficiary Bank ID', apiColumnName: 'BeneficiaryBankID' },
              { headerName: 'Intermediary Bank ID Type', apiColumnName: 'IntermediaryBankIDType' },
              { headerName: 'Intermediary Bank Name', apiColumnName: 'IntermediaryBankName' },
              { headerName: 'Routing Number(Intermediary Bank ID)', apiColumnName: 'IntermediaryBankID' },
              { headerName: 'Other Instructions', apiColumnName: 'OtherInstr' },
              { headerName: 'Third Party Approval-Timestamp', apiColumnName: 'ThirdPartyApprovalTimestampInternal' },
          ];
      case 'Legal Address':
          return [{ headerName: 'Address', apiColumnName: 'Address' }];
      case 'CallbackHistory':
            return [
                { headerName: '# of Callback Attempts', apiColumnName: 'SequenceNumber', colSpan:1 },
                { headerName: 'Contact Name', apiColumnName: 'Callback_Verification_Contact_Name__c', colSpan: 2 },
                { headerName: 'Contact Number', apiColumnName: 'Callback_Verification_Contact_Number__c', colSpan: 2 },
                { headerName: 'Callback Notes', apiColumnName: 'Notes__c', colSpan: 4},
                { headerName: 'Callback Date/Time', apiColumnName: 'CallbackDateTimeInternal', colSpan: 1 },
               
            ];
      case 'APACCommentsHistory':
              return [
                  { headerName: 'Changed Field', apiColumnName: 'Field' },
                  { headerName: 'Old Value', apiColumnName: 'OldValue' },
                  { headerName: 'New Value', apiColumnName: 'NewValue' },
                  { headerName: 'Changed By', apiColumnName: 'ChangedUser' },
                  { headerName: 'Changed Date', apiColumnName: 'CreatedDate' },                 
              ];
      case 'ExpenseCode':
      case 'PrimarySIC':
        return [
          { headerName: 'Code', apiColumnName: 'Code__c' },
          { headerName: 'Description', apiColumnName: 'Description__c' }
        ];
      case 'Relationship Manager':
      case 'Relationship Associate':
      case 'Credit Officer/Underwriter':
      case 'Cross Sell Referral':
      case 'Treasury Management Sales Consultant':
      case 'OLS Specialist':
      case 'ITM':
      case 'DoCO-CPMG Contact':
        return [
          { headerName: 'Last Name', apiColumnName: 'LastName' },
          { headerName: 'First Name', apiColumnName: 'FirstName' },
          { headerName: 'Employee Id', apiColumnName: 'EmpId' },
          { headerName: 'Email Address', apiColumnName: 'EmailAddress' },
          { headerName: 'AU', apiColumnName: 'AU' },
          { headerName: 'Phone Number', apiColumnName: 'PhoneNumber' },
          { headerName: 'jobTitle', apiColumnName: 'Job Title' }
        ];
      default:
      // code to be executed if n doesn't match any constant
    }
  }
}
