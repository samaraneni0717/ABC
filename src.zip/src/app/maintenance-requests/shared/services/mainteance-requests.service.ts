import { Injectable } from '@angular/core';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/Common/services/api.service';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class MaintenanceRequestsService {
  constructor(private httpClient: HttpClient, private apiService: ApiService) {
    console.log('Service instantiated');
  }

  getMaintenanceColumnDefinations() {
    return this.apiService.Get(environment.BASEURL + 'Maintenance/GetMaintenanceColumnDefinations/');
  }
  getMaintenanceRequests(paramObj: any): Observable<any> {
    let pgParams = new HttpParams();
    pgParams = pgParams.set(
      'searchInputModel',
      JSON.stringify(paramObj ? paramObj : undefined)
    );
    return this.apiService.Get(environment.BASEURL + 'Maintenance/GetMaintenanceRequests/', pgParams);
  }

  deleteMaintenanceRequests(mtReqIds: any): Observable<any> {
    return this.apiService.Get(environment.BASEURL + 'Maintenance/DeleteMaintenanceRequest/?mtReqIds=' + mtReqIds);
  }
  buildRequestFormFields() {
    let questions: QuestionBase<any>[] = [];
    questions = [
      new DropdownQuestion({
        key: 'MaintenanceType',
        label: 'Maintenance Type',
        defaultOption: 'Business Account Level Changes',
        order: 100,
        options: [
          { key: 'Business Account Level Changes', value: 'Business Account Level Changes' },
          { key: 'Externals', value: 'Externals' },
          { key: 'Instructions', value: 'Instructions' },
          { key: 'Legal Changes', value: 'Legal Changes' },
          { key: 'Miscellaneous/Other', value: 'Miscellaneous/Other' },
          { key: 'Regulatory Changes', value: 'Regulatory Changes' },
          { key: 'Sales Coverage', value: 'Sales Coverage' },
          { key: 'Update POQ', value: 'Update POQ' },
          { key: 'MiFID Categorization Change', value: 'MiFID Categorization Change' },
        ],
      }),
      new DropdownQuestion({
        key: 'MaintenanceSubType',
        label: 'Maintenance SubType',
        //defaultOption: 'Address Change',
        parent: { 
          key: 'MaintenanceType', 
          value: '' 
          }, 
          
        order: 200,
        options: [
          { key: '-- Please Select --', value: '-- Please Select --' },
          { key: 'Add Concert account(s)', value: 'Add Concert account(s)', parentKey: 'Externals' },
          { key: 'Add new external(s)', value: 'Add new external(s)', parentKey: 'Externals' },
          { key: 'Add PRECISE account(s)', value: 'Add PRECISE account(s)', parentKey: 'Externals' },
          { key: 'Address Change', value: 'Address Change', parentKey: 'Business Account Level Changes' },
          { key: 'AML data update', value: 'AML data update', parentKey: 'Regulatory Changes' },
          { key: 'Business Account Re-mapping', value: 'Business Account Re-mapping', parentKey: 'Business Account Level Changes' },
          { key: 'Create a New Sales Rep Code', value: 'Create a New Sales Rep Code', parentKey: 'Sales Coverage' },
          { key: 'DCOT - AML And Ops Risk', value: 'DCOT - AML And Ops Risk', parentKey: 'Regulatory Changes' },
          { key: 'DCOT - Coverage Admin RM/AU', value: 'DCOT - Coverage Admin RM/AU', parentKey: 'Sales Coverage' },
          { key: 'DVP Instructions', value: 'DVP Instructions', parentKey: 'Instructions' },
          { key: 'Flag/Tag Updates', value: 'Flag/Tag Updates', parentKey: 'Business Account Level Changes' },
          { key: 'Fund Mergers (LIQ)', value: 'Fund Mergers (LIQ)', parentKey: 'Business Account Level Changes' },
          { key: 'Fund Updates', value: 'Fund Updates', parentKey: 'Business Account Level Changes' },
          { key: 'Interested Parties', value: 'Interested Parties', parentKey: 'Business Account Level Changes' },
          { key: 'Legal Mergers', value: 'Legal Mergers', parentKey: 'Legal Changes' },
          { key: 'Legal Name Changes', value: 'Legal Name Changes', parentKey: 'Legal Changes' },
          { key: 'LoanNet Mapping', value: 'LoanNet Mapping', parentKey: 'Miscellaneous/Other' },
          { key: 'Other', value: 'Other', parentKey: 'Miscellaneous/Other' },
          { key: 'Payment Instructions', value: 'Payment Instructions', parentKey: 'Instructions' },
          { key: 'Prime - Form 1 Schedule A Update', value: 'Prime - Form 1 Schedule A Update', parentKey: 'Miscellaneous/Other' },
          { key: 'Prime - PB Int\'l/BD Credit letter update', value: 'Prime - PB Int\'l/BD Credit letter update', parentKey: 'Miscellaneous/Other' },
          { key: 'Statement Preferences', value: 'Statement Preferences', parentKey: 'Business Account Level Changes' },
          { key: 'Tax ID Changes', value: 'Tax ID Changes', parentKey: 'Legal Changes' },
          { key: 'Update Existing Rep Code', value: 'Update Existing Rep Code', parentKey: 'Sales Coverage' },
          { key: 'Update Legal Hierarchy', value: 'Update Legal Hierarchy', parentKey: 'Legal Changes' },
          { key: 'Update POQ', value: 'Update POQ', parentKey: 'Update POQ' },
          { key: 'Tax Withholding Reversal', value: 'Tax Withholding Reversal', parentKey: 'Externals' },
          { key: 'MiFID Categorization Change', value: 'MiFID Categorization Change', parentKey: 'MiFID Categorization Change' },
          { key: 'Wire Changes', value: 'Wire Changes', parentKey: 'Instructions' },
          { key: 'MiFID II Risk Reducing', value: 'MiFID II Risk Reducing', parentKey: 'Business Account Level Changes' },
          { key: 'Hong Kong Classification Refresh', value: 'Hong Kong Classification Refresh', parentKey: 'Legal Changes' },
          { key: 'Safekeeping Updates', value: 'Safekeeping Updates', parentKey: 'Business Account Level Changes' }
        ]
      })
    ];
    return questions.sort((a, b) => a.order - b.order);
  }
}
