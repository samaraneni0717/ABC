export class MaintenanceRequestQueue {
    MaintenanceRequestNo: string;
    BAID: string;
    BusinessAccountName: string;
    LegalName: string;
    DeskName: string;
    TypeOfReq: string;
    TimeSubmitted: string;
    LastModifiedDate: string;
    RequestorName: string;
    QueueStatus: string;
    Notes: string;

}
