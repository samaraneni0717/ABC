import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MaintenanceRequestQueue } from './maintenance-request.model';
import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class MaintenanceRequestService {
    indLoading = false;
    selectedMaintenanceRequest: MaintenanceRequestQueue;
    maintenanceRequestList: MaintenanceRequestQueue[];
    constructor(private http: Http) { }

    postMaintenanceRequest(request: MaintenanceRequestQueue) {
        const body = JSON.stringify(request);
        const headerOptions = new Headers({ 'Content-Type': 'application/json' });
        const requestOptions = new RequestOptions({ method: RequestMethod.Post, headers: headerOptions });

        return this.http.post(environment.BASEURL + 'MaintenanceRequest', body, requestOptions).pipe(map(x => x.json()));
    }

    putMaintenanceRequest(id, request) {
        const body = JSON.stringify(request);
        const headerOptions = new Headers({ 'Content-Type': 'application/json' });
        const requestOptions = new RequestOptions({ method: RequestMethod.Put, headers: headerOptions });
        return this.http.put(environment.BASEURL + 'MaintenanceRequest/' + id,
            body,
            requestOptions).pipe(map(res => res.json()));
    }

    getMaintenanceRequestList(reqType: string) {

        this.indLoading = true;
        this.http.get(environment.BASEURL + 'MaintenanceRequest/' + reqType)
            .pipe(map((data: Response) => {
                return data.json() as MaintenanceRequestQueue[];

            })).toPromise().then(x => {
                this.maintenanceRequestList = x;
                this.indLoading = false;
            });
    }

    deleteMaintenanceRequest(id: string) {
        return this.http.delete(environment.BASEURL + 'MaintenanceRequest/' + id).pipe(map(res => res.json()));
    }
}
