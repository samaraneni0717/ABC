import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MtDetailRequestsCIDLEIDComponent } from './mt-detail-requests-cidleid-grid.component';

describe('MtDetailRequestsCIDLEIDComponent', () => {
    let component: MtDetailRequestsCIDLEIDComponent;
    let fixture: ComponentFixture<MtDetailRequestsCIDLEIDComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [MtDetailRequestsCIDLEIDComponent]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MtDetailRequestsCIDLEIDComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
