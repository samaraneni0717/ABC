import {
    Component,
    OnInit,
    OnChanges,
    Input,
    ViewEncapsulation
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { DetailRequestService } from '../shared/services/mt-detail-request.service';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { MaintenanceRequestDetailOutputs } from '../Models';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-mt-detail-requests-cidleid-grid',
  templateUrl: './mt-detail-requests-cidleid-grid.component.html',
  styleUrls: ['./mt-detail-requests-cidleid-grid.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MtDetailRequestsCIDLEIDComponent implements OnInit, OnChanges {
  @Input() mtRequestDetailOutputs: any[] = [];
  leidGridForm: FormGroup;
  popLeidId: string;
  popIndicateSurviving: boolean;
  selected: any;
  increment = 0;
  formFields: QuestionBase<any>[] = [];
  checkAll = true;
  showUpdateAll = false;
  massUpdateOptions = ['Mass Update Selected Rows', 'Flag Selected Rows'];
  displayLEIDGridList: MaintenanceRequestDetailOutputs[] = [];
  iteratorObj: any;
  displayLEIDGridFilteredList: MaintenanceRequestDetailOutputs[] = [];
  displayLEIDGridNormalList: MaintenanceRequestDetailOutputs[] = [];
  page = 0;
  size = 5;
  constructor(
    private dialog: MatDialog,
    private detailRequestService: DetailRequestService,
    private qcs: QuestionControlService
  ) {}

  ngOnInit() {
    this.formFields = this.detailRequestService.buildLeidGridFields();
    this.leidGridForm = this.qcs.toFormGroup(this.formFields);
  }
  ngOnChanges() {
      this.displayLEIDGridNormalList = [];
      if (this.mtRequestDetailOutputs) {
          this.mtRequestDetailOutputs.forEach(
              (item: MaintenanceRequestDetailOutputs) => {
                  const iteratorObj: any = {};
                  for (const prop in item) {
                      if (item.hasOwnProperty(prop)) {
                          iteratorObj[prop] = item[prop];
                          iteratorObj['checked'] = false;
                          iteratorObj['style'] = '';
                          iteratorObj['editView'] = false;
                          iteratorObj['IsDeleted'] = false;
                      }
                  }
                  this.displayLEIDGridNormalList.push(iteratorObj);
                  this.displayLEIDGridList = this.displayLEIDGridNormalList;
                  this.checkAll =
                      this.displayLEIDGridList.filter(x => x.checked === true).length ===
                          this.displayLEIDGridList.length
                          ? true
                          : false;
                  this.OnPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
              }
          );
      }
  }

  checkAllGrid(event: boolean) {
    if (event === true && this.displayLEIDGridNormalList.length > 0) {
      this.showUpdateAll = true;
    } else {
      this.showUpdateAll = false;
    }
    this.displayLEIDGridList.forEach(x => (x.checked = event));
  }
  itemSelected(item: any, event: boolean) {
    this.checkAll =
    this.displayLEIDGridList.filter(x => x.checked === true).length ===
    this.displayLEIDGridList.length
    ? true
    : false;

    if (this.displayLEIDGridNormalList.filter(x => x.checked === true).length > 0) {
      this.showUpdateAll = true;
    } else {
      this.showUpdateAll = false;
    }
  }
  addNewRow() {
    const newObj: any = {
      checked: false,
      CID_LEID__c: '',
      Indicate_Surviving__c: false,
      editView: true,
      IsDeleted: false
    };
    this.displayLEIDGridNormalList.unshift(newObj);
    if (this.displayLEIDGridNormalList.length > 0) this.checkAll = false;
    this.OnPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
  }
  removeItem(item) {
    // console.log('Index', index);
    if (item.style === '') {
        item.style = { background: 'pink' };
        item.IsDeleted = true;
    } else {
        item.style = '';
        item.IsDeleted = false;
    }
  }
  editItem(item) {
      item.editView = !item.editView;
  }

  openUpdateGridModal(template, item: any): void {
    if (
      item !== '[object Event]' &&
      item !== '[object MouseEvent]' &&
      item.value !== 'Flag Selected Rows'
    ) {
      this.dialog.open(template, {
        width: '40%'
      });
    } else if (item.value === 'Flag Selected Rows') {
       this.displayLEIDGridNormalList.forEach(gridItem => {
           if (gridItem.checked === true && (gridItem.IsDeleted === false || gridItem.IsDeleted === null)) {
               gridItem['style'] = { background: 'pink' };
               gridItem.IsDeleted = true;
           } else if (gridItem.checked === true && gridItem.IsDeleted === true) {
               gridItem['style'] = '';
               gridItem.IsDeleted = false;
           }
      });
    }
    this.selected = this.increment++;
  }
  applyDetails() {
    const popLeidId = this.leidGridForm.controls['CID_LEID__c'].value;
    const popIndicateSurviving = this.leidGridForm.controls[
      'Indicate_Surviving__c'
    ].value;
    this.displayLEIDGridNormalList.forEach(gridItem => {
      if (gridItem.checked === true) {
        gridItem.CID_LEID__c = popLeidId;
        gridItem.Indicate_Surviving__c = popIndicateSurviving === null || popIndicateSurviving === '' ? false : popIndicateSurviving;
      }
    });
    console.log(this.displayLEIDGridList);
    this.leidGridForm.reset();
    this.dialog.closeAll();
  }
  applyFilter(searchExpression: any) {
      if (searchExpression === '') {
          this.displayLEIDGridFilteredList = [];
          this.displayLEIDGridList = this.displayLEIDGridNormalList;
          this.OnPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
      } else {
          this.displayLEIDGridFilteredList = this.displayLEIDGridNormalList.filter(
              (mtRequestDetailOutputs: MaintenanceRequestDetailOutputs) =>
                  mtRequestDetailOutputs.CID_LEID__c.toLowerCase().includes(
                      searchExpression.toLowerCase()
                  )
          );
          this.displayLEIDGridList = this.displayLEIDGridFilteredList;
          this.OnFilterPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
      }
  }
  OnPageSizeChanged(obj) {
      let index = 0;
      const startingIndex = obj.pageIndex * obj.pageSize;
      const endingIndex = startingIndex + obj.pageSize;

      this.displayLEIDGridList = this.displayLEIDGridNormalList.filter(() => {
          index++;
          return index > startingIndex && index <= endingIndex ? true : false;
      });
      this.checkAll =
          this.displayLEIDGridList.filter(x => x.checked === true).length ===
              this.displayLEIDGridList.length
              ? true
              : false;
  }

  OnFilterPageSizeChanged(obj) {
      let index = 0;
      const startingIndex = obj.pageIndex * obj.pageSize;
      const endingIndex = startingIndex + obj.pageSize;

      this.displayLEIDGridList = this.displayLEIDGridFilteredList.filter(() => {
          index++;
          return index > startingIndex && index <= endingIndex ? true : false;
      });
      this.checkAll =
          this.displayLEIDGridList.filter(x => x.checked === true).length ===
              this.displayLEIDGridList.length
              ? true
              : false;
  }

  onModalClose() {
    this.dialog.closeAll();
  }
}
