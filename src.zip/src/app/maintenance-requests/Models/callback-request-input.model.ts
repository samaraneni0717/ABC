//import { User } from "src/app/Common/models/User";
import { User } from "src/app/Common/dynamic-form-services/dynamic-form.service";
export class CallbackRequestInput {
    Id: string;
    third_Party_Approval_Timestamp__c: Date;
    third_Party_Desk_Head_App_ID__c: string;
    third_Party_Desk_Head_Approval__c: string;
    third_Party_Exception_Approval_Status__c: string;
    supervisor_Principal_Comments__c: string;
    desk_Head_Approver_ID__c: string;
    desk_Head_Approver_Name__c: string;
    desk_Head_Callback_Exception_App_Time__c: Date;
    callback_Status__c: string;
    sequenceId__c: string;
    account_Number_Bank_FI_ID__c: string;
    bank_FI_Name__c: string;
    beneficiary_Bank_Financial_Institution_O__c: string;
    beneficiary_ID_Type__c: string;
    beneficiary_ID__c: string;
    beneficiary_Name__c: string;
    business_Unit_Requesting_Exception__c: string;
    callback_Analyst__c: string;
    callback_Analyst__r: User;
    callback_Date_Time__c: Date;
    callback_Time__c: string;
    callback_Verification_Contact_Name__c: string;
    callback_Verification_Contact_Number__c: string;
    counterparty_Contact_CB_Name_2__c: string;
    counterparty_Contact_CB_Name_3__c: string;
    counterparty_Contact_CB_Phone_1__c: string;
    counterparty_Contact_CB_Phone_2__c: string;
    counterparty_Contact_CB_Phone_3__c: string;
    counterparty_Contact_Name1__c: string;
    counterparty_Contact_Name2__c: string;
    counterparty_Contact_Name3__c: string;
    counterparty_Contact_Phone1__c: string;
    counterparty_Contact_Phone2__c: string;
    counterparty_Contact_Phone3__c: string;
    counterparty_Contact_for_CB_Name1__c: string;
    delegate_Email__c: string;
    delegate_Id__c: string;
    desk_Head_Email__c: string;
    existing_Thirdparty__c: string;
    fax__c: string;
    intermediary_Bank_ID_Type__c: string;
    intermediary_Bank_Name__c: string;
    other_Instructions__c: string;
    policy_Exception_Justification__c: string;
    routing_Number_Intermediary_Bank_ID__c: string;
    source_Type_Other__c: string;
    source_Type__c: string;
    supervisor_Email__c: string;
    supervisor_Id__c: string;
    supervisor__c: string;
    telephone__c: string;
    third_Party_Approval_Sup_Pri_Name__c: string;
    third_Party_Request_Type__c: string;
    third_Party_form_Completed_By__c: string;
    third_Party_form_Completed_Date__c: Date;
    two_distinct_individuals_confirm_instruc__c: boolean;
    verification_Source__c: string;
    Callback_Notes__c: string;
    
    constructor() {
        (this.Id = ''),
            (this.account_Number_Bank_FI_ID__c = ''),
            (this.bank_FI_Name__c = ''),
            (this.beneficiary_Bank_Financial_Institution_O__c = ''),
            (this.beneficiary_ID_Type__c = ''),
            (this.beneficiary_ID__c = ''),
            (this.beneficiary_Name__c = ''),
            (this.business_Unit_Requesting_Exception__c = ''),
            (this.callback_Analyst__c = ''),
            (this.callback_Analyst__r = null),
            (this.callback_Date_Time__c = null),
            (this.callback_Time__c = ''),
            (this.Callback_Notes__c = ''),
            (this.callback_Status__c = ''),
            (this.callback_Verification_Contact_Name__c = ''),
            (this.callback_Verification_Contact_Number__c = ''),
            (this.counterparty_Contact_CB_Name_2__c = ''),
            (this.counterparty_Contact_CB_Name_3__c = ''),
            (this.counterparty_Contact_CB_Phone_1__c = ''),
            (this.counterparty_Contact_CB_Phone_2__c = ''),
            (this.counterparty_Contact_CB_Phone_3__c = ''),
            (this.counterparty_Contact_for_CB_Name1__c = ''),
            (this.counterparty_Contact_Name1__c = ''),
            (this.counterparty_Contact_Name2__c = ''),
            (this.counterparty_Contact_Name3__c = ''),
            (this.counterparty_Contact_Phone1__c = ''),
            (this.counterparty_Contact_Phone2__c = ''),
            (this.counterparty_Contact_Phone3__c = ''),
            (this.delegate_Email__c = ''),
            (this.delegate_Id__c = ''),
            (this.desk_Head_Approver_ID__c = ''),
            (this.desk_Head_Approver_Name__c = ''),
            (this.desk_Head_Callback_Exception_App_Time__c = null),
            (this.desk_Head_Email__c = ''),
            (this.existing_Thirdparty__c = ''),
            (this.fax__c = ''),
            (this.intermediary_Bank_ID_Type__c = ''),
            (this.intermediary_Bank_Name__c = ''),
            (this.other_Instructions__c = ''),
            (this.policy_Exception_Justification__c = ''),
            (this.routing_Number_Intermediary_Bank_ID__c = ''),
            (this.sequenceId__c = ''),
            (this.source_Type_Other__c = ''),
            (this.source_Type__c = ''),
            (this.supervisor_Email__c = ''),
            (this.supervisor_Id__c = ''),
            (this.supervisor_Principal_Comments__c = ''),
            (this.supervisor__c = ''),
            (this.telephone__c = ''),
            (this.third_Party_Approval_Sup_Pri_Name__c = ''),
            (this.third_Party_Approval_Timestamp__c = null),
            (this.third_Party_Desk_Head_Approval__c = ''),
            (this.third_Party_Desk_Head_App_ID__c = ''),
            (this.third_Party_Exception_Approval_Status__c = ''),
            (this.third_Party_form_Completed_By__c = ''),
            (this.third_Party_form_Completed_Date__c = null),
            (this.third_Party_Request_Type__c = ''),
            (this.two_distinct_individuals_confirm_instruc__c = null),
            (this.verification_Source__c = '');
           
    }
}
