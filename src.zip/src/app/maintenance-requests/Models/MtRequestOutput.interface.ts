export interface MtRequestOutput {
    id: string;
    Name: string;
    Maintenance_Request_Type__c: string;
    Maintenance_Request_Sub_Type__c: string;
    Legal_Name__c: string;
    Business_Acct_Fund_Name__c: string;
    Middle_Market_Indicator__c: string;
    CID_LEID__c: number;
    BA_ID__c: string;
    Status__c: string;
    Notes__c: string;
    LastModifiedDate: Date;
    Time_Submitted__c: Date;
    Requestor_Name__c: string;
    CreatedBy: string;
    Owner: string;
    RequestedBy__r: string;
    MiFID_II_Risk_Reducing__c: string;
}
