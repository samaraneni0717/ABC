import { MaintenanceRequestInput, MaintenanceRequestDetailInputs, CallbackRequestInput } from '.';

export interface MaintenanceRequestParentInput {
  MaintenanceRequestInput: MaintenanceRequestInput;
  MaintenanceRequestDetailInputs: MaintenanceRequestDetailInputs[];
  CallbackThirdPartyRequestInput: CallbackRequestInput;
  UserAction: string;
}
