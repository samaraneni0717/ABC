export class CobamSearchInput {
  Id: string;
  SearchText: string;
  CreatedBy: string;
  Desk: string;
  Status: string;
  Statuses: string; // List
  SortedList: string;  // List
  Type: string;
  SubType: string;
  CreatedStartDate: Date;
  CreatedEndDate: Date;
  RequestorName: string;
  RequestorId: string;
  PageNumber: number;
  PageSize: number;
  Endrow: any;
  constructor() {
    (this.Id = ''),
      (this.SearchText = ''),
      (this.CreatedBy = ''),
      (this.Desk = ''),
      (this.Status = ''),
      (this.Statuses = ''),   // List
      (this.SortedList = ''),    // List
      (this.Type = ''),
      (this.SubType = ''),
      (this.CreatedStartDate = null),
      (this.CreatedEndDate = null),
      (this.RequestorName = ''),
      (this.RequestorId = ''),
      (this.PageNumber = null),
      (this.PageSize = null),
      (this.Endrow = null);
  }
}
