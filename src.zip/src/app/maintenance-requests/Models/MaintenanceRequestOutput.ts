import { User } from "src/app/Common/models/User";

export class MaintenanceRequestOutput {
  Id: string;
  Name: string;
  Maintenance_Request_Type__c: string;
  Maintenance_Request_Sub_Type__c: string;
  Legal_Name__c: string;
  Business_Acct_Fund_Name__c: string;
  Middle_Market_Indicator__c: boolean;
  CID_LEID__c: string;
  BA_ID__c: string;
  Status__c: string;
  Notes__c: string;
  External_Name__c: string;
  External_ID__c: string;
  Requestor_Name__c: string;
  Time_Submitted__c: Date;
  OwnerId: string;
  RequestedBy__c: string;
  UpdatedBy__c: string;
  MiFID_II_Client_Categorization__c: string;
  MiFID_II_Investment_Firm__c: string;
  MiFID_II_Central_Bank__c: string;
  WFS_Booking_Entity__c: string;
  New_Wires__c: string;
  Is_this_Wire_a_Third_Party_payment__c: string;
  CreatedDate: Date;
  Is_Payment_pending__c: string;
  SalesPerson_Percent__c: string;
  Marketer__c: string;
  SalesPerson_GroupName__c: string;
  X2MA_Broadridge_Parent__c: string;
  Add_ID__c: string;
  Address_Line1__c: string;
  Address_Line2__c: string;
  Agent_Bank__c: string;
  Assigned_To__c: string;
  Assigned_To__r: User;
  Branch_Location__c: string;
  Bus_Unit__c: string;
  Canada_Province__c: string;
  Change_Coverage_Start_Date__c: Date;
  ChangeLegalAcctOrBusAcctData__c: string;
  City__c: string;
  Closed_Reason__c: string;
  Correct_A_U__c: string;
  Correct_RM__c: string;
  Country__c: string;
  CUSIP__c: string;
  Customer_Email__c: string;
  DTC__c: string;
  EFTPS_ID__c: string;
  Form_150_on_File__c: string;
  FX_Specific_Products__c: string;
  HighRiskEntity__c: string;
  I_have_read_the_definition_of_what_a_3rd__c: boolean;
  Institution_ID__c: string;
  Internal_Number__c: string;
  IsInternetGamblingBussiness__c: string;
  IsNonUSExeOrAffiliates__c: string;
  LoanIQ_Customer_ID__c: string;
  LoanIQ_ID__c: string;
  Marketer_Email__c: string;
  Marketer_Id__c: string;
  New_Advisor__c: string;
  New_Beneficial_Owner__c: string;
  New_Legal_Name__c: string;
  New_Parent_Customer_ID__c: string;
  New_Tax_ID__c: string;
  Payment_Date__c: Date;
  PoliticallyExposedPerson__c: string;
  Postal_Code__c: string;
  Reason_Code__c: string;
  SalesCategory__c: string;
  SalesCategoryId__c: number;
  SalesCategoryType__c: string;
  SalesPerson_Emp_Key_Id__c: string;
  SEC_ID__c: string;
  SPTR_Email__c: string;
  State__c: string;
  Subsequent_2MA_Broadridge_Child__c: string;
  WCIS_ID__c: string;
  WFS_Entity_Validation_Internal__c: string;
  changing_relationship__c: string;
  Zip__c: string;
  MiFID_II_Risk_Reducing__c: string;
  APAC_Approver__c: string;
  APAC_Status__c: string;
  APAC_Comments__c: string;
  Hong_Kong_Classification__c: string;
  Product_group_Market_coverage__c: string;
  Sales_Coverage_Start_Date__c: Date;
  Sales_Coverage_End_Date__c: Date;

  constructor() {
    (this.Id = ''),
      (this.Name = ''),
      (this.Maintenance_Request_Type__c = ''),
      (this.Maintenance_Request_Sub_Type__c = ''),
      (this.Legal_Name__c = ''),
      (this.Business_Acct_Fund_Name__c = ''),
      (this.Middle_Market_Indicator__c = null),
      (this.CID_LEID__c = ''),
      (this.BA_ID__c = ''),
      (this.Status__c = ''),
      (this.Notes__c = ''),
      (this.External_Name__c = ''),
      (this.External_ID__c = ''),
      (this.Requestor_Name__c = ''),
      (this.Time_Submitted__c = null),
      (this.OwnerId = ''),
      (this.RequestedBy__c = ''),
      (this.UpdatedBy__c = ''),
      (this.MiFID_II_Client_Categorization__c = ''),
      (this.MiFID_II_Investment_Firm__c = ''),
      (this.MiFID_II_Central_Bank__c = ''),
      (this.WFS_Booking_Entity__c = ''),
      (this.New_Wires__c = ''),
      (this.Is_this_Wire_a_Third_Party_payment__c = ''),
      (this.CreatedDate = null),
      (this.Is_Payment_pending__c = ''),
      (this.SalesPerson_Percent__c = ''),
      (this.Marketer__c = ''),
      (this.SalesPerson_GroupName__c = ''),
      (this.X2MA_Broadridge_Parent__c = ''),
      (this.Add_ID__c = ''),
      (this.Address_Line1__c = ''),
      (this.Address_Line2__c = ''),
      (this.Agent_Bank__c = ''),
      (this.Assigned_To__c = ''),
      (this.Assigned_To__r = null),
      (this.Branch_Location__c = ''),
      (this.Bus_Unit__c = ''),
      (this.Canada_Province__c = ''),
      (this.Change_Coverage_Start_Date__c = null),
      (this.ChangeLegalAcctOrBusAcctData__c = ''),
      (this.City__c = ''),
      (this.Closed_Reason__c = ''),
      (this.Correct_A_U__c = ''),
      (this.Correct_RM__c = ''),
      (this.Country__c = ''),
      (this.CUSIP__c = ''),
      (this.Customer_Email__c = ''),
      (this.DTC__c = ''),
      (this.EFTPS_ID__c = ''),
      (this.Form_150_on_File__c = ''),
      (this.FX_Specific_Products__c = ''),
      (this.HighRiskEntity__c = ''),
      (this.I_have_read_the_definition_of_what_a_3rd__c = null),
      (this.Institution_ID__c = ''),
      (this.Internal_Number__c = ''),
      (this.IsInternetGamblingBussiness__c = ''),
      (this.IsNonUSExeOrAffiliates__c = ''),
      (this.LoanIQ_Customer_ID__c = ''),
      (this.LoanIQ_ID__c = ''),
      (this.Marketer_Email__c = ''),
      (this.Marketer_Id__c = ''),
      (this.New_Advisor__c = ''),
      (this.New_Beneficial_Owner__c = ''),
      (this.New_Legal_Name__c = ''),
      (this.New_Parent_Customer_ID__c = ''),
      (this.New_Tax_ID__c = ''),
      (this.Payment_Date__c = null),
      (this.PoliticallyExposedPerson__c = ''),
      (this.Postal_Code__c = ''),
      (this.Reason_Code__c = ''),
      (this.SalesCategory__c = ''),
      (this.SalesCategoryId__c = null),
      (this.SalesCategoryType__c = ''),
      (this.SalesPerson_Emp_Key_Id__c = ''),
      (this.SEC_ID__c = ''),
      (this.SPTR_Email__c = ''),
      (this.State__c = ''),
      (this.Subsequent_2MA_Broadridge_Child__c = ''),
      (this.WCIS_ID__c = ''),
      (this.WFS_Entity_Validation_Internal__c = ''),
      (this.changing_relationship__c = ''),
      (this.Zip__c = ''),
      (this.MiFID_II_Risk_Reducing__c = ''),
      (this.APAC_Approver__c = ''),
      (this.APAC_Status__c = ''),
      (this.APAC_Comments__c = ''),
      (this.Hong_Kong_Classification__c = ''),
      (this.Product_group_Market_coverage__c = '');
    (this.Sales_Coverage_Start_Date__c = null);
    (this.Sales_Coverage_End_Date__c = null);
  }
}
