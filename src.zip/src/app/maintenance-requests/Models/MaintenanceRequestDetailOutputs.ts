export class MaintenanceRequestDetailOutputs {
  Id: string;
  Name: string;
  CID_LEID__c: string;
  Current_Flag_Tag_Name__c: string;
  Flag__c: string;
  Fund_ID__c: string;
  Indicate_Surviving__c: boolean;
  Maintenance_Request__c: string;
  New_Flag_Tag_Name__c: string;
  IsDeleted: boolean;
  checked: boolean;
  editView: boolean;
  constructor() {
    (this.Id = ''),
      (this.Name = ''),
      (this.CID_LEID__c = ''),
      (this.Current_Flag_Tag_Name__c = ''),
      (this.Flag__c = ''),
      (this.Fund_ID__c = ''),
      (this.Current_Flag_Tag_Name__c = ''),
      (this.Indicate_Surviving__c = null),
      (this.Maintenance_Request__c = ''),
      (this.New_Flag_Tag_Name__c = ''),
      (this.IsDeleted = null);
  }
}
