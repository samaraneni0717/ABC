export class BusinessAccountSearchDetails {
  busAcctId?: number;
  acctShortName: string;
  busAcctName: string;
  accountLongName: string;
  prefix: string;
  alertAcronym: string;
  speedCode: string;
  systemCode: string;
  systemId: string;
  externalId: string;
  externalShortName: string;
  legalId?: number;
  legalName: string;
  limitRow?: number;
  srchAction: string;
  intEmpKeyId?: number;
}
