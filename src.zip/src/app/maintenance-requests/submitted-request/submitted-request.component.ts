import { Component, OnInit, ViewChild, DoCheck } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MaintenanceRequestService } from '../shared/maintenance-request.service';
// import { CashRequestsService } from '../../Common/services/client-build-request.service';
import { MaintenanceRequestQueue } from '../shared/maintenance-request.model';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { MaintenanceRequest } from '../../Common/models/Maintenance-request.model';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { DropdownQuestion } from '../../Common/dynamic-form-models/question-dropdown';
import { TextboxQuestion } from '../../Common/dynamic-form-models/question-textbox';
import { CheckboxQuestion } from '../../Common/dynamic-form-models/question-checkbox';
import { OptionsQuestion } from '../../Common/dynamic-form-models/Question-Options';
import { Data } from '../../Common/shared/data';

import { Validator } from '../../Common/shared/validator';


@Component({
    selector: 'app-submitted-request',
    templateUrl: './submitted-request.component.html',
    styleUrls: ['./submitted-request.component.css']
})
export class SubmittedRequestComponent implements OnInit, DoCheck {
    maintenanceRequests: MaintenanceRequest[] = [];
    modalRef: NgbModalRef;
    questions: QuestionBase<any>[] = [];
    form: FormGroup;
    payLoad = '';
    workitemCount = 0;
    dataSource;
    displayedColumns = [];
    myExtraColumn = [];
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    // constructor(private maintenanceRequestService: MaintenanceRequestService, private toastr:
    // ToastrService, private route: ActivatedRoute) { }

    constructor(private modalService: NgbModal,
        private maintenanceRequestService: MaintenanceRequestService,
        private router: Router,
        private qcs: QuestionControlService,
        private data: Data,
        private toastr: ToastrService,
    ) {

        this.getFieldConfig();
        this.form = this.qcs.toFormGroup(this.questions);
    }
    /**
     * Pre-defined columns list for user table
     */
    PrimaryColumnNames = [
        {
            id: 'MaintenanceRequestNo1',
            value: 'MaintenanceRequestNo1'

        }];

    columnNames = [
        {
            id: 'MaintenanceRequestNo',
            value: 'MaintenanceRequestNo'

        },
        {
            id: 'BAID',
            value: 'BAID'
        },
        {
            id: 'BusinessAccountName',
            value: 'BusinessAccountName'
        },
        {
            id: 'LegalName',
            value: 'LegalName'
        },
        {
            id: 'DeskName',
            value: 'DeskName'
        },
        {
            id: 'TypeOfReq',
            value: 'TypeOfReq'
        },
        {
            id: 'TimeSubmitted',
            value: 'TimeSubmitted'
        },
        {
            id: 'LastModifiedDate',
            value: 'LastModifiedDate'
        },
        {
            id: 'RequestorName',
            value: 'RequestorName'
        },
        {
            id: 'QueueStatus',
            value: 'QueueStatus'
        },
        {
            id: 'Notes',
            value: 'Notes'
        },
    ];
    ngOnInit() {
        // this.columnNames.concat(this.PrimaryColumnNames);
        this.displayedColumns = this.columnNames.map(x => x.id);
        this.displayedColumns.concat(this.PrimaryColumnNames.map(x => x.id));
        this.maintenanceRequestService.getMaintenanceRequestList('submitted');
        this.BindData();
    }


    getFieldConfig() {
        this.questions = [
            new DropdownQuestion({
                key: 'BuildType',
                label: 'Build Type',
                options: [
                    { key: 'New Legal & Bus Acc', value: 'New Legal & Bus Acc' },
                    { key: 'New Bus Acc Only', value: 'New Bus Acc Only' }
                ],
                // required: true,
                order: 10
            }),

            new DropdownQuestion({
                key: 'ProductType',
                label: 'Product Type',
                parent: {
                    key: 'BuildType',
                    value: ''
                },
                defaultOption: '-- Please Select Build Type --',
                options: [
                    { key: 'Fixed Income Cash', value: 'Fixed Income Cash', parentKey: 'New Bus Acc Only' },
                    { key: 'Equities', value: 'Equities', parentKey: 'New Bus Acc Only' },
                    { key: 'CTS', value: 'CTS', parentKey: 'New Legal & Bus Acc' },
                    { key: 'Agency', value: 'Agency', parentKey: 'New Legal & Bus Acc' },
                    { key: 'Loan Sales', value: 'Loan Sales', parentKey: 'New Legal & Bus Acc' },
                ],
                order: 30,
            }),

            new DropdownQuestion({
                key: 'SettlementType',
                label: 'Settlement Type',
                options: [
                    { key: 'Regular', value: 'Regular' },
                    { key: 'Extended', value: 'Extended' },
                ],
                order: 40
            }),

            new DropdownQuestion({
                key: 'ProductSubType',
                label: 'Product Sub Type',
                options: [
                    { key: 'Cash', value: 'Cash' },
                    { key: 'TBA', value: 'TBA' },
                    { key: 'Repo', value: 'Repo' },
                    { key: 'Rev Repo', value: 'Rev Repo' },
                    { key: 'Tri-Party Repo', value: 'Tri-Party Repo' },
                    { key: 'Repo (Overnight)', value: 'Repo (Overnight)' },
                    { key: 'Prime - PB', value: 'Prime - PB' },
                    { key: 'Prime - DVP', value: 'Prime - DVP' },
                    { key: 'Prime - Margin Roll Up', value: 'Prime - Margin Roll Up' },
                    { key: 'FCM - Futures', value: 'FCM - Futures' },
                    { key: 'FCM - Interest Rate Swap', value: 'FCM - Interest Rate Swap' },
                    { key: 'FCM - Credit Default Swap', value: 'FCM - Credit Default Swap' }
                ],
                order: 60
            }),




        ];
    }

    openModal(template) {
        this.modalRef = this.modalService.open(template);
    }

    btnClick(maintenanceRequests: MaintenanceRequest) {
        this.data.requestDetails = null;
        this.router.navigateByUrl('/maintenance-requests/detail/:' + maintenanceRequests.MaintenanceRequestNo);
    }

    // selectRow(value: any): void {
    //    this.maintenanceRequest = value as MaintenanceRequestQueue;
    //    alert(value);
    //    //for (const prop of Object.keys(this.MaintenanceRequestQueue)) {
    //    //    if (this.form.controls[prop]) {
    //    //        this.form.controls[prop].setValue(this.cashRequest[prop]);
    //    //    }
    //    //}
    //    //this.modalRef.dismiss();
    // }

    BindData() {

        const tableArr: MaintenanceRequest[] = this.maintenanceRequestService.maintenanceRequestList;
        this.dataSource = new MatTableDataSource(tableArr);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;

    }

    ngDoCheck() {
        if (this.maintenanceRequestService.maintenanceRequestList !== undefined &&
            this.maintenanceRequestService.maintenanceRequestList.length > 0
            && this.workitemCount !== this.maintenanceRequestService.maintenanceRequestList.length) {
            this.workitemCount = this.maintenanceRequestService.maintenanceRequestList.length;
            this.systemChanged(1);
        }
    }
    systemChanged(queueType: number) {
        if (this.maintenanceRequestService.maintenanceRequestList !== undefined &&
            this.maintenanceRequestService.maintenanceRequestList.length > 0) {
            if (queueType === 1) {
                this.BindData();
            }

        }
    }

    applyFilter(filterValue: string) {
        this.dataSource.filter = filterValue.trim().toLowerCase();

        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }
}
