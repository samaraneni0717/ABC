import {
  Component,
  OnInit,
  ViewEncapsulation,
  Input,
  OnChanges
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { FormGroup } from '@angular/forms';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { DetailRequestService } from '../shared/services/mt-detail-request.service';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import {
  MaintenanceRequestDetailOutputs,
  MaintenanceRequestDetailInputs
} from '../Models';

@Component({
  selector: 'app-mt-detail-requests-flag-grid',
  templateUrl: './mt-detail-requests-flag-grid.component.html',
  styleUrls: ['./mt-detail-requests-flag-grid.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MtDetailRequestsFlagComponent implements OnInit, OnChanges {
  @Input() mtRequestDetailOutputs: any[] = [];
  gridForm: FormGroup;
  selected: any;
  increment = 0;
  // editView = false;
  formFields: QuestionBase<any>[] = [];
  checkAll = true;
  showUpdateAll = false;
  massUpdateOptions = ['Mass Update Selected Rows', 'Flag Selected Rows'];
  displayFlagGridList: MaintenanceRequestDetailOutputs[] = [];
  tableGridList: MaintenanceRequestDetailInputs[] = [];
  iteratorObj: any;
  displayFlagGridFilteredList: MaintenanceRequestDetailOutputs[];
  displayFlagGridNormalList: MaintenanceRequestDetailOutputs[] = [];
  page = 0;
  size = 5;

  constructor(
    private dialog: MatDialog,
    private detailRequestService: DetailRequestService,
    private qcs: QuestionControlService
  ) {}

  ngOnInit() {
    this.formFields = this.detailRequestService.buildGridFields();
    this.gridForm = this.qcs.toFormGroup(this.formFields);
  }
  ngOnChanges() {
    this.displayFlagGridNormalList = [];
    if (this.mtRequestDetailOutputs) {
      this.mtRequestDetailOutputs.forEach(
        (item: MaintenanceRequestDetailOutputs) => {
          const iteratorObj: any = {
              flagOptions: [
                  { value: '--None--', viewValue: '--None--' },
                  { value: 'Brass Tag', viewValue: 'Brass Tag' },
                  { value: 'MEI', viewValue: 'MEI' },
                  { value: 'MIS', viewValue: 'MIS' },
                  { value: 'Options Levels', viewValue: 'Options Levels' },
                  { value: 'Sweep Code', viewValue: 'Sweep Code' }
              ]
          };
          for (const prop in item) {
            if (item.hasOwnProperty(prop)) {
              iteratorObj[prop] = item[prop];
              iteratorObj['checked'] = false;
              iteratorObj['style'] = '';
              iteratorObj['editView'] = false;
              iteratorObj['IsDeleted'] = false;
            }
          }
          this.displayFlagGridNormalList.push(iteratorObj);
          this.displayFlagGridList = this.displayFlagGridNormalList;
          this.checkAll =
              this.displayFlagGridList.filter(x => x.checked === true).length ===
                  this.displayFlagGridList.length
                  ? true
                  : false;
          this.OnPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
            }
        );
    }
  }

  checkAllGrid(event: boolean) {
    if (event === true && this.displayFlagGridNormalList.length > 0) {
      this.showUpdateAll = true;
    } else {
      this.showUpdateAll = false;
    }
    this.displayFlagGridList.forEach(x => (x.checked = event));
  }

  itemSelected(item: any, event: boolean) {
    this.checkAll =
      this.displayFlagGridList.filter(x => x.checked === true).length ===
      this.displayFlagGridList.length
        ? true
        : false;

    if (this.displayFlagGridNormalList.filter(x => x.checked === true).length > 0) {
      this.showUpdateAll = true;
    } else {
      this.showUpdateAll = false;
    }
  }

  addNewRow() {
    const newObj: any = {
      checked: false,
      Flag__c: '--None--',
      flagOptions: [
        { value: '', viewValue: '--None--' },
        { value: 'Brass Tag', viewValue: 'Brass Tag' },
        { value: 'MEI', viewValue: 'MEI' },
        { value: 'MIS', viewValue: 'MIS' },
        { value: 'Options Levels', viewValue: 'Options Levels' },
        { value: 'Sweep Code', viewValue: 'Sweep Code' }
      ],
      Current_Flag_Tag_Name__c: '',
      New_Flag_Tag_Name__c: '',
      editView: true,
      IsDeleted: false
    };
    this.displayFlagGridNormalList.unshift(newObj);
    if (this.displayFlagGridNormalList.length > 0) this.checkAll = false;
    this.OnPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
  }

  removeItem(item) {
    if (item.style === '') {
      item.style = { background: 'pink' };
      item.IsDeleted = true;
    } else {
      item.style = '';
      item.IsDeleted = false;
    }
  }

  editItem(item) {
      item.editView = !item.editView;
  }
  massUpdateOptionSelected(event) {
    console.log('The selected ', event);
  }
  openUpdateGridModal(template, item: any): void {
    if (
      item !== '[object Event]' &&
      item !== '[object MouseEvent]' &&
      item.value !== 'Flag Selected Rows'
    ) {
      this.dialog.open(template, {
        width: '40%'
      });
    } else if (item.value === 'Flag Selected Rows') {
        this.displayFlagGridNormalList.forEach(gridItem => {
            if (gridItem.checked === true && (gridItem.IsDeleted === false || gridItem.IsDeleted === null)) {
                gridItem['style'] = { background: 'pink' };
                gridItem.IsDeleted = true;
            } else if (gridItem.checked === true && gridItem.IsDeleted === true) {
                gridItem['style'] = '';
                gridItem.IsDeleted = false;
            }
        });
      }
      this.selected = this.increment++;
  }
  applyDetails() {
    const popFlag = this.gridForm.controls['Flag__c'].value;
    const popCurrentFlagName = this.gridForm.controls[
      'Current_Flag_Tag_Name__c'
    ].value;
    const popNewFlagName = this.gridForm.controls['New_Flag_Tag_Name__c'].value;
    this.displayFlagGridNormalList.forEach(gridItem => {
      if (gridItem.checked === true) {
        gridItem.Current_Flag_Tag_Name__c = popCurrentFlagName;
        gridItem.New_Flag_Tag_Name__c = popNewFlagName;
        gridItem.Flag__c = popFlag;
      }
    });
    this.gridForm.reset();
    this.dialog.closeAll();
  }
  applyFilter(searchExpression: any) {
    if (searchExpression === '') {
      this.displayFlagGridFilteredList = [];
      this.displayFlagGridList = this.displayFlagGridNormalList;
      this.OnPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
    } else {
      this.displayFlagGridFilteredList = this.displayFlagGridNormalList.filter(
        (mtRequestDetailOutputs: MaintenanceRequestDetailOutputs) =>
          mtRequestDetailOutputs.New_Flag_Tag_Name__c.toLowerCase().includes(
            searchExpression.toLowerCase()
          ) ||
          mtRequestDetailOutputs.Flag__c.toLowerCase().includes(
            searchExpression.toLowerCase()
          ) ||
          mtRequestDetailOutputs.Current_Flag_Tag_Name__c.toLowerCase().includes(
            searchExpression.toLowerCase()
          )
      );
      this.displayFlagGridList = this.displayFlagGridFilteredList;
      this.OnFilterPageSizeChanged({ pageIndex: this.page, pageSize: this.size });
    }
  }
  onModalClose() {
    this.dialog.closeAll();
  }

  OnPageSizeChanged(obj) {
    let index = 0;
    const startingIndex = obj.pageIndex * obj.pageSize;
    const endingIndex = startingIndex + obj.pageSize;

    this.displayFlagGridList = this.displayFlagGridNormalList.filter(() => {
      index++;
      return index > startingIndex && index <= endingIndex ? true : false;
    });
    this.checkAll =
        this.displayFlagGridList.filter(x => x.checked === true).length ===
        this.displayFlagGridList.length
            ? true
            : false;
  }

  OnFilterPageSizeChanged(obj) {
      let index = 0;
      const startingIndex = obj.pageIndex * obj.pageSize;
      const endingIndex = startingIndex + obj.pageSize;

      this.displayFlagGridList = this.displayFlagGridFilteredList.filter(() => {
          index++;
          return index > startingIndex && index <= endingIndex ? true : false;
      });
      this.checkAll =
          this.displayFlagGridList.filter(x => x.checked === true).length ===
          this.displayFlagGridList.length
              ? true
              : false;
  }
}
