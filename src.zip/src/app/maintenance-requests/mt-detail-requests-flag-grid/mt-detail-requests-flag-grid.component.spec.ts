import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MtDetailRequestsFlagComponent } from './mt-detail-requests-flag-grid.component';

describe('MtRequestsGridComponent', () => {
  let component: MtDetailRequestsFlagComponent;
  let fixture: ComponentFixture<MtDetailRequestsFlagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MtDetailRequestsFlagComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MtDetailRequestsFlagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
