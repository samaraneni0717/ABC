export class Status {
    Id: number;
    Code: string;
    DisplayText: string;
    StatusIndex: number;
    IsActive: boolean;
    IsWorkItemActive: boolean;
}
