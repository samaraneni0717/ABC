export class DistributionListMapping {
    Id: number;
    WorkItemType_Id: number;
    DistributionListId_Id: number;
    IsActive: boolean;
    IsSelected: boolean;
}
