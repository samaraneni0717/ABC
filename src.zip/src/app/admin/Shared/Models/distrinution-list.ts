export class DistrinutionList {
    Id: number;
    Code: string;
    DisplayText: string;
    ShowDLUser: boolean;
    IsActive: boolean;
}
