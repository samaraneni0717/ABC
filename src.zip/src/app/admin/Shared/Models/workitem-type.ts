export class WorkitemType {
    Id: number;
    Code: string;
    DisplayText: string;
    WorkItemTypeIndex: number;
    IsActive: boolean;
    ShowDLUser: boolean;
    isMapped: boolean;
}
