export class WorkitemTypeStatusMapping {
    Id: number;
    WorkItemType_Id: number;
    Status_Id: number;
    Index: number;
    IsActive: boolean;
}
