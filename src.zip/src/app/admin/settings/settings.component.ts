import { Component, OnInit } from '@angular/core';
import { WorkitemType } from '../Shared/Models/workitem-type';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Http, RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { HttpParams } from '@angular/common/http';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { ApiService } from 'src/app/Common/services/api.service';
import { DistrinutionList } from '../Shared/Models/distrinution-list';
import { DistributionListMapping } from '../Shared/Models/distribution-list-mapping';
import { SnackBarService } from 'src/app/Common/snackbar/snack-bar.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-settings',
    templateUrl: './settings.component.html',
    styleUrls: ['./settings.component.css']
})

export class SettingsComponent implements OnInit {
    lstWorkitemType: Array<WorkitemType> = [];
    selectedDistrinutionList: DistrinutionList;
    lstWorkitemDistrinutionList: Array<DistrinutionList> = [];
    lstWorkitemDistributionListMapping: Array<DistributionListMapping> = [];
    lstWorkitemDistributionListMappingtoSave: Array<DistributionListMapping> = [];
    showmapping = false;
    selecteddlid = 0;
    index = 0;
    sub;
    ShowMessage: boolean = false;
    constructor(private http: Http,
        private alertService: AlertService,
        private auth: AuthService,
        private apiService: ApiService,
        private _SnackBarService: SnackBarService,
        private route: ActivatedRoute) { }

    ngOnInit() {
        this.sub = this.route
            .queryParams
            .subscribe(params => {
                this.doSearch(params['EditSettings']);
            });
    }

    GetWorkItemType() {
        this.lstGetWorkItemType().subscribe((lstWitype: any) => {
            if (lstWitype != null) {
                this.lstWorkitemType = lstWitype.lstWorkItemType;
                this.alertService.indLoading = false;
            } else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
                this.alertService.indLoading = false;
            });

    }

    lstGetWorkItemType(): Observable<WorkitemType> {
        this.alertService.indLoading = true;

        let httpParams = new HttpParams()
            .set('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '')
            .set('Type', 'WorkItemType');

        return this.apiService.Get<any>(environment.BASEURL + 'Settings', httpParams);

        // const myParams = new URLSearchParams();
        // myParams.append('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');
        // myParams.append('Type', 'WorkItemType');
        // const options = new RequestOptions({ params: myParams });
        // return this.http.get(environment.BASEURL + 'Settings', options)
        //   .pipe(map((response: Response) => <any>response.json()));
    }

    GetDistributionList() {
        this.lstGetDistributionList().subscribe((lstWidl: any) => {
            if (lstWidl != null) {
                this.lstWorkitemDistrinutionList = lstWidl.lstDistributionList;
                this.alertService.indLoading = false;
            } else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
                this.alertService.indLoading = false;
            });

    }

    lstGetDistributionList(): Observable<WorkitemType> {
        this.alertService.indLoading = true;

        let httpParams = new HttpParams()
            .set('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '')
            .set('Type', 'WorkItemDistributionList');

        return this.apiService.Get<any>(environment.BASEURL + 'Settings', httpParams);

        // const myParams = new URLSearchParams();
        // myParams.append('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');
        // myParams.append('Type', 'WorkItemDistributionList');
        // const options = new RequestOptions({ params: myParams });
        // return this.http.get(environment.BASEURL + 'Settings', options)
        //   .pipe(map((response: Response) => <any>response.json()));
    }

    SelecteddlChanged(changeddl) {
        this.lstWorkitemDistributionListMappingtoSave = [];
        this.lstWorkitemType.forEach(w => {
            w.isMapped = false;
            w.IsActive = false;
        });
        if (changeddl.value === 0) {
            this.selecteddlid = 0;
            this.showmapping = false;
            this.selectedDistrinutionList = new DistrinutionList();
        } else {
            const dl = this.lstWorkitemDistrinutionList.filter(w => w.Id === changeddl.value)[0];
            this.selectedDistrinutionList = {
                Id: dl.Id, Code: dl.Code, DisplayText: dl.DisplayText,
                IsActive: dl.IsActive, ShowDLUser: dl.ShowDLUser
            };
            this.selecteddlid = changeddl.value;
            this.GetWorkItemDistributionListMapping(changeddl.value);
            this.showmapping = true;
        }
    }

    GetWorkItemDistributionListMapping(dlid) {
        this.lstGetWorkItemDistributionListMapping(dlid).subscribe((lstWidlm: any) => {
            if (lstWidlm != null) {
                this.lstWorkitemDistributionListMapping = lstWidlm.lstDistributionListMapping;
                this.lstWorkitemDistributionListMapping.forEach(wim => {
                    this.lstWorkitemType.filter((o) => o.Id === wim.WorkItemType_Id).forEach(wt => {
                        wt.IsActive = wim.IsActive;
                    });
                });
                this.alertService.indLoading = false;
            } else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
                this.alertService.indLoading = false;
            });

    }

    lstGetWorkItemDistributionListMapping(dlid): Observable<WorkitemType> {
        this.alertService.indLoading = true;


        let httpParams = new HttpParams()
            .set('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '')
            .set('Type', 'WorkItemType_DistributiolList_Mapping')
            .set('Id', dlid);

        return this.apiService.Get<any>(environment.BASEURL + 'Settings', httpParams);

        // const myParams = new URLSearchParams();
        // myParams.append('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');
        // myParams.append('Type', 'WorkItemType_DistributiolList_Mapping');
        // myParams.append('Id', dlid);
        // const options = new RequestOptions({ params: myParams });
        // return this.http.get(environment.BASEURL + 'Settings', options)
        //   .pipe(map((response: Response) => <any>response.json()));
    }

    wtMapCheckChanged(wt: WorkitemType, event) {
        wt.isMapped = !wt.isMapped;
        if (wt.isMapped) {
            if (this.lstWorkitemDistributionListMappingtoSave.length === 0) {
                this.lstWorkitemDistributionListMappingtoSave.push({
                    Id: 0,
                    DistributionListId_Id: this.selecteddlid,
                    IsActive: true,
                    WorkItemType_Id: wt.Id,
                    IsSelected: true
                });
            } else {
                if (!this.lstWorkitemDistributionListMappingtoSave.filter((dlm) => dlm.DistributionListId_Id === this.selecteddlid &&
                    dlm.WorkItemType_Id === wt.Id)) {
                    this.lstWorkitemDistributionListMappingtoSave.push({
                        Id: 0,
                        DistributionListId_Id: this.selecteddlid,
                        IsActive: true,
                        WorkItemType_Id: wt.Id,
                        IsSelected: true
                    });
                } else {
                    this.lstWorkitemDistributionListMappingtoSave.filter((dlm) => dlm.DistributionListId_Id === this.selecteddlid &&
                        dlm.WorkItemType_Id === wt.Id).forEach(w => {
                            w.IsSelected = true;
                        });
                }
            }
        } else {
            if (this.lstWorkitemDistributionListMappingtoSave.length === 0) {
                this.lstWorkitemDistributionListMappingtoSave.push({
                    Id: 0,
                    DistributionListId_Id: this.selecteddlid,
                    IsActive: false,
                    WorkItemType_Id: wt.Id,
                    IsSelected: true
                });
            } else {
                this.lstWorkitemDistributionListMappingtoSave.filter((dlm) => dlm.DistributionListId_Id === this.selecteddlid &&
                    dlm.WorkItemType_Id === wt.Id).forEach(w => {
                        this.index = this.lstWorkitemDistributionListMappingtoSave.indexOf(w);
                    });
                this.lstWorkitemDistributionListMappingtoSave.splice(this.index, 1);
            }
        }
    }

    UpdateSettingsDB() {
        if (this.lstWorkitemDistributionListMappingtoSave && this.lstWorkitemDistributionListMappingtoSave.length > 0) {
            this.UpdateWorkitemqDistributionMapping();
        }
        if (this.selectedDistrinutionList) {
            const UserDl = this.lstWorkitemDistrinutionList.filter(dl => dl.Id === this.selectedDistrinutionList.Id);
            if (UserDl && UserDl.length > 0) {
                if (UserDl[0].Code !== this.selectedDistrinutionList.Code ||
                    UserDl[0].DisplayText !== this.selectedDistrinutionList.DisplayText ||
                    UserDl[0].IsActive !== this.selectedDistrinutionList.IsActive ||
                    UserDl[0].ShowDLUser !== this.selectedDistrinutionList.ShowDLUser) {
                    this.UpdateDistributionList();
                }
            } else {
                this.UpdateDistributionList();
            }
        }
    }

    RefreshMasterData() {
        this.RefreshCOBAMMasterData().subscribe(
        (Results) => {
            this.ShowMessage = true;
            document.querySelector("#divMessage").className = "alert alert-success";
            document.querySelector("#divMessage").innerHTML = "Workitem Users cache reset is complete.";
        },
        (error) => {
            this.ShowMessage = true;
            document.querySelector("#divMessage").className = "alert alert-warning";
            document.querySelector("#divMessage").innerHTML = "Not able to communicate with Service Please try Again.";
        });
    }

    RefreshSettings() {
        this.GetDistributionList();
        this.GetWorkItemType();
    }

    RefreshCOBAMMasterData() {
        let httpParams = new HttpParams()
            .set('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');

        return this.apiService.Get<any>(environment.BASEURL + 'RefreshCache', httpParams);

        // const myParams = new URLSearchParams();
        // myParams.append('strUNumber', this.auth.userDetail ? this.auth.userDetail.UNumber : '');
        // const options = new RequestOptions({ params: myParams });
        // return this.http.get(environment.BASEURL + 'RefreshCache', options)
        //   .pipe(map((response: Response) => response.json()));
    }

    UpdateWorkitemqDistributionMapping() {
        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });
        const body = JSON.stringify({
            DistributionListMapping: this.lstWorkitemDistributionListMappingtoSave,
            strUNumber: this.auth.userDetail.UNumber
        });
        this.http.put(environment.BASEURL + 'Settings', body, options).toPromise()
            .then(this.extractData)
            .catch(this.handleErrorPromise);
        this._SnackBarService.openSnackBar('Data Updated Sucessfully', '');
    }

    UpdateDistributionList() {
        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });
        const body = JSON.stringify({
            DistributionList: this.selectedDistrinutionList,
            strUNumber: this.auth.userDetail.UNumber
        });
        this.http.put(environment.BASEURL + 'Settings', body, options).toPromise()
            .then(this.extractData)
            .catch(this.handleErrorPromise);
        this._SnackBarService.openSnackBar('Data Updated Sucessfully', '');
    }

    extractData() {

    }

    handleErrorPromise() {
    }

    ActiveCheckChanged(Distributionlst: DistrinutionList) {
        Distributionlst.IsActive = !Distributionlst.IsActive;
    }

    UserCheckChanged(Distributionlst: DistrinutionList) {
        Distributionlst.ShowDLUser = !Distributionlst.ShowDLUser;
    }

    applyDistributionListCode(Changedevent: string) {
        this.selectedDistrinutionList.Code = Changedevent;
    }

    applyDistributionListDisplayText(Changedevent: string) {
        this.selectedDistrinutionList.DisplayText = Changedevent;
    }

    doSearch(settingsparm: string) {
        if ((this.auth.userDetail !== undefined && (this.auth.userDetail.UNumber === 'U198374' || this.auth.userDetail.UNumber === 'U662121')) || settingsparm === 'true') {
            this.RefreshSettings();
        }
        //refreshworkitemuserscache
        else if (settingsparm === "1") {
            this.RefreshMasterData();
        }
    }
}
