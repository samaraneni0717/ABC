import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { SettingsComponent } from './settings/settings.component';
import { AdminRoutingModule } from './admin-routing.module';
import {MatSelectModule, MatIconModule, MatTooltipModule} from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    MatSelectModule,
    MatIconModule,
    MatTooltipModule
  ],
  declarations: [SettingsComponent]
})
export class AdminModule { }
