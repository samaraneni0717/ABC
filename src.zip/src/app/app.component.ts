import { Component, OnInit, OnDestroy } from '@angular/core'
import { Router, Event, NavigationEnd } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';
import { Login } from './core/services/login.service';

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit, OnDestroy {
  email: string;
  isDisplayComponent: boolean = false;
  userIsLoggedIn: boolean = false;

  //Subscriptions
  routerEventsSubscription: ISubscription;

  constructor(private router: Router, private loginService: Login) {}

  getLogin() {
    JSON.parse(sessionStorage.getItem("user"));

    if (JSON.parse(sessionStorage.getItem("user"))) {
      this.email = JSON.parse(sessionStorage.getItem("user")).email;
    }
  }

  setUserLoggedIn($event) {
    
    this.userIsLoggedIn = true;
  
  }

  setUserLoggedOut($event){

    this.loginService.logout();
    this.userIsLoggedIn = false;

  }

  logout($event){
    this.loginService.logout();
  }

  ngOnInit() {

    this.routerEventsSubscription = this.router.events.subscribe((e: Event) => {
      if (e instanceof NavigationEnd) {
        if (e.url == "/login") {
          this.isDisplayComponent = false;
          this.getLogin();
          
        } else {
          this.isDisplayComponent = true;
          this.getLogin();          
        }
      }
    });
  }

  ngOnDestroy(){

    this.routerEventsSubscription.unsubscribe();

  }

}






