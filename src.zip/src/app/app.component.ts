import { Component, ViewChild, OnInit } from '@angular/core';
import { AuthService } from './Common/Auth/auth-service.service';
import { AlertComponent } from './Common/alert/alert.component';
import { MatMenuTrigger } from '../../node_modules/@angular/material';
import { Router, NavigationEnd } from '../../node_modules/@angular/router';
import { WorkitemService } from './workitem/workitem-queue/shared/workitem-queue.service';
import { DashboardService } from './safekeeping/shared/dashboard.service';
import { ISubscription } from 'rxjs/Subscription';
import { Configuration, User } from './Common/models/User';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
    routerEventSubscription: ISubscription;
    showNavBar = false;

    constructor(
        private router: Router,
        public auth: AuthService,
        private myRoute: Router,
        public _WorkitemService: WorkitemService,
        public _DashboardService: DashboardService) { }

    taxReconUrl:string;

    showAlert = false;

    isDashboard: boolean = true;

    showDashboardMenu = false;
    showWorkitemMenu = false;
    showMaintenanceMenu = false;
    showOnboardingMenu = true;

    date = new Date();

    ngOnInit() {
        let rootUrl: string = '';

        var url = window.location.href;
        var urlList = url.split('#');

        if (urlList != undefined && urlList.length > 0)
            rootUrl = urlList[0];

        this.auth.getConfiguration();

        if (this.auth.configuration != undefined)
            this.taxReconUrl = this.auth.configuration.COBAMURL.replace('COBAM', 'TaxRecon');
        else {
            // if(rootUrl.indexOf("COBAM") >= 0)
            //     this.taxReconUrl = rootUrl.replace('COBAM', 'TaxRecon');
            // else 
            if(rootUrl != undefined)   
                this.taxReconUrl = rootUrl.replace('COBAM', 'TaxRecon');
        }

        this.routerEventSubscription = this.router.events.subscribe((e: any) => {
            if (e instanceof NavigationEnd) {
                if ((e.url.indexOf('/maintenance/detail') >= 0) ||
                    (e.url.indexOf('/offboarding/detail') >= 0) ||
                    (e.url.indexOf('/drools') >= 0) ||
                    (e.url.indexOf('/onboarding/detail') >= 0)) {
                    this.showNavBar = false;
                }
                else {
                    this.showNavBar = true;
                    if (!this.auth.userDetail) {
                        this.auth.logIn();
                    }

                    if ((e.url != "/" && e.url != "/dashboard")) {
                        this.isDashboard = false;
                    }
                }

                if (e.url.includes('dashboard') || this.isDashboard)
                    this.showDashboardMenu = false;
                else
                    this.showDashboardMenu = true;

                if (e.url.endsWith('workitem'))
                    this.showWorkitemMenu = false;
                else
                    this.showWorkitemMenu = true;

                if (e.url.includes('maintenance'))
                    this.showMaintenanceMenu = false;
                else
                    this.showMaintenanceMenu = true;
                /*
                if (e.url.includes('onboarding'))
                    this.showOnboardingMenu = false;
                else
                    this.showOnboardingMenu = true;*/

                if (e.url.includes('search'))
                    this.showAlert = false;
                else
                    this.showAlert = true;
            }
        });
    }
    loadRequestedRouter(Requested: any, requestType: string) {
        this.myRoute.navigate([Requested.currentTarget.id], { queryParams: { type: requestType } });
    }
}
