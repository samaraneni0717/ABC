import {
    Component,
    OnInit,
    ViewEncapsulation,
    ChangeDetectorRef
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-tax-information',
    templateUrl: './tax-information.component.html',
    styleUrls: ['./tax-information.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class TaxInformationComponent implements OnInit {
    taxInformationFormFields: QuestionBase<any>[] = [];
    taxInformationForm: FormGroup;
    onboardingRole: string;
    private subscriptions: Subscription[] = [];
    
    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private cdRef: ChangeDetectorRef) {

    }

    ngOnInit(): void {
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.BuildPage();
    }

    BuildPage() {
        this.taxInformationFormFields = this.onboardingDetailRequestService.buildTaxInformationFields(this.onboardingRole);
        this.taxInformationForm = this.qcs.toFormGroup(this.taxInformationFormFields);

        this.cdRef.detectChanges();
        let totalNumberofTaxForms = 0;
        
        if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r
            && ((this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c === 'Equities' && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Sub_Type__c === 'Derivatives')
                || this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c === 'Swaps'
                || this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c === 'FX'
                )
            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails){

            for (const prop of Object.keys(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails)) {
                if (this.taxInformationForm.controls[prop] && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails[prop]) {
                    this.taxInformationForm.controls[prop].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails[prop]);
                }
            }

            //start

            if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.Is_CRS_Forms_Included__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.Is_CRS_Forms_Included__c === 'Yes'){
                totalNumberofTaxForms = totalNumberofTaxForms + 1;
            }
            if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxFormType__c){
                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxFormType__c === 'W-8IMY'){
                    totalNumberofTaxForms = totalNumberofTaxForms + 1;
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_9__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_9__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_9__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8ECI__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8ECI__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8ECI__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8EXP__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8EXP__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8EXP__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN_E__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN_E__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN_E__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN_E_Chapter_4_Only__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN_E_Chapter_4_Only__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8BEN_E_Chapter_4_Only__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8IMY__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8IMY__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.W_8IMY__c;
                    }
                }
                else if(!this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxFormType__c)){
                    totalNumberofTaxForms = totalNumberofTaxForms + 1;
                }
            }
    
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(totalNumberofTaxForms);
        }
        //else if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r && this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails){
        else{
            for (const prop of Object.keys(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails)) {
                if (this.taxInformationForm.controls[prop] && this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails[prop]) {
                    this.taxInformationForm.controls[prop].setValue(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails[prop]);
                }
            }

            if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.Is_CRS_Forms_Included__c && this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.Is_CRS_Forms_Included__c === 'Yes'){
                totalNumberofTaxForms = totalNumberofTaxForms + 1;
            }
            if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxFormType__c){
                if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxFormType__c === 'W-8IMY'){
                    totalNumberofTaxForms = totalNumberofTaxForms + 1;
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_9__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_9__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_9__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8ECI__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8ECI__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8ECI__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8EXP__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8EXP__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8EXP__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN_E__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN_E__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN_E__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN_E_Chapter_4_Only__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN_E_Chapter_4_Only__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8BEN_E_Chapter_4_Only__c;
                    }
    
                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8IMY__c 
                        && !isNaN(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8IMY__c)){
                            totalNumberofTaxForms = totalNumberofTaxForms + this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8IMY__c;
                    }
                }
                else if(!this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxFormType__c)){
                    totalNumberofTaxForms = totalNumberofTaxForms + 1;
                }
            }
    
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(totalNumberofTaxForms);
        }

        let filteredFields = this.taxInformationFormFields.filter(f => f.section && f.section === 'TaxInformationDetails')
        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
                // const filteredFields = this.taxInformationFormFields.filter(f => f.section && f.section === 'TaxInformationDetails')
                if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r && filteredFields && filteredFields.length > 0) {
                    this.controlCashTaxFieldRendering(filteredFields);
                }
                else{
                    filteredFields.forEach(element => {
                        this.taxInformationForm.controls[element.key].disable();
                    });
                }
                break;
            case 'Account Approval':
                // const filteredFields = this.taxInformationFormFields.filter(f => f.section && f.section === 'TaxInformationDetails')
                if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r && filteredFields && filteredFields.length > 0) {
                    this.controlCashTaxFieldRendering(filteredFields);
                }
                else if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r 
                    && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c !== 'FX' 
                    && filteredFields && filteredFields.length > 0){

                    this.ControlNonCashTaxFieldRendering(filteredFields);
                }
                else{
                    filteredFields.forEach(element => {
                        this.taxInformationForm.controls[element.key].disable();
                    });
                }
                break;
            case 'DCOT':
                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c !== 'FX'
                    && filteredFields && filteredFields.length > 0){

                    this.ControlNonCashTaxFieldRendering(filteredFields);
                }
                else{
                    filteredFields.forEach(element => {
                        this.taxInformationForm.controls[element.key].disable();
                    });
                }
                break;
            case 'FX Static Data':
                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c === 'FX'
                    && filteredFields && filteredFields.length > 0){

                        this.ControlFXTaxFieldRendering(filteredFields);
                }
                else{
                    filteredFields.forEach(element => {
                        this.taxInformationForm.controls[element.key].disable();
                    });
                }
                break;
            case 'Tax Profile I':
                if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r){
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'TaxReviewStatus__c':
                                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r && this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxReviewStatus__c){
                                        (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key !== '');
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                                default:
                                    break;
                            }
                        });
                    }
                }
                else if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r){
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'TaxReviewStatus__c':
                                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c){
                                        (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key !== '');
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                                default:
                                    break;
                            }
                        });
                    }
                }
                if(this.taxInformationForm.controls['Is_Entity_disrega__c'] && this.taxInformationForm.controls['Is_Entity_disrega__c'].value && this.taxInformationForm.controls['Is_Entity_disrega__c'].value === 'Yes'){
                    this.taxInformationForm.controls['Is_a_Parent_build_needed__c'].enable();
                    this.subscriptions.push(this.taxInformationForm.controls['Is_Entity_disrega__c'].valueChanges.subscribe(() =>
                        this.onIsEntitydisregaChange()
                    ));  
                }
                else{
                    this.taxInformationForm.controls['Is_a_Parent_build_needed__c'].disable();
                }
                break;
            case 'Client Services':
            case 'FXOL':
            case 'AML EDD':
            case 'AML KYC':
            case 'Requester':
            case 'Requester NonCash':
                this.DisableTaxInformationDetailsSection();
                break;
            default:
                break;
        }

        
        if (this.taxInformationForm.controls['Is_CRS_Forms_Included__c']) {
            this.subscriptions.push(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].valueChanges.subscribe(() =>
                    this.onIsCRSFormsIncludedChange()
                ));
        }

        if (this.taxInformationForm.controls['TaxFormType__c']) {
            this.subscriptions.push(this.taxInformationForm.controls['TaxFormType__c'].valueChanges.subscribe(() =>
                    this.onTaxFormTypeChange()
                ));
        }
    }

    controlCashTaxFieldRendering(filteredFields){
        if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r && filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                switch (element.key) {
                    case 'TaxReviewStatus__c':
                        if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r){
                            switch (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxReviewStatus__c) {
                                case 'Pending Review - Unassigned':
                                    (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Pending Review - Unassigned');
                                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                                case 'Rejected':
                                    (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === 'Rejected' || o.key === 'Resubmitted');
                                    this.taxInformationForm.controls[element.key].enable();
                                    break;
                                case 'Resubmitted':
                                    (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === 'Rejected' || o.key === 'Resubmitted');
                                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                                default:
                                    if(this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxReviewStatus__c)){
                                        (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Pending Review - Unassigned');
                                        if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.IsModified){
                                            this.taxInformationForm.controls[element.key].enable();
                                        }
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                            }
                        }
                        break;
                    case 'TaxFormType__c':
                    case 'Is_CRS_Forms_Included__c':
                        if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r){
                            switch (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxReviewStatus__c) {
                                case 'Pending Review - Unassigned':
                                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                                case 'Rejected':
                                    this.taxInformationForm.controls[element.key].enable();
                                    break;
                                case 'Resubmitted':
                                    if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                                default:
                                    if(this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxReviewStatus__c)){
                                        if(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.IsModified){
                                            this.taxInformationForm.controls[element.key].enable();
                                        }
                                    }
                                    else{
                                        this.taxInformationForm.controls[element.key].disable();
                                    }
                                    break;
                            }
                        }
                        break;
                    default:
                        this.taxInformationForm.controls[element.key].disable();
                        break;
                }
            });
        }
    }

    ControlNonCashTaxFieldRendering(filteredFields){
        filteredFields.forEach(element => {
            switch (element.key) {
                case 'TaxReviewStatus__c':
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r){
                        switch (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c) {
                            case 'Pending Review - Unassigned':
                                (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Pending Review - Unassigned');
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            case 'Rejected':
                                (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === 'Rejected' || o.key === 'Resubmitted');
                                this.taxInformationForm.controls[element.key].enable();
                                break;
                            case 'Resubmitted':
                                (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === 'Rejected' || o.key === 'Resubmitted');
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            default:
                                if(this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c)){
                                    (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Pending Review - Unassigned');
                                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                        }
                    }
                    break;
                case 'TaxFormType__c':
                case 'Is_CRS_Forms_Included__c':
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r){
                        switch (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c) {
                            case 'Pending Review - Unassigned':
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            case 'Rejected':
                                this.taxInformationForm.controls[element.key].enable();
                                break;
                            case 'Resubmitted':
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            default:
                                if(this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c)){
                                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                        }
                    }
                    break;
                default:
                    this.taxInformationForm.controls[element.key].disable();
                    break;
            }
        });
    }

    ControlFXTaxFieldRendering(filteredFields){
        filteredFields.forEach(element => {
            switch (element.key) {
                case 'TaxReviewStatus__c':
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r){
                        switch (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c) {
                            case 'Pending Review - Unassigned':
                                (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Pending Review - Unassigned');
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            case 'Rejected':
                                (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === 'Rejected' || o.key === 'Resubmitted');
                                this.taxInformationForm.controls[element.key].enable();
                                break;
                            case 'Resubmitted':
                                (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === 'Rejected' || o.key === 'Resubmitted');
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            default:
                                if(this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c)){
                                    (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options = (this.taxInformationFormFields.filter(f => f.key === 'TaxReviewStatus__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Pending Review - Unassigned');
                                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                        }
                    }
                    break;
                case 'TaxFormType__c':
                case 'Is_CRS_Forms_Included__c':
                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r){
                        switch (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c) {
                            case 'Pending Review - Unassigned':
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            case 'Rejected':
                                this.taxInformationForm.controls[element.key].enable();
                                break;
                            case 'Resubmitted':
                                if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                    this.taxInformationForm.controls[element.key].enable();
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                            default:
                                if(this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.TaxReviewStatus__c)){
                                    if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified){
                                        this.taxInformationForm.controls[element.key].enable();
                                    }
                                }
                                else{
                                    this.taxInformationForm.controls[element.key].disable();
                                }
                                break;
                        }
                    }
                    break;
                default:
                    this.taxInformationForm.controls[element.key].disable();
                    break;
            }
        });
    }

    onIsEntitydisregaChange(){
        if(this.taxInformationForm.controls['Is_Entity_disrega__c'] && this.taxInformationForm.controls['Is_Entity_disrega__c'].value && this.taxInformationForm.controls['Is_Entity_disrega__c'].value === 'Yes'){
            this.taxInformationForm.controls['Is_a_Parent_build_needed__c'].enable();
        }
        else{
            this.taxInformationForm.controls['Is_a_Parent_build_needed__c'].disable();
        }
    }

    onIsCRSFormsIncludedChange(){
        if(this.taxInformationForm.controls['TaxFormType__c'] && this.taxInformationForm.controls['TaxFormType__c'].value === 'W-8IMY'){
            if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(1);
            }
            else{
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);
            }

            if (this.taxInformationForm.controls['W_9__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_9__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8ECI__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8ECI__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8EXP__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8EXP__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8BEN__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8BEN__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8BEN_E__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8BEN_E__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8IMY__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8IMY__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }
        }
        else if(this.taxInformationForm.controls['TaxFormType__c'] && this.taxInformationForm.controls['TaxFormType__c'].value !== '' && this.taxInformationForm.controls['TaxFormType__c'].value !== 'W-8IMY'){
            if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(1);
            }
            else{
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);
            }
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + 1);
        }
        else{
            if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(1);
            }
            else{
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);
            }

            // if(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) > 0){
            //     this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) - 1);
            // }
        }
    }

    onTaxFormTypeChange(){
        if(this.taxInformationForm.controls['TaxFormType__c'] && this.taxInformationForm.controls['TaxFormType__c'].value === 'W-8IMY'){
            if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(1);
            }
            else{
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);
            }

            if (this.taxInformationForm.controls['W_9__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_9__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8ECI__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8ECI__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8EXP__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8EXP__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8BEN__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8BEN__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8BEN_E__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8BEN_E__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }

            if (this.taxInformationForm.controls['W_8IMY__c']) {
                this.subscriptions.push(this.taxInformationForm.controls['W_8IMY__c'].valueChanges.subscribe(() =>
                        this.onW8IMYChange()
                    ));
            }
        }
        else if(this.taxInformationForm.controls['TaxFormType__c'] && this.taxInformationForm.controls['TaxFormType__c'].value !== '' && this.taxInformationForm.controls['TaxFormType__c'].value !== 'W-8IMY'){
            if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(1);
            }
            else{
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);
            }
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + 1);
        }
        else{
            if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(1);
            }
            else{
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);
            }

            // if(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) > 0){
            //     this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) - 1);
            // }
        }
    }

    onW8IMYChange(){
        //debugger
        this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(0);

        if(this.taxInformationForm.controls['TaxFormType__c'] && this.taxInformationForm.controls['TaxFormType__c'].value !== '' && this.taxInformationForm.controls['TaxFormType__c'].value !== 'W-8IMY'){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + 1);
        }
        else{
            if(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) > 0){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) - 1);
            }
        }

        if(this.taxInformationForm.controls['Is_CRS_Forms_Included__c'] && this.taxInformationForm.controls['Is_CRS_Forms_Included__c'].value === 'Yes'){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + 1);
        }
        else{
            if(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) > 0){
                this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) - 1);
            }
        }

        if(this.taxInformationForm.controls['W_9__c'] && this.taxInformationForm.controls['W_9__c'].value && !isNaN(this.taxInformationForm.controls['W_9__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_9__c'].value));
        }

        if(this.taxInformationForm.controls['W_8ECI__c'] && this.taxInformationForm.controls['W_8ECI__c'].value && !isNaN(this.taxInformationForm.controls['W_8ECI__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_8ECI__c'].value));
        }

        if(this.taxInformationForm.controls['W_8EXP__c'] && this.taxInformationForm.controls['W_8EXP__c'].value && !isNaN(this.taxInformationForm.controls['W_8EXP__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_8EXP__c'].value));
        }

        if(this.taxInformationForm.controls['W_8BEN__c'] && this.taxInformationForm.controls['W_8BEN__c'].value && !isNaN(this.taxInformationForm.controls['W_8BEN__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_8BEN__c'].value));
        }

        if(this.taxInformationForm.controls['W_8BEN_E__c'] && this.taxInformationForm.controls['W_8BEN_E__c'].value && !isNaN(this.taxInformationForm.controls['W_8BEN_E__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_8BEN_E__c'].value));
        }

        if(this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c'] && this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c'].value && !isNaN(this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_8BEN_E_Chapter_4_Only__c'].value));
        }

        if(this.taxInformationForm.controls['W_8IMY__c'] && this.taxInformationForm.controls['W_8IMY__c'].value && !isNaN(this.taxInformationForm.controls['W_8IMY__c'].value)){
            this.taxInformationForm.controls['TotalNumberofTaxForms'].setValue(parseInt(this.taxInformationForm.controls['TotalNumberofTaxForms'].value) + parseInt(this.taxInformationForm.controls['W_8IMY__c'].value));
        }
    }

    DisableTaxInformationDetailsSection() {
        const filteredFields = this.taxInformationFormFields.filter(f => f.section && f.section === 'TaxInformationDetails');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.taxInformationForm.controls[element.key]) {
                    this.taxInformationForm.controls[element.key].disable();
                }
            });
        }
    }

    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
        this.subscriptions = [];
    }
}
