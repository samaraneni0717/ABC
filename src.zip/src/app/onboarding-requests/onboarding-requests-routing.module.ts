import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SubmittedRequestComponent } from './submitted-request/submitted-request.component';
import { SavedRequestComponent } from './saved-request/saved-request.component';
import { TemplateRequestComponent } from './template-request/template-request.component';
import { DetailRequestComponent } from './detail-request/detail-request.component';
import { OnboardingRequestComponent } from './onboarding-requests/onboarding-requests.component';
import { OnboardingDetailRequestComponent } from './onboarding-detail-request/onboarding-detail-request.component';

const routes: Routes = [
    {
        path: 'submitted',
        component: SubmittedRequestComponent
    },
    {
        path: 'saved',
        component: SavedRequestComponent
    },
    {
        path: 'template',
        component: TemplateRequestComponent
    },
    {
        path: 'detail',
        component: OnboardingDetailRequestComponent
    },
    {
        path: 'detail/:id',
        component: OnboardingDetailRequestComponent
    },
    {
        path: 'onboarding',
        component: OnboardingRequestComponent
    },
    {
        path: '',
        component: OnboardingRequestComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OnboardingRequestsRoutingModule { }
