import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-request',
  templateUrl: './saved-request.component.html',
  styleUrls: ['./saved-request.component.css']
})
export class SavedRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
