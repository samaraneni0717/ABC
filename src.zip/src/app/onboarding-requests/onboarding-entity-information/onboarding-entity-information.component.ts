import {
    Component,
    OnInit,
    ViewEncapsulation,
    Input,
    ChangeDetectorRef
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { MatDialog } from '@angular/material';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { GridApi, IGetRowsParams, IDatasource } from 'ag-grid-community';
import { AgGridLoadingOverlay } from 'src/app/Common/ag-grid/ag-grid-loading-overlay.component';
import { AgGridNoRowsOverlay } from 'src/app/Common/ag-grid/ag-grid-no-rows-overlay.component';
import { AgGrid } from 'src/app/Common/ag-grid/ag-grid.model';
import { SPOQ_EntityInformation } from '../Models/spoq_EntityInformation';
import { debounceTime, switchMap } from 'rxjs/operators';
import { Subscription } from 'rxjs';


@Component({
    selector: 'app-onboarding-entity-information',
    templateUrl: './onboarding-entity-information.component.html',
    styleUrls: ['./onboarding-entity-information.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class EntityInformationComponent implements OnInit {
    entityInformationFormFields: QuestionBase<any>[] = [];
    entityInformationForm: FormGroup;

    gridApi: GridApi;
    defaultColDef = {
        sortable: true,
        resizable: true,
    };
    // gridOptions: GridOptions = {
    //     pagination: true,
    //     rowSelection: 'multiple',
    //     rowModelType: 'infinite',
    //     suppressRowClickSelection: true,
    //     suppressCellSelection: true,
    //     cacheBlockSize: 100,
    //     paginationPageSize: 100,
    //     enableServerSideSorting: true,
    //     enableServerSideFilter: true,
    // };
    sortValue = '';
    idlist = '';
    showAlert = false;
    isProcessingRequest = false;
    columnDefs: any[] = [];
    rowData = [{}];
    //AgGridApi;
    rowParams: IGetRowsParams;
    showDeleteButton = false;
    showEntityInformationTabs = false;
    showComplianceQuestionsTab = false;
    errorMessage: string;
    payLoad: any;
    //cobamSearchInput: CobamSearchInput;
    frameworkComponents = {
        agGridLoadingOverlay: AgGridLoadingOverlay,
        agGridNoRowsOverlay: AgGridNoRowsOverlay
    };
    loadingOverlayComponent = 'agGridLoadingOverlay';
    loadingOverlayComponentParams = { loadingMessage: 'Loading...' };
    noRowsOverlayComponent = 'agGridNoRowsOverlay';
    rowSelection: string;
    searchTitle = '';
    searchDialogRef: any;
    components = {};
    private entityInformationFormSubscription: Subscription;
    isDeleteEntity = false;
    deleteEntityIndex = -1;
    rowClassRules: any;
    getRowHeight: any;
    onboardingRole: string;

    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private dialog: MatDialog,
        private cdRef: ChangeDetectorRef) {
        this.rowSelection = "single";
        this.rowClassRules = {
            "deleted": function (params) {
                return params.data.IsEntityMarkForDeletion;
            }
        };
        this.getRowHeight = function () {
            return 35;
        };
    }

    ngOnInit(): void {
        //debugger
        this.components = { 'deleteClickRenderer': this.DeleteClickRenderer };
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.onboardingDetailRequestService.getEntityInformationColumnDefinations().subscribe(response => {
            this.setDefaultColumnDef();
            // this.columnDefs = [
            //     {
            //         headerName: '',
            //         checkboxSelection: true,
            //         width: 30,
            //         suppressMenu: true,
            //         suppressFilter: true,
            //         filter: false,
            //     }
            // ];
            if (response && (response as any).columnDefs) {
                ((response as any).columnDefs as any[]).forEach(column => {
                    console.log(column);
                    this.columnDefs.push(AgGrid.LoadColumnDefinition(column)[0]);
                });

                //this.rowData = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation;

                if (this.gridApi !== undefined) {
                    this.gridApi.hideOverlay();
                }
            }

        });
        this.BuildPage();
    }

    BuildPage() {
        this.entityInformationFormFields = this.onboardingDetailRequestService.buildEntityInformationFields(this.onboardingRole);
        this.entityInformationForm = this.qcs.toFormGroup(this.entityInformationFormFields);
        //this.showEntityInformationTabs = true;


    }
    DisableEntityInformationDetailsSection() {
        // const filteredFields = this.entityInformationFormFields.filter(f => f.section && f.section === 'EntityInformationDetails');
        const filteredFields = this.entityInformationFormFields;
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.entityInformationForm.controls[element.key]) {
                    this.entityInformationForm.controls[element.key].disable();
                }
            });
        }
    }
    setDefaultColumnDef() {
        this.columnDefs = [
            {
                headerName: "Delete",
                field: "Id",
                cellRenderer: "deleteClickRenderer",
                suppressMenu: true,
                filter: false,
                suppressFilter: true,
                width: 80,
                tooltipField: "Click here to Delete Entity Details"
            }
        ];
    }

    DeleteClickRenderer(params): HTMLElement {
        var anchorElement: HTMLButtonElement = document.createElement("button");
        //anchorElement.innerText = 'Delete'
        anchorElement.innerHTML = '<i class="fa fa-trash" aria-hidden="true"></i>';

        //var thisComponent = params.frameworkComponentWrapper.viewContainerRef.injector.view.component;

        anchorElement.onclick = function () {
            if (params.rowIndex !== undefined) {
                params.data.IsEntityMarkForDeletion = true;
                params.node.setSelected(params.data);
            }
        };

        return anchorElement;
    }


    noRowsOverlayComponentParams = {
        noRowsMessageFunc: function () {
            return '';
        }
    };

    onSelectionChanged(event) {
        if (event.api.getSelectedRows().length > 0) {
            this.showComplianceQuestionsTab = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c !== 'FX';
            const selectedSPOQ_EntityInformation = event.api.getSelectedRows()[0];
            if (!selectedSPOQ_EntityInformation.IsEntityMarkForDeletion) {
                this.showEntityInformationTabs = true;
                console.log(selectedSPOQ_EntityInformation);

                for (const prop of Object.keys(selectedSPOQ_EntityInformation)) {
                    if (this.entityInformationForm.controls[prop]) {
                        this.entityInformationForm.get(prop).setValue(selectedSPOQ_EntityInformation[prop]);
                    }
                }
                if (this.entityInformationFormSubscription) {
                    this.entityInformationFormSubscription.unsubscribe();
                }

                this.entityInformationFormSubscription = this.entityInformationForm.valueChanges.pipe(
                    debounceTime(300))
                    .subscribe(val => {
                        const dirtyValues = this.getDirtyValues(this.entityInformationForm);
                        const selectedSPOQ_EntityInformation = event.api.getSelectedNodes()[0].data;
                        Object.keys(dirtyValues).forEach(key => {
                            selectedSPOQ_EntityInformation[key] = dirtyValues[key];
                        });
                        event.api.getSelectedNodes()[0].setData(selectedSPOQ_EntityInformation);
                    });
            } else {
                this.showEntityInformationTabs = false;
                this.gridApi.updateRowData({ update: event.api.getSelectedRows() });
                const spoqEntities = [];
                this.gridApi.forEachNode(function (node) {
                    if (!node.data.IsEntityMarkForDeletion) {
                        spoqEntities.push(node.data);
                    }
                });
                if (spoqEntities.length <= 0) {
                    const newItem = new SPOQ_EntityInformation();
                    newItem.Id = (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length + 1).toString();
                    newItem.IsNew = true;
                    this.gridApi.updateRowData({ add: [newItem] });
                }
            }
        } else {
            this.showEntityInformationTabs = false;
        }
        this.cdRef.detectChanges();
        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
            case 'Account Approval':
            case 'FX Static Data':
            case 'FXOL':
            case 'Client Services':
            case 'Tax Profile I':
            case 'AML EDD':
            case 'AML KYC':
                this.DisableEntityInformationDetailsSection();
                break;
            default:
                break;
        }
    }

    getDirtyValues(form: any) {
        let dirtyValues = {};

        Object.keys(form.controls)
            .forEach(key => {
                let currentControl = form.controls[key];

                if (currentControl.dirty) {
                    if (currentControl.controls)
                        dirtyValues[key] = this.getDirtyValues(currentControl);
                    else
                        dirtyValues[key] = currentControl.value;
                }
            });

        return dirtyValues;
    }

    onRowDoubleClicked(params) {
        console.log(params);
    }

    apiService(params) {
        // debugger
        // if (params.sortModel.length > 0) {
        //     params.sortModel.forEach(item => this.sortValue = this.sortValue + item.colId + ' ' + item.sort + ' NULLS LAST' + ',');
        // }
        // this.cobamSearchInput.SortedList = this.sortValue.substring(0, this.sortValue.length - 1);
        // this.cobamSearchInput.SearchText = params.filterModel;
        // this.cobamSearchInput.PageSize = 100;
        // this.cobamSearchInput.Endrow = params.endRow;
        // this.payLoad = JSON.parse(JSON.stringify(this.cobamSearchInput));
        // console.log(this.payLoad);
        // return this.onboardingRequestsService.getRequests(this.payLoad);
    }

    onGridReady(params: any) {
        this.gridApi = params;
        this.rowData = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation;
    }

    onOptionsinlineSelectionChange(template, value: string) {
        switch (value) {
            case 'IsSecSPESPV__c':
                this.entityInformationForm.controls['IsSecSPERiskTransferred__c'].setValue(null);
                this.entityInformationForm.controls['IsSecSPERiskSeparated__c'].setValue(null);
                this.entityInformationForm.controls['IsSecSPEPerformanceExposure__c'].setValue(null);
                this.entityInformationForm.controls['IsSecSPEAllFinancialExp__c'].setValue(null);
                this.entityInformationForm.controls['IsSecSPESeniorTransaction__c'].setValue(null);
                this.entityInformationForm.controls['IsSecuritizationSPE__c'].setValue('No');
                break;
            case 'IsSecSPERiskTransferred__c':
            case 'IsSecSPERiskSeparated__c':
            case 'IsSecSPEPerformanceExposure__c':
            case 'IsSecSPEAllFinancialExp__c':
            case 'IsSecSPESeniorTransaction__c':
                if (this.entityInformationForm.controls['IsSecSPESPV__c'].value === 'Yes'
                    && this.entityInformationForm.controls['IsSecSPERiskTransferred__c'].value === 'Yes'
                    && this.entityInformationForm.controls['IsSecSPERiskSeparated__c'].value === 'Yes'
                    && this.entityInformationForm.controls['IsSecSPEPerformanceExposure__c'].value === 'Yes'
                    && this.entityInformationForm.controls['IsSecSPEAllFinancialExp__c'].value === 'Yes') {

                    this.entityInformationForm.controls['IsSecuritizationSPE__c'].setValue('Yes');
                }
                else {
                    this.entityInformationForm.controls['IsSecuritizationSPE__c'].setValue('No');
                }

                break;
            default:
                break;
        }
    }

    onOptionsDropDownSelectionChange(fieldName) {
        switch (fieldName) {
            case 'Country_Organized__c':
                if (this.entityInformationForm.controls['Country_Organized__c'].value !== 'US - UNITED STATES'
                    && this.entityInformationForm.controls['Country_Organized__c'].value !== 'CA - CANADA') {
                    this.entityInformationForm.controls['StateOrProvinceOrganized__c'].setValue('');
                }
                break;
            case 'Legal_Country__c':
                if (this.entityInformationForm.controls['Legal_Country__c'].value !== 'US - UNITED STATES'
                    && this.entityInformationForm.controls['Legal_Country__c'].value !== 'CA - CANADA') {
                    this.entityInformationForm.controls['Legal_State__c'] ? this.entityInformationForm.controls['Legal_State__c'].setValue('') : null;
                    this.entityInformationForm.controls['Legal_Zip__c'] ? this.entityInformationForm.controls['Legal_Zip__c'].setValue('') : null;
                }
            default:
                break;
        }
    }

    addNewEntity() {
        var newItem = new SPOQ_EntityInformation();
        newItem.Id = (this.gridApi.paginationGetRowCount() + 1).toString();
        newItem.IsNew = true;
        this.gridApi.updateRowData({ add: [newItem] });
        let lastNode;
        this.gridApi.forEachNode(function (node) {
            lastNode = node;
        });
        this.gridApi.selectNode(lastNode, false, false);
    }

    addExistingEntity(template) {
        //debugger
        this.searchTitle = 'SPOQLegal';
        this.searchDialogRef = this.dialog.open(template, {
            width: '80%',
            height: '90%'
        });
    }
    onModalClose() {
        this.searchDialogRef.close();
    }

    selectRowData(value: any, legalTemplate: any): void {
        //debugger
        switch (this.searchTitle) {
            case 'SPOQLegal':
                this.onboardingDetailRequestService.getCounterpartyAndComplianceDetailsByLegalId(value.ClientId, value.LegalId).subscribe(data => {
                    if (data) {
                        //console.log(data);
                        this.onModalClose();
                        let legalDetails = JSON.parse(JSON.stringify(data));
                        let spoq_EntityInformation = new SPOQ_EntityInformation();
                        spoq_EntityInformation.Id = (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length + 1).toString();
                        if (legalDetails.RestrictedLegalReasons !== undefined && legalDetails.RestrictedLegalReasons !== null && legalDetails.RestrictedLegalReasons !== '') {

                            alert('LEGALID:' + legalDetails.CIDLegalId + ', Legal Name:' + legalDetails.FullLegalName + ' is in Restricted status for Reason(s):' + legalDetails.RestrictedLegalReasons + '.\n' +
                                'You may proceed with COBAM submission, however, please note that an account will not be created until the above mentioned Legal Restriction(s) have been reviewed/ lifted.\n' +
                                'Please coordinate with the appropriate WFS CDD or WFS Facilitations team to have this restriction reviewed/lifted to proceed with account opening.\n' +

                                'For any questions, please contact:\n' +
                                'WFS CDD Onboarding: G=WFS CDD Onboarding Team \n' +
                                'WFS EMEA CDD Onboarding: G=WFS EMEA CDD Onboarding Team');
                        }

                        spoq_EntityInformation.MiFID_II_Clnt_Cat_Internal_Use__c = legalDetails.MiFIDIIClientCategorization;
                        spoq_EntityInformation.RestrictedLegalReasons__c = legalDetails.RestrictedLegalReasons;

                        spoq_EntityInformation.Legal_Id__c = legalDetails.LegalId;
                        spoq_EntityInformation.Legal_Name__c = legalDetails.FullLegalName;
                        spoq_EntityInformation.WCIS_ID__c = legalDetails.WCISId;

                        spoq_EntityInformation.Tax_Id__c = legalDetails.TaxIdNumber;
                        spoq_EntityInformation.RequesterTax__ui = legalDetails.TaxIdNumber ? legalDetails.TaxIdNumber.substring(0, 5).replace(/\d/g, "X") + legalDetails.TaxIdNumber.substring(5, 9) : null;
                        spoq_EntityInformation.SSN__c = legalDetails.SSN;
                        spoq_EntityInformation.RequesterSSN__ui = legalDetails.SSN ? legalDetails.SSN.substring(0, 5).replace(/\d/g, "X") + legalDetails.SSN.substring(5, 9) : null;
                        if (legalDetails.CountryOrganized) {
                            spoq_EntityInformation.Country_Organized__c = this.onboardingDetailRequestService.countryOptions().filter(s => s.key.startsWith(legalDetails.CountryOrganized))[0].key;
                            if (legalDetails.CountryOrganized === 'US') {
                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.StateOrProvinceOrganized)) {
                                    if (this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized)).length > 0) {
                                        spoq_EntityInformation.StateOrProvinceOrganized__c = this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized))[0].key;
                                    }
                                }
                            }
                            else if (legalDetails.CountryOrganized === 'CA') {
                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.StateOrProvinceOrganized)) {
                                    if (this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized)).length > 0) {
                                        spoq_EntityInformation.StateOrProvinceOrganized__c = this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized))[0].key;
                                    }
                                }
                            }
                        }
                        if (legalDetails.COBAMLegalAddressDetails) {
                            spoq_EntityInformation.Legal_Address1__c = legalDetails.COBAMLegalAddressDetails.Address1;
                            spoq_EntityInformation.Legal_Address2__c = legalDetails.COBAMLegalAddressDetails.Address2;
                            spoq_EntityInformation.Legal_City__c = legalDetails.COBAMLegalAddressDetails.City;
                            spoq_EntityInformation.Legal_Zip__c = legalDetails.COBAMLegalAddressDetails.Zip;
                            if (legalDetails.COBAMLegalAddressDetails.CountryCode) {
                                spoq_EntityInformation.Legal_Country__c = this.onboardingDetailRequestService.countryOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.CountryCode))[0].key;
                                if (legalDetails.COBAMLegalAddressDetails.CountryCode === 'US') {
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.COBAMLegalAddressDetails.State)) {
                                        if (this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State)).length > 0) {
                                            spoq_EntityInformation.Legal_State__c = this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State))[0].key;
                                        }
                                    }
                                }
                                else if (legalDetails.COBAMLegalAddressDetails.CountryCode === 'CA') {
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.COBAMLegalAddressDetails.State)) {
                                        if (this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State)).length > 0) {
                                            spoq_EntityInformation.Legal_State__c = this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State))[0].key;
                                        }
                                    }
                                }
                            }

                        }

                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.EntityType)) {
                            spoq_EntityInformation.Entity_Type__c = this.onboardingDetailRequestService.getEntityTypeOptions().filter(s => s.key.startsWith(legalDetails.EntityType))[0].key;
                        }
                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.ClientType)) {
                            spoq_EntityInformation.Client_Type__c = this.onboardingDetailRequestService.getClientType(legalDetails.ClientType);
                        }
                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.ClientSubType)) {
                            spoq_EntityInformation.Client_SubType__c = this.onboardingDetailRequestService.getClientSubType(legalDetails.ClientSubType);
                        }
                        if (legalDetails.CountryOrganized !== 'US') {
                            spoq_EntityInformation.Government_ID_Number__c = legalDetails.GovernmentIDNumber;
                            if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.GovernmentIDType)) {
                                spoq_EntityInformation.Government_ID_Type__c = this.onboardingDetailRequestService.buildGovermentIdTypeOptions().filter(t => t.key === legalDetails.GovernmentIDType)[0].key;
                            }
                            if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.GovernmentIDIssuer)) {
                                spoq_EntityInformation.Government_ID_Issuer__c = this.onboardingDetailRequestService.countryOptions().concat({ key: 'ZZ - Z COUNTRY', value: 'ZZ - Z COUNTRY' }).filter(c => c.key === legalDetails.GovernmentIDIssuer)[0].key;
                            }
                        }
                        spoq_EntityInformation.Date_Of_Birth__c = legalDetails.DateOfBirth;

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c !== 'FX') {
                            if (legalDetails.COBAMLegalComplianceDetails.isClientRegOCustomer != null || legalDetails.COBAMLegalComplianceDetails.isClientRegOCustomer != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.isClientRegOCustomer) {
                                    spoq_EntityInformation.isClientRegOCustomer__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.isClientRegOCustomer__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.HasappropriateExecutionofTransaction != null || legalDetails.COBAMLegalComplianceDetails.HasappropriateExecutionofTransaction != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.HasappropriateExecutionofTransaction) {
                                    spoq_EntityInformation.HasappropriateExecutionofTransaction__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.HasappropriateExecutionofTransaction__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsTransactionHedge != null || legalDetails.COBAMLegalComplianceDetails.IsTransactionHedge != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsTransactionHedge) {
                                    spoq_EntityInformation.IsTransactionHedge__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsTransactionHedge__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsInLegalDispute != null || legalDetails.COBAMLegalComplianceDetails.IsInLegalDispute != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsInLegalDispute) {
                                    spoq_EntityInformation.IsInLegalDispute__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsInLegalDispute__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsSecuritizationSPE != null || legalDetails.COBAMLegalComplianceDetails.IsSecuritizationSPE != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsSecuritizationSPE) {
                                    spoq_EntityInformation.IsSecuritizationSPE__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsSecuritizationSPE__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsSecSPESPV != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPESPV != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsSecSPESPV) {
                                    spoq_EntityInformation.IsSecSPESPV__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsSecSPESPV__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskTransferred != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskTransferred != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskTransferred) {
                                    spoq_EntityInformation.IsSecSPERiskTransferred__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsSecSPERiskTransferred__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskSeparated != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskSeparated != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskSeparated) {
                                    spoq_EntityInformation.IsSecSPERiskSeparated__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsSecSPERiskSeparated__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEMultDebtTranche != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPEMultDebtTranche != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEMultDebtTranche) {
                                    spoq_EntityInformation.IsSecSPEMultDebtTranche__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsSecSPEMultDebtTranche__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEAllFinancialExp != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPEAllFinancialExp != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEAllFinancialExp) {
                                    spoq_EntityInformation.IsSecSPEAllFinancialExp__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsSecSPEAllFinancialExp__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsPoliticallyExposedPerson != null || legalDetails.COBAMLegalComplianceDetails.IsPoliticallyExposedPerson != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsPoliticallyExposedPerson) {
                                    spoq_EntityInformation.IndPEPInfo__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IndPEPInfo__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.HasPoliticallyExposedPerson != null || legalDetails.COBAMLegalComplianceDetails.HasPoliticallyExposedPerson != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.HasPoliticallyExposedPerson) {
                                    spoq_EntityInformation.NonIndPEP__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.NonIndPEP__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsInternetGamblingBussiness != null || legalDetails.COBAMLegalComplianceDetails.IsInternetGamblingBussiness != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsInternetGamblingBussiness) {
                                    spoq_EntityInformation.IsInternetGamblingBussiness__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsInternetGamblingBussiness__c = 'No';
                                }
                            }

                            if (legalDetails.COBAMLegalComplianceDetails.IsNonUSExeOrAffiliates != null || legalDetails.COBAMLegalComplianceDetails.IsNonUSExeOrAffiliates != undefined) {
                                if (legalDetails.COBAMLegalComplianceDetails.IsNonUSExeOrAffiliates) {
                                    spoq_EntityInformation.IsNonUSExeOrAffiliates__c = 'Yes';
                                }
                                else {
                                    spoq_EntityInformation.IsNonUSExeOrAffiliates__c = 'No';
                                }
                            }
                        }

                        spoq_EntityInformation.CreateOrSelectCMA__c = null;
                        spoq_EntityInformation.CMA_Name__c = null;
                        spoq_EntityInformation.CMAId__c = null;

                        if (legalDetails.MasterAliasId !== undefined && legalDetails.MasterAliasId !== null && legalDetails.MasterAliasId > 0) {
                            spoq_EntityInformation.CreateOrSelectCMA__c = 'Select existing CMA';
                            spoq_EntityInformation.CMA_Name__c = legalDetails.MasterAliasName;
                            spoq_EntityInformation.CMAId__c = legalDetails.MasterAliasId;
                        }
                        else {
                            if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.WCISId)) {
                                spoq_EntityInformation.CreateOrSelectCMA__c = 'Select existing CMA';
                                spoq_EntityInformation.CMA_Name__c = '';
                                spoq_EntityInformation.CMAId__c = 0;
                            }
                            else {
                                spoq_EntityInformation.CreateOrSelectCMA__c = 'Create New CMA';
                                spoq_EntityInformation.CMA_Name__c = legalDetails.FullLegalName;
                                spoq_EntityInformation.CMAId__c = -1;
                            }
                        }
                        spoq_EntityInformation.IsNew = true;
                        this.gridApi.updateRowData({ add: [spoq_EntityInformation] });
                        let lastNode;
                        this.gridApi.forEachNode(function (node) {
                            lastNode = node;
                        });
                        this.gridApi.selectNode(lastNode, false, false);
                    }
                });
                break;
            default:
                break;
        }
    }

    ngOnDestroy() {
        if (this.entityInformationFormSubscription) {
            this.entityInformationFormSubscription.unsubscribe();
        }
    }
}