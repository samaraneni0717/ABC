import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    FormsModule,
    ReactiveFormsModule
} from '@angular/forms';
import { OnboardingRequestsRoutingModule } from './onboarding-requests-routing.module';
import { SubmittedRequestComponent } from './submitted-request/submitted-request.component';
import { SavedRequestComponent } from './saved-request/saved-request.component';
import { TemplateRequestComponent } from './template-request/template-request.component';
import { DetailRequestComponent } from './detail-request/detail-request.component';
import { CommonModuleModule } from '../Common/common-module/common-module.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { OnboardingRequestComponent } from './onboarding-requests/onboarding-requests.component';
import { OnboardingDetailRequestComponent } from './onboarding-detail-request/onboarding-detail-request.component';
import { CdkTableModule } from '@angular/cdk/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from '@angular/material/list';
import { RouterModule } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CustomAgGridModule } from '../Common/ag-grid/ag-grid.module';

import {
    MatButtonModule,
    MatGridListModule,
    MatInputModule,
    MatSidenavModule,
    MatMenuModule,
    MatToolbarModule,
    MatTooltipModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatProgressSpinnerModule
} from '@angular/material';
import { TaxInformationComponent } from './onboarding-tax-information/tax-information.component';
import { InternalContactsComponent } from './onboarding-internal-contacts/onboarding-internal-contacts.component';
import { EntityInformationComponent } from './onboarding-entity-information/onboarding-entity-information.component';
import { DocumentationRequestComponent } from './onboarding-documentation-request/onboarding-documentation-request.component';
import { CustomerContactComponent } from './onboarding-customer-contact/onboarding-customer-contact.component';
import { LoanAndCreditSupportComponent } from './onboarding-loan-credit-support/onboarding-loan-credit-support.component';
import { EChannelsComponent } from './onboarding-echannels/onboarding-echannels.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        OnboardingRequestsRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModuleModule,
        MatButtonModule,
        MatInputModule,
        MatSidenavModule,
        MatMenuModule,
        MatToolbarModule,
        MatTooltipModule,
        MatIconModule,
        MatCardModule,
        MatProgressBarModule,
        MatSelectModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatCheckboxModule,
        MatTableModule,
        MatSortModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatTabsModule,
        MatListModule,
        MatGridListModule,
        CustomAgGridModule,
        AgGridModule.withComponents([
            OnboardingRequestComponent,
            CustomAgGridModule
        ])
    ],
    exports: [
        MatButtonModule,
        MatInputModule,
        MatSidenavModule,
        MatMenuModule,
        MatToolbarModule,
        MatTooltipModule,
        MatIconModule,
        MatCardModule,
        MatProgressBarModule,
        MatSelectModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatCheckboxModule,
        CdkTableModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatTabsModule
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    declarations: [
        SubmittedRequestComponent,
        SavedRequestComponent,
        TemplateRequestComponent,
        DetailRequestComponent,
        OnboardingRequestComponent,
        OnboardingDetailRequestComponent,
        TaxInformationComponent,
        InternalContactsComponent,
        EntityInformationComponent,
        DocumentationRequestComponent,
        CustomerContactComponent,
        LoanAndCreditSupportComponent,
        EChannelsComponent
    ]
})
export class OnboardingRequestsModule { }
