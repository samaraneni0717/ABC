export class COBAMLookup {
  Code: string;
  Description: string;
  Id: string;
  Category__c: string;
  public constructor() {
    (this.Code = null),
      (this.Description = null),
      (this.Id = null),
      (this.Category__c = null)
  }
}
