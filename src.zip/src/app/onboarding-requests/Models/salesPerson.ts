import { User } from 'src/app/Common/models/User';

export class COBAM_SalesPerson {
    Id: string;
    Name: string;
    Branch_Location__c: string;
    COBAM_ID__c: string;
    EmpKeyId__c: number;
    GroupName__c: string;
    Percent__c: string;
    SalesCategory__c: string;
    SalesCategoryId__c: string;
    SalesCategoryType__c: string;
    SalesPersonName__c: string;
    SPTR_Email__c: string;
    
    constructor() {
        this.Id = null;
        this.Name = null;
        this.Branch_Location__c = null;
        this.COBAM_ID__c = null;
        this.EmpKeyId__c = null;
        this.GroupName__c = null;
        this.Percent__c = null;
        this.SalesCategory__c = null;
        this.SalesCategoryId__c = null;
        this.SalesCategoryType__c = null;
        this.SalesPersonName__c = null;
        this.SPTR_Email__c = null;
    }
}