export class SPOQ_FX_eChannels {
    Id: string;
    Name: string;
    MarketerFXSpecialist: string;
    RelationshipManager: string;
    Add_Account_to_FXOL_Setup__c: string;
    CEO_Company_ID__c: string;
    Company_CMR_IDs__c: string;
    Company_Contact_Email__c: string;
    Company_Contact_Names__c: string;
    Company_Contact_Phone__c: string;
    Company_Names__c: string;
    Counterparty_Name1__c: string;
    Counterparty_Name2__c: string;
    DDA_Account_Numbers__c: string;
    Foreign_Exchange_Products__c: string;
    IndicateStatusOfDualCustodyException__c: string;
    Is_the_counterparty_already_setup_on_CEO__c: string;
    MCA_Accounts__c: string;
    MCA_Implementation__c: string;
    Net_New_FXOL_Implementation__c: string;
    Parent_CMR_ID_for_a_Family_Setup__c: string;
    Part_of_a_Family_Setup__c: string;
    SPOQ_ID__c: string;
    Spread_percentage_or_criteria__c: string;
    Waiver_Type__c: string;
    Who_will_perform_the_CEO_ID_setup__c: string;
    IsFxOnline: string;

    constructor(){
        this.Id = null;
        this.Name = null;
        this.MarketerFXSpecialist = null;
        this.RelationshipManager = null;
        this.IsFxOnline = 'No';
        this.Add_Account_to_FXOL_Setup__c = '';
        this.CEO_Company_ID__c = null;
        this.Company_CMR_IDs__c = null;
        this.Company_Contact_Email__c = null;
        this.Company_Contact_Names__c = null;
        this.Company_Contact_Phone__c = null;
        this.Company_Names__c = null;
        this.Counterparty_Name1__c = null;
        this.Counterparty_Name2__c = null;
        this.DDA_Account_Numbers__c = null;
        this.Foreign_Exchange_Products__c = null;
        this.IndicateStatusOfDualCustodyException__c = '';
        this.Is_the_counterparty_already_setup_on_CEO__c = null;
        this.MCA_Accounts__c = null;
        this.MCA_Implementation__c = '';
        this.Net_New_FXOL_Implementation__c = '';
        this.Parent_CMR_ID_for_a_Family_Setup__c = null;
        this.Part_of_a_Family_Setup__c = '';
        this.SPOQ_ID__c = null;
        this.Spread_percentage_or_criteria__c = null;
        this.Waiver_Type__c = null;
        this.Who_will_perform_the_CEO_ID_setup__c = '';
    }
}