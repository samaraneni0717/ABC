import { User } from 'src/app/Common/models/User';
import { ClientBuildRequest } from './clientBuildRequest';
import { SPOQ_DocumentationRequest } from './spoq_DocumentationRequest';

export class OnboardingRequest {
    Id: string;
    Name: string;
    Build_Type__c: string;
    Client_Build_Request__c: string;
    Client_Build_Request__r: ClientBuildRequest;
    COBAM_No__c: string;
    Product_Type__c: string;
    Product_Sub_Type__c: string;
    Product_Sub_Type_MS__c: string;
    ProductSettlementType__c: string;
    Queue_Status__c: string;
    Settlement_Type__c: string;
    SPOQ_DocumentationRequest__c: string;
    SPOQ_DocumentationRequest__r: SPOQ_DocumentationRequest;
    WFS_Entity__c: string;
    UserAction: string;
    
    constructor() {
        this.Id = null;
        this.Name = null;
        this.Build_Type__c = '';
        this.Client_Build_Request__c = null;
        this.Client_Build_Request__r = new ClientBuildRequest();
        this.COBAM_No__c = null;
        this.Product_Type__c = null;
        this.Product_Sub_Type__c = null;
        this.Product_Sub_Type_MS__c = null;
        this.ProductSettlementType__c = null;
        this.Queue_Status__c = null;
        this.Settlement_Type__c = null;
        this.SPOQ_DocumentationRequest__c = null;
        this.SPOQ_DocumentationRequest__r = new SPOQ_DocumentationRequest();
        this.WFS_Entity__c = null;
        this.UserAction = null;
    }
}