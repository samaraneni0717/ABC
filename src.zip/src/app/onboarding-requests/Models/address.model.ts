export class Address {
  Address1: string;
  Address2: string;
  Address3: string;
  Address4: string;
  City: string;
  State: string;
  CountryCode: string;
  Zip: string;
  AddressFormat: string;
  CanadianProvince: string;
  CanadianPostal: string;
  public constructor() {
    (this.Address1 = ''),
      (this.Address2 = ''),
      (this.Address3 = ''),
      (this.Address4 = ''),
      (this.City = ''),
      (this.State = ''),
      (this.CountryCode = ''),
      (this.Zip = ''),
      (this.AddressFormat = ''),
      (this.CanadianProvince = ''),
      (this.CanadianPostal = '');
  }
}
