export class SPOQ_InternalContact {
    Id: string;
    Name: string;
    Branch_Location__c: string;
    Employee_Email__c: string;
    Employee_Id__c: string;
    Employee_Name__c: string;
    InternalContactType__c: string;
    SPOQ_ID__c: string;

    constructor(){
        this.Id = null;
        this.Name = null;
        this.Branch_Location__c = null;
        this.Employee_Email__c = null;
        this.Employee_Id__c = null;
        this.Employee_Name__c = null;
        this.InternalContactType__c = null;
        this.SPOQ_ID__c = null;
    }
}