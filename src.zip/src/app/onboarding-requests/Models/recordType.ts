export class RecordType {
    Id: string;
    Name: string;
    Description: string;
    SobjectType; string;

    constructor(){
        this.Id = null;
        this.Name = null;
        this.Description = null;
        this.SobjectType = null;
    }
}