export class SPOQ_LoanAndCreditSupport {
    Id: string;
    Name: string;
    Comments__c: string;
    Credit_Support_Comments__c: string;
    Date_of_Loan_Agreement__c: Date;
    Documentation_to_prepare_a_guarantee__c: string;
    Does_Credit_Support_Annex_need_to_be_VM__c: string;
    Is_any_guarantor_a_trust__c: string;
    Legal_Name_of_Guarantor_s__c: string;
    Loan_Facility__c: string;
    Credit_Support_Comments_2__c: string;
    Will_Credit_Approval_require_derivative__c: string;
    Require_derivative_transaction__c: string;
    SPOQ_ID__c: string;
    SwapGuarantorVerification__c: string;
    Syndicated__c: string;
    Transaction_guaranteed_via_loan_facility__c: string;
    Via_loan_facility__c: boolean;
    WF_Loan_Entity__c: string;
    WF_Loan_Entity_Other__c: string;
    WFS_Prepare_a_Credit_Su__c: string;

    constructor(){
        this.Id = null;
        this.Name = null;
        this.Comments__c = null;
        this.Credit_Support_Comments__c = null;
        this.Date_of_Loan_Agreement__c = null;
        this.Documentation_to_prepare_a_guarantee__c = null;
        this.Does_Credit_Support_Annex_need_to_be_VM__c = null;
        this.Is_any_guarantor_a_trust__c = null;
        this.Legal_Name_of_Guarantor_s__c = null;
        this.Loan_Facility__c = null;
        this.Credit_Support_Comments_2__c = null;
        this.Will_Credit_Approval_require_derivative__c = null;
        this.Require_derivative_transaction__c = null;
        this.SPOQ_ID__c = null;
        this.SwapGuarantorVerification__c = null;
        this.Syndicated__c = '';
        this.Transaction_guaranteed_via_loan_facility__c = null;
        this.Via_loan_facility__c = false;
        this.WF_Loan_Entity__c = '';
        this.WF_Loan_Entity_Other__c = null;
        this.WFS_Prepare_a_Credit_Su__c = null;

    }
}