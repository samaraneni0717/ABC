import { User } from "src/app/Common/dynamic-form-services/dynamic-form.service";

export class COBAM_TaxDetailsInput {
    Id: string;
    Name: string;
    CreatedBy: string;
    LastModifiedBy: string;

    CASH_Lookup_Relation__c: string;
    Entity_Type__c: string;
    FXStaticDataTaxStatus__c: string;
    Is_a_Parent_build_needed__c: string;
    Is_CRS_Forms_Included__c: string;
    Is_Entity_disrega__c: string;
    Parent_Legal_Name__c: string;
    Parent_LEID__c: string;
    NonCASH_Lookup_Relation__c: string;
    TaxFormType__c: string;
    TaxRequestType__c: string;
    TaxReviewStatus__c: string;
    Time_Submitted__c: Date;
    PrimaryTaxOwner__c: string;
    PrimaryTaxOwner__r: User;
    SecondaryTaxOwner__c: string;
    SecondaryTaxOwner__r: User;
    W_8BEN__c: number;
    W_8BEN_E__c: number;
    W_8BEN_E_Chapter_4_Only__c: number;
    W_8ECI__c: number;
    W_8EXP__c: number;
    W_8IMY__c: number;
    W_9__c: number;
    IsModified: boolean;

    constructor() {
        this.Id = null;
        this.Name = null;
        this.CreatedBy = null;
        this.LastModifiedBy = null;

        this.CASH_Lookup_Relation__c = null;
        this.Entity_Type__c = null;
        this.FXStaticDataTaxStatus__c = null;
        this.Is_a_Parent_build_needed__c = null;
        this.Is_CRS_Forms_Included__c = null;
        this.Is_Entity_disrega__c = null;
        this.Parent_Legal_Name__c = null;
        this.Parent_LEID__c = null;
        this.NonCASH_Lookup_Relation__c = null;
        this.TaxFormType__c = null;
        this.TaxRequestType__c = null;
        this.TaxReviewStatus__c = null;
        this.Time_Submitted__c = null;
        this.PrimaryTaxOwner__c = null;
        this.PrimaryTaxOwner__r = null;
        this.SecondaryTaxOwner__c = null;
        this.SecondaryTaxOwner__r = null;
        this.W_8BEN__c = null;
        this.W_8BEN_E__c = null;
        this.W_8BEN_E_Chapter_4_Only__c = null;
        this.W_8ECI__c = null;
        this.W_8EXP__c = null;
        this.W_8IMY__c = null;
        this.W_9__c = null;
        this.IsModified = false;
    }

}