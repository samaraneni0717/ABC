export class SPOQ_CustomerContact {
    Id: string;
    Name: string;
    RecordType: string;
    RecordTypeName: string;
    Additional_Instructions__c: string;
    Address1__c: string;
    Address2__c: string;
    City__c: string;
    Contact_Name__c: string;
    Contact_Title__c: string;
    Contact_Type__c: string;
    Country__c: string;
    Email__c: string;
    Fax__c: string;
    Fx_Conf_Contact_Email__c: string;
    Fx_Conf_Contact_Name__c: string;
    FX_Confirmations__c: string;
    FX_Contact_Email_Address1__c: string;
    FX_Contact_Email_Address2__c: string;
    FX_Contact_Name_1__c: string;
    FX_Contact_Name_2__c: string;
    Phone__c: string;
    SPOQ_ID__c: string;
    State__c: string;
    Who_will_send_the_docs_to_the_customer__c: string;
    Zip__c: string;

    constructor(){
        this.Id = null;
        this.Name = null;
        this.RecordType = null;
        this.RecordTypeName = null;
        this.Additional_Instructions__c = null;
        this.Address1__c = null;
        this.Address2__c = null;
        this.City__c = null;
        this.Contact_Name__c = null;
        this.Contact_Title__c = null;
        this.Contact_Type__c = null;
        this.Country__c = null;
        this.Email__c = null;
        this.Fax__c = null;
        this.Fx_Conf_Contact_Email__c = null;
        this.Fx_Conf_Contact_Name__c = null;
        this.FX_Confirmations__c = null;
        this.FX_Contact_Email_Address1__c = null;
        this.FX_Contact_Email_Address2__c = null;
        this.FX_Contact_Name_1__c = null;
        this.FX_Contact_Name_2__c = null;
        this.Phone__c = null;
        this.SPOQ_ID__c = null;
        this.State__c = null;
        this.Who_will_send_the_docs_to_the_customer__c = null;
        this.Zip__c = null;
    }
}