import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { OnboardingRequestsService } from '../shared/onboarding-requests.service';
import { MatDialog } from '@angular/material';
import { FormGroup } from '@angular/forms';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { AgGrid } from 'src/app/Common/ag-grid/ag-grid.model';
import { IGetRowsParams, IDatasource, GridOptions, GridApi } from 'ag-grid-community';
import { CobamSearchInput } from '../../maintenance-requests/Models/CobamSearchInput';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AgGridLoadingOverlay } from 'src/app/Common/ag-grid/ag-grid-loading-overlay.component';
import { AgGridNoRowsOverlay } from 'src/app/Common/ag-grid/ag-grid-no-rows-overlay.component'

import { MaintenanceRequestsService } from '../../maintenance-requests/shared/services/mainteance-requests.service';
import { Subscription } from 'rxjs';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
    selector: 'app-onboarding-requests',
    templateUrl: './onboarding-requests.component.html',
    styleUrls: ['./onboarding-requests.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class OnboardingRequestComponent implements OnInit {
    gridApi: GridApi;
    defaultColDef = {
        sortable: true,
        resizable: true,
    };
    gridOptions: GridOptions = {
        pagination: true,
        rowModelType: 'infinite',
        cacheBlockSize: 100,
        paginationPageSize: 100,
        enableServerSideSorting: true,
        enableServerSideFilter: true,
    };
    sortValue = '';
    idlist = '';
    showAlert = false;

    obRequestForm: FormGroup;
    formFields: QuestionBase<any>[] = [];
    productType;
    productSubType;
    WFEntity;
    buildType;
    settlementType;
    productSettlementType: string;
    requestId;
    isProcessingRequest = false;
    columnDefs: any[] = [];
    rowData = [{}];
    AgGridApi;
    rowParams: IGetRowsParams;
    fileName = 'Onboarding';
    showDeleteButton = false;
    errorMessage: string;
    payLoad: any;
    onboardingRequestIds: any;
    onboardingRequestNumber: string;
    cobamSearchInput: CobamSearchInput;
    frameworkComponents = {
        agGridLoadingOverlay: AgGridLoadingOverlay,
        agGridNoRowsOverlay: AgGridNoRowsOverlay
    };
    loadingOverlayComponent = 'agGridLoadingOverlay';
    loadingOverlayComponentParams = { loadingMessage: 'Loading...' };
    noRowsOverlayComponent = 'agGridNoRowsOverlay';
    cobamRole: string = '';
    currentUserId: string = '';
    currentUserName: string = '';
    showOnboardingNewButton: boolean = false;
    private subscriptions: Subscription[] = [];
    
    constructor(private onboardingRequestsService: OnboardingRequestsService,
        private mrs: MaintenanceRequestsService,
        private dialog: MatDialog,
        private authservice: AuthService,
        private router: Router,
        private alertService: AlertService,
        private qcs: QuestionControlService) { }

    ngOnInit() {
        this.cobamSearchInput = this.assignDefaultValues();
        this.formFields = this.onboardingRequestsService.buildRequestFormFields();
        this.obRequestForm = this.qcs.toFormGroup(this.formFields);
        //ProductType
        //SettlementType

        // if(this.obRequestForm.get('ProductType')){
        //     this.subscriptions.push(
        //         this.obRequestForm.get('ProductType')
        //             .valueChanges.subscribe(() =>
        //                 this.setSettlementType()
        //             )
        //     );
        // };

        if(this.obRequestForm.get('SettlementType')){
            this.subscriptions.push(
                this.obRequestForm.get('SettlementType')
                    .valueChanges.subscribe(() =>
                        this.setProductSettlementType()
                    )
            );
        };

        // debugger
        // this.onboardingRequestsService.getCurrentUser().subscribe(data => {
        //     if (data) {
        //         debugger
        //         this.currentUserId = data.Id;
        //         this.currentUserName = data.Name;
        //         this.cobamRole = data.COBAM_Role__c;
        //     }
        // });
        
        this.onboardingRequestsService.getColumnDefinations().subscribe(response => {
            this.columnDefs = [{
                headerName: '',
                checkboxSelection: true,
                width: 30,
                suppressMenu: true,
                suppressFilter: true,
                filter: false,
            }];
            if (response && (response as any).columnDefs) {
                ((response as any).columnDefs as any[]).forEach(column => {
                    console.log(column);
                    this.columnDefs.push(AgGrid.LoadColumnDefinition(column)[0]);
                });
            }
        });
    }
    setSettlementType(){
        if (this.obRequestForm.controls['ProductType'] && this.obRequestForm.controls['ProductType'].value !== '') {
            switch (this.obRequestForm.controls['ProductType'].value) {
                case 'Fixed Income':
                    this.obRequestForm.controls['SettlementType'].setValue('Regular');
                    break;
                case 'Equities':
                    this.obRequestForm.controls['SettlementType'].setValue('Regular');
                    break;
                case 'Prime':
                case 'FCM':
                case 'Agency':
                case 'Swaps':
                case 'FX':
                    this.obRequestForm.controls['SettlementType'].setValue('');
                    break;
                case 'Loan Sales':
                    this.obRequestForm.controls['SettlementType'].setValue('Extended');
                    break;
            }
        }
    }
    setProductSettlementType() {
        if (this.obRequestForm.controls['ProductType'] && this.obRequestForm.controls['ProductType'].value !== '') {
            switch (this.obRequestForm.controls['ProductType'].value) {
                case 'Fixed Income':
                    switch (this.obRequestForm.controls['SettlementType'].value) {
                        case 'Regular':
                            this.obRequestForm.controls['ProductSettlementType'].setValue('Fixed IncomeRegular');
                            break;
                        case 'Extended':
                            this.obRequestForm.controls['ProductSettlementType'].setValue('Fixed IncomeExtended');
                            break;
                        default:
                            this.obRequestForm.controls['ProductSettlementType'].setValue('Fixed Income');
                            break;
                    }
                    break;
                case 'Equities':
                    // switch (this.obRequestForm.controls['SettlementType'].value) {
                    //     case 'Regular':
                    //         this.obRequestForm.controls['ProductSettlementType'].setValue('EquitiesRegular');
                    //         break;
                    //     default:
                    //         this.obRequestForm.controls['ProductSettlementType'].setValue('Equities');
                    //         break;
                    // }
                    this.obRequestForm.controls['ProductSettlementType'].setValue('EquitiesRegular');
                    break;
                case 'Prime':
                    this.obRequestForm.controls['ProductSettlementType'].setValue('Prime');
                    break;
                case 'FCM':
                    this.obRequestForm.controls['ProductSettlementType'].setValue('FCM');
                    break;
                case 'Agency':
                    this.obRequestForm.controls['ProductSettlementType'].setValue('Agency');
                    break;
                case 'Loan Sales':
                    // switch (this.obRequestForm.controls['SettlementType'].value) {
                    //     case 'Extended':
                    //         this.obRequestForm.controls['ProductSettlementType'].setValue('Loan SalesExtended');
                    //         break;
                    //     default:
                    //         this.obRequestForm.controls['ProductSettlementType'].setValue('Loan SalesExtended');
                    //         break;
                    // }
                    this.obRequestForm.controls['ProductSettlementType'].setValue('Loan SalesExtended');
                    break;
                case 'Swaps':
                    this.obRequestForm.controls['ProductSettlementType'].setValue('Swaps');
                    break;
            }
        }
    }

    noRowsOverlayComponentParams = {
        noRowsMessageFunc: function () {
            return '';
        }
    };

    onSelectionChanged(event) {
        if (event.api.getSelectedNodes().length > 0) {
            this.onboardingRequestIds = '';
            this.onboardingRequestNumber = '';
            event.api.getSelectedNodes().forEach(element => {
                this.onboardingRequestIds += element.data.Id + ',';
                this.onboardingRequestNumber += element.data.Name + ', ';
            });
            this.onboardingRequestIds = this.onboardingRequestIds.substring(0, this.onboardingRequestIds.length - 1);
            this.onboardingRequestNumber = this.onboardingRequestNumber.substring(0, this.onboardingRequestNumber.length - 2);
            this.showDeleteButton = false;
        } else {
            this.showDeleteButton = false;
        }
    }

    dataSource: IDatasource = {
        getRows: (params: IGetRowsParams) => {
            this.gridApi.showLoadingOverlay();
            //debugger
            if(sessionStorage.getItem('COBAM_Role')){
                this.apiService(params).subscribe(response => {
                    if (!(sessionStorage.getItem('COBAM_Role') === 'Requester'
                        || sessionStorage.getItem('COBAM_Role') === 'Requester NonCash'
                        || sessionStorage.getItem('COBAM_Role') === 'Tax Profile I'
                        || sessionStorage.getItem('COBAM_Role') === 'APAC Markets Compliance'
                        || sessionStorage.getItem('COBAM_Role') === 'Account Approval'
                        || sessionStorage.getItem('COBAM_Role') === 'AML EDD'
                        || sessionStorage.getItem('COBAM_Role') === 'AML KYC'
                        || sessionStorage.getItem('COBAM_Role') === 'Client Services'
                        || sessionStorage.getItem('COBAM_Role') === 'DCOT'
                        || sessionStorage.getItem('COBAM_Role') === 'Facilitator'
                        || sessionStorage.getItem('COBAM_Role') === 'Facilitator Manager'
                    )) {
                        
                        this.router.navigate(['notauthorized']);
                    }
                    if (sessionStorage.getItem('COBAM_Role') === 'Requester'
                        || sessionStorage.getItem('COBAM_Role') === 'Requester NonCash'
                        || sessionStorage.getItem('COBAM_Role') === 'DCOT'){
                            //commented for now
                            //this.showOnboardingNewButton = true;
                    }
                    console.log(response['requests']);
                    params.successCallback(
                        response['requests'] as any[],
                        null
                    );
                    this.gridApi.hideOverlay();
                },
                    error => {
                        console.error(error);
                        this.alertService.clear();
                        this.alertService.warn(
                            'Not able to communicate with Service Please try Again'
                        );
                    }
                );
            }
            else {
                this.onboardingRequestsService.getCurrentUser().subscribe(data => {
                    //debugger
                    if (data) {
                        sessionStorage.setItem('COBAM_Role', data.COBAM_Role__c);
                        if(sessionStorage.getItem('COBAM_Role')){
                            if (!(sessionStorage.getItem('COBAM_Role') === 'Requester'
                                || sessionStorage.getItem('COBAM_Role') === 'Requester NonCash'
                                || sessionStorage.getItem('COBAM_Role') === 'Tax Profile I'
                                || sessionStorage.getItem('COBAM_Role') === 'APAC Markets Compliance'
                                || sessionStorage.getItem('COBAM_Role') === 'Account Approval'
                                || sessionStorage.getItem('COBAM_Role') === 'AML EDD'
                                || sessionStorage.getItem('COBAM_Role') === 'AML KYC'
                                || sessionStorage.getItem('COBAM_Role') === 'Client Services'
                                || sessionStorage.getItem('COBAM_Role') === 'DCOT'
                                || sessionStorage.getItem('COBAM_Role') === 'Facilitator'
                                || sessionStorage.getItem('COBAM_Role') === 'Facilitator Manager'
                            )) {

                                this.router.navigate(['notauthorized']);
                            }
                            if (sessionStorage.getItem('COBAM_Role') === 'Requester'
                                || sessionStorage.getItem('COBAM_Role') === 'Requester NonCash'
                                || sessionStorage.getItem('COBAM_Role') === 'DCOT'){
                                    //commented for now
                                    //this.showOnboardingNewButton = true;
                            }
                            this.apiService(params).subscribe(response => {
                                params.successCallback(
                                    response['requests'] as any[],
                                    null
                                );
                                this.gridApi.hideOverlay();
                            },
                                error => {
                                    console.error(error);
                                    this.alertService.clear();
                                    this.alertService.warn(
                                        'Not able to communicate with Service Please try Again'
                                    );
                                }
                            );
                        }
                    }
                });

            }
        }
    };

    isRowSelectable(rowNode) {
        const aa = rowNode.data ? rowNode.data.Status__c === 'Draft' : false;
        return aa;
    }

    assignDefaultValues(): CobamSearchInput {
        const cobamObj = new CobamSearchInput();
        cobamObj.SortedList = '';
        cobamObj.SearchText = '';
        return cobamObj;
    }
    apiService(params) {
        //debugger
        if (params.sortModel.length > 0) {
            params.sortModel.forEach(item => this.sortValue = this.sortValue + item.colId + ' ' + item.sort + ' NULLS LAST' + ',');
        }
        this.cobamSearchInput.SortedList = this.sortValue.substring(0, this.sortValue.length - 1);
        this.cobamSearchInput.SearchText = params.filterModel;
        this.cobamSearchInput.PageSize = 100;
        this.cobamSearchInput.Endrow = params.endRow;
        this.payLoad = JSON.parse(JSON.stringify(this.cobamSearchInput));
        console.log(this.payLoad);
        return this.onboardingRequestsService.getRequests(this.payLoad);
    }
    onRowDoubleClicked(event: any) {
        if ((sessionStorage.getItem('COBAM_Role') === 'Requester'
            || sessionStorage.getItem('COBAM_Role') === 'Requester NonCash')) {
            if (event.data.Client_Build_Request__c) {
                window.open(this.authservice.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_Onboarding_Request_Edit&id=' + event.data.Client_Build_Request__c, '_blank')
            }
            else if (event.data.SPOQ_DocumentationRequest__c) {
                window.open(this.authservice.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_Onboarding_Request_Edit&id=' + event.data.SPOQ_DocumentationRequest__c, '_blank')
            }
        }
        else if (sessionStorage.getItem('COBAM_Role') === 'Tax Profile I'
            || sessionStorage.getItem('COBAM_Role') === 'APAC Markets Compliance'
            || sessionStorage.getItem('COBAM_Role') === 'Account Approval'
            || sessionStorage.getItem('COBAM_Role') === 'AML EDD'
            || sessionStorage.getItem('COBAM_Role') === 'AML KYC'
            || sessionStorage.getItem('COBAM_Role') === 'Client Services'
            || sessionStorage.getItem('COBAM_Role') === 'DCOT'
            || sessionStorage.getItem('COBAM_Role') === 'Facilitator'
            || sessionStorage.getItem('COBAM_Role') === 'Facilitator Manager'
        ) {

            if (event.data.Client_Build_Request__c) {
                window.open(this.authservice.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_Edit&id=' + event.data.Client_Build_Request__c, '_blank')
            }
            else if (event.data.SPOQ_DocumentationRequest__c) {
                window.open(this.authservice.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_SPOQ_Request&id=' + event.data.SPOQ_DocumentationRequest__c, '_blank')
            }
        }
    }
    onGridReady(params: any) {
        this.gridApi = params.api;
        this.gridApi.sizeColumnsToFit();
        this.gridApi.setDatasource(this.dataSource);
    }

    Deleterow() {
        alert('DeleteRow');
    }
    closeErrorMsg() {
        this.showAlert = false;
    }
    onExport() {
        const params = {
            fileName: this.fileName + '.csv'
        };
        this.gridApi.exportDataAsCsv(params);
    }

    openModal(template): void {
        this.resetForm();
        const dialogRef = this.dialog.open(template, {
            width: '40%',
            height: '45%',
            disableClose: true
        });
    }

    resetForm(){
        Object.keys(this.obRequestForm.controls).forEach(item => {
            switch (item) {
                case 'BuildType':
                case 'WFEntity':
                case 'ProductType':
                case 'SettlementType':
                case 'ProductSettlementType':
                case 'ProductSubType':
                    this.obRequestForm.controls[item].setValue('');
                break;
            }
        });
    }

    onModalClose() {
        this.resetForm();
        this.dialog.closeAll();
    }

    continueClick(onboardingtemplate: any, value: any) {
        Object.keys(this.obRequestForm.controls).forEach(prop => {
            switch (prop) {
                case 'ProductType':
                    this.productType = this.obRequestForm.controls[prop].value;
                    break;
                case 'ProductSubType':
                    if(Array.isArray(this.obRequestForm.controls[prop].value)){
                        this.productSubType = this.obRequestForm.controls[prop].value.join(';');
                    }
                    else{
                        this.productSubType = this.obRequestForm.controls[prop].value;
                    }
                    break;
                case 'WFEntity':
                    this.WFEntity = this.obRequestForm.controls[prop].value.join(';');
                    break;
                case 'BuildType':
                    this.buildType = this.obRequestForm.controls[prop].value;
                    break;
                case 'SettlementType':
                    this.settlementType = this.obRequestForm.controls[prop].value;
                    break;
                case 'ProductSettlementType':
                    this.productSettlementType = this.obRequestForm.controls[prop].value;
                    break;
            }
        });
        const dialogRef = this.dialog.open(onboardingtemplate, {
            width: '98%',
            height: '90%',
            maxWidth: '100%',
            disableClose: true
        });
    }

    multiSelectionHandler(event) {
        if (event['controlName'] === 'WFEntity') {
            if (event.value.length < 6) {
                if (event.value.filter(x => x === 'WFSAL').length === 1 &&
                    event.value.length > 1 && (
                        event.value.filter(x => x === 'WFSJ').length === 1 ||
                        event.value.filter(x => x === 'WFSLLC - Singapore Branch').length === 1 ||
                        event.value.filter(x => x === 'WFBI').length === 1 ||
                        event.value.filter(x => x === 'WFSC LTD').length === 1 ||
                        event.value.filter(x => x === 'WFS Prime Services').length === 1 ||
                        event.value.filter(x => x === 'WFBNA - Canada Branch').length === 1)
                ) {
                    alert('The multiple selection made is not a valid combination. Please select a valid WFS Entity');
                    this.obRequestForm.get('WFEntity').setValue(null);
                }
                else if (
                    event.value.length > 2 &&
                    event.value.filter(x => x === 'WFSLLC - US').length === 1 &&
                    event.value.filter(x => x === 'WFBNA - US').length === 1
                ) {
                    alert('You can select only two values WFSLLC - US and WFBNA - US');
                    this.obRequestForm.get('WFEntity').setValue(null);
                } else if (
                    event.value.length > 1 &&
                    !(
                        (event.value.filter(x => x === 'WFSLLC - US').length === 1 &&
                            event.value.filter(x => x === 'WFBNA - US').length === 1) ||
                        event.value.filter(x => x === 'WFSAL').length === 1
                    )
                ) {
                    alert('Please select only one value');
                    this.obRequestForm.get('WFEntity').setValue(null);
                }
            } else {
                alert('The multiple selection made is not a valid combination. The only combination allowed is WFSLLC-US and WFBNA-US.Please select a valid WFS Entity');
                this.obRequestForm.get('WFEntity').setValue(null);
            }
        }
        else if (event['controlName'] === 'ProductSubType') {
            if (event.value.length > 1) {
                if (event.value.filter(x => x === 'CDS Single Name').length === 1 &&
                    event.value.filter(x => x === 'CDS Index (SEF)').length === 0 &&
                    event.value.length > 1
                ) {
                    alert('You cannot select Interest Rates, Commodity, FX/Cross Currency and CDS Single Name');
                    this.obRequestForm.get('ProductSubType').setValue(null);
                }
                else if (event.value.filter(x => x === 'CDS Single Name').length === 0 &&
                    event.value.filter(x => x === 'CDS Index (SEF)').length === 1 &&
                    event.value.length > 1
                ) {
                    alert('You cannot select Interest Rates, Commodity, FX/Cross Currency and CDS Index (SEF)');
                    this.obRequestForm.get('ProductSubType').setValue(null);
                }
                else if ((event.value.filter(x => x === 'CDS Single Name').length === 1 ||
                    event.value.filter(x => x === 'CDS Index (SEF)').length === 1) &&
                    event.value.length > 1
                ) {
                    alert('You cannot select CDS Single Name and CDS Index (SEF)');
                    this.obRequestForm.get('ProductSubType').setValue(null);
                }
            }
        }
    }

    disableContinue() {
        
        if (this.obRequestForm.get('ProductType').value != '' &&
            this.obRequestForm.get('ProductType').value != null &&
            this.obRequestForm.get('WFEntity').value != '' &&
            this.obRequestForm.get('WFEntity').value != null &&
            this.obRequestForm.get('BuildType').value != '' &&
            this.obRequestForm.get('BuildType').value != null) {
            if (this.obRequestForm.get('ProductType').value === 'Agency' ||
                this.obRequestForm.get('ProductType').value === 'FX') {
                return false;
            }
            else if(this.obRequestForm.get('ProductType').value === 'Loan Sales' && (this.obRequestForm.get('SettlementType').value != null && this.obRequestForm.get('SettlementType').value != '')){
                return false;
            }
            else {
                if (this.obRequestForm.get('ProductSubType').value != '' &&
                    this.obRequestForm.get('ProductSubType').value != null &&
                    this.obRequestForm.get('ProductSubType').value != '-- Please Select --') {
                    return false;
                }
                else {
                    return true;
                }
            }
        }
        else {
            return true;
        }
    }

    onOptionsDropDownSelectionChange(fieldName) {
        if (fieldName === 'ProductType') {
            switch (this.obRequestForm.get('ProductType').value) {
                case 'Fixed Income':
                    switch (this.obRequestForm.get('SettlementType').value) {
                        case 'Regular':
                            this.obRequestForm.get('ProductSettlementType').setValue('Fixed IncomeRegular');
                            this.obRequestForm.get('SettlementType').setValue('Regular');
                            break;
                        case 'Extended':
                            this.obRequestForm.get('ProductSettlementType').setValue('Fixed IncomeExtended');
                            this.obRequestForm.get('SettlementType').setValue('Extended');
                            break;
                        default:
                            this.obRequestForm.get('ProductSettlementType').setValue('Fixed IncomeRegular');
                            this.obRequestForm.get('SettlementType').setValue('Regular');
                            break;
                    }

                    this.obRequestForm.get('ProductSubType').setValue('');
                    break;
                case 'Equities':
                    this.obRequestForm.get('ProductSettlementType').setValue('EquitiesRegular');
                    this.obRequestForm.get('SettlementType').setValue('Regular');
                    this.obRequestForm.get('ProductSubType').setValue('');
                    break;
                
                case 'Prime':
                    this.obRequestForm.get('ProductSettlementType').setValue('Prime');
                    this.obRequestForm.get('SettlementType').setValue(null);
                    break;
                case 'FCM':
                    this.obRequestForm.get('ProductSettlementType').setValue('FCM');
                    this.obRequestForm.get('SettlementType').setValue(null);
                    break;
                case 'Agency':
                    this.obRequestForm.get('ProductSettlementType').setValue('Agency');
                    this.obRequestForm.get('SettlementType').setValue(null);
                    break;
                case 'Loan Sales':
                    this.obRequestForm.controls['SettlementType'].setValue('Extended');
                    this.obRequestForm.get('ProductSubType').setValue(null);
                    break;
                case 'Swaps':
                    this.obRequestForm.get('ProductSettlementType').setValue('Swaps');
                    this.obRequestForm.get('SettlementType').setValue(null);
                    break;
                case 'FX':
                case '':
                    this.obRequestForm.get('ProductSettlementType').setValue(null);
                    this.obRequestForm.get('SettlementType').setValue(null);
                    break;
            }
        }
    }

    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
        this.subscriptions = [];
    }
}



