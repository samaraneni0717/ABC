import {
    Component,
    OnInit,
    ViewEncapsulation,
    Input,
    ChangeDetectorRef
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { MatDialog } from '@angular/material';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { SPOQ_DocumentationRequest } from '../Models/spoq_DocumentationRequest';
import { MultiselectQuestion } from 'src/app/Common/dynamic-form-models/question-multiselect';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { OptionsInlineQuestion } from 'src/app/Common/dynamic-form-models/Question-OptionsInline';


@Component({
    selector: 'app-onboarding-documentation-request',
    templateUrl: './onboarding-documentation-request.component.html',
    styleUrls: ['./onboarding-documentation-request.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class DocumentationRequestComponent implements OnInit {
    @Input() productType: string = '';
    @Input() productSubtype: string = '';
    spoq_DocumentationRequest: SPOQ_DocumentationRequest;

    documentationRequestFormFields: QuestionBase<any>[] = [];
    documentationRequestForm: FormGroup;
    fxDocumentationRequestFormFields: QuestionBase<any>[] = [];
    fxDocumentationRequestForm: FormGroup;
    onboardingRole: string;

    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private authService: AuthService,
        private cdRef: ChangeDetectorRef) {

    }

    ngOnInit(): void {
        //debugger
        //alert('DocumentationRequestComponent ngOnInit');
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.spoq_DocumentationRequest = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r;
        this.BuildPage();
    }

    BuildPage() {
        //debugger
        this.documentationRequestFormFields = this.onboardingDetailRequestService.buildDocumentationRequestFields(this.onboardingRole);
        this.documentationRequestForm = this.qcs.toFormGroup(this.documentationRequestFormFields);

        if (this.productType === 'FX') {
            this.fxDocumentationRequestFormFields = this.onboardingDetailRequestService.buildFXDocumentationRequestFields(this.onboardingRole);
            this.fxDocumentationRequestForm = this.qcs.toFormGroup(this.fxDocumentationRequestFormFields);
        }

        this.cdRef.detectChanges();

        for (const prop of Object.keys(this.spoq_DocumentationRequest)) {
            if (this.documentationRequestForm.controls[prop]) {
                this.documentationRequestForm.controls[prop].setValue(this.spoq_DocumentationRequest[prop]);
            } else if (this.productType === 'FX' && this.fxDocumentationRequestForm.controls[prop]) {
                this.fxDocumentationRequestForm.controls[prop].setValue(this.spoq_DocumentationRequest[prop]);
            }
        }

        // if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CustomerType__c 
        //     && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CustomerType__c === 'Wealth Management/Wealth Brokerage Retirement'){

        //     (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Wealth_FA_disclosure_form_required__c')[0] as OptionsInlineQuestion).mandatory = true;
        // }
        // else{
        //     (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Wealth_FA_disclosure_form_required__c')[0] as OptionsInlineQuestion).mandatory = false;
        // }

        if (this.productType === 'FX' && this.fxDocumentationRequestForm.controls['Country_and_Licensing__c']) {
            let enableCountryAndLicensing = false;
            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.forEach(element => {
                if (element.Country_Organized__c !== 'US - UNITED STATES') {
                    enableCountryAndLicensing = true;
                }
            });

            if (enableCountryAndLicensing) {
                this.fxDocumentationRequestForm.controls['Country_and_Licensing__c'].enable();
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Country_and_Licensing__c')[0] as DropdownQuestion).mandatory = true;
            } else {
                this.fxDocumentationRequestForm.controls['Country_and_Licensing__c'].disable();
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Country_and_Licensing__c')[0] as DropdownQuestion).mandatory = false;
            }

            this.onFXSpecificProductChange(this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui']);
            this.renderMasterAgreementType();
        }
        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
            case 'Account Approval':
            case 'FX Static Data':
            case 'FXOL':
            case 'Client Services':
            case 'Tax Profile I':
            case 'AML EDD':
            case 'AML KYC':
                this.DisableDocumentationRequestDetailsSection();
                if (this.productType === 'FX') {
                    this.DisableFXDocumentationRequestDetailsSection();
                }
                break;
            default:
                break;
        }
    }
    DisableFXDocumentationRequestDetailsSection() {
        const filteredFields = this.fxDocumentationRequestFormFields.filter(f => f.section && f.section === 'FXDocumentationRequestDetails');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.fxDocumentationRequestForm.controls[element.key]) {
                    this.fxDocumentationRequestForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableDocumentationRequestDetailsSection() {
        const filteredFields = this.documentationRequestFormFields.filter(f => f.section && f.section === 'DocumentationRequestDetails');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.documentationRequestForm.controls[element.key]) {
                    this.documentationRequestForm.controls[element.key].disable();
                }
            });
        }
    }
    openSearchModal(template, legalTemplate, cobamLookupTemplate, value: string): void {
    }

    onOptionsinlineSelectionChange(value: string) {
        switch (value) {
            case 'IsCustPooledInvestment__c':
                if (!this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].value) && this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].value === 'Yes') {
                    if (!this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value) && this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value === 'FX Master Agreement') {
                        alert('FX Master Agreement cannot be selected when a customer is a Pooled Investment Vehicle, Financial Institution, Gov\'t or Gov\'t owned entity or Highly Regulated/ Other non-traditional entity type');
                        this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].setValue(null);
                    }
                }
                else if (!this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].value) && this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].value === 'No') {
                    alert('Please note: There may be a delay in processing the document request if the customer is deemed to be one of these entity types.');
                }
                break;
            case 'Will_collateral_be_required_for_FX_trade__c':
                this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].setValue(null);
                this.renderMasterAgreementType();
                break;
            default:
                break;
        }
    }

    onOptionsDropDownSelectionChange(fieldName: string) {
        if (fieldName === 'Type_of_Documentation_Request__c') {
            switch (this.documentationRequestForm.controls['Type_of_Documentation_Request__c'].value) {
                case 'Amendment to Existing Agreement':
                    alert("Selecting this option will prompt a request for review of the existing agreement as well as a Hedge Review of any new or modified loan and/or credit support documentation.");
                    break;
                case 'FX Agreement':
                    alert("For requests for an FX Agreement, please contact fxstaticdata@wellsfargo.com");
                    break;
                case 'Hedge Review Only - No Documentation Requested':
                    alert("Select this option only if there is an existing trading agreement in place with the Customer and you do not anticipate putting a new trading agreement in place (or amending an existing agreement).");
                    break;
                case 'Rate Management Agreement':
                    alert("Upon submission of this form, contact your loan center to request documentation of the Rate Management Agreement");
                    break;
                default:
                    break;
            }
        } else if (fieldName === 'Master_Agreement_Type__c') {
            if (this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'] &&
                (this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value)
                    || this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value !== 'FX Master Agreement')) {

                this.fxDocumentationRequestForm.controls['FX_Master_Agreement_Type__ui'].setValue('');
                this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Master_Agreement_Type__ui')[0].disabled = true;
            } else {
                this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Master_Agreement_Type__ui')[0].disabled = false;
                this.onFXSpecificProductChange(this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui']);

                if (!this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].value) && this.fxDocumentationRequestForm.controls['IsCustPooledInvestment__c'].value === 'Yes') {
                    alert('FX Master Agreement cannot be selected when a customer is a Pooled Investment Vehicle, Financial Institution, Gov\'t or Gov\'t owned entity or Highly Regulated/ Other non-traditional entity type');
                    this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].setValue(null);
                }
            }
        }

    }

    multiSelectionHandler(event) {
        if (event['controlName'] === 'FX_Specific_Products__ui') {
            this.onFXSpecificProductChange(event);
            this.renderMasterAgreementType();
        } else if (event['controlName'] === 'FX_Specific_Currencies__c') {
            if (this.fxDocumentationRequestForm.controls['FX_Specific_Currencies__c'].value && this.fxDocumentationRequestForm.controls['FX_Specific_Currencies__c'].value.includes('Chinese RMB')) {
                if (!Array.isArray(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value) && this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value)) {
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(['RMB Onshore letter']);
                }
                else if (Array.isArray(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value) && !this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value.includes('RMB Onshore letter')) {
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value.push('RMB Onshore letter');
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value);
                }
            }
        }
    }

    onFXSpecificProductChange(event) {
        //this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].setValue('');
        if (event.value && event.value.filter(i => i === 'FX Online').length > 0) {
            //if(this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value && this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Online')){
            if (this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c']
                && this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value
                && this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value === 'FX Master Agreement') {

                // if(!this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value){
                //     this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue([]);
                // }
                // this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(arr);

                if (Array.isArray(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value) && !this.fxDocumentationRequestForm.controls['FX_Specific_Currencies__c'].value.includes('FXOL Service Description')) {
                    //this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value.push('FXOL Service Description'));
                    //this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(arr);
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value.push('FXOL Service Description');
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value);
                }
                else {
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(['FXOL Service Description']);
                }

                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Standalone')[0].disableOption = true;
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Service Description')[0].disableOption = true;
            }
            else {
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Standalone')[0].disableOption = false;
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Service Description')[0].disableOption = false;
            }
        }
        else {
            this.fxDocumentationRequestForm.controls['Is_FXOL_Client__c'].setValue(null);
            if (this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c']
                && this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value) {

                if (this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value.filter(a => a === 'FXOL Service Description')) {
                    this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].setValue(this.fxDocumentationRequestForm.controls['FX_Service_Product_Specific_Agreements__c'].value.filter(a => a !== 'FXOL Service Description'));
                }
                //(this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options[0].disableOption = false;
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Service Description')[0].disableOption = false;

                if (this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c']
                    && this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value
                    && this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].value === 'FX Master Agreement') {

                    (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Standalone')[0].disableOption = true;
                }
                else {
                    (this.fxDocumentationRequestFormFields.filter(f => f.key === 'FX_Service_Product_Specific_Agreements__c')[0] as MultiselectQuestion).options.filter(v => v.key === 'FXOL Standalone')[0].disableOption = false;
                }
            }
        }

        if (!this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value)
            && this.onboardingDetailRequestService.isFieldEmpty(this.spoq_DocumentationRequest.MiFID_II_Client_Categorization__c) &&
            (this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX EYD') ||
                this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Forward') ||
                this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX NDF') ||
                this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Option') ||
                this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Swap') ||
                this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Window Forward')
            )) {
            if (this.spoq_DocumentationRequest.Build_Type__c === 'New Legal & Bus Acc' &&
                (
                    (!this.onboardingDetailRequestService.isFieldEmpty(this.spoq_DocumentationRequest.WFS_Entity__c)
                        && (this.spoq_DocumentationRequest.WFS_Entity__c.includes('WFSIL')
                            || this.spoq_DocumentationRequest.WFS_Entity__c.includes('WFBNA - LB')))
                    || ((!this.onboardingDetailRequestService.isFieldEmpty(this.spoq_DocumentationRequest.WFS_Entity__c)
                        && this.spoq_DocumentationRequest.WFS_Entity__c.includes('WFBNA - US'))
                        && (this.spoq_DocumentationRequest.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer').length > 0 && (this.spoq_DocumentationRequest.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0].Branch_Location__c === 'LONDON' || this.spoq_DocumentationRequest.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0].Branch_Location__c === 'DUBLIN'))
                    )
                )) {

                alert('Please update the MIFID Client II Categorization in Request Details Tab');
            }
        }
    }

    renderMasterAgreementType() {
        //debugger
        var fxMasterAgreementoption: { key: string, value: string, parentKey: string };
        fxMasterAgreementoption = { key: 'FX Master Agreement', value: 'FX Master Agreement', parentKey: '' };

        if (!this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.length > 0) {
            this.fxDocumentationRequestForm.controls['Master_Agreement_Type__c'].setValue('');
            //this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = true;
            //this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = false;
        }
        else if (this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX EYD') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Forward *') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX NDF *') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Offshore Time Deposit *') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Option **') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Spot') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Swap *') ||
            this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Window Forward *')
        ) {
            if ((this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.filter(o => o.key === 'FX Master Agreement').length <= 0) {
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options = (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.concat(fxMasterAgreementoption);
                (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.sort((a, b): number => {
                    if (a.key < b.key) return -1;
                    if (a.key > b.key) return 1;
                    return 0;
                });
            }

            this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
            this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;

            if (this.fxDocumentationRequestForm.controls['Will_collateral_be_required_for_FX_trade__c'] && !this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['Will_collateral_be_required_for_FX_trade__c'].value)
                && this.fxDocumentationRequestForm.controls['Will_collateral_be_required_for_FX_trade__c'].value === 'No') {

                if (this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Forward *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Swap *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Window Forward *')) {

                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;
                }
                if (this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX NDF *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Option **')) {

                    (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options = (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.filter(o => o.key !== 'FX Master Agreement');
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;
                }

                if (!(this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Forward')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Swap')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Window Forward')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX NDF')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Option'))) {

                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;
                }

            }
            else if (this.fxDocumentationRequestForm.controls['Will_collateral_be_required_for_FX_trade__c'] && !this.onboardingDetailRequestService.isFieldEmpty(this.fxDocumentationRequestForm.controls['Will_collateral_be_required_for_FX_trade__c'].value)
                && this.fxDocumentationRequestForm.controls['Will_collateral_be_required_for_FX_trade__c'].value === 'Yes') {

                if (this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Forward *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Swap *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Window Forward *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX NDF *')
                    || this.fxDocumentationRequestForm.controls['FX_Specific_Products__ui'].value.includes('FX Option **')) {

                    (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options = (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.filter(o => o.key !== 'FX Master Agreement');
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;
                }
                else {
                    if ((this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.filter(o => o.key === 'FX Master Agreement').length <= 0) {
                        (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options = (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.concat(fxMasterAgreementoption);
                        (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.sort((a, b): number => {
                            if (a.key < b.key) return -1;
                            if (a.key > b.key) return 1;
                            return 0;
                        });
                    }

                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
                    this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;
                }
            }
            else {
                if ((this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.filter(o => o.key === 'FX Master Agreement').length <= 0) {
                    (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options = (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.concat(fxMasterAgreementoption);
                    (this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0] as DropdownQuestion).options.sort((a, b): number => {
                        if (a.key < b.key) return -1;
                        if (a.key > b.key) return 1;
                        return 0;
                    });
                }
                this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].disabled = false;
                this.fxDocumentationRequestFormFields.filter(f => f.key === 'Master_Agreement_Type__c')[0].mandatory = true;
            }
        }
    }
}