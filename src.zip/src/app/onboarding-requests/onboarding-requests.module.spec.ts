import { OnboardingRequestsModule } from './onboarding-requests.module';

describe('OnboardingRequestsModule', () => {
  let onboardingRequestsModule: OnboardingRequestsModule;

  beforeEach(() => {
    onboardingRequestsModule = new OnboardingRequestsModule();
  });

  it('should create an instance', () => {
    expect(onboardingRequestsModule).toBeTruthy();
  });
});
