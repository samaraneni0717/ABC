import { Component, OnInit } from '@angular/core';
import { OnboardingRequestService } from '../shared/onboarding-request.service';
import { OnboardingRequest } from '../shared/onboarding-request.model';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-submitted-request',
    templateUrl: './submitted-request.component.html',
    styleUrls: ['./submitted-request.component.css']
})

export class SubmittedRequestComponent implements OnInit {
    reqType: any;
    // tslint:disable-next-line:max-line-length
    constructor(public onboardingRequestService: OnboardingRequestService, private toastr: ToastrService, private route: ActivatedRoute, ) {

    }

    ngOnInit() {
        this.onboardingRequestService.getOnboardingRequestList('submitted');
    }

    showForEdit(request: OnboardingRequest) {
        this.onboardingRequestService.selectedOnboardingRequest = Object.assign({}, request);
    }


    onDelete(id: string) {
        if (confirm('Are you sure to delete this record ?') === true) {
            this.onboardingRequestService.deleteOnboardingRequest(id)
                .subscribe(x => {
                    this.onboardingRequestService.getOnboardingRequestList('submitted');
                    this.toastr.warning('Deleted Successfully', 'Onboarding Request');
                });
        }
    }
}



