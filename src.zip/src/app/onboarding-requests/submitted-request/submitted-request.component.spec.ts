import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmittedRequestComponent } from './submitted-request.component';

describe('SubmittedRequestComponent', () => {
  let component: SubmittedRequestComponent;
  let fixture: ComponentFixture<SubmittedRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmittedRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmittedRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
