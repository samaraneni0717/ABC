import {
    Component,
    OnInit,
    ViewEncapsulation,
    ChangeDetectorRef
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { SPOQ_FX_eChannels } from '../Models/spoq_FX_eChannels';


@Component({
    selector: 'app-onboarding-echannels',
    templateUrl: './onboarding-echannels.component.html',
    styleUrls: ['./onboarding-echannels.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class EChannelsComponent implements OnInit {
    spoq_FX_eChannels: SPOQ_FX_eChannels;

    eChannelsFormFields: QuestionBase<any>[] = [];
    eChannelsForm: FormGroup;
    onboardingRole: string;

    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private cdRef: ChangeDetectorRef) {

    }

    ngOnInit(): void {
        //debugger
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.spoq_FX_eChannels = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels;
        this.BuildPage();
    }

    BuildPage() {
        this.eChannelsFormFields = this.onboardingDetailRequestService.buildEChannelsFields(this.onboardingRole);
        this.eChannelsForm = this.qcs.toFormGroup(this.eChannelsFormFields);
        this.cdRef.detectChanges();
        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
            case 'Account Approval':
            case 'FX Static Data':
            case 'Client Services':
            case 'Tax Profile I':
            case 'AML EDD':
            case 'AML KYC':
                this.DisableEChannelsFieldsSection();
                break;
            default:
                break;
        }
        for (const prop of Object.keys(this.spoq_FX_eChannels)) {
            if (this.eChannelsForm.controls[prop]) {
                this.eChannelsForm.controls[prop].setValue(this.spoq_FX_eChannels[prop]);
            }
        }


    }

    DisableEChannelsFieldsSection() {
        const filteredFields = this.eChannelsFormFields.filter(f => f.section && f.section === 'EChannels');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.eChannelsForm.controls[element.key]) {
                    this.eChannelsForm.controls[element.key].disable();
                }
            });
        }
    }
}
