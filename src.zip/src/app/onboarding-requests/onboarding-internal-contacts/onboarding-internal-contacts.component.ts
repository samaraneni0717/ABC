import {
    Component,
    OnInit,
    ViewEncapsulation,
    Input
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { MatDialog } from '@angular/material';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { SPOQ_InternalContact } from '../Models/spoq_InternalContact';
import { CallbackRequestInput } from 'src/app/maintenance-requests/Models';

@Component({
    selector: 'app-onboarding-internal-contacts',
    templateUrl: './onboarding-internal-contacts.component.html',
    styleUrls: ['./onboarding-internal-contacts.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class InternalContactsComponent implements OnInit {
    @Input() productType: string = '';
    spoq_InternalContacts: SPOQ_InternalContact[] = [];

    internalContact_RelationshipManager_FormFields: QuestionBase<any>[] = [];
    internalContact_RelationshipManager_Form: FormGroup;

    internalContact_RelationshipAssociate_FormFields: QuestionBase<any>[] = [];
    internalContact_RelationshipAssociate_Form: FormGroup;

    internalContact_CreditOfficerUnderwriter_FormFields: QuestionBase<any>[] = [];
    internalContact_CreditOfficerUnderwriter_Form: FormGroup;

    internalContact_CrossSellReferral_FormFields: QuestionBase<any>[] = [];
    internalContact_CrossSellReferral_Form: FormGroup;

    internalContact_Marketer_FormFields: QuestionBase<any>[] = [];
    internalContact_Marketer_Form: FormGroup;

    internalContact_MarketerAssociateAnalyst_FormFields: QuestionBase<any>[] = [];
    internalContact_MarketerAssociateAnalyst_Form: FormGroup;

    internalContact_TreasuryManagementSalesConsultant_FormFields: QuestionBase<any>[] = [];
    internalContact_TreasuryManagementSalesConsultant_Form: FormGroup;

    internalContact_OLSSpecialist_FormFields: QuestionBase<any>[] = [];
    internalContact_OLSSpecialist_Form: FormGroup;

    internalContact_ITM_FormFields: QuestionBase<any>[] = [];
    internalContact_ITM_Form: FormGroup;

    internalContact_DoCOCPMGContact_FormFields: QuestionBase<any>[] = [];
    internalContact_DoCOCPMGContact_Form: FormGroup;

    searchTitle = '';
    searchDialogRef: any;
    onboardingRole: string;

    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private authService: AuthService){

    }

    ngOnInit(): void {
        //debugger
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.spoq_InternalContacts = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts;
        this.BuildPage();
    }

    BuildPage() {
        this.internalContact_RelationshipManager_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Relationship Manager');
        this.internalContact_RelationshipManager_Form = this.qcs.toFormGroup(this.internalContact_RelationshipManager_FormFields);

        this.internalContact_RelationshipAssociate_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Relationship Associate');
        this.internalContact_RelationshipAssociate_Form = this.qcs.toFormGroup(this.internalContact_RelationshipAssociate_FormFields);

        this.internalContact_CreditOfficerUnderwriter_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Credit Officer/Underwriter');
        this.internalContact_CreditOfficerUnderwriter_Form = this.qcs.toFormGroup(this.internalContact_CreditOfficerUnderwriter_FormFields);

        this.internalContact_CrossSellReferral_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Cross Sell Referral');
        this.internalContact_CrossSellReferral_Form = this.qcs.toFormGroup(this.internalContact_CrossSellReferral_FormFields);

        this.internalContact_Marketer_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Marketer');
        this.internalContact_Marketer_Form = this.qcs.toFormGroup(this.internalContact_Marketer_FormFields);

        this.internalContact_MarketerAssociateAnalyst_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Marketer Associate/Analyst');
        this.internalContact_MarketerAssociateAnalyst_Form = this.qcs.toFormGroup(this.internalContact_MarketerAssociateAnalyst_FormFields);

        if(this.productType === 'FX'){
            this.internalContact_TreasuryManagementSalesConsultant_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'Treasury Management Sales Consultant');
            this.internalContact_TreasuryManagementSalesConsultant_Form = this.qcs.toFormGroup(this.internalContact_TreasuryManagementSalesConsultant_FormFields);

            this.internalContact_OLSSpecialist_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'OLS Specialist');
            this.internalContact_OLSSpecialist_Form = this.qcs.toFormGroup(this.internalContact_OLSSpecialist_FormFields);

            this.internalContact_ITM_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'ITM');
            this.internalContact_ITM_Form = this.qcs.toFormGroup(this.internalContact_ITM_FormFields);

            this.internalContact_DoCOCPMGContact_FormFields = this.onboardingDetailRequestService.buildInternalContactFields(this.onboardingRole, 'DoCO-CPMG Contact');
            this.internalContact_DoCOCPMGContact_Form = this.qcs.toFormGroup(this.internalContact_DoCOCPMGContact_FormFields);
        }

        if(this.spoq_InternalContacts != null && this.spoq_InternalContacts.length > 0){
            if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Relationship Manager').length > 0){
                let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Relationship Manager')[0];
                for (const prop of Object.keys(spoq_InternalContact)) {
                    if (this.internalContact_RelationshipManager_Form.controls[prop]) {
                        this.internalContact_RelationshipManager_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                    }
                }
            }

            if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Relationship Associate').length > 0){
                let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Relationship Associate')[0];
                for (const prop of Object.keys(spoq_InternalContact)) {
                    if (this.internalContact_RelationshipAssociate_Form.controls[prop]) {
                        this.internalContact_RelationshipAssociate_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                    }
                }
            }

            if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Credit Officer/Underwriter').length > 0){
                let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Credit Officer/Underwriter')[0];
                for (const prop of Object.keys(spoq_InternalContact)) {
                    if (this.internalContact_CreditOfficerUnderwriter_Form.controls[prop]) {
                        this.internalContact_CreditOfficerUnderwriter_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                    }
                }
            }

            if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Cross Sell Referral').length > 0){
                let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Cross Sell Referral')[0];
                for (const prop of Object.keys(spoq_InternalContact)) {
                    if (this.internalContact_CrossSellReferral_Form.controls[prop]) {
                        this.internalContact_CrossSellReferral_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                    }
                }
            }

            if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer').length > 0){
                let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer')[0];
                for (const prop of Object.keys(spoq_InternalContact)) {
                    if (this.internalContact_Marketer_Form.controls[prop]) {
                        this.internalContact_Marketer_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                    }
                }
            }

            if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer Associate/Analyst').length > 0){
                let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer Associate/Analyst')[0];
                for (const prop of Object.keys(spoq_InternalContact)) {
                    if (this.internalContact_MarketerAssociateAnalyst_Form.controls[prop]) {
                        this.internalContact_MarketerAssociateAnalyst_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                    }
                }
            }

            if(this.productType === 'FX'){
                if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Treasury Management Sales Consultant').length > 0){
                    let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'Treasury Management Sales Consultant')[0];
                    for (const prop of Object.keys(spoq_InternalContact)) {
                        if (this.internalContact_TreasuryManagementSalesConsultant_Form.controls[prop]) {
                            this.internalContact_TreasuryManagementSalesConsultant_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                        }
                    }
                }

                if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'OLS Specialist').length > 0){
                    let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'OLS Specialist')[0];
                    for (const prop of Object.keys(spoq_InternalContact)) {
                        if (this.internalContact_OLSSpecialist_Form.controls[prop]) {
                            this.internalContact_OLSSpecialist_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                        }
                    }
                }

                if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'ITM').length > 0){
                    let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'ITM')[0];
                    for (const prop of Object.keys(spoq_InternalContact)) {
                        if (this.internalContact_ITM_Form.controls[prop]) {
                            this.internalContact_ITM_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                        }
                    }
                }

                if(this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'DoCO-CPMG Contact').length > 0){
                    let spoq_InternalContact = this.spoq_InternalContacts.filter(c => c.InternalContactType__c === 'DoCO-CPMG Contact')[0];
                    for (const prop of Object.keys(spoq_InternalContact)) {
                        if (this.internalContact_DoCOCPMGContact_Form.controls[prop]) {
                            this.internalContact_DoCOCPMGContact_Form.controls[prop].setValue(spoq_InternalContact[prop]);
                        }
                    }
                }
            }
        }
        
        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
            case 'Account Approval':
            case 'FX Static Data':
            case 'FXOL':
            case 'Client Services':
            case 'Tax Profile I':
            case 'AML EDD':
            case 'AML KYC':
                this.internalContact_RelationshipManager_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_RelationshipManager_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                this.internalContact_RelationshipAssociate_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_RelationshipAssociate_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                this.internalContact_CreditOfficerUnderwriter_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_CreditOfficerUnderwriter_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                this.internalContact_CrossSellReferral_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_CrossSellReferral_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                this.internalContact_Marketer_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_Marketer_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                this.internalContact_MarketerAssociateAnalyst_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_MarketerAssociateAnalyst_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                
                if(this.productType === 'FX'){
                    this.internalContact_TreasuryManagementSalesConsultant_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_TreasuryManagementSalesConsultant_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                    this.internalContact_OLSSpecialist_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_OLSSpecialist_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                    this.internalContact_ITM_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_ITM_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                    this.internalContact_DoCOCPMGContact_FormFields.filter(f => f.key === 'Search').length > 0 ? this.internalContact_DoCOCPMGContact_FormFields.filter(f => f.key === 'Search')[0].disabled = true : null;
                }
                break;
        
            default:
                break;
        }
        
    }

    openSearchModal(template, legalTemplate, cobamLookupTemplate, value: string): void {
        if (value !== '[object Event]' && value !== '[object MouseEvent]') {
            switch (value) {
                default:
                    this.searchTitle = value;
                    this.searchDialogRef = this.dialog.open(template, {
                        width: '80%',
                        height: '90%'
                    });
                    break;
            }
        }
    }

    onModalClose() {
        this.searchDialogRef.close();
    }

    selectRowData(value: any, legalTemplate: any): void {
        //debugger
        switch (this.searchTitle) {
            case 'Relationship Manager':
                this.internalContact_RelationshipManager_Form.controls['InternalContactType__c'].setValue('Relationship Manager');
                this.internalContact_RelationshipManager_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_RelationshipManager_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_RelationshipManager_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'Relationship Associate':
                this.internalContact_RelationshipAssociate_Form.controls['InternalContactType__c'].setValue('Relationship Associate');
                this.internalContact_RelationshipAssociate_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_RelationshipAssociate_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_RelationshipAssociate_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'Credit Officer/Underwriter':
                this.internalContact_CreditOfficerUnderwriter_Form.controls['InternalContactType__c'].setValue('Credit Officer/Underwriter');
                this.internalContact_CreditOfficerUnderwriter_Form .controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_CreditOfficerUnderwriter_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_CreditOfficerUnderwriter_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'Cross Sell Referral':
                this.internalContact_CrossSellReferral_Form.controls['InternalContactType__c'].setValue('Cross Sell Referral');
                this.internalContact_CrossSellReferral_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_CrossSellReferral_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_CrossSellReferral_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'Marketer':
                this.internalContact_Marketer_Form.controls['InternalContactType__c'].setValue('Marketer');
                this.internalContact_Marketer_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_Marketer_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_Marketer_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);

                this.internalContact_Marketer_Form.controls['Branch_Location__c'].setValue(value.BranchLocation);
                this.internalContact_Marketer_Form.controls['Marketer_Supervisor__c'].setValue(value.SupervisorName);
                this.internalContact_Marketer_Form.controls['Marketer_Supervisor_Id__c'].setValue(value.SupervisorId);
                this.internalContact_Marketer_Form.controls['Marketer_Supervisor_Email__c'].setValue(value.SupervisorEmailAddress);
                this.internalContact_Marketer_Form.controls['Marketer_Delegate_Id__c'].setValue(value.DelegateId);
                this.internalContact_Marketer_Form.controls['Marketer_Delegate_Email__c'].setValue(value.DelegateEmail);

                if(!this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput){
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput = new CallbackRequestInput();
                }
                
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.supervisor__c = value.SupervisorName;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.supervisor_Id__c = value.SupervisorId;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.supervisor_Email__c = value.SupervisorEmailAddress;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.delegate_Id__c = value.DelegateId;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.delegate_Email__c = value.DelegateEmail;

                this.onModalClose();
                break;
            case 'Marketer Associate/Analyst':
                this.internalContact_MarketerAssociateAnalyst_Form.controls['InternalContactType__c'].setValue('Marketer Associate/Analyst');
                this.internalContact_MarketerAssociateAnalyst_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_MarketerAssociateAnalyst_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_MarketerAssociateAnalyst_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'Treasury Management Sales Consultant':
                this.internalContact_TreasuryManagementSalesConsultant_Form.controls['InternalContactType__c'].setValue('Treasury Management Sales Consultant');
                this.internalContact_TreasuryManagementSalesConsultant_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_TreasuryManagementSalesConsultant_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_TreasuryManagementSalesConsultant_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'OLS Specialist':
                this.internalContact_OLSSpecialist_Form.controls['InternalContactType__c'].setValue('OLS Specialist');
                this.internalContact_OLSSpecialist_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_OLSSpecialist_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_OLSSpecialist_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'ITM':
                this.internalContact_ITM_Form.controls['InternalContactType__c'].setValue('ITM');
                this.internalContact_ITM_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_ITM_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_ITM_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            case 'DoCO-CPMG Contact':
                this.internalContact_DoCOCPMGContact_Form.controls['InternalContactType__c'].setValue('DoCO-CPMG Contact');
                this.internalContact_DoCOCPMGContact_Form.controls['Employee_Name__c'].setValue(value.FirstName + ' ' + value.LastName);
                this.internalContact_DoCOCPMGContact_Form.controls['Employee_Id__c'].setValue(value.EmpId);
                this.internalContact_DoCOCPMGContact_Form.controls['Employee_Email__c'].setValue(value.EmailAddress);
                this.onModalClose();
                break;
            default:
                
                break;
        }
    }
}