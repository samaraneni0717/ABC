import {
    Component,
    OnInit,
    ViewEncapsulation,
    Input,
    ViewChild,
    ChangeDetectorRef
} from '@angular/core';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
//Import Onboarding Models
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { MatDialog, MatTabChangeEvent } from '@angular/material';
import { AlertService } from '../../Common/services/alert.service';
import { DatePipe } from '@angular/common';
import { environment } from 'src/environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { Address } from '../Models/address.model';
import { COBAMLookup } from "../Models/cobamLookup.model";
import { Subscription } from 'rxjs';
import { OnboardingRequest } from '../Models/onbaordingRequest';
import { InternalContactsComponent } from '../onboarding-internal-contacts/onboarding-internal-contacts.component';
import { SPOQ_InternalContact } from '../Models/spoq_InternalContact';
import { DocumentationRequestComponent } from '../onboarding-documentation-request/onboarding-documentation-request.component';
import { SPOQ_DocumentationRequest } from '../Models/spoq_DocumentationRequest';
import { CustomerContactComponent } from '../onboarding-customer-contact/onboarding-customer-contact.component';
import { SPOQ_CustomerContact } from '../Models/spoq_CustomerContact';
import { LoanAndCreditSupportComponent } from '../onboarding-loan-credit-support/onboarding-loan-credit-support.component';
import { SPOQ_LoanAndCreditSupport } from '../Models/spoq_LoanAndCreditSupport';
import { SPOQ_FX_eChannels } from '../Models/spoq_FX_eChannels';
import { EChannelsComponent } from '../onboarding-echannels/onboarding-echannels.component';
import { EntityInformationComponent } from '../onboarding-entity-information/onboarding-entity-information.component';
import { SPOQ_EntityInformation } from '../Models/spoq_EntityInformation';
import { debounceTime } from 'rxjs/operators';
import { ClientBuildRequest } from '../Models/clientBuildRequest';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { SalesforceUser } from 'src/app/Common/models/salesforceUser';
import { TaxInformationComponent } from '../onboarding-tax-information/tax-information.component';

@Component({
    selector: 'app-onboarding-detail-request',
    templateUrl: './onboarding-detail-request.component.html',
    styleUrls: ['./onboarding-detail-request.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class OnboardingDetailRequestComponent implements OnInit {
    @Input() productTypeVal: string;
    @Input() productSubTypeVal: string;
    @Input() WFEntityVal: string;
    @Input() buildTypeVal: string;
    @Input() settlementType: string;
    @Input() productSettlementType: string
    @ViewChild(TaxInformationComponent)
    taxInformationComponent: TaxInformationComponent;

    @ViewChild(InternalContactsComponent)
    internalContactsComponent: InternalContactsComponent;

    @ViewChild(EntityInformationComponent)
    entityInformationComponent: EntityInformationComponent;

    @ViewChild(DocumentationRequestComponent)
    documentationRequestComponent: DocumentationRequestComponent;

    @ViewChild(CustomerContactComponent)
    customerContactComponent: CustomerContactComponent;

    @ViewChild(LoanAndCreditSupportComponent)
    loanAndCreditSupportComponent: LoanAndCreditSupportComponent;

    @ViewChild(EChannelsComponent)
    eChannelsComponent: EChannelsComponent;

    onboardingRequsetIdVal = this.route.snapshot.queryParams['id'];
    queueStatus: string;
    isSave = false;
    isLoading = false;
    formFields: QuestionBase<any>[] = [];
    SearchFormFields: QuestionBase<any>[] = [];
    reqForm: FormGroup;
    SearchForm: FormGroup;
    payLoad: any;
    isSearchLoading = false;
    showAlert = false;
    errorMessage: string;
    showNonCashTabs = false;
    showFXTabs = false;
    showAttachFilesTab = false;
    showChatterTab = false;
    showSaveButton = true;
    showSaveTemplateButton = true;
    showSubmitButton = true;
    showSKFeeDiscountButton = false;
    reqStatus: string;
    searchTitle = '';
    searchBtnName = '';
    currentUserId = '';
    isValidMaintenanceSalesforceUser = false;
    searchDialogRef: any;
    legalAddressSearchDialogRef: any;
    cobamLookupSearchDialogRef: any;
    onboardingRole: string;
    currentUserName = '';
    currentUserDesk = '';
    legalId: number;
    expenseCode: string;
    legalAddressTable = new Array<Address>();
    expenseCodeLookup = new Array<COBAMLookup>();
    clientType: string;
    clientSubType: string;
    entityType: string;
    state: string;
    country: string;
    selectedInnerTab = 'Request Details';
    selectedMainTab = 'Request Details';
    showResetRulesEngineButton = false;
    showRefreshWorkItemsButton = false;
    private subscriptions: Subscription[] = [];

    // onboardingRequest: OnboardingRequest;

    constructor(
        private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private datePipe: DatePipe,
        private router: Router,
        private authService: AuthService,
        private route: ActivatedRoute,
        private cdRef: ChangeDetectorRef
    ) { }

    ngOnInit() {
        this.isLoading = true;
        this.isLoading = true;
        this.onboardingRequsetIdVal = "1";
        this.isLoading = true;
        this.productTypeVal = 'Fixed Income';
        this.productSubTypeVal = 'Cash';
        this.buildTypeVal = 'New Bus Acc Only';
        this.WFEntityVal = 'WFSIL;WFSAL';
        this.settlementType = 'Regular';
        this.onboardingRole = 'AML EDD';
        this.queueStatus = 'Closed - Approved';
        this.initializeModels();
        this.onboardingRequsetIdVal = "1";
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.New_Wires__c = 'No';
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Reg_Requirements__c = 'Complete';
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CDD_Requirements__c = 'Pending';
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Tax_Requirements__c = 'Complete';
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Documentation_Requirements__c = 'Pending';

        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Secondary_Review__c = 'Complete';
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Static_Data_Status__c = 'New Request';

        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c = '';
        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c = 'CSTN down - AML Approved';

        this.onboardingDetailRequestService.currentUser = new SalesforceUser();
        this.onboardingDetailRequestService.currentUser.COBAM_Role__c = 'AML EDD';

        //this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxReviewStatus__c = ''; //'Rejected';//'Pending Review - Unassigned';

        // this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.TaxFormType__c = 'W-9'; 
        // this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_9__c = 1; 
        // this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.W_8ECI__c = 5; 
        // this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails.Is_CRS_Forms_Included__c = 'Yes';

        this.BuildPage();

        // if (this.onboardingDetailRequestService.currentUser) {
        //     this.initializeComponent();
        // }
        // else {
        //     this.onboardingDetailRequestService.getCurrentUser().subscribe(data => {
        //         if (data) {
        //             this.onboardingDetailRequestService.currentUser = data;
        //             this.initializeComponent();
        //         }
        //         else {
        //             this.router.navigate(['notauthorized']);
        //         }
        //     });
        // }
    }

    initializeComponent() {
        this.currentUserId = this.onboardingDetailRequestService.currentUser.Id;
        this.currentUserName = this.onboardingDetailRequestService.currentUser.Name;
        this.currentUserDesk = this.onboardingDetailRequestService.currentUser.Desk__c;
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;

        if (this.onboardingRole === 'Requester' || this.onboardingRole === 'Requester NonCash' ||
            this.onboardingRole === 'Facilitator' || this.onboardingRole === 'Facilitator Manager' ||
            this.onboardingRole === 'Account Approval' || this.onboardingRole === 'DCOT' ||
            this.onboardingRole === 'FXOL' || this.onboardingRole === 'FX Static Data' ||
            this.onboardingRole === 'Tax Profile I' || this.onboardingRole === 'Tax Profile II' ||
            this.onboardingRole === 'APAC Markets Compliance' || this.onboardingRole === 'Client Services') {
            if (this.onboardingRequsetIdVal) {
                this.showSaveButton = false;
                this.isLoading = true;
                this.onboardingDetailRequestService.GetOnboardingRequestDetails(this.onboardingRequsetIdVal).subscribe(
                    data => {
                        if (data) {
                            data = JSON.parse(JSON.stringify(data));
                            console.log(data);
                            this.onboardingDetailRequestService.onboardingRequest = data;
                            this.buildTypeVal = data.Client_Build_Request__r.Build_Type__c;
                            this.WFEntityVal = data.Client_Build_Request__r.WFS_Entity__c;
                            this.productTypeVal = data.Client_Build_Request__r.Product_Type__c;
                            this.settlementType = data.Client_Build_Request__r.Settlement_Type__c;
                            this.productSettlementType = data.Client_Build_Request__r.ProductSettlementType__c;
                            this.productSubTypeVal = data.Client_Build_Request__r.Product_Sub_Type__c;
                            this.queueStatus = data.Client_Build_Request__r.Status__c;

                            if (this.queueStatus === 'Draft' && (this.onboardingRole !== 'Requester' && this.onboardingRole !== 'Requester NonCash' && this.onboardingRole !== 'DCOT')) {
                                this.router.navigate(['notauthorized']);
                            }

                            this.BuildPage();
                        }
                    });
                this.isSave = true;
            }
            else {
                this.queueStatus = 'Draft';
                if (this.queueStatus === 'Draft' && (this.onboardingRole !== 'Requester' && this.onboardingRole !== 'Requester NonCash' && this.onboardingRole !== 'DCOT')) {
                    this.router.navigate(['notauthorized']);
                }
                this.initializeModels();
                this.BuildPage();
            }
        }
        else {
            this.router.navigate(['notauthorized']);
        }
    }

    //Initialize Models
    initializeModels() {
        this.onboardingDetailRequestService.onboardingRequest = new OnboardingRequest();
    }

    BuildPage() {
        //debugger
        this.formFields = this.onboardingDetailRequestService.buildFields(
            this.productTypeVal,
            this.productSubTypeVal,
            this.buildTypeVal,
            this.WFEntityVal,
            this.onboardingRole,
            this.queueStatus,
            this.currentUserName,
            this.settlementType
        );
        console.log(this.formFields);

        if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps') {
            this.showNonCashTabs = true;
            this.showFXTabs = false;
        }
        else if (this.productTypeVal === 'FX') {
            this.showNonCashTabs = true;
            this.showFXTabs = true;
        }

        // console.log(new Date().toUTCString());

        // this.onboardingDetailRequestService.getLookup().subscribe(data => {
        //     if (data) {
        //         console.log(new Date().toUTCString());
        //         var fields = data.objectDescription.fields.filter(function(field) {
        //             return field.pickListValues.length > 0 && field.pickListValues.filter(function(pickListValue) {
        //                 return pickListValue.active 
        //             });

        //         });
        //         var countryField = fields.filter(function(field) {
        //             return field.name === 'Country__c'
        //         })[0].pickListValues.filter(function(pickListValue){
        //             return pickListValue.active
        //         });

        //         console.log(countryField);
        //     }
        // });

        //debugger
        this.reqForm = this.qcs.toFormGroup(this.formFields);

        this.cdRef.detectChanges();

        if (this.onboardingRequsetIdVal) {
            if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                for (const prop of Object.keys(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r)) {
                    if (this.reqForm.controls[prop] && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[prop]) {
                        this.reqForm.controls[prop].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[prop]);
                    }
                }
                //#region WorkItem details

                if (this.queueStatus && this.queueStatus !== 'Draft' && this.queueStatus !== 'Closed - Approved' && this.queueStatus !== 'Closed - Rejected' && this.queueStatus !== 'Closed - Inactive'
                    && (this.onboardingRole !== 'Requester' && this.onboardingRole !== 'Requester NonCash')) {

                    this.showResetRulesEngineButton = true;
                }

                if (this.queueStatus !== 'Draft') {
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Reg_Requirements__c) {
                        this.formFields.filter(f => f.key === 'Reg_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Reg_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CDD_Requirements__c) {
                        this.formFields.filter(f => f.key === 'CDD_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CDD_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Tax_Requirements__c) {
                        this.formFields.filter(f => f.key === 'Tax_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Tax_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Documentation_Requirements__c) {
                        this.formFields.filter(f => f.key === 'Documentation_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Documentation_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Secondary_Review__c) {
                        this.formFields.filter(f => f.key === 'Secondary_Review__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Secondary_Review__c;
                        this.showRefreshWorkItemsButton = true;
                    }
                }
                //#endregion

            }
            else {
                for (const prop of Object.keys(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r)) {
                    if (this.reqForm.controls[prop] && this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r[prop]) {
                        this.reqForm.controls[prop].setValue(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r[prop]);
                    }
                }

                //#region WorkItem details

                if (this.queueStatus && this.queueStatus !== 'Draft' && this.queueStatus !== 'Closed - Approved' && this.queueStatus !== 'Closed - Rejected' && this.queueStatus !== 'Closed - Inactive'
                    && (this.onboardingRole !== 'Requester' && this.onboardingRole !== 'Requester NonCash')) {

                    this.showResetRulesEngineButton = true;
                }

                if (this.queueStatus !== 'Draft') {
                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Reg_Requirements__c) {
                        this.formFields.filter(f => f.key === 'Reg_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Reg_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Requirements__c) {
                        this.formFields.filter(f => f.key === 'AML_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Tax_Requirements__c) {
                        this.formFields.filter(f => f.key === 'Tax_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Tax_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Documentation_Requirements__c) {
                        this.formFields.filter(f => f.key === 'Documentation_Requirements__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Documentation_Requirements__c;
                        this.showRefreshWorkItemsButton = true;
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Secondary_Review__c) {
                        this.formFields.filter(f => f.key === 'Secondary_Review__ui')[0].value = this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Secondary_Review__c;
                        this.showRefreshWorkItemsButton = true;
                    }
                }
                //#endregion
            }
        }



        switch (this.onboardingRole) {
            case 'Requester':
            case 'Requester NonCash':
                break;
            case 'Facilitator':
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    //#region NonCash/FX request
                    this.DisableRequestDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisableFXOLSection();
                    if (this.reqForm.controls['Type_of_Documentation_Request__c']) {
                        this.reqForm.controls['Type_of_Documentation_Request__c'].disable();
                    }
                    //#endregion
                }
                else {
                    //#region Cash request

                    var filteredFields = this.formFields.filter(f => f.section && f.section === 'LegalAndBusAcct')
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'CID_LEID__c':
                                    this.reqForm.controls[element.key].enable();
                                    break;
                                case 'Client_Type__c':
                                case 'Client_SubType__c':
                                case 'Entity_Type__c':
                                case 'CMA_Name__c':
                                    this.reqForm.controls[element.key].disable();
                                    break;
                                default:
                                    break;
                            }
                        });
                    }

                    filteredFields = this.formFields.filter(f => f.section && f.section === 'AMLDetails')
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'AML_Status__c':
                                    if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps') {
                                        if (!this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.AML_Status__c) {
                                            //     this.reqForm.controls[element.key].enable();
                                            //     (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options = (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Ready In CSTN/CRMS');
                                            // }
                                            // else{
                                            this.reqForm.controls[element.key].disable();
                                        }
                                    }
                                    else {
                                        if (!this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c) {
                                            this.reqForm.controls[element.key].enable();
                                            (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options = (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Ready In CSTN/CRMS');
                                        }
                                        else {
                                            this.reqForm.controls[element.key].disable();
                                        }
                                    }

                                    break;
                                default:
                                    this.reqForm.controls[element.key].disable();
                                    break;
                            }
                        });
                    }
                    this.DisableAPACDetailsSection();

                    //#endregion
                }
                break;
            case 'Facilitator Manager':
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    //#region NonCash/FX request
                    this.DisableRequestDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisableFXOLSection();
                    if (this.reqForm.controls['Type_of_Documentation_Request__c']) {
                        this.reqForm.controls['Type_of_Documentation_Request__c'].disable();
                    }
                    //#endregion
                }
                else {
                    //#region Cash Request
                    var filteredFields = this.formFields.filter(f => f.section && f.section === 'FacilitatorDetails')
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'Primary_Facilitator__c':
                                case 'Secondary_Facilitator__c':
                                case 'Document_Status__c':
                                    this.reqForm.controls[element.key].enable();
                                    break;
                                default:
                                    this.reqForm.controls[element.key].disable();
                                    break;
                            }
                            if (this.reqForm.controls[element.key]) {

                            }
                        });
                    }
                    this.DisableRequestDetailsSection();
                    this.DisableLegalAndBusAcctSection();
                    //this.DisableLegalAddressDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    //this.DisableTaxInformationDetailsSection();

                    //#endregion
                }

                break;
            case 'Account Approval':
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    //#region NonCash/FX request
                    this.DisableRequestDetailsSection();
                    var filteredFields = this.formFields.filter(f => f.section && f.section === 'RequestDetails')
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'Status__c':
                                case 'BA_ID__c':
                                    this.reqForm.controls[element.key].enable();
                                    break;
                                default:
                                    this.reqForm.controls[element.key].disable();
                                    break;
                            }
                        });
                    }
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisableFXOLSection();
                    //#endregion
                }
                else {
                    //#region Cash Request
                    this.DisableRequestDetailsSection();
                    var filteredFields = this.formFields.filter(f => f.section && f.section === 'LegalAndBusAcct')
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'CID_LEID__c':
                                case 'Business_Acct_Fund_Name__c':
                                case 'Short_Name__c':
                                case 'BA_ID__c':
                                    this.reqForm.controls[element.key].enable();
                                    break;
                                default:
                                    this.reqForm.controls[element.key].disable();
                                    break;
                            }
                        });
                    }
                    this.DisableLegalAddressDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();

                    //#endregion
                }
                break;
            case 'DCOT':
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    filteredFields = this.formFields.filter(f => f.section && f.section === 'AMLDetails')
                    if (filteredFields && filteredFields.length > 0) {
                        filteredFields.forEach(element => {
                            switch (element.key) {
                                case 'AML_Status__c':
                                    if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                                        if (!this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.AML_Status__c) {
                                            this.reqForm.controls[element.key].enable();
                                            (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options = (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key === '' || o.key === 'Ready In CSTN/CRMS');
                                        }
                                        else {
                                            this.reqForm.controls[element.key].disable();
                                        }
                                    }
                                    else {
                                        this.reqForm.controls[element.key].disable();
                                    }

                                    break;
                                default:
                                    this.reqForm.controls[element.key].disable();
                                    break;
                            }
                        });
                    }
                }
                else {

                    this.DisableRequestDetailsSection();
                    this.DisableLegalAndBusAcctSection();
                    this.DisableLegalAddressDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisablePrimeDetailsSection();
                }
                break;
            case 'FX Static Data':
                if (this.productTypeVal === 'FX') {
                    this.DisableRequestDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisableFXOLSection();
                    if (this.reqForm.controls['Type_of_Documentation_Request__c']) {
                        this.reqForm.controls['Type_of_Documentation_Request__c'].disable();
                    }
                    if (this.reqForm.controls['CMNE_Number__c']) {
                        this.reqForm.controls['CMNE_Number__c'].enable();
                    }
                }
                else {
                    this.DisableRequestDetailsSection();
                    this.DisableLegalAndBusAcctSection();
                    this.DisableLegalAddressDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisablePrimeDetailsSection();
                    this.DisableAMLDetailsSection();
                }
                break;
            case 'FXOL':
                if (this.productTypeVal === 'FX') {
                    this.DisableRequestDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAMLDetailsSection();
                    this.DisableAPACDetailsSection();
                    if (this.reqForm.controls['Type_of_Documentation_Request__c']) {
                        this.reqForm.controls['Type_of_Documentation_Request__c'].disable();
                    }
                }
                else {
                    this.DisableRequestDetailsSection();
                    this.DisableLegalAndBusAcctSection();
                    this.DisableLegalAddressDetailsSection();
                    this.DisableDocumentMatrixSection();
                    this.DisableFacilitatorDetailsSection();
                    this.DisableAPACDetailsSection();
                    this.DisablePrimeDetailsSection();
                    this.DisableAMLDetailsSection();
                }
                break;
            case 'Client Services':
                this.DisableRequestDetailsSection();
                this.DisableLegalAndBusAcctSection();
                this.DisableLegalAddressDetailsSection();
                this.DisableDocumentMatrixSection();
                this.DisableFacilitatorDetailsSection();
                this.DisableAMLDetailsSection();
                this.DisableAPACDetailsSection();
                this.DisablePrimeDetailsSection();
                this.DisableFXOLSection();
                break;
            case 'Tax Profile I':
                this.DisableRequestDetailsSection();
                this.DisableLegalAndBusAcctSection();
                this.DisableLegalAddressDetailsSection();
                this.DisableDocumentMatrixSection();
                this.DisableFacilitatorDetailsSection();
                this.DisableAMLDetailsSection();
                this.DisableAPACDetailsSection();
                this.DisablePrimeDetailsSection();
                this.DisableFXOLSection();
                break;

            case 'AML EDD':
                filteredFields = this.formFields.filter(f => f.section && f.section === 'AMLDetails')
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') ||
                    this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.AML_Status__c) {
                        if (filteredFields && filteredFields.length > 0) {
                            filteredFields.forEach(element => {
                                switch (element.key) {
                                    case 'AML_Status__c':
                                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r) {
                                            (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options =
                                                (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key !== '');
                                            this.reqForm.controls[element.key].enable();
                                        }
                                        else {
                                            this.reqForm.controls[element.key].disable();
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            });
                        }
                    }
                }
                else {
                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c) {
                        if (filteredFields && filteredFields.length > 0) {
                            filteredFields.forEach(element => {
                                switch (element.key) {
                                    case 'AML_Status__c':
                                        if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c
                                            && (!this.queueStatus.includes('Closed') ||
                                                (this.buildTypeVal == 'New Bus Acc Only' &&
                                                    this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c !== 'Approved in CSTN/CRMS' &&
                                                    this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c !== 'CSTN down - AML Approved'))) {
                                            this.reqForm.controls[element.key].enable();
                                            (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options = (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key !== '');
                                        }
                                        else {
                                            this.reqForm.controls[element.key].disable();
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            });
                        }

                    }
                }
                this.DisableRequestDetailsSection();
                this.DisableLegalAndBusAcctSection();
                this.DisableLegalAddressDetailsSection();
                this.DisableDocumentMatrixSection();
                this.DisableFacilitatorDetailsSection();
                this.DisableAPACDetailsSection();
                this.DisablePrimeDetailsSection();
                this.EnableAMLDetailsSection();
                this.DisableFXOLSection();
                break;
            case 'AML KYC':
                filteredFields = this.formFields.filter(f => f.section && f.section === 'AMLDetails')
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.AML_Status__c) {
                        if (filteredFields && filteredFields.length > 0) {
                            filteredFields.forEach(element => {
                                switch (element.key) {
                                    case 'AML_Status__c':
                                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r) {
                                            (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options = (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key !== '');
                                            this.reqForm.controls[element.key].enable();
                                        }
                                        else {
                                            this.reqForm.controls[element.key].disable();
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            });
                        }
                    }
                }
                else {
                    if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c) {
                        if (filteredFields && filteredFields.length > 0) {
                            filteredFields.forEach(element => {
                                switch (element.key) {
                                    case 'AML_Status__c':
                                        if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c
                                            && (!this.queueStatus.includes('Closed') ||
                                                (this.buildTypeVal == 'New Bus Acc Only' &&
                                                    // tslint:disable-next-line:max-line-length
                                                    this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c !== 'Approved in CSTN/CRMS' &&
                                                    // tslint:disable-next-line:max-line-length
                                                    this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.AML_Status__c !== 'CSTN down - AML Approved'))) {
                                            this.reqForm.controls[element.key].enable();
                                            // tslint:disable-next-line:max-line-length
                                            (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options = (this.formFields.filter(f => f.key === 'AML_Status__c')[0] as DropdownQuestion).options.filter(o => o.key !== '');
                                        }
                                        else {
                                            this.reqForm.controls[element.key].disable();
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            });
                        }

                    }
                }

                this.DisableRequestDetailsSection();
                this.DisableLegalAndBusAcctSection();
                this.DisableLegalAddressDetailsSection();
                this.DisableDocumentMatrixSection();
                this.DisableFacilitatorDetailsSection();
                this.DisableAPACDetailsSection();
                this.DisablePrimeDetailsSection();
                // this.EnableAMLDetailsSection();
                this.DisableFXOLSection();
                break;


            default:
                this.DisableRequestDetailsSection();
                this.DisableLegalAndBusAcctSection();
                this.DisableLegalAddressDetailsSection();
                this.DisableDocumentMatrixSection();
                this.DisableFacilitatorDetailsSection();
                this.DisableAPACDetailsSection();
                this.DisablePrimeDetailsSection();
                this.DisableAMLDetailsSection();
                this.DisableFXOLSection();
                break;
        }

        if (this.reqForm.get('APAC_Status__c')) {
            this.reqForm.get('APAC_Status__c').disable();
        }

        if (this.reqForm.controls['Customer_Classification__c']) {
            this.reqForm.get('Customer_Classification__c').disable();
        }

        if (this.productTypeVal === 'Fixed Income' && this.settlementType === 'Extended' && !this.onboardingRequsetIdVal) {
            if (!this.reqForm.get('External_system_list__c').value) {
                this.reqForm.get('External_system_list__c').setValue([]);
            }

            this.reqForm.get('External_system_list__c').value.push('GDD : GLOBAL DERIVATIVE DOC SYSTEM');
            this.reqForm.get('External_system_list__c').setValue(this.reqForm.get('External_system_list__c').value);

            this.reqForm.get('External_system_list__c').value.push('ARTS : ANVIL REPO TRADING SYSTEM');
            this.reqForm.get('External_system_list__c').setValue(this.reqForm.get('External_system_list__c').value);
        }

        this.enableDisableQueueStatus(this.onboardingRole, 'Draft');
        this.setDisplayModeForCallbackTHirdParty();


        if (!this.showNonCashTabs && this.reqForm.controls['Legal_Name__c']) {
            this.subscriptions.push(this.reqForm.controls['Legal_Name__c'].valueChanges.pipe(
                debounceTime(300))
                .subscribe(() =>
                    this.onLegalNameValueChange()
                ));
        }

        if (!this.showNonCashTabs && this.reqForm.controls['CID_LEID__c']) {
            this.subscriptions.push(this.reqForm.controls['CID_LEID__c'].valueChanges.pipe(
                debounceTime(300))
                .subscribe(() =>
                    this.onLegalIdValueChange()
                ));
        }

        this.setShowMiFidField();

        this.reqForm.get('CDD_Type_And_Sub_Type__c') ? this.reqForm.get('CDD_Type_And_Sub_Type__c').disable() : null;
        this.showhidetabsbuttons();

        this.isLoading = false;
    }

    DisableRequestDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'RequestDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableLegalAndBusAcctSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'LegalAndBusAcct')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableLegalAddressDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'LegalAddressDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableDocumentMatrixSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'DocumentMatrix')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }


    DisableFacilitatorDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'FacilitatorDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }
    DisableAMLDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'AMLDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }
    DisableAPACDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'APACDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableFXOLSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'FXOL')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }



    DisablePrimeDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'PrimeDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].disable();
                }
            });
        }
    }
    EnableAMLDetailsSection() {
        var filteredFields = this.formFields.filter(f => f.section && f.section === 'AMLDetails')
        if (filteredFields && filteredFields.length > 0) {
            filteredFields.forEach(element => {
                if (this.reqForm.controls[element.key]) {
                    this.reqForm.controls[element.key].enable();
                }
            });
        }
    }

    onLegalIdValueChange() {
        if (this.reqForm.controls['Status__c'] && this.reqForm.controls['Status__c'].value !== 'Draft') {
            alert('Legal Entity information has been changed please visit \'Wholesale CDD & AML\' tab to update AML forms');
        }
    }

    onLegalNameValueChange() {
        this.reqForm.controls['Build_Type__c'] ? this.reqForm.controls['Build_Type__c'].setValue('New Legal & Bus Acc', { emitEvent: false }) : null;
        this.reqForm.controls['CID_LEID__c'] ? this.reqForm.controls['CID_LEID__c'].setValue('') : null;
        this.reqForm.controls['ClientId__c'] ? this.reqForm.controls['ClientId__c'].setValue('') : null;
        this.reqForm.controls['Alert_Acronym__c'] ? this.reqForm.controls['Alert_Acronym__c'].setValue('') : null;
        this.reqForm.controls['Alert_code__c'] ? this.reqForm.controls['Alert_code__c'].setValue('') : null;
        this.reqForm.controls['Client_Type__c'] ? this.reqForm.controls['Client_Type__c'].setValue('') : null;
        this.reqForm.controls['Client_SubType__c'] ? this.reqForm.controls['Client_SubType__c'].setValue('') : null;
        this.reqForm.controls['Entity_Type__c'] ? this.reqForm.controls['Entity_Type__c'].setValue('') : null;
        this.reqForm.controls['AddressLine1__c'] ? this.reqForm.controls['AddressLine1__c'].setValue('') : null;
        this.reqForm.controls['AddressLine2__c'] ? this.reqForm.controls['AddressLine2__c'].setValue('') : null;
        this.reqForm.controls['AddressLine3__c'] ? this.reqForm.controls['AddressLine3__c'].setValue('') : null;
        this.reqForm.controls['City__c'] ? this.reqForm.controls['City__c'].setValue('') : null;
        this.reqForm.controls['Country__c'] ? this.reqForm.controls['Country__c'].setValue('US - UNITED STATES') : null;
        this.reqForm.controls['State__c'] ? this.reqForm.controls['State__c'].setValue('') : null;
        this.reqForm.controls['Zip__c'] ? this.reqForm.controls['Zip__c'].setValue('') : null;
        this.reqForm.controls['MiFID_II_Clnt_Cat_Internal_Use__c'] ? this.reqForm.controls['MiFID_II_Clnt_Cat_Internal_Use__c'].setValue('') : null;
        this.reqForm.controls['MiFID_II_Client_Categorization__c'] ? this.reqForm.controls['MiFID_II_Client_Categorization__c'].setValue('') : null;
        this.reqForm.controls['RestrictedLegalReasons__c'] ? this.reqForm.controls['RestrictedLegalReasons__c'].setValue('') : null;
        this.reqForm.controls['IsNewCMA__c'] ? this.reqForm.controls['IsNewCMA__c'].setValue('Create new CMA') : null;
        this.reqForm.controls['CMA_Name__c'] ? this.reqForm.controls['CMA_Name__c'].setValue(this.reqForm.controls['Legal_Name__c'].value) : null;
        this.reqForm.controls['CMAId__c'] ? this.reqForm.controls['CMAId__c'].setValue(-1) : null;
        this.reqForm.controls['Hong_Kong_Classification__c'] ? this.reqForm.controls['Hong_Kong_Classification__c'].setValue('') : null;
        this.reqForm.controls['Product_group_Market_coverage__c'] ? this.reqForm.controls['Product_group_Market_coverage__c'].setValue('') : null;
        this.reqForm.controls['CPI_Letter_Complete__c'] ? this.reqForm.controls['CPI_Letter_Complete__c'].setValue(false) : null;
        this.reqForm.controls['Comments__c'] ? this.reqForm.controls['Comments__c'].setValue('') : null;
    }

    setShowMiFidField() {
        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Product_Type__c === 'FX') {
            if (!this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.length > 0)
                && (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.includes('FX EYD') ||
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.includes('FX Forward') ||
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.includes('FX NDF') ||
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.includes('FX Option') ||
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.includes('FX Swap') ||
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.includes('FX Window Forward')
                )) {
                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Build_Type__c === 'New Legal & Bus Acc' &&
                    (
                        (!this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.WFS_Entity__c)
                            && (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.WFS_Entity__c.includes('WFSIL')
                                || this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.WFS_Entity__c.includes('WFBNA - LB')))
                        || ((!this.onboardingDetailRequestService.isFieldEmpty(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.WFS_Entity__c)
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.WFS_Entity__c.includes('WFBNA - US'))
                            && (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer').length > 0 && (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0].Branch_Location__c === 'LONDON' || this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0].Branch_Location__c === 'DUBLIN'))
                        )
                    )) {

                    this.reqForm.get('ShowMiFidField').setValue('Yes');
                }
                else {
                    this.reqForm.get('ShowMiFidField').setValue('No');
                }
            }
            else {
                this.reqForm.get('ShowMiFidField').setValue('No');
            }
        }
    }

    tabChanged(tabChangeEvent: MatTabChangeEvent) {
        //debugger
        this.getFormValues();

        this.selectedInnerTab = tabChangeEvent.tab.textLabel;

        if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
            switch (this.selectedInnerTab) {
                case 'Request Details':
                    if (this.reqForm.controls['Type_of_Documentation_Request__c']) {
                        this.formFields.filter(f => f.key === 'Type_of_Documentation_Request__c')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Type_of_Documentation_Request__c;
                    }
                    if (this.reqForm.controls['CustomerType__c']) {
                        this.formFields.filter(f => f.key === 'CustomerType__c')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CustomerType__c;
                    }

                    this.setShowMiFidField();

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length > 0) {
                        this.reqForm.controls['Legal_Name__c'].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Name__c);
                        this.reqForm.controls['Legal_Id__c'].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Id__c);
                        this.reqForm.controls['WCIS_ID__c'].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].WCIS_ID__c);

                    }
                    break;
                case 'FX Documentation Request':
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c.split(';');
                    }
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__c.split(';');
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__c.split(';');
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__c.split(';');
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__c.split(';');
                    }
                    break;
                case 'eChannels':
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length > 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.Company_Names__c = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Name__c;
                    }
                    break;
                default:
                    break;
            }
        }
    }

    mainTabChanged(tabChangeEvent: MatTabChangeEvent) {
        //debugger
        this.getFormValues();
        this.getMainTabFormValues();
        this.selectedMainTab = tabChangeEvent.tab.textLabel;
        if (this.selectedMainTab === 'Request Details') {
            this.selectedInnerTab = 'Request Details';
        }
        else {
            this.selectedInnerTab = '';
        }

        if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
            switch (this.selectedInnerTab) {
                case 'Request Details':
                    if (this.reqForm.controls['Type_of_Documentation_Request__c']) {
                        this.formFields.filter(f => f.key === 'Type_of_Documentation_Request__c')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Type_of_Documentation_Request__c;
                    }
                    if (this.reqForm.controls['CustomerType__c']) {
                        this.formFields.filter(f => f.key === 'CustomerType__c')[0].value = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CustomerType__c;
                    }

                    this.setShowMiFidField();

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length > 0) {
                        this.reqForm.controls['Legal_Name__c'].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Name__c);
                        this.reqForm.controls['Legal_Id__c'].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Id__c);
                        this.reqForm.controls['WCIS_ID__c'].setValue(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].WCIS_ID__c);

                    }
                    break;
                case 'FX Documentation Request':
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c.split(';');
                    }
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__c.split(';');
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__c.split(';');
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__c.split(';');
                    }

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__c && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__ui.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__ui = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__c.split(';');
                    }
                    break;
                case 'eChannels':
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length > 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.Company_Names__c = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Name__c;
                    }
                    break;
                default:
                    break;
            }
        }
    }

    getFormValues() {
        //debugger
        if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
            this.selectedInnerTab
            //debugger
            let keysArr = [];
            switch (this.selectedInnerTab) {
                case 'Request Details':
                    //#region Request Details
                    //keysArr = Object.keys(new SPOQ_DocumentationRequest());
                    keysArr = Object.keys(this.reqForm.controls);

                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.reqForm.get(key).value;
                        }
                        else if (this.reqForm.get('New_Wires__c') && this.reqForm.get('New_Wires__c').value && this.reqForm.get('New_Wires__c').value === 'Yes'
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput[key] !== undefined) {

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput[key] = this.reqForm.get(key).value;
                        }

                    });

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length > 0) {
                        if (this.reqForm.get('Legal_Id__c') && this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.get('Legal_Id__c').value)) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Name__c = this.reqForm.get('Legal_Name__c').value;
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Id__c = this.reqForm.get('Legal_Id__c').value;
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].WCIS_ID__c = this.reqForm.get('WCIS_ID__c').value;
                        }
                    }

                    //#endregion
                    break;
                case 'Internal Contacts':
                    //#region Internal Contacts

                    keysArr = Object.keys(this.internalContactsComponent.internalContact_RelationshipManager_Form.controls);
                    let internalContact = new SPOQ_InternalContact();

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Manager').length > 0) {

                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Manager')[0][key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Manager')[0][key] = this.internalContactsComponent.internalContact_RelationshipManager_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.RelationshipManager = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Manager')[0]['Employee_Name__c'];
                    }
                    else {
                        keysArr.forEach(key => {
                            if (internalContact[key] !== undefined) {
                                internalContact[key] = this.internalContactsComponent.internalContact_RelationshipManager_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.RelationshipManager = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Manager')[0]['Employee_Name__c'];
                    }

                    internalContact = new SPOQ_InternalContact();
                    keysArr = Object.keys(this.internalContactsComponent.internalContact_RelationshipAssociate_Form.controls);

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Associate').length > 0) {
                        //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Associate')[0];
                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Associate')[0][key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Relationship Associate')[0][key] = this.internalContactsComponent.internalContact_RelationshipAssociate_Form.get(key).value;
                            }
                        });
                    }
                    else {
                        keysArr.forEach(key => {
                            if (internalContact[key] !== undefined) {
                                internalContact[key] = this.internalContactsComponent.internalContact_RelationshipAssociate_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                    }

                    internalContact = new SPOQ_InternalContact();
                    keysArr = Object.keys(this.internalContactsComponent.internalContact_CreditOfficerUnderwriter_Form.controls);

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Credit Officer/Underwriter').length > 0) {
                        //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Credit Officer/Underwriter')[0];

                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Credit Officer/Underwriter')[0][key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Credit Officer/Underwriter')[0][key] = this.internalContactsComponent.internalContact_CreditOfficerUnderwriter_Form.get(key).value;
                            }
                        });
                    }
                    else {
                        keysArr.forEach(key => {
                            if (internalContact[key] !== undefined) {
                                internalContact[key] = this.internalContactsComponent.internalContact_CreditOfficerUnderwriter_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                    }

                    internalContact = new SPOQ_InternalContact();
                    keysArr = Object.keys(this.internalContactsComponent.internalContact_CrossSellReferral_Form.controls);

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Cross Sell Referral').length > 0) {
                        //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Cross Sell Referral')[0];
                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Cross Sell Referral')[0][key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Cross Sell Referral')[0][key] = this.internalContactsComponent.internalContact_CrossSellReferral_Form.get(key).value;
                            }
                        });
                    }
                    else {
                        keysArr.forEach(key => {
                            if (internalContact[key] !== undefined) {
                                internalContact[key] = this.internalContactsComponent.internalContact_CrossSellReferral_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                    }

                    internalContact = new SPOQ_InternalContact();
                    keysArr = Object.keys(this.internalContactsComponent.internalContact_Marketer_Form.controls);

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer').length > 0) {
                        //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0];
                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0][key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0][key] = this.internalContactsComponent.internalContact_Marketer_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.MarketerFXSpecialist = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0]['Employee_Name__c'];
                    }
                    else {
                        keysArr.forEach(key => {
                            if (internalContact[key] !== undefined) {
                                internalContact[key] = this.internalContactsComponent.internalContact_Marketer_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.MarketerFXSpecialist = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer')[0]['Employee_Name__c'];
                    }

                    internalContact = new SPOQ_InternalContact();
                    keysArr = Object.keys(this.internalContactsComponent.internalContact_MarketerAssociateAnalyst_Form.controls);

                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                        && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer Associate/Analyst').length > 0) {
                        //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer Associate/Analyst')[0];
                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer Associate/Analyst')[0][key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Marketer Associate/Analyst')[0][key] = this.internalContactsComponent.internalContact_MarketerAssociateAnalyst_Form.get(key).value;
                            }
                        });
                    }
                    else {
                        keysArr.forEach(key => {
                            if (internalContact[key] !== undefined) {
                                internalContact[key] = this.internalContactsComponent.internalContact_MarketerAssociateAnalyst_Form.get(key).value;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                    }

                    if (this.productTypeVal === 'FX') {
                        internalContact = new SPOQ_InternalContact();
                        keysArr = Object.keys(this.internalContactsComponent.internalContact_TreasuryManagementSalesConsultant_Form.controls);

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Treasury Management Sales Consultant').length > 0) {
                            //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Treasury Management Sales Consultant')[0];

                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Treasury Management Sales Consultant')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'Treasury Management Sales Consultant')[0][key] = this.internalContactsComponent.internalContact_TreasuryManagementSalesConsultant_Form.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (internalContact[key] !== undefined) {
                                    internalContact[key] = this.internalContactsComponent.internalContact_TreasuryManagementSalesConsultant_Form.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                        }

                        internalContact = new SPOQ_InternalContact();
                        keysArr = Object.keys(this.internalContactsComponent.internalContact_OLSSpecialist_Form.controls);

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'OLS Specialist').length > 0) {
                            //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'OLS Specialist')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'OLS Specialist')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'OLS Specialist')[0][key] = this.internalContactsComponent.internalContact_OLSSpecialist_Form.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (internalContact[key] !== undefined) {
                                    internalContact[key] = this.internalContactsComponent.internalContact_OLSSpecialist_Form.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                        }

                        internalContact = new SPOQ_InternalContact();
                        keysArr = Object.keys(this.internalContactsComponent.internalContact_ITM_Form.controls);

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'ITM').length > 0) {
                            //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'ITM')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'ITM')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'ITM')[0][key] = this.internalContactsComponent.internalContact_ITM_Form.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (internalContact[key] !== undefined) {
                                    internalContact[key] = this.internalContactsComponent.internalContact_ITM_Form.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                        }

                        internalContact = new SPOQ_InternalContact();
                        keysArr = Object.keys(this.internalContactsComponent.internalContact_DoCOCPMGContact_Form.controls);

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'DoCO-CPMG Contact').length > 0) {
                            //internalContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'DoCO-CPMG Contact')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'DoCO-CPMG Contact')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(i => i.InternalContactType__c === 'DoCO-CPMG Contact')[0][key] = this.internalContactsComponent.internalContact_DoCOCPMGContact_Form.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (internalContact[key] !== undefined) {
                                    internalContact[key] = this.internalContactsComponent.internalContact_DoCOCPMGContact_Form.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(internalContact);
                        }
                    }

                    console.log(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts);

                    //#endregion
                    break;
                case 'Entity Information':
                    //#region Entity Information
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation = [];
                    var spoqEntities = []
                    this.entityInformationComponent.gridApi.forEachNode(function (node) {
                        spoqEntities.push(node.data);
                    });

                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.concat(spoqEntities);

                    //#endregion
                    break;
                case 'Documentation Request':
                    //#region Documentation Request
                    // keysArr = Object.keys(new SPOQ_DocumentationRequest());

                    // keysArr.forEach(key => {
                    //     if (this.documentationRequestComponent.documentationRequestForm.get(key) && this.documentationRequestComponent.documentationRequestForm.get(key).value) {
                    //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.documentationRequestForm.get(key).value;
                    //     }
                    //     else{
                    //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = null;
                    //     }
                    // });

                    keysArr = Object.keys(this.documentationRequestComponent.documentationRequestForm.controls);
                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.documentationRequestForm.get(key).value;
                        }
                    });

                    if (this.documentationRequestComponent.documentationRequestForm.get('Dodd_Frank_Documentation__ui') && this.documentationRequestComponent.documentationRequestForm.get('Dodd_Frank_Documentation__ui').value) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Dodd_Frank_Documentation__c = this.documentationRequestComponent.documentationRequestForm.get('Dodd_Frank_Documentation__ui').value.join(';');
                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Dodd_Frank_Documentation__c = null;
                    }

                    console.log(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r);

                    //#endregion
                    break;
                case 'FX Documentation Request':
                    //#region FX Documentation Request
                    // keysArr = Object.keys(new SPOQ_DocumentationRequest());

                    // keysArr.forEach(key => {
                    //     if (this.documentationRequestComponent.documentationRequestForm.get(key)&& this.documentationRequestComponent.documentationRequestForm.get(key).value) {
                    //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.documentationRequestForm.get(key).value;
                    //     }
                    //     else{
                    //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = null;
                    //     }
                    // });

                    // keysArr.forEach(key => {
                    //     if (this.documentationRequestComponent.fxDocumentationRequestForm.get(key) && this.documentationRequestComponent.fxDocumentationRequestForm.get(key).value) {
                    //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.fxDocumentationRequestForm.get(key).value;
                    //     }
                    //     else{
                    //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = null;
                    //     }
                    // });

                    keysArr = Object.keys(this.documentationRequestComponent.fxDocumentationRequestForm);
                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.documentationRequestForm.get(key).value;
                        }
                    });

                    keysArr = Object.keys(this.documentationRequestComponent.fxDocumentationRequestForm.controls);
                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.fxDocumentationRequestForm.get(key).value;
                        }
                    });

                    if (this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Products__ui') && this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Products__ui').value) {
                        var fxSpecificProducts = this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Products__ui').value;
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c = this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Products__ui').value.join(';');

                        if (Array.isArray(fxSpecificProducts)) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.IsFxOnline = fxSpecificProducts.filter(i => i === 'FX Online').length > 0 && (this.documentationRequestComponent.fxDocumentationRequestForm.get('Is_FXOL_Client__c') && this.documentationRequestComponent.fxDocumentationRequestForm.get('Is_FXOL_Client__c').value === 'Yes') ? 'Yes' : 'No';
                        }
                        else {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.IsFxOnline = fxSpecificProducts.indexOf('FX Online') > 0 && (this.documentationRequestComponent.fxDocumentationRequestForm.get('Is_FXOL_Client__c') && this.documentationRequestComponent.fxDocumentationRequestForm.get('Is_FXOL_Client__c').value === 'Yes') ? 'Yes' : 'No';
                        }
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.IsFxOnline !== 'Yes') {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels = new SPOQ_FX_eChannels();
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.IsFxOnline = 'No';
                        }

                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Products__c = null;
                    }

                    if (this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Master_Agreement_Type__ui') && this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Master_Agreement_Type__ui').value) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__c = this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Master_Agreement_Type__ui').value.join(';');
                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Master_Agreement_Type__c = null;
                    }

                    if (this.documentationRequestComponent.fxDocumentationRequestForm.get('Amendment__ui') && this.documentationRequestComponent.fxDocumentationRequestForm.get('Amendment__ui').value) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__c = this.documentationRequestComponent.fxDocumentationRequestForm.get('Amendment__ui').value.join(';');
                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.Amendment__c = null;
                    }

                    if (this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Credit_Support_Document__ui') && this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Credit_Support_Document__ui').value) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__c = this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Credit_Support_Document__ui').value.join(';');
                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Credit_Support_Document__c = null;
                    }

                    if (this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Currencies__ui') && this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Currencies__ui').value) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__c = this.documentationRequestComponent.fxDocumentationRequestForm.get('FX_Specific_Currencies__ui').value.join(';');
                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.FX_Specific_Currencies__c = null;
                    }

                    //console.log(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r);

                    //#endregion

                    break;
                case 'Customer Contact':
                    //#region Customer Contact 
                    if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps') {
                        // keysArr = Object.keys(this.documentationRequestComponent.fxDocumentationRequestForm.controls);
                        // keysArr.forEach(key => {
                        //     if(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key]){
                        //         this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r[key] = this.documentationRequestComponent.fxDocumentationRequestForm.get(key).value;
                        //     }
                        // });

                        keysArr = Object.keys(this.customerContactComponent.customerContactDocumentationForm.controls);
                        let spoq_CustomerContact = new SPOQ_CustomerContact();
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Documentation').length > 0) {
                            //spoq_CustomerContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Documentation')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Documentation')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Documentation')[0][key] = this.customerContactComponent.customerContactDocumentationForm.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (spoq_CustomerContact[key] !== undefined) {
                                    spoq_CustomerContact[key] = this.customerContactComponent.customerContactDocumentationForm.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.push(spoq_CustomerContact);
                        }

                        spoq_CustomerContact = new SPOQ_CustomerContact();
                        keysArr = Object.keys(this.customerContactComponent.customerContactLegalCounselForm.controls);

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Legal Counsel').length > 0) {
                            //spoq_CustomerContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Legal Counsel')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Legal Counsel')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Legal Counsel')[0][key] = this.customerContactComponent.customerContactLegalCounselForm.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (spoq_CustomerContact[key] !== undefined) {
                                    spoq_CustomerContact[key] = this.customerContactComponent.customerContactLegalCounselForm.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.push(spoq_CustomerContact);
                        }

                        spoq_CustomerContact = new SPOQ_CustomerContact();
                        keysArr = Object.keys(this.customerContactComponent.customerContactSettlementInvoicesForm.controls);

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.length > 0
                            && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Settlement').length > 0) {
                            //spoq_CustomerContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Settlement')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Settlement')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'Settlement')[0][key] = this.customerContactComponent.customerContactSettlementInvoicesForm.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (spoq_CustomerContact[key] !== undefined) {
                                    spoq_CustomerContact[key] = this.customerContactComponent.customerContactSettlementInvoicesForm.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.push(spoq_CustomerContact);
                        }
                    }
                    if (this.productTypeVal === 'FX') {
                        keysArr = Object.keys(this.customerContactComponent.customerContactDocumentationForm.controls);
                        let spoq_CustomerContact = new SPOQ_CustomerContact();

                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts != null && this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.length > 0) {
                            //spoq_CustomerContact = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact')[0];
                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact')[0][key] = this.customerContactComponent.customerContactDocumentationForm.get(key).value;
                                }
                            });

                            keysArr = Object.keys(this.customerContactComponent.customerContactFXConfirmationsForm.controls);

                            keysArr.forEach(key => {
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact')[0][key] !== undefined) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact')[0][key] = this.customerContactComponent.customerContactFXConfirmationsForm.get(key).value;
                                }
                            });
                        }
                        else {
                            keysArr.forEach(key => {
                                if (spoq_CustomerContact[key] !== undefined) {
                                    spoq_CustomerContact[key] = this.customerContactComponent.customerContactDocumentationForm.get(key).value;
                                }
                            });

                            keysArr = Object.keys(this.customerContactComponent.customerContactFXConfirmationsForm.controls);
                            keysArr.forEach(key => {
                                if (spoq_CustomerContact[key] !== undefined) {
                                    spoq_CustomerContact[key] = this.customerContactComponent.customerContactFXConfirmationsForm.get(key).value;
                                }
                            });

                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts.push(spoq_CustomerContact);
                        }
                    }


                    console.log(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts);

                    //#endregion
                    break;
                case 'Loan and Credit Support':
                    //#region Loan and Credit Support

                    keysArr = Object.keys(this.loanAndCreditSupportComponent.loanAndCreditSupportForm.controls);
                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_LoanAndCreditSupport[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_LoanAndCreditSupport[key] = this.loanAndCreditSupportComponent.loanAndCreditSupportForm.get(key).value;
                        }
                    });

                    console.log(this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_LoanAndCreditSupport);


                    //#endregion

                    break;
                case 'eChannels':
                    //#region eChannels
                    //debugger

                    if (this.eChannelsComponent.eChannelsForm.get('IsFxOnline') && this.eChannelsComponent.eChannelsForm.get('IsFxOnline').value === 'Yes') {
                        keysArr = Object.keys(this.eChannelsComponent.eChannelsForm.controls);
                        keysArr.forEach(key => {
                            if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels[key] !== undefined) {
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels[key] = this.eChannelsComponent.eChannelsForm.get(key).value;
                            }
                        });
                    }
                    else {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels = new SPOQ_FX_eChannels();
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_FX_eChannels.IsFxOnline = 'No';
                    }

                    //#endregion
                    break;
                default:
                    break;
            }
        }
        else {
            let keysArr = [];
            keysArr = Object.keys(this.reqForm.controls);

            keysArr.forEach(key => {
                if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r[key] !== undefined) {
                    this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r[key] = this.reqForm.get(key).value;
                }
                else if (this.reqForm.get('New_Wires__c') && this.reqForm.get('New_Wires__c').value && this.reqForm.get('New_Wires__c').value === 'Yes'
                    && this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput[key] !== undefined) {

                    this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput[key] = this.reqForm.get(key).value;
                }
            });

            console.log(this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r);
        }
    }

    getMainTabFormValues() {
        let keysArr = [];
        switch (this.selectedMainTab) {
            case 'Tax Information':
                if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
                    keysArr = Object.keys(this.taxInformationComponent.taxInformationForm.controls);
                    if (this.taxInformationComponent.taxInformationForm.touched) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails.IsModified = true;
                    }
                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.COBAM_TaxDetails[key] = this.taxInformationComponent.taxInformationForm.get(key).value;
                        }
                    });
                }
                else {
                    keysArr = Object.keys(this.taxInformationComponent.taxInformationForm.controls);
                    keysArr.forEach(key => {
                        if (this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails[key] !== undefined) {
                            this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.COBAM_TaxDetails[key] = this.taxInformationComponent.taxInformationForm.get(key).value;
                        }
                    });
                }

                break;

            default:
                break;
        }
    }

    populateForm(onboardingRequsetIdVal) {

    }

    saveDetails() {
        //debugger
        this.isLoading = true;
        if (this.onboardingRequsetIdVal != null && this.onboardingRequsetIdVal !== '') {
            this.updateDetailsService();
        } else {
            this.saveDetailsservice('SAVE');
        }
    }

    saveDetailsAsTemplate() {
        this.reqForm.get('Is_Template__c') ? this.reqForm.get('Is_Template__c').setValue(true) : null;
    }

    updateDetailsService() {
    }

    saveDetailsservice(userAction: string) {
        if ((this.productTypeVal === 'Fixed Income' || this.productTypeVal === 'Prime'
            || this.productTypeVal === 'FCM' || this.productTypeVal === 'Agency'
            || this.productTypeVal === 'Loan Sales') || (this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Cash')) {

            this.saveCashRequest(userAction);
        }
        else if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
            this.saveNonCashRequest(userAction);
        }

        this.isLoading = false;
    }

    saveCashRequest(userAction: string) {

        this.getFormValues();
        if (this.queueStatus !== 'Draft') {
            this.getMainTabFormValues();
        }

        this.onboardingDetailRequestService.onboardingRequest.UserAction = userAction;
        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.ProductSettlementType__c = this.productSettlementType;
        console.log(this.onboardingDetailRequestService.onboardingRequest);
        this.payLoad = JSON.stringify(this.onboardingDetailRequestService.onboardingRequest);
        console.log(this.payLoad);
        this.onboardingDetailRequestService.AddOnboardingRequest(this.payLoad).subscribe(
            data => {
            }
        );
    }

    saveNonCashRequest(userAction: string) {
        //debugger
        this.getFormValues();
        if (this.queueStatus !== 'Draft') {
            this.getMainTabFormValues();
        }

        this.onboardingDetailRequestService.onboardingRequest.UserAction = userAction;
        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.ProductSettlementType__c = this.productSettlementType;
        console.log(this.onboardingDetailRequestService.onboardingRequest);
        this.payLoad = JSON.stringify(this.onboardingDetailRequestService.onboardingRequest);
        console.log(this.payLoad);
        this.onboardingDetailRequestService.AddOnboardingRequest(this.payLoad).subscribe(
            data => {
            }
        );
    }


    enableDisableQueueStatus(onBoardingRole?: string, currentStatus?: string): void {
        if ((this.productTypeVal === 'Fixed Income' || this.productTypeVal === 'Prime'
            || this.productTypeVal === 'FCM' || this.productTypeVal === 'Agency'
            || this.productTypeVal === 'Loan Sales') || (this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Cash')) {

            if (this.onboardingRole && (this.onboardingRole === 'Facilitator' || this.onboardingRole === 'Facilitator Manager' || this.onboardingRole === 'Account Approval')) {
                this.reqForm.get('Status__c').enable()
            }
            else {
                this.reqForm.get('Status__c').disable()
            }
        }
        else if ((this.productTypeVal === 'Equities' && this.productSubTypeVal === 'Derivatives') || this.productTypeVal === 'Swaps' || this.productTypeVal === 'FX') {
            if (this.onboardingRole && (this.onboardingRole === 'DCOT' || this.onboardingRole === 'Account Approval')) {
                this.reqForm.get('Status__c').enable()
            }
            else {
                this.reqForm.get('Status__c').disable()
            }
        }
    }

    setDisplayModeForCallbackTHirdParty(): void {
        if (this.onboardingRole === 'Client Services') {
            if (this.reqForm.get('Notes__c')) {
                this.reqForm.get('Notes__c').disable();
            }
            if (this.reqForm.get('callback_Status__c')) {
                this.reqForm.get('callback_Status__c').enable();
            }
            if (this.reqForm.get('callback_Time__c')) {
                this.reqForm.get('callback_Time__c').enable();
            }
        } else {
            if (this.reqForm.get('Notes__c')) {
                this.reqForm.get('Notes__c').enable();
            }
            if (this.reqForm.get('callback_Status__c')) {
                this.reqForm.get('callback_Status__c').disable();
            }
            if (this.reqForm.get('callback_Time__c')) {
                this.reqForm.get('callback_Time__c').disable();
            }
        }

        if (this.reqForm.get('third_Party_Exception_Approval_Status__c')) {
            this.reqForm.get('third_Party_Exception_Approval_Status__c').disable();
        }

        if (
            this.reqForm.get('Status__c') &&
            this.reqForm.get('Status__c').value === 'Draft'
        ) {
            if (this.reqForm.get('third_Party_Request_Type__c')) {
                this.reqForm.get('third_Party_Request_Type__c').enable();
            }
            if (this.reqForm.get('beneficiary_ID_Type__c')) {
                this.reqForm.get('beneficiary_ID_Type__c').enable();
            }
            if (this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c')) {
                this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').enable();
            }
            if (this.reqForm.get('intermediary_Bank_ID_Type__c')) {
                this.reqForm.get('intermediary_Bank_ID_Type__c').enable();
            }
            if (this.reqForm.get('source_Type__c')) {
                this.reqForm.get('source_Type__c').enable();
            }
        } else {
            if (this.reqForm.get('third_Partythird_Party_Request_Type__c_Exception_Approval_Status__c')) {
                this.reqForm.get('third_Party_Request_Type__c').disable();
            }
            if (this.reqForm.get('beneficiary_ID_Type__c')) {
                this.reqForm.get('beneficiary_ID_Type__c').disable();
            }
            if (this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c')) {
                this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').disable();
            }
            if (this.reqForm.get('intermediary_Bank_ID_Type__c')) {
                this.reqForm.get('intermediary_Bank_ID_Type__c').disable();
            }
            if (this.reqForm.get('source_Type__c')) {
                this.reqForm.get('source_Type__c').disable();
            }
        }
    }

    showhidetabsbuttons() {
        switch (this.onboardingRole) {
            case 'Requester':
            case 'Requester NonCash':
                switch (this.queueStatus) {
                    case 'Draft':
                        this.showSaveButton = true;
                        this.showSubmitButton = true;
                        if (!this.showNonCashTabs) {
                            this.showSaveTemplateButton = true;
                        }
                        break;
                    case 'Closed - Rejected':
                        this.showSaveButton = true;
                        this.showSubmitButton = true;
                        break;

                    default:
                        this.showSaveButton = false;
                        this.showSubmitButton = false;
                        this.showSaveTemplateButton = false;
                        break;
                }
                break;

            default:
                break;
        }
    }

    setMarginTypeVisiblity() {
        //console.log(this.reqForm.controls['External_system_list__c']);
        if (this.productTypeVal === 'Prime') {

            this.reqForm.controls['Margin_Type__c'] ? this.reqForm.controls['Margin_Type__c'].setValue(null) : null;

            if (this.reqForm.controls['External_system_list__c'] && this.reqForm.controls['External_system_list__c'].value.length == 1) {
                if (this.reqForm.controls['External_system_list__c'].value[0].indexOf('BRWFB : BROADRIDGE - WELLS FARGO BANK NA') > -1) {
                    this.reqForm.controls['Margin_Type_Visiblity_UI'].setValue('BRWFB');
                }
                else if (this.reqForm.controls['External_system_list__c'].value[0].indexOf('BRWFS : BROADRIDGE - WELLS FARGO SEC') > -1) {
                    this.reqForm.controls['Margin_Type_Visiblity_UI'].setValue('BRWFS');
                }
                else {
                    this.reqForm.controls['Margin_Type_Visiblity_UI'].setValue('All');
                }
            }
            else if (this.reqForm.controls['External_system_list__c'] && this.reqForm.controls['External_system_list__c'].value.length > 1) {
                this.reqForm.controls['Margin_Type_Visiblity_UI'].setValue('All');
            }
            else {
                this.reqForm.controls['Margin_Type_Visiblity_UI'].setValue('');
            }
        }
    }

    setCustomerClassification() {
        let customerClassification: string = '';
        if (this.reqForm.controls['Legal_Code__c'] && this.reqForm.controls['Legal_Code__c'].value !== '') {
            switch (this.reqForm.controls['Legal_Code__c'].value) {
                case '011':
                    customerClassification = 'Individual'
                    break;
                case '015':
                    customerClassification = 'Sole Proprietorship'
                    break;
                case '020':
                    customerClassification = 'General Partnerships'
                    break;
                case '025':
                    customerClassification = 'Limited Partnerships'
                    break;
                case '030':
                    customerClassification = 'Association'
                    break;
                case '035':
                    customerClassification = 'Joint Venture'
                    break;
                case '040':
                    customerClassification = 'Corporations'
                    break;
                case '045':
                    customerClassification = 'Limited Liability Company'
                    break;
                case '050':
                    customerClassification = 'Limited Liability Partnership'
                    break;
                case '101':
                    customerClassification = 'NDFI-COMMERCIAL EQUITY REIT'
                    break;
                case '102':
                    customerClassification = 'NDFI-COMMERCIAL MORTGAGE REIT'
                    break;
                case '105':
                    customerClassification = 'NDFI-Investment Bank'
                    break;
                case '106':
                    customerClassification = 'NDFI-Insurance Company'
                    break;
                case '107':
                    customerClassification = 'NDFI-Non -Profit Insurance Company'
                    break;
                case '108':
                    customerClassification = 'NDFI-Lend Agcy/Co that Extend Credit'
                    break;
                case '109':
                    customerClassification = 'NDFI-Non-Profit Lend Agcy/Co Ext Credit'
                    break;
                case '110':
                    customerClassification = 'NDFI-Holdiing Co of Other Deposit Instit'
                    break;
                case '111':
                    customerClassification = 'NDFI-Asset Management'
                    break;
                case '112':
                    customerClassification = 'NDFI CLOs'
                    break;
                case '200':
                    customerClassification = 'Foreign Domiciled Business'
                    break;
                case '201':
                    customerClassification = 'Foreign Government'
                    break;
                case '208':
                    customerClassification = 'Foreign Central Bank'
                    break;
                case '209':
                    customerClassification = 'Foreign Branches of US Banks'
                    break;
                case '212':
                    customerClassification = 'Non-CmBG Borrower'
                    break;
                case '213':
                    customerClassification = 'Foreign Banks & Fgn Branches of Fgn Bank'
                    break;
                case '215':
                    customerClassification = 'Non-Profit'
                    break;
                case '216':
                    customerClassification = 'Trust'
                    break;
                case '220':
                    customerClassification = 'US Branches of Foreign Banks'
                    break;
                case '300':
                    customerClassification = 'Wells Fargo and Company Affiliates'
                    break;
                case '610':
                    customerClassification = 'Domestic Banks'
                    break;
                case '612':
                    customerClassification = 'Other Financial Insitutions'
                    break;
                case '650':
                    customerClassification = 'State or Local Government Entities, Agencies,'
                    break;
                case '651':
                    customerClassification = 'US Government'
                    break;
                case '660':
                    customerClassification = 'US Government Agencies'
                    break;
                case '665':
                    customerClassification = 'US Government Sponsored Enterprise'
                    break;
                case '700':
                    customerClassification = 'Borrowers Not Elsewhere Classified'
                    break;
                case '211':
                    customerClassification = 'Fed Fund Line Borrower'
                    break;
                default:
                    customerClassification = ''
                    break;
            }
        }

        this.reqForm.controls['Customer_Classification__c'].setValue(customerClassification);
    }

    setCDDSubType() {
        if (this.reqForm.controls['CDD_Sub_Type__c']) {
            //this.reqForm.controls['CDD_Sub_Type__c'].setValue('');
        }
    }

    setCDDTypeAndSubtype() {
        if (this.reqForm.controls['CDD_Type__c'] && this.reqForm.controls['CDD_Type__c'].value !== '') {
            switch (this.reqForm.controls['CDD_Type__c'].value) {
                case 'Individuals, Joint Account holders, IRAs, Custodian':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Individuals, Joint Account holders, IRAs, Custodian');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Operating':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Operating_Operating');
                                break;
                            case 'Unregistered Investment Advisor':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Operating_Unregistered Investment Advisor');
                                break;

                            case 'Fund':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Operating_Fund');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'General Partnerships':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('General Partnerships');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Operating Limited Partnership or LLP':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP');
                                break;
                            case 'Unregistered Investment Manager / Advisor':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor');
                                break;

                            case 'Registered Investment Manager/Advisor':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Limited Partnerships or Limited Liability Partnerships_Registered Investment Manager/Advisor');
                                break;
                            case 'Fund':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Limited Partnerships or Limited Liability Partnerships_Fund');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Trusts with Regulated Trustees':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Trusts with Regulated Trustees');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Trusts with Unregulated Trustees':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Trusts with Unregulated Trustees');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]. US Regulated Credit or Financial Institutions':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('US Regulated Credit or Financial Institutions');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Non-US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisors, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Non-US Regulated Credit or Financial Institutions: Banks':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Non-US Regulated Credit or Financial Institutions: Banks');
                                break;
                            case 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Company Listed on Approved Exchange and Subsidiaries':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Companies on Approved Exchange':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Company Listed on Approved Exchange and Subsidiaries_Companies on Approved Exchange');
                                break;
                            case 'Subsidiary of Listed Parent (>50% Ownership)':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Company Listed on Approved Exchange and Subsidiaries_Subsidiary of Listed Parent (>50% Ownership)');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Pension Plans':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'ERISA':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Pension Plans_ERISA');
                                break;
                            case 'Non ERISA':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Pension Plans_Non ERISA');
                                break;
                            case 'State, Municipal, or Government Pension Plan':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Pension Plans_State, Municipal, or Government Pension Plan');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Local/Domestic Government and Public Authorities / Public Utilities':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Local/Domestic Government and Public Authorities / Public Utilities');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('');
                    break;

                case 'Foreign Government and Public Authorities [i.e., other Government- Regulated Entities, Consulates, Embassies, Foreign Ministries/Mission, Honorary Consul and Sovereign Wealth Funds]':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds');
                                break;
                            case 'Foreign Government and Public Authorities: Consulates':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Foreign Government and Public Authorities: Consulates');
                                break;
                            case 'Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits [including Educational Institutions, Research Institutes, Churches, Professional Associations and Lobby Groups]':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Central Banks, National Monetary Authorities and Supranational Organizations':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Central Bank':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Central Banks, National Monetary Authorities and Supranational Organizations_Central Bank');
                                break;
                            case 'National Monetary authority':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Central Banks, National Monetary Authorities and Supranational Organizations_National Monetary authority');
                                break;
                            case 'Supranational Organization':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Central Banks, National Monetary Authorities and Supranational Organizations_Supranational Organization');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Estates':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Estates');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Personal Investment / Holding Companies or Sole Proprietorships':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case 'Personal Investment or Holding Co.':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.');
                                break;
                            case 'Sole Proprietorship':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                case 'Wells Fargo & Co. Affiliates and Subsidiaries':
                    if (this.reqForm.controls['CDD_Sub_Type__c'] && this.reqForm.controls['CDD_Sub_Type__c'].value !== '') {
                        switch (this.reqForm.controls['CDD_Sub_Type__c'].value) {
                            case '--N/A--':
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue('Wells Fargo & Co. Affiliates and Subsidiaries');
                                break;
                            default:
                                this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                                break;
                        }
                    }
                    break;

                default:
                    this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
                    break;
            }

        }
        else if (this.reqForm.controls['CDD_Type__c'] && this.reqForm.controls['CDD_Type__c'].value === '') {
            this.reqForm.controls['CDD_Type_And_Sub_Type__c'].setValue(null);
        }
    }

    reRunDrools() {
        alert('Reset Rules Engine clicked');
    }

    refreshWI() {
        alert('Refresh Work Items clicked');
    }

    // showCallbackAndthirdPartyFields(){
    //     if(this.reqForm.get('New_Wires__c') && this.reqForm.get('New_Wires__c').value === 'Yes'){
    //         alert('in New Wire');
    //         this.formFields.concat(this.onboardingDetailRequestService.buildCallbackAndThirdpartyFields());

    //         this.reqForm = this.qcs.toFormGroup(this.formFields);
    //     }
    // }

    openSearchModal(template, legalTemplate, cobamLookupTemplate, value: string): void {
        //debugger
        if (value !== '[object Event]' && value !== '[object MouseEvent]') {
            switch (value) {
                case 'Address':
                    this.legalAddressTable = new Array<Address>();
                    this.getLegalAdressData();
                    this.legalAddressSearchDialogRef = this.dialog.open(legalTemplate, {
                        width: '40%'
                    });
                    break;
                case 'Expense Code':
                case 'Primary SIC':
                    this.searchTitle = value;
                    this.searchDialogRef = this.dialog.open(template, {
                        width: '50%',
                        height: '60%'
                    });
                    break;
                default:
                    this.searchTitle = value;
                    this.searchDialogRef = this.dialog.open(template, {
                        width: '80%',
                        height: '90%'
                    });
                    break;
            }
        }
    }

    onModalClose() {
        this.searchDialogRef.close();
    }

    selectRowData(value: any, legalTemplate: any): void {
        //debugger
        switch (this.searchTitle) {
            case 'SPOQLegal':
                this.legalId = value.LegalId;
                if (this.showNonCashTabs) {
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length <= 0) {
                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.push(new SPOQ_EntityInformation());
                    }
                    if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.length > 0) {
                        this.onboardingDetailRequestService.getCounterpartyAndComplianceDetailsByLegalId(value.ClientId, value.LegalId).subscribe(data => {
                            if (data) {
                                //console.log(data);
                                this.onModalClose();
                                let legalDetails = JSON.parse(JSON.stringify(data));
                                if (legalDetails.CIDLegalId) {
                                    if (this.reqForm.controls['Build_Type__c'].value !== 'New Bus Acc Only') {
                                        alert('The selected Legal has a record in CID, the Build Type will be updated to "New Bus Acc Only"');
                                        this.reqForm.controls['Build_Type__c'].setValue('New Bus Acc Only', { emitEvent: false });
                                    }
                                }
                                else {
                                    if (this.reqForm.controls['Build_Type__c'].value !== 'New Legal & Bus Acc') {
                                        alert('The selected Legal doesn\'t have a record in CID, the Build Type will be updated to  "New Legal & Bus Acc"');
                                        this.reqForm.controls['Build_Type__c'].setValue('New Legal & Bus Acc', { emitEvent: false });
                                    }
                                }
                                if (legalDetails.RestrictedLegalReasons !== undefined && legalDetails.RestrictedLegalReasons !== null && legalDetails.RestrictedLegalReasons !== '') {

                                    alert('LEGALID:' + legalDetails.CIDLegalId + ', Legal Name:' + legalDetails.FullLegalName + ' is in Restricted status for Reason(s):' + legalDetails.RestrictedLegalReasons + '.\n' +
                                        'You may proceed with COBAM submission, however, please note that an account will not be created until the above mentioned Legal Restriction(s) have been reviewed/ lifted.\n' +
                                        'Please coordinate with the appropriate WFS CDD or WFS Facilitations team to have this restriction reviewed/lifted to proceed with account opening.\n' +

                                        'For any questions, please contact:\n' +
                                        'WFS CDD Onboarding: G=WFS CDD Onboarding Team \n' +
                                        'WFS EMEA CDD Onboarding: G=WFS EMEA CDD Onboarding Team');
                                }
                                this.reqForm.controls['Legal_Name__c'].setValue(legalDetails.FullLegalName, { emitEvent: false });
                                this.reqForm.controls['Legal_Id__c'].setValue(value.LegalId, { emitEvent: false });
                                this.reqForm.controls['WCIS_ID__c'].setValue(legalDetails.WCISId);
                                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion).length <= 0) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.concat(new SPOQ_EntityInformation());
                                }

                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].MiFID_II_Clnt_Cat_Internal_Use__c = legalDetails.MiFIDIIClientCategorization;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].RestrictedLegalReasons__c = legalDetails.RestrictedLegalReasons;
                                if (this.reqForm.controls['MiFID_II_Client_Categorization__c']) {
                                    this.reqForm.controls['MiFID_II_Client_Categorization__c'].setValue(legalDetails.MiFIDIIClientCategorization);
                                }
                                if (this.reqForm.controls['WFS_Entity__c'].value.includes('WFSAL')) {
                                    this.reqForm.controls['Hong_Kong_Classification__c'].setValue(value.HongKongInvClass);
                                    //this.reqForm.controls['HongKongClassificationUI'].setValue(value.HongKongInvClass);

                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.ProdMrkCoverage)) {
                                        this.reqForm.controls['Product_group_Market_coverage__c'].setValue(legalDetails.ProdMrkCoverage.replace(/,/g, ';'));
                                        this.reqForm.controls['ProductCoverageUI'].setValue(legalDetails.ProdMrkCoverage.replace(/,/g, ';'));
                                    }

                                    this.reqForm.controls['CPI_Letter_Complete__c'].setValue(legalDetails.CPILetterComplete);
                                    this.reqForm.controls['Comments__c'].setValue(legalDetails.APACComments);
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.HongKongInvClass)) {
                                        this.reqForm.controls['APAC_Status__c'].setValue('Approved');
                                    }
                                }

                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Id__c = legalDetails.LegalId;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Name__c = legalDetails.FullLegalName;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].WCIS_ID__c = legalDetails.WCISId;

                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Tax_Id__c = legalDetails.TaxIdNumber;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].RequesterTax__ui = legalDetails.TaxIdNumber ? legalDetails.TaxIdNumber.substring(0, 5).replace(/\d/g, "X") + legalDetails.TaxIdNumber.substring(5, 9) : null;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].SSN__c = legalDetails.SSN;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].RequesterSSN__ui = legalDetails.SSN ? legalDetails.SSN.substring(0, 5).replace(/\d/g, "X") + legalDetails.SSN.substring(5, 9) : null;
                                if (legalDetails.CountryOrganized) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Country_Organized__c = this.onboardingDetailRequestService.countryOptions().filter(s => s.key.startsWith(legalDetails.CountryOrganized))[0].key;
                                    if (legalDetails.CountryOrganized === 'US') {
                                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.StateOrProvinceOrganized)) {
                                            if (this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized)).length > 0) {
                                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].StateOrProvinceOrganized__c = this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized))[0].key;
                                            }
                                        }
                                    }
                                    else if (legalDetails.CountryOrganized === 'CA') {
                                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.StateOrProvinceOrganized)) {
                                            if (this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized)).length > 0) {
                                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].StateOrProvinceOrganized__c = this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.StateOrProvinceOrganized))[0].key;
                                            }
                                        }
                                    }
                                }
                                if (legalDetails.COBAMLegalAddressDetails) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Address1__c = legalDetails.COBAMLegalAddressDetails.Address1;
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Address2__c = legalDetails.COBAMLegalAddressDetails.Address2;
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_City__c = legalDetails.COBAMLegalAddressDetails.City;
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Zip__c = legalDetails.COBAMLegalAddressDetails.Zip;
                                    if (legalDetails.COBAMLegalAddressDetails.CountryCode) {
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_Country__c = this.onboardingDetailRequestService.countryOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.CountryCode))[0].key;
                                        if (legalDetails.COBAMLegalAddressDetails.CountryCode === 'US') {
                                            if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.COBAMLegalAddressDetails.State)) {
                                                if (this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State)).length > 0) {
                                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_State__c = this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State))[0].key;
                                                }
                                            }
                                        }
                                        else if (legalDetails.COBAMLegalAddressDetails.CountryCode === 'CA') {
                                            if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.COBAMLegalAddressDetails.State)) {
                                                if (this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State)).length > 0) {
                                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Legal_State__c = this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.COBAMLegalAddressDetails.State))[0].key;
                                                }
                                            }
                                        }
                                    }

                                }

                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.EntityType)) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Entity_Type__c = this.onboardingDetailRequestService.getEntityTypeOptions().filter(s => s.key.startsWith(legalDetails.EntityType))[0].key;
                                }
                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.ClientType)) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Client_Type__c = this.onboardingDetailRequestService.getClientType(legalDetails.ClientType);
                                }
                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.ClientSubType)) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Client_SubType__c = this.onboardingDetailRequestService.getClientSubType(legalDetails.ClientSubType);
                                }
                                if (legalDetails.CountryOrganized !== 'US') {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Government_ID_Number__c = legalDetails.GovernmentIDNumber;
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.GovernmentIDType)) {
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Government_ID_Type__c = this.onboardingDetailRequestService.buildGovermentIdTypeOptions().filter(t => t.key === legalDetails.GovernmentIDType)[0].key;
                                    }
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.GovernmentIDIssuer)) {
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Government_ID_Issuer__c = this.onboardingDetailRequestService.countryOptions().concat({ key: 'ZZ - Z COUNTRY', value: 'ZZ - Z COUNTRY' }).filter(c => c.key === legalDetails.GovernmentIDIssuer)[0].key;
                                    }
                                }
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].Date_Of_Birth__c = legalDetails.DateOfBirth;

                                if (this.productTypeVal !== 'FX') {
                                    if (legalDetails.COBAMLegalComplianceDetails.isClientRegOCustomer != null || legalDetails.COBAMLegalComplianceDetails.isClientRegOCustomer != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.isClientRegOCustomer) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].isClientRegOCustomer__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].isClientRegOCustomer__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.HasappropriateExecutionofTransaction != null || legalDetails.COBAMLegalComplianceDetails.HasappropriateExecutionofTransaction != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.HasappropriateExecutionofTransaction) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].HasappropriateExecutionofTransaction__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].HasappropriateExecutionofTransaction__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsTransactionHedge != null || legalDetails.COBAMLegalComplianceDetails.IsTransactionHedge != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsTransactionHedge) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsTransactionHedge__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsTransactionHedge__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsInLegalDispute != null || legalDetails.COBAMLegalComplianceDetails.IsInLegalDispute != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsInLegalDispute) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsInLegalDispute__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsInLegalDispute__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsSecuritizationSPE != null || legalDetails.COBAMLegalComplianceDetails.IsSecuritizationSPE != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsSecuritizationSPE) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecuritizationSPE__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecuritizationSPE__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsSecSPESPV != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPESPV != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsSecSPESPV) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPESPV__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPESPV__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskTransferred != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskTransferred != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskTransferred) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPERiskTransferred__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPERiskTransferred__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskSeparated != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskSeparated != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsSecSPERiskSeparated) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPERiskSeparated__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPERiskSeparated__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEMultDebtTranche != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPEMultDebtTranche != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEMultDebtTranche) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPEMultDebtTranche__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPEMultDebtTranche__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEAllFinancialExp != null || legalDetails.COBAMLegalComplianceDetails.IsSecSPEAllFinancialExp != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsSecSPEAllFinancialExp) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPEAllFinancialExp__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsSecSPEAllFinancialExp__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsPoliticallyExposedPerson != null || legalDetails.COBAMLegalComplianceDetails.IsPoliticallyExposedPerson != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsPoliticallyExposedPerson) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IndPEPInfo__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IndPEPInfo__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.HasPoliticallyExposedPerson != null || legalDetails.COBAMLegalComplianceDetails.HasPoliticallyExposedPerson != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.HasPoliticallyExposedPerson) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].NonIndPEP__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].NonIndPEP__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsInternetGamblingBussiness != null || legalDetails.COBAMLegalComplianceDetails.IsInternetGamblingBussiness != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsInternetGamblingBussiness) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsInternetGamblingBussiness__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsInternetGamblingBussiness__c = 'No';
                                        }
                                    }

                                    if (legalDetails.COBAMLegalComplianceDetails.IsNonUSExeOrAffiliates != null || legalDetails.COBAMLegalComplianceDetails.IsNonUSExeOrAffiliates != undefined) {
                                        if (legalDetails.COBAMLegalComplianceDetails.IsNonUSExeOrAffiliates) {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsNonUSExeOrAffiliates__c = 'Yes';
                                        }
                                        else {
                                            this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].IsNonUSExeOrAffiliates__c = 'No';
                                        }
                                    }
                                }

                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CreateOrSelectCMA__c = null;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMA_Name__c = null;
                                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMAId__c = null;

                                if (legalDetails.MasterAliasId !== undefined && legalDetails.MasterAliasId !== null && legalDetails.MasterAliasId > 0) {
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CreateOrSelectCMA__c = 'Select existing CMA';
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMA_Name__c = legalDetails.MasterAliasName;
                                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMAId__c = legalDetails.MasterAliasId;
                                }
                                else {
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.WCISId)) {
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CreateOrSelectCMA__c = 'Select existing CMA';
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMA_Name__c = '';
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMAId__c = 0;
                                    }
                                    else {
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CreateOrSelectCMA__c = 'Create New CMA';
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMA_Name__c = legalDetails.FullLegalName;
                                        this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_EntityInformation.filter(e => !e.IsEntityMarkForDeletion)[0].CMAId__c = -1;
                                    }
                                }
                            }
                        });
                    }
                }
                break;
            case 'Legal':
                if (!this.showNonCashTabs) {
                    this.legalId = value.LegalId;
                    if (this.reqForm.controls['Legal_Name__c']) {
                        this.reqForm.controls['Legal_Name__c'].setValue(value.LegalFullName, { emitEvent: false });
                    }

                    if (this.reqForm.controls['CID_LEID__c']) {
                        this.reqForm.controls['CID_LEID__c'].setValue(value.LegalId, { emitEvent: false });
                        if (value.LegalId) {
                            if (this.reqForm.controls['Build_Type__c'].value !== 'New Bus Acc Only') {
                                alert('The selected Legal has a record in CID, the Build Type will be updated to "New Bus Acc Only"');
                                this.reqForm.controls['Build_Type__c'].setValue('New Bus Acc Only');
                            }
                        }
                        else {
                            if (this.reqForm.controls['Build_Type__c'].value !== 'New Legal & Bus Acc') {
                                alert('The selected Legal doesn\'t have a record in CID, the Build Type will be updated to  "New Legal & Bus Acc"');
                                this.reqForm.controls['Build_Type__c'].setValue('New Legal & Bus Acc');
                            }
                        }

                    }
                    if (value.AlertAcronym && this.reqForm.controls['Alert_Acronym__c']) {
                        this.reqForm.controls['Alert_Acronym__c'].setValue(value.AlertAcronym);
                    }

                    if (value.AlertAccessCode && this.reqForm.controls['Alert_code__c']) {
                        this.reqForm.controls['Alert_code__c'].setValue(value.AlertAccessCode);
                    }
                    if (value.ClientId && this.reqForm.controls['ClientId__c']) {
                        this.reqForm.controls['ClientId__c'].setValue(value.ClientId);
                    }
                    if (value.ClientType && this.reqForm.controls['Client_Type__c']) {
                        this.clientType = this.onboardingDetailRequestService.getClientType(value.ClientType);
                        this.reqForm.controls['Client_Type__c'].setValue(this.clientType);
                    }
                    if (value.ClientSubType && this.reqForm.controls['Client_SubType__c']) {
                        this.clientSubType = this.onboardingDetailRequestService.getClientSubType(value.ClientSubType);
                        this.reqForm.controls['Client_SubType__c'].setValue(this.clientSubType);
                    }
                    if (value.LegalType && this.reqForm.controls['Entity_Type__c']) {
                        this.entityType = this.onboardingDetailRequestService.getEntityTypeOptions().filter(s => s.key.startsWith(value.LegalType.trim()))[0].key
                        this.reqForm.controls['Entity_Type__c'].setValue(this.entityType);
                    }

                    this.onboardingDetailRequestService.getLegalDetailsForCOBAMCash(value.ClientId, value.LegalId).subscribe(data => {
                        if (data) {
                            let legalDetails = JSON.parse(JSON.stringify(data));
                            console.log(legalDetails);
                            if (this.reqForm.controls['WFS_Entity__c'].value.includes('WFSAL')) {
                                this.reqForm.controls['Hong_Kong_Classification__c'].setValue(value.HongKongInvClass);
                                //this.reqForm.controls['HongKongClassificationUI'].setValue(value.HongKongInvClass);

                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.ProdMrkCoverage)) {
                                    this.reqForm.controls['Product_group_Market_coverage__c'].setValue(legalDetails.ProdMrkCoverage.replace(/,/g, ';'));
                                    this.reqForm.controls['ProductCoverageUI'].setValue(legalDetails.ProdMrkCoverage.replace(/,/g, ';'));
                                }

                                this.reqForm.controls['CPI_Letter_Complete__c'].setValue(legalDetails.CPILetterComplete);
                                this.reqForm.controls['Comments__c'].setValue(legalDetails.APACComments);
                                if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.HongKongInvClass)) {
                                    this.reqForm.controls['APAC_Status__c'].setValue('Approved');
                                }
                            }
                            if (legalDetails.RestrictedLegalReasons !== undefined && legalDetails.RestrictedLegalReasons !== null && legalDetails.RestrictedLegalReasons !== '') {

                                alert('LEGALID:' + legalDetails.CIDLegalId + ', Legal Name:' + legalDetails.FullLegalName + ' is in Restricted status for Reason(s):' + legalDetails.RestrictedLegalReasons + '.\n' +
                                    'You may proceed with COBAM submission, however, please note that an account will not be created until the above mentioned Legal Restriction(s) have been reviewed/ lifted.\n' +
                                    'Please coordinate with the appropriate WFS CDD or WFS Facilitations team to have this restriction reviewed/lifted to proceed with account opening.\n' +

                                    'For any questions, please contact:\n' +
                                    'WFS CDD Onboarding: G=WFS CDD Onboarding Team \n' +
                                    'WFS EMEA CDD Onboarding: G=WFS EMEA CDD Onboarding Team');
                            }

                            if (legalDetails.ClientType) {
                                this.clientType = this.onboardingDetailRequestService.getClientType(legalDetails.ClientType);
                                this.reqForm.controls['Client_Type__c'].setValue(this.clientType);
                            }
                            if (legalDetails.ClientSubType) {
                                this.clientSubType = this.onboardingDetailRequestService.getClientSubType(legalDetails.ClientSubType);
                                this.reqForm.controls['Client_SubType__c'].setValue(this.clientSubType);
                            }

                            //RestrictedLegalReasons__c = legalDetails.RestrictedLegalReasons;
                            if (this.reqForm.controls['MiFID_II_Client_Categorization__c']) {
                                this.reqForm.controls['MiFID_II_Client_Categorization__c'].setValue(legalDetails.MiFIDIIClientCategorization);
                            }

                            if (this.reqForm.controls['IsNewCMA__c']) {
                                this.reqForm.controls['IsNewCMA__c'].setValue('Create new CMA');
                            }

                            if (this.reqForm.controls['CMA_Name__c']) {
                                this.reqForm.controls['CMA_Name__c'].setValue(null);
                            }

                            if (this.reqForm.controls['CMAId__c']) {
                                this.reqForm.controls['CMAId__c'].setValue(-1);
                            }

                            if (legalDetails.MasterAliasId > 0) {
                                if (this.reqForm.controls['IsNewCMA__c']) {
                                    this.reqForm.controls['IsNewCMA__c'].setValue('Select existing CMA');
                                }

                                if (this.reqForm.controls['CMA_Name__c']) {
                                    this.reqForm.controls['CMA_Name__c'].setValue(legalDetails.MasterAliasName);
                                }

                                if (this.reqForm.controls['CMAId__c']) {
                                    this.reqForm.controls['CMAId__c'].setValue(legalDetails.MasterAliasId);
                                }
                            }
                            else {
                                if (this.onboardingRole === 'Requester' || this.onboardingRole === 'Requester NonCash' || this.onboardingRole === 'DCOT') {
                                    if (!this.onboardingDetailRequestService.isFieldEmpty(value.ClientId)) {
                                        if (this.reqForm.controls['IsNewCMA__c']) {
                                            this.reqForm.controls['IsNewCMA__c'].setValue('Select existing CMA');
                                        }

                                        if (this.reqForm.controls['CMAId__c']) {
                                            this.reqForm.controls['CMAId__c'].setValue(0);
                                        }
                                    }
                                    else {
                                        if (this.reqForm.controls['IsNewCMA__c']) {
                                            this.reqForm.controls['IsNewCMA__c'].setValue('Create new CMA');
                                        }

                                        if (this.reqForm.controls['CMA_Name__c']) {
                                            this.reqForm.controls['CMA_Name__c'].setValue(value.LegalFullName);
                                        }

                                        if (this.reqForm.controls['CMAId__c']) {
                                            this.reqForm.controls['CMAId__c'].setValue(-1);
                                        }
                                    }
                                }
                            }

                            if (!this.onboardingDetailRequestService.isFieldEmpty(value.LegalId) && value.LegalId.trim() !== '-') {
                                this.onModalClose();
                                this.legalAddressTable = new Array<Address>();
                                this.getLegalAdressData();
                                this.legalAddressSearchDialogRef = this.dialog.open(legalTemplate, {
                                    width: '40%'
                                });
                            }
                            else {
                                if (this.reqForm.controls['AddressLine3__c']) {
                                    this.reqForm.controls['AddressLine3__c'].setValue(legalDetails.addressId);
                                }

                                if (this.reqForm.controls['AddressLine1__c']) {
                                    this.reqForm.controls['AddressLine1__c'].setValue(legalDetails.AddressLine1);
                                }

                                if (this.reqForm.controls['AddressLine2__c']) {
                                    this.reqForm.controls['AddressLine2__c'].setValue(legalDetails.AddressLine2__c);
                                }

                                if (this.reqForm.controls['City__c']) {
                                    this.reqForm.controls['City__c'].setValue(legalDetails.City);
                                }

                                if (this.reqForm.controls['Zip__c']) {
                                    this.reqForm.controls['Zip__c'].setValue(legalDetails.ZipCode);
                                }

                                if (legalDetails.CountryCode) {
                                    if (this.reqForm.controls['Country__c']) {
                                        this.reqForm.controls['Country__c'].setValue(this.onboardingDetailRequestService.countryOptions().filter(s => s.key.startsWith(legalDetails.CountryCode))[0].key);
                                    }
                                    if (legalDetails.CountryCode === 'US') {
                                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.StateCode)) {
                                            if (this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.StateCode)).length > 0) {
                                                if (this.reqForm.controls['State__c']) {
                                                    this.reqForm.controls['State__c'].setValue(this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(legalDetails.StateCode))[0].key);
                                                }
                                            }
                                        }
                                    }
                                    else if (legalDetails.COBAMLegalAddressDetails.CountryCode === 'CA') {
                                        if (!this.onboardingDetailRequestService.isFieldEmpty(legalDetails.StateCode)) {
                                            if (this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.StateCode)).length > 0) {
                                                if (this.reqForm.controls['State__c']) {
                                                    this.reqForm.controls['State__c'].setValue(this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(legalDetails.StateCode))[0].key);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
                break;
            case 'Salesperson/Trader':
                this.populateSPTR(value);
                break;
            case 'Expense Code':
                this.reqForm.controls['Expense_Code__c'].setValue(value.Id);
                this.reqForm.controls['Expense_Code_Description'].setValue(value.Code__c);
                this.onModalClose();
                break;
            case 'Primary SIC':
                this.reqForm.controls['Primary_SIC__c'].setValue(value.Id);
                this.reqForm.controls['Primary_SIC_Description'].setValue(value.Code__c);
                this.onModalClose();
                break;
            case 'Marketer':
                this.reqForm.controls['Marketer__ui'].setValue(value.FirstName + ' ' + value.LastName);
                this.reqForm.controls['Branch_Location__ui'].setValue(value.BranchLocation);
                if (this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer').length > 0) {
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer')[0].InternalContactType__c = 'Marketer';
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer')[0].Employee_Name__c = value.FirstName + ' ' + value.LastName;
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer')[0].Employee_Id__c = value.EmpId;
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer')[0].Employee_Email__c = value.EmailAddress;
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.filter(c => c.InternalContactType__c === 'Marketer')[0].Branch_Location__c = value.BranchLocation;
                }
                else {
                    let marketer = new SPOQ_InternalContact();
                    marketer.InternalContactType__c = 'Marketer';
                    marketer.Employee_Name__c = value.FirstName + ' ' + value.LastName;
                    marketer.Employee_Id__c = value.EmpId;
                    marketer.Employee_Email__c = value.EmailAddress;
                    marketer.Branch_Location__c = value.BranchLocation;
                    this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_InternalContacts.push(marketer);
                }

                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.supervisor__c = value.SupervisorName;
                this.reqForm.controls['supervisor__c'] ? this.reqForm.controls['supervisor__c'].setValue(value.SupervisorName) : null;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.supervisor_Id__c = value.SupervisorId;
                this.reqForm.controls['supervisor_Id__c'] ? this.reqForm.controls['supervisor_Id__c'].setValue(value.SupervisorId) : null;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.supervisor_Email__c = value.SupervisorEmailAddress;
                this.reqForm.controls['supervisor_Email__c'] ? this.reqForm.controls['supervisor_Email__c'].setValue(value.SupervisorEmailAddress) : null;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.delegate_Id__c = value.DelegateId;
                this.reqForm.controls['delegate_Id__c'] ? this.reqForm.controls['delegate_Id__c'].setValue(value.DelegateId) : null;
                this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.CallbackRequestInput.delegate_Email__c = value.DelegateEmail;
                this.reqForm.controls['delegate_Email__c'] ? this.reqForm.controls['delegate_Email__c'].setValue(value.DelegateEmail) : null;

                this.setShowMiFidField();
                this.onModalClose();

                break;
            default:
                this.isSave = false;
                this.showAlert = false;
                Object.keys(this.reqForm.controls).forEach(item => {
                    switch (item) {
                        case 'BA_ID__c':
                            this.reqForm.controls[item].setValue(value.AccountId);
                            break;
                    }
                });
                break;
        }
    }



    getLegalAdressData(): void {
        this.onboardingDetailRequestService
            .GetCounterpartyAddressList(this.legalId, '"')
            .subscribe(data => {
                if (data) {
                    data.oAddress.forEach((item, index) => {
                        const iteratorObj: Address = {
                            Address1: '',
                            Address2: '',
                            Address3: '',
                            Address4: '',
                            City: '',
                            State: '',
                            CountryCode: '',
                            Zip: '',
                            CanadianProvince: '',
                            CanadianPostal: '',
                            AddressFormat: ''
                        };
                        for (const prop in item) {
                            if (iteratorObj.hasOwnProperty(prop)) {
                                iteratorObj[prop] = item[prop];
                            }
                        }
                        this.legalAddressTable.push(iteratorObj);
                    });
                }
            });
    }

    populateSPTR(value: any): void {
        this.isSave = false;
        this.showAlert = false;
        this.onboardingDetailRequestService
            .getIndividualSalesPerson(value.EmployeeKeyId)
            .subscribe(
                data => {
                    if (data) {
                        //debugger
                        data = JSON.parse(JSON.stringify(data));
                        Object.keys(this.reqForm.controls).forEach(item => {
                            switch (item) {
                                case 'SPTRSearch':
                                case 'SalesPerson__c':
                                    this.reqForm.controls[item].setValue(
                                        value.SPName +
                                        ' (' +
                                        value.SalesGroup +
                                        '-' +
                                        value.Percentage +
                                        '%)'
                                    );
                                    break;
                            }
                        });

                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.Branch_Location__c = value.BranchLocation;
                        this.reqForm.controls['Branch_Location__c'] ? this.reqForm.controls['Branch_Location__c'].setValue(value.BranchLocation) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.EmpKeyId__c = data.result.EmpKeyId;
                        this.reqForm.controls['EmpKeyId__c'] ? this.reqForm.controls['EmpKeyId__c'].setValue(data.result.EmpKeyId) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.GroupName__c = value.SalesGroup;
                        this.reqForm.controls['GroupName__c'] ? this.reqForm.controls['GroupName__c'].setValue(value.SalesGroup) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.Percent__c = value.Percentage;
                        this.reqForm.controls['Percent__c'] ? this.reqForm.controls['Percent__c'].setValue(value.Percentage) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.SalesCategory__c = value.SalesCategory;
                        this.reqForm.controls['SalesCategory__c'] ? this.reqForm.controls['SalesCategory__c'].setValue(value.SalesCategory) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.SalesCategoryId__c = value.SalesCategoryId;
                        this.reqForm.controls['SalesCategoryId__c'] ? this.reqForm.controls['SalesCategoryId__c'].setValue(value.SalesCategoryId) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.SalesCategoryType__c = value.SalesCategoryType;
                        this.reqForm.controls['SalesCategoryType__c'] ? this.reqForm.controls['SalesCategoryType__c'].setValue(value.SalesCategoryType) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.SalesPersonName__c = value.SPName;
                        this.reqForm.controls['SalesPersonName__c'] ? this.reqForm.controls['SalesPersonName__c'].setValue(value.SPName) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.Salesperson_Trader__r.SPTR_Email__c = value.emailAddress;
                        this.reqForm.controls['SPTR_Email__c'] ? this.reqForm.controls['SPTR_Email__c'].setValue(value.emailAddress) : null;

                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput.supervisor__c = data.result.MgrName;
                        this.reqForm.controls['supervisor__c'] ? this.reqForm.controls['supervisor__c'].setValue(data.result.MgrName) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput.supervisor_Email__c = data.result.MgrEmail;
                        this.reqForm.controls['supervisor_Email__c'] ? this.reqForm.controls['supervisor_Email__c'].setValue(data.result.MgrEmail) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput.supervisor_Id__c = data.result.MgrEmpKeyId;
                        this.reqForm.controls['supervisor_Id__c'] ? this.reqForm.controls['supervisor_Id__c'].setValue(data.result.MgrEmpKeyId) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput.delegate_Id__c = data.result.DelegateMgrEmpKeyId;
                        this.reqForm.controls['delegate_Id__c'] ? this.reqForm.controls['delegate_Id__c'].setValue(data.result.DelegateMgrEmpKeyId) : null;
                        this.onboardingDetailRequestService.onboardingRequest.Client_Build_Request__r.CallbackRequestInput.delegate_Email__c = data.result.DelegateMgrEmail;
                        this.reqForm.controls['delegate_Email__c'] ? this.reqForm.controls['delegate_Email__c'].setValue(data.result.DelegateMgrEmail) : null;
                    }

                    this.onModalClose();
                },
                error => {
                    console.error(error);
                    this.isSearchLoading = false; // stop spinner
                    this.alertService.clear();
                    this.alertService.warn(
                        'Not able to communicate with Service Please try Again'
                    );
                }
            );
    }

    onOptionsinlineSelectionChange(template, value: string) {
        //debugger
        switch (value) {
            case 'New_Wires__c':
                if (this.reqForm.get('New_Wires__c').value === 'No') {
                    this.reqForm.controls['Is_this_Wire_a_Third_Party_payment__c'].setValue(null);
                    this.reqForm.controls['I_have_read_the_definition_of_what_a_3rd__c'].setValue(null);
                    this.reqForm.controls['Is_Payment_pending__c'].setValue(undefined);
                    this.reqForm.controls['Payment_date__c'].setValue(null);

                    this.reqForm.controls['Intermediary_Bank_Routing_Details_Visibility'] ? this.reqForm.get('Intermediary_Bank_Routing_Details_Visibility').setValue('No') : null;
                    this.reqForm.controls['callback_Analyst__r'] ? this.reqForm.controls['callback_Analyst__r'].setValue(null) : null;
                    this.reqForm.controls['analyst_Performing_Callback_for_Prime__c'] ? this.reqForm.controls['analyst_Performing_Callback_for_Prime__c'].setValue(null) : null;

                    this.reqForm.controls['beneficiary_Name__c'] ? this.reqForm.controls['beneficiary_Name__c'].setValue(null) : null;
                    this.reqForm.controls['beneficiary_ID__c'] ? this.reqForm.controls['beneficiary_ID__c'].setValue(null) : null;
                    this.reqForm.controls['source_Type__c'] ? this.reqForm.controls['source_Type__c'].setValue(null) : null;
                    this.reqForm.controls['source_Type_Other__c'] ? this.reqForm.controls['source_Type_Other__c'].setValue(null) : null;
                    this.reqForm.controls['verification_Source__c'] ? this.reqForm.controls['verification_Source__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_Name1__c'] ? this.reqForm.controls['counterparty_Contact_Name1__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_Phone1__c'] ? this.reqForm.controls['counterparty_Contact_Phone1__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_Name2__c'] ? this.reqForm.controls['counterparty_Contact_Name2__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_Phone2__c'] ? this.reqForm.controls['counterparty_Contact_Phone2__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_Name3__c'] ? this.reqForm.controls['counterparty_Contact_Name3__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_Phone3__c'] ? this.reqForm.controls['counterparty_Contact_Phone3__c'].setValue(null) : null;
                    this.reqForm.controls['callback_Verification_Contact_Name__c'] ? this.reqForm.controls['callback_Verification_Contact_Name__c'].setValue(null) : null;
                    this.reqForm.controls['callback_Verification_Contact_Number__c'] ? this.reqForm.controls['callback_Verification_Contact_Number__c'].setValue(null) : null;
                    //this.reqForm.controls['desk_Head_Approver_Name__c'].setValue(null);
                    //this.reqForm.controls['desk_Head_Callback_Exception_App_Time__c'].setValue(null);
                    this.reqForm.controls['account_Number_Bank_FI_ID__c'] ? this.reqForm.controls['account_Number_Bank_FI_ID__c'].setValue(null) : null;
                    this.reqForm.controls['bank_FI_Name__c'] ? this.reqForm.controls['bank_FI_Name__c'].setValue(null) : null;
                    this.reqForm.controls['beneficiary_Bank_Financial_Institution_O__c'] ? this.reqForm.controls['beneficiary_Bank_Financial_Institution_O__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_CB_Name_2__c'] ? this.reqForm.controls['counterparty_Contact_CB_Name_2__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_CB_Name_3__c'] ? this.reqForm.controls['counterparty_Contact_CB_Name_3__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_CB_Phone_1__c'] ? this.reqForm.controls['counterparty_Contact_CB_Phone_1__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_CB_Phone_2__c'] ? this.reqForm.controls['counterparty_Contact_CB_Phone_2__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_CB_Phone_3__c'] ? this.reqForm.controls['counterparty_Contact_CB_Phone_3__c'].setValue(null) : null;
                    this.reqForm.controls['counterparty_Contact_for_CB_Name1__c'] ? this.reqForm.controls['counterparty_Contact_for_CB_Name1__c'].setValue(null) : null;
                    this.reqForm.controls['intermediary_Bank_ID_Type__c'] ? this.reqForm.controls['intermediary_Bank_ID_Type__c'].setValue(null) : null;
                    this.reqForm.controls['intermediary_Bank_Name__c'] ? this.reqForm.controls['intermediary_Bank_Name__c'].setValue(null) : null;
                    this.reqForm.controls['other_Instructions__c'] ? this.reqForm.controls['other_Instructions__c'].setValue(null) : null;
                    this.reqForm.controls['routing_Number_Intermediary_Bank_ID__c'] ? this.reqForm.controls['routing_Number_Intermediary_Bank_ID__c'].setValue(null) : null;
                    this.reqForm.controls['two_distinct_individuals_confirm_instruc__c'] ? this.reqForm.controls['two_distinct_individuals_confirm_instruc__c'].setValue(null) : null;
                }
                else if (this.reqForm.get('New_Wires__c').value === 'Yes') {
                    if (this.reqForm.get('New_Wires__c').value === 'Yes'
                        && (this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === ''
                            || this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === 'Account Number (DDA)'
                            || this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === 'General Ledger'
                            || this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === 'Unspecified')) {

                        this.reqForm.get('Intermediary_Bank_Routing_Details_Visibility').setValue('Yes');
                    }
                }
                break;
            case 'Is_Payment_pending__c':
                this.reqForm.controls['Payment_date__c'].setValue(null);
                break;
            case 'Is_this_Wire_a_Third_Party_payment__c':
                if (this.reqForm.get('Is_this_Wire_a_Third_Party_payment__c').value === 'No') {
                    this.reqForm.controls['Third_Party_Request_Type__c'] ? this.reqForm.controls['Third_Party_Request_Type__c'].setValue(null) : null;
                    this.reqForm.controls['Third_Party_Exception_Approval_Status__c'] ? this.reqForm.controls['Third_Party_Exception_Approval_Status__c'].setValue(null) : null;
                    this.reqForm.controls['Third_Party_form_Completed_By__c'] ? this.reqForm.controls['Third_Party_form_Completed_By__c'].setValue(null) : null;
                    this.reqForm.controls['Third_Party_form_Completed_Date__c'] ? this.reqForm.controls['Third_Party_form_Completed_Date__c'].setValue(null) : null;
                    this.reqForm.controls['Business_Unit_Requesting_Exception__c'] ? this.reqForm.controls['Business_Unit_Requesting_Exception__c'].setValue(null) : null;
                    this.reqForm.controls['Policy_Exception_Justification__c'] ? this.reqForm.controls['Policy_Exception_Justification__c'].setValue(null) : null;
                    this.reqForm.controls['Telephone__c'] ? this.reqForm.controls['Telephone__c'].setValue(null) : null;
                    this.reqForm.controls['Fax__c'] ? this.reqForm.controls['Fax__c'].setValue(null) : null;
                    this.reqForm.controls['Third_Party_Desk_Head_Approval__c'] ? this.reqForm.controls['Third_Party_Desk_Head_Approval__c'].setValue(null) : null;
                    this.reqForm.controls['Third_Party_Approval_Timestamp__c'] ? this.reqForm.controls['Third_Party_Approval_Timestamp__c'].setValue(null) : null;

                }
                else {
                    this.reqForm.get('third_Party_form_Completed_By__c') ? this.reqForm.controls['third_Party_form_Completed_By__c'].setValue(this.currentUserName) : null;
                }
                break;
            case 'Is_Payment_pending__c':
                this.reqForm.get('Is_Payment_pending__c').value === 'No' ? this.reqForm.controls['Payment_date__c'].setValue(null) : null;

                break;
            case 'Can_the_client_be_contacted__c':
                if (!this.showNonCashTabs) {
                    this.reqForm.get('Client_Contact_Name__c') ? this.reqForm.controls['Client_Contact_Name__c'].setValue(null) : null;
                    this.reqForm.get('Client_Contact_Phone__c') ? this.reqForm.controls['Client_Contact_Phone__c'].setValue(null) : null;
                    this.reqForm.get('Client_Contact_Email__c') ? this.reqForm.controls['Client_Contact_Email__c'].setValue(null) : null
                }
                break;
            default:
                break;
        }
    }

    onOptionsDropDownSelectionChange(fieldName) {
        //debugger
        switch (fieldName) {
            case 'Build_Type__c':
                this.reqForm.controls['Alert_Acronym__c'].setValue(null);
                this.reqForm.controls['CID_LEID__c'].setValue('', { emitEvent: false });
                if (this.reqForm.get('Product_Type__c').value === 'Prime') {
                    if (this.reqForm.get('Build_Type__c').value === 'New Legal & Bus Acc'
                        && (this.WFEntityVal.indexOf('WFSIL') >= 0 || this.WFEntityVal.indexOf('WFSE') >= 0)) {
                        this.reqForm.controls['Can_the_client_be_contacted__c'].setValue('Yes');
                    } else {
                        this.reqForm.controls['Can_the_client_be_contacted__c'].setValue('No');
                    }
                    this.reqForm.controls['Client_Type__c'].setValue('INVESTMENT MANAGER');
                    this.reqForm.controls['Client_SubType__c'].setValue('Non Bank Owned Investment Manager');
                } else {
                    this.reqForm.controls['Can_the_client_be_contacted__c'].setValue('Yes');
                    this.reqForm.controls['Client_Type__c'].setValue('');
                    this.reqForm.controls['Client_SubType__c'].setValue('-- Please Select --');
                }
                this.onLegalNameValueChange();
                break;
            case 'Can_the_client_be_contacted__c':
                if (this.reqForm.get('Can_the_client_be_contacted__c').value === 'No') {
                    this.reqForm.controls['Client_Contact_Name__c'].setValue(null);
                    this.reqForm.controls['Client_Contact_Phone__c'].setValue(null);
                    this.reqForm.controls['Client_Contact_Email__c'].setValue(null);
                }
                break;
            case 'Is_safekeeping_required__c':
                switch (this.reqForm.get('Is_safekeeping_required__c').value) {
                    case 'Yes':
                        this.showSKFeeDiscountButton = true;
                        this.reqForm.controls['Safekeeping_Type__c'].setValue('');
                        break;
                    case 'No':
                        this.showSKFeeDiscountButton = false;
                        this.reqForm.controls['Safekeeping_Type__c'].setValue('');
                        break;
                    default:
                        this.showSKFeeDiscountButton = false;
                        break;
                }
            case 'Safekeeping_Type__c':
                if (this.reqForm.get('Safekeeping_Type__c').value === 'Bank') {
                    if (this.reqForm.get('External_system_list__c')) {
                        if (!this.reqForm.get('External_system_list__c').value) {
                            this.reqForm.get('External_system_list__c').setValue([]);
                        }
                    }
                    if (!this.reqForm.get('External_system_list__c').value.includes('BRWFS : BROADRIDGE - WELLS FARGO SEC')) {
                        this.reqForm.get('External_system_list__c').value.push('BRWFS : BROADRIDGE - WELLS FARGO SEC')
                        this.reqForm.get('External_system_list__c').setValue(this.reqForm.get('External_system_list__c').value);
                    }

                    if (!this.reqForm.get('External_system_list__c').value.includes('BRWFB : BROADRIDGE - WELLS FARGO BANK NA')) {
                        this.reqForm.get('External_system_list__c').value.push('BRWFB : BROADRIDGE - WELLS FARGO BANK NA')
                        this.reqForm.get('External_system_list__c').setValue(this.reqForm.get('External_system_list__c').value);
                    }
                }
                else if (this.reqForm.get('Settlement_Type__c').value === 'Regular') {
                    this.reqForm.controls['Credit_limit__c'].setValue(null);
                    this.reqForm.controls['Tenor_Requested__c'].setValue(null);
                }
                break;
            case 'Country__c':
                if (this.reqForm.get('Country__c').value !== 'US - UNITED STATES' && this.reqForm.get('Country__c').value !== 'CA - CANADA') {
                    this.reqForm.controls['State__c'] ? this.reqForm.controls['State__c'].setValue('') : null;
                    this.reqForm.controls['Zip__c'] ? this.reqForm.controls['Zip__c'].setValue('') : null;
                }
                break;
            case 'Hong_Kong_Classification__c':
                if (this.reqForm.get('Hong_Kong_Classification__c').value === 'Institutional Professional Investor') {
                    this.reqForm.controls['Product_group_Market_coverage__c'].setValue('None selected');
                }
                break;
            case 'Legal_Code__c':
                this.setCustomerClassification();
                break;
            case 'CDD_Type__c':
                this.setCDDTypeAndSubtype();
                break;
            case 'Type_of_Documentation_Request__c':
                switch (this.reqForm.controls['Type_of_Documentation_Request__c'].value) {
                    case 'Amendment to Existing Agreement':
                        alert("Selecting this option will prompt a request for review of the existing agreement as well as a Hedge Review of any new or modified loan and/or credit support documentation.");
                        break;
                    case 'FX Agreement':
                        alert("For requests for an FX Agreement, please contact fxstaticdata@wellsfargo.com");
                        break;
                    case 'Hedge Review Only - No Documentation Requested':
                        alert("Select this option only if there is an existing trading agreement in place with the Customer and you do not anticipate putting a new trading agreement in place (or amending an existing agreement).");
                        break;
                    case 'Rate Management Agreement':
                        alert("Upon submission of this form, contact your loan center to request documentation of the Rate Management Agreement");
                        break;
                    default:
                        break;
                }
                break;
            case 'MiFID_II_Client_Categorization__c':
                if (this.reqForm.controls['MiFID_II_Client_Categorization__c'] && !this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.controls['MiFID_II_Client_Categorization__c'].value)) {
                    if (this.reqForm.get('External_system_list__c')) {
                        if (!this.reqForm.get('External_system_list__c').value) {
                            this.reqForm.get('External_system_list__c').setValue([]);
                        }
                    }
                    if (!this.reqForm.get('External_system_list__c').value.includes('GDD : GLOBAL DERIVATIVE DOC SYSTEM')) {
                        this.reqForm.get('External_system_list__c').value.push('GDD : GLOBAL DERIVATIVE DOC SYSTEM')
                        this.reqForm.get('External_system_list__c').setValue(this.reqForm.get('External_system_list__c').value);
                    }
                }
                else {
                    if (this.reqForm.get('External_system_list__c').value.includes('GDD : GLOBAL DERIVATIVE DOC SYSTEM')) {
                        let externalList = this.reqForm.get('External_system_list__c').value.filter(e => e !== 'GDD : GLOBAL DERIVATIVE DOC SYSTEM');
                        this.reqForm.get('External_system_list__c').setValue(externalList);
                    }
                }
                break;
            case 'Is_Prime_Account__c':

                this.reqForm.controls['Callback_Status__c'] ? this.reqForm.controls['Callback_Status__c'].setValue(null) : null;
                break;
            case 'beneficiary_Bank_Financial_Institution_O__c':
                if (this.reqForm.get('New_Wires__c').value === 'Yes'
                    && (this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === ''
                        || this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === 'Account Number (DDA)'
                        || this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === 'General Ledger'
                        || this.reqForm.get('beneficiary_Bank_Financial_Institution_O__c').value === 'Unspecified')) {

                    this.reqForm.get('Intermediary_Bank_Routing_Details_Visibility').setValue('Yes');
                }
                else {
                    this.reqForm.get('Intermediary_Bank_Routing_Details_Visibility').setValue('No');
                }
                break;
            default:
                break;
        }
    }

    multiSelectionHandler(event) {
        if (event['controlName'] === 'External_system_list__c') {
            switch (this.productTypeVal) {
                case 'Prime':
                    this.setMarginTypeVisiblity();
                    break;
                default:
                    break;
            }

            if (this.productTypeVal === 'FCM'
                && (this.reqForm.controls['WFS_Entity__c'].value.includes('WFSIL') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSLLC - US') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSE'))
                && (this.reqForm.controls['MiFID_II_Risk_Reducing__c'] && this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.controls['MiFID_II_Risk_Reducing__c'].value))
                && (this.reqForm.get('External_system_list__c').value && (this.reqForm.get('External_system_list__c').value.includes('GMIBD : GMI WELLS FARGO SECURITIES, LLC')
                    || this.reqForm.get('External_system_list__c').value.includes('GMICLR : GMI (CLEARING)')
                    || this.reqForm.get('External_system_list__c').value.includes('GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED')))
            ) {
                this.reqForm.controls['MiFID_II_Risk_Reducing__c'] ? this.reqForm.controls['MiFID_II_Risk_Reducing__c'].setValue('No') : null;
                if (this.formFields.filter(f => f.key === 'MiFID_II_Risk_Reducing__c').length > 0) {
                    this.formFields.filter(f => f.key === 'MiFID_II_Risk_Reducing__c')[0].value = 'No';
                }
            }
            else if (this.productTypeVal === 'FCM'
                && (!this.reqForm.controls['WFS_Entity__c'].value.includes('WFSIL') && !this.reqForm.controls['WFS_Entity__c'].value.includes('WFSLLC - US') && !this.reqForm.controls['WFS_Entity__c'].value.includes('WFSE'))
                && (this.reqForm.controls['MiFID_II_Risk_Reducing__c'] && !this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.controls['MiFID_II_Risk_Reducing__c'].value))
                && (this.reqForm.get('External_system_list__c').value && (this.reqForm.get('External_system_list__c').value.includes('GMIBD : GMI WELLS FARGO SECURITIES, LLC')
                    || this.reqForm.get('External_system_list__c').value.includes('GMICLR : GMI (CLEARING)')
                    || this.reqForm.get('External_system_list__c').value.includes('GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED')))
            ) {
                this.reqForm.controls['MiFID_II_Risk_Reducing__c'] ? this.reqForm.controls['MiFID_II_Risk_Reducing__c'].setValue(null) : null;
            }
            else if (this.productTypeVal === 'FCM'
                && (this.reqForm.controls['WFS_Entity__c'].value.includes('WFSIL') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSLLC - US') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSE'))
                && (this.reqForm.controls['MiFID_II_Risk_Reducing__c'] && !this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.controls['MiFID_II_Risk_Reducing__c'].value))
                && (this.reqForm.get('External_system_list__c').value && (!this.reqForm.get('External_system_list__c').value.includes('GMIBD : GMI WELLS FARGO SECURITIES, LLC')
                    && !this.reqForm.get('External_system_list__c').value.includes('GMICLR : GMI (CLEARING)')
                    && !this.reqForm.get('External_system_list__c').value.includes('GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED')))
            ) {
                this.reqForm.controls['MiFID_II_Risk_Reducing__c'] ? this.reqForm.controls['MiFID_II_Risk_Reducing__c'].setValue(null) : null;
            }
            else if (this.productTypeVal === 'FCM'
                && (this.reqForm.controls['WFS_Entity__c'].value.includes('WFSIL') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSLLC - US') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSE'))
                && (this.reqForm.controls['MiFID_II_Risk_Reducing__c'] && this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.controls['MiFID_II_Risk_Reducing__c'].value))
                && !this.reqForm.get('External_system_list__c').value
            ) {
                this.reqForm.controls['MiFID_II_Risk_Reducing__c'] ? this.reqForm.controls['MiFID_II_Risk_Reducing__c'].setValue(null) : null;
            }
            else if (this.productTypeVal !== 'FCM'
                && (this.reqForm.controls['WFS_Entity__c'].value.includes('WFSIL') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSLLC - US') || this.reqForm.controls['WFS_Entity__c'].value.includes('WFSE'))
                && (this.reqForm.controls['MiFID_II_Risk_Reducing__c'] && this.onboardingDetailRequestService.isFieldEmpty(this.reqForm.controls['MiFID_II_Risk_Reducing__c'].value))
                && (this.reqForm.get('External_system_list__c').value && (this.reqForm.get('External_system_list__c').value.includes('GMIBD : GMI WELLS FARGO SECURITIES, LLC')
                    || this.reqForm.get('External_system_list__c').value.includes('GMICLR : GMI (CLEARING)')
                    || this.reqForm.get('External_system_list__c').value.includes('GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED')))
            ) {
                this.reqForm.controls['MiFID_II_Risk_Reducing__c'] ? this.reqForm.controls['MiFID_II_Risk_Reducing__c'].setValue(null) : null;
            }
        }
    }

    onAutocompleteSelctionChange(controlName: string) {
        switch (controlName) {
            case 'Primary_Facilitator__c':
                if (this.reqForm.get('Status__c').value === 'Open - Unassigned') {
                    this.reqForm.get('Status__c').setValue('Pending - Inprogress');
                }
                break;
            case 'Assigned_eFX_Service_Specialist__r':
                if (this.reqForm.get('eFX_Service_Specialist_assigned_date__c')) {
                    this.reqForm.controls['eFX_Service_Specialist_assigned_date__c'].setValue(new Date());
                }
                break;
            default:
                break;
        }
        if (controlName === 'Primary_Facilitator__c') {
            if (this.reqForm.get('Status__c').value === 'Open - Unassigned') {
                this.reqForm.get('Status__c').setValue('Pending - Inprogress');
            }
        }
    }

    selectExpenseCode(item: any): void {
        this.isSave = false;
        this.showAlert = false;
        Object.keys(this.reqForm.controls).forEach(prop => {
            switch (prop) {
                case 'City__c':
                    this.reqForm.controls[prop].setValue(item.City);
                    break;
            }
        });

        //this.onExpenseCodeModalClose();
    }

    selectLegalRowData(item: any): void {
        this.isSave = false;
        this.showAlert = false;
        Object.keys(this.reqForm.controls).forEach(prop => {
            switch (prop) {
                case 'City__c':
                    this.reqForm.controls[prop].setValue(item.City);
                    break;
                case 'State__c':
                    if (item.CountryCode) {
                        if (item.CountryCode.trim() === 'US' && item.State) {
                            this.state = this.onboardingDetailRequestService.buildStateOptions().filter(s => s.key.startsWith(item.State.trim()))[0].key;
                        }
                        else if (item.CountryCode.trim() === 'CA' && item.CanadianProvince) {
                            this.state = this.onboardingDetailRequestService.buildCanadianProvinceOptions().filter(s => s.key.startsWith(item.CanadianProvince.trim()))[0].key;
                        }
                        this.reqForm.controls[prop].setValue(this.state);
                    }

                    break;
                case 'AddressLine1__c':
                    this.reqForm.controls[prop].setValue(item.Address1);
                    break;
                case 'AddressLine2__c':
                    this.reqForm.controls[prop].setValue(item.Address2);
                    break;
                case 'AddressLine3__c':
                    this.reqForm.controls[prop].setValue(item.Address3);
                    break;
                case 'Zip__c':
                    if (item.CountryCode && item.CountryCode.trim() !== 'CA') {
                        this.reqForm.controls[prop].setValue(item.Zip);
                    }
                    else {
                        this.reqForm.controls[prop].setValue(item.CanadianPostal);
                    }
                    break;
                case 'Country__c':
                    if (item.CountryCode) {
                        this.country = this.onboardingDetailRequestService.countryOptions().filter(s => s.key.startsWith(item.CountryCode.trim()))[0].key;
                        this.reqForm.controls[prop].setValue(this.country);
                    }
                    break;
            }
        });
        this.onLegalAddressModalClose();
    }

    onLegalAddressModalClose() {
        this.legalAddressSearchDialogRef.close();
    }

    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
        this.subscriptions = [];
    }
}