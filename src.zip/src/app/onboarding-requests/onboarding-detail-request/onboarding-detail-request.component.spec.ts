import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardingDetailRequestComponent } from './onboarding-detail-request.component';

describe('OnboardingDetailRequestComponent', () => {
  let component: OnboardingDetailRequestComponent;
  let fixture: ComponentFixture<OnboardingDetailRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardingDetailRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardingDetailRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
