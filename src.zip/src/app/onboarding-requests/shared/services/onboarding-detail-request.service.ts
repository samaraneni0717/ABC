import { Injectable } from '@angular/core';
import { ApiService } from '../../../Common/services/api.service';
import { Observable } from 'rxjs/Observable';
import { environment } from 'src/environments/environment';
import { User } from '../../../Common/models/User';
import { AlertService } from '../../../Common/services/alert.service';
import { QuestionBase } from '../../../Common/dynamic-form-models/question-base';
import { TextAreaQuestion } from 'src/app/Common/dynamic-form-models/question-textarea';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { LabelQuestion } from 'src/app/Common/dynamic-form-models/question-label';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { TextboxQuestion } from '../../../Common/dynamic-form-models/question-textbox';
import { OptionsInlineQuestion } from 'src/app/Common/dynamic-form-models/Question-OptionsInline';
import { SingleCheckboxQuestion } from 'src/app/Common/dynamic-form-models/question-single-checkbox';
import { DatePickerQuestion } from 'src/app/Common/dynamic-form-models/question-date-picker';
import { MultiselectQuestion } from 'src/app/Common/dynamic-form-models/question-multiselect';
import { AutoCompleteQuestion } from 'src/app/Common/dynamic-form-models/question-autocomplete';
import { OptionsQuestion } from '../../../Common/dynamic-form-models/Question-Options';
import { LookupQuestion } from 'src/app/Common/dynamic-form-models/quetions-lookup';
import { ListQuestion } from 'src/app/Common/dynamic-form-models/question-list';
import { OnboardingRequest } from '../../Models/onbaordingRequest';
import { SalesforceUser } from 'src/app/Common/models/salesforceUser';
import { IndicatorQuestion } from 'src/app/Common/dynamic-form-models/question-indicator';

@Injectable({
    providedIn: 'root'
})

export class OnboardingDetailRequestService {
    userDetail: User;
    onboardingRequest: OnboardingRequest;
    currentUser: SalesforceUser;

    constructor(private httpClient: HttpClient, private apiService: ApiService, private alertService: AlertService) {
        console.log('Service instantiated');
    }

    logInUser(): Observable<User> {

        const url: string = environment.BASEURL + 'User';

        return this.apiService.Get<User>(url);
    }

    logIn() {
        this.logInUser().retryWhen((err) => err.delay(5000)).subscribe((userdtls: User) => {
            if (userdtls != null) {
                this.userDetail = userdtls;
                localStorage.setItem('LoggedInUser', this.userDetail.UNumber);
                console.log(this.userDetail.UNumber);
            } else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
            });
    }

    getCurrentUser(): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL + 'Lookup/currentUser' //User/currentUser, check request-cache.service.ts
        );
    }

    getIndividualSalesPerson(empKeyId: number): Observable<any> {

        return this.httpClient.get(
            environment.BASEURL +
            'Maintenance/GetIndividualSalesPerson/?EmpKeyId=' +     //Onboarding??
            empKeyId
        );

    }

    getCounterpartyAndComplianceDetailsByLegalId(clientId: string, legalId: string) {
        return this.httpClient.get(
            environment.BASEURL +
            'Lookup/GetCounterpartyAndComplianceDetailsByLegalId/?clientId=' + clientId + '&legalId=' + legalId
        );
    }

    getLegalDetailsForCOBAMCash(clientId: string, legalId: string) {
        return this.httpClient.get(
            environment.BASEURL +
            'Lookup/GetLegalDetailsForCOBAMCash/?clientId=' + clientId + '&legalId=' + legalId
        );
    }

    GetCounterpartyAddressList(legalid: number, addressType: string): Observable<any> {

        return this.httpClient.get(environment.BASEURL + 'Maintenance/GetCounterpartyAddressList/?legalid=' + legalid + '&addressType=' + addressType);     //Onboarding??
    }

    AddOnboardingRequest(paramObj: any): Observable<any> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers };
        const body = JSON.stringify({ onboardingrequest: paramObj });
        return this.httpClient.post(
            environment.BASEURL + 'Onboarding/AddOnboardingRequest/'
            , body
            , options
        );
    }

    GetOnboardingRequestDetails(onboardingRequsestId: string): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL +
            'Onboarding/GetOnboardingRequest/?id=' +
            onboardingRequsestId
        );
    }

    isFieldEmpty(fieldValue) {
        if (fieldValue === undefined || fieldValue === null || fieldValue === '') {
            return true;
        }
        else {
            return false;
        }
    }

    getEntityInformationColumnDefinations() {
        return this.apiService.Get(environment.BASEURL + 'Onboarding/getEntityInformationColumnDefinations/');
    }

    buildProductType(productType?: string): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'Product_Type__c',
            label: 'Product Type',
            value: productType,
            order: 500,
            disabled: true
        })
    }

    buildProductSubType(productSubType?: string, key?: string, order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: key,
            label: 'Product Sub Type',
            value: productSubType,
            order: order,
            disabled: true
        })
    }

    buildBuildType(buildType?: string): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Build_Type__c',
            label: 'Build Type',
            mandatory: true,
            defaultOption: buildType,
            selectionChange: true,
            isTooltipPresent: true,
            typeOfTooltip: 'help',
            tooltipText: `"New Legal & Bus Acc" is a net new client relationship that requires a legal (parent) and a business (child) account. A "Business Acc" assumes there is an existing relationship with the legal level account and only a new sub-account is required.`,
            order: 100,
            options: [
                { key: '', value: '--None--' },
                { key: 'New Legal & Bus Acc', value: 'New Legal & Bus Acc' },
                { key: 'New Bus Acc Only', value: 'New Bus Acc Only' }
            ]
        })
    }

    buildWFEntity(wfEntity?: string): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'WFS_Entity__c',
            label: 'WF Entity',
            value: wfEntity,
            order: 200,
            disabled: true
        })
    }

    buildSalesAssistant(currentUserName?: string): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'Sales_Assistant__c',
            label: 'Sales Assistant',
            value: currentUserName,
            order: 300,
            disabled: true
        })
    }

    buildCreatedDate(): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'CreatedDate',
            label: 'Created Date',
            order: 400,
            disabled: true
        })
    }

    buildCOBAMNumber(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'Name',
            label: 'COBAM Number',
            order: order,
            disabled: true
        })
    }

    buildCMRID(role: string): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'RequestDetails',
            key: 'CMR_ID__c',
            label: 'CMR ID',
            order: 600,
            mandatory: true,
            disabled: (role === 'Requester' || role === 'Requester NonCash') ? false : true
        });
    }

    buildLastModifiedDate(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'LastModifiedDate',
            label: 'Last Modified Date',
            order: order,
            disabled: true
        })
    }

    buildQueueStatus(requestStatus?: string, order?: number, cobamRole?: string, buildType?: string, amlStatus?: string): QuestionBase<any> {
        let options: any = [];
        let disabled: boolean = true;

        if (requestStatus && requestStatus === 'Draft') {
            options = [{ key: 'Draft', value: 'Draft' }];
        }
        else if (requestStatus && requestStatus === 'Open - Unassigned') {
            options = [{ key: 'Open - Unassigned', value: 'Open - Unassigned' }, { key: 'Pending - Assigned', value: 'Pending - Assigned' },];
        }
        else if (requestStatus && requestStatus === 'Closed - Inactive') {
            options = [{ key: 'Closed - Inactive', value: 'Closed - Inactive' }, { key: 'Re-Open', value: 'Re-Open' }];
        }
        else if (requestStatus && requestStatus === 'Re-Open') {
            options = [{ key: 'Re-Open', value: 'Re-Open' }, { key: 'Pending - Assigned', value: 'Pending - Assigned' },];
        }
        else if ((buildType && buildType === 'New Legal & Bus Acc') && (amlStatus && (amlStatus === 'Approved in CSTN/CRMS' || amlStatus === 'CSTN down – AML Approved'))
            && (requestStatus && (requestStatus === 'Pending - Assigned' || requestStatus === 'Pending - Awaiting Sales Response' || requestStatus === 'Pending - Awaiting Client Response' || requestStatus === 'Ready for CID Staging/Approval' || requestStatus === 'Waiting for Tax Validation'))) {
            options = [
                { key: 'Pending - Assigned', value: 'Pending - Assigned' },
                { key: 'Pending - Awaiting Sales Response', value: 'Pending - Awaiting Sales Response' },
                { key: 'Pending - Awaiting Client Response', value: 'Pending - Awaiting Client Response' },
                { key: 'Ready for CID Staging/Approval', value: 'Ready for CID Staging/Approval' },
                { key: 'Waiting for Tax Validation', value: 'Waiting for Tax Validation' },
                { key: 'Closed - Approved', value: 'Closed - Approved' },
                { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                { key: 'Closed - Inactive', value: 'Closed - Inactive' }
            ];
        }
        else if ((buildType && buildType === 'New Legal & Bus Acc') && (amlStatus && (amlStatus !== 'Approved in CSTN/CRMS' && amlStatus !== 'CSTN down – AML Approved'))
            && (requestStatus && (requestStatus === 'Pending - Assigned' || requestStatus === 'Pending - Awaiting Sales Response' || requestStatus === 'Pending - Awaiting Client Response' || requestStatus === 'Ready for CID Staging/Approval' || requestStatus === 'Waiting for Tax Validation'))) {
            options = [
                { key: 'Pending - Assigned', value: 'Pending - Assigned' },
                { key: 'Pending - Awaiting Sales Response', value: 'Pending - Awaiting Sales Response' },
                { key: 'Pending - Awaiting Client Response', value: 'Pending - Awaiting Client Response' },
                { key: 'Ready for CID Staging/Approval', value: 'Ready for CID Staging/Approval' },
                { key: 'Waiting for Tax Validation', value: 'Waiting for Tax Validation' },
                { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                { key: 'Closed - Inactive', value: 'Closed - Inactive' }
            ];
        }
        else if ((buildType && buildType === 'New Bus Acc Only')
            && (requestStatus && (requestStatus === 'Pending - Assigned' || requestStatus === 'Pending - Awaiting Sales Response' || requestStatus === 'Pending - Awaiting Client Response' || requestStatus === 'Ready for CID Staging/Approval' || requestStatus === 'Waiting for Tax Validation'))) {

            options = [
                { key: 'Pending - Assigned', value: 'Pending - Assigned' },
                { key: 'Pending - Awaiting Sales Response', value: 'Pending - Awaiting Sales Response' },
                { key: 'Pending - Awaiting Client Response', value: 'Pending - Awaiting Client Response' },
                { key: 'Ready for CID Staging/Approval', value: 'Ready for CID Staging/Approval' },
                { key: 'Waiting for Tax Validation', value: 'Waiting for Tax Validation' },
                { key: 'Closed - Approved', value: 'Closed - Approved' },
                { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                { key: 'Closed - Inactive', value: 'Closed - Inactive' }
            ];
        }
        else if (requestStatus && (requestStatus === 'Closed - Approved' || requestStatus === 'Closed - Rejected' || requestStatus === 'Closed - Inactive')) {
            options = [
                { key: 'Closed - Approved', value: 'Closed - Approved' },
                { key: 'Closed - Rejected', value: 'Closed - Rejected' },
                { key: 'Closed - Inactive', value: 'Closed - Inactive' },
                { key: 'Re-Open', value: 'Re-Open' }
            ];
        }

        if (cobamRole && (cobamRole === 'Facilitator' || cobamRole === 'Facilitator Manager' || cobamRole === 'Account Approval')) {
            disabled = false;
        }

        //options = [{ key: 'Draft', value: 'Draft' }, { key: 'Open - Unassigned', value: 'Open - Unassigned' }];
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Status__c',
            label: 'Queue Status',
            order: order,
            value: requestStatus,
            disabled: disabled,
            options: options
        })
    }

    buildRelationshipType(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Relationship_Type__c',
            label: 'Relationship Type',
            mandatory: true,
            defaultOption: '',
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'Non-Fiduciary', value: 'Non-Fiduciary' },
                { key: 'Fiduciary', value: 'Fiduciary' }
            ]
        })
    }

    buildSalesPersonSearch(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            key: 'SPTRSearch',
            label: 'Sales Person/Trader Search',
            order: order,
            searchable: true,
            disabled: false,
            template: 'Salesperson/Trader'
        })
    }

    buildSalesPersonTrader(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            key: 'SalesPerson__c',
            label: 'Salesperson/Trader',
            order: order,
            mandatory: true,
            disabled: true,
        })
    }

    buildMiFIDIIClientCategorization(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'MiFID_II_Client_Categorization__c',
            label: 'MiFID II Client Categorization',
            mandatory: true,
            defaultOption: '',
            order: order,
            options: [
                { key: '', value: '-- Please Select --' },
                { key: 'Per Se Professional Client', value: 'Per Se Professional Client' },
                { key: 'Elective Professional Client', value: 'Elective Professional Client' },
                { key: 'Per Se Eligible Counterparty', value: 'Per Se Eligible Counterparty' },
                { key: 'Elective Eligible Counterparty', value: 'Elective Eligible Counterparty' }
            ]
        })
    }

    buildEmptyField(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            key: order.toString(),
            label: '',
            order: order,
            disabled: true
        })
    }

    buildPrimeBrokerAccount(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Is_Prime_Account__c',
            label: 'Is this a Prime Broker Account?',
            mandatory: true,
            selectionChange: true,
            defaultOption: 'No',
            order: order,
            options: [
                { key: 'No', value: 'No' },
                { key: 'Yes', value: 'Yes' }
            ]
        })
    }

    buildTradePending(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Is_trade_pending__c',
            label: 'Is trade pending?',
            defaultOption: '',
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ]
        })
    }

    buildNewWires(order?: number): QuestionBase<any> {
        return new OptionsInlineQuestion({
            section: 'RequestDetails',
            key: 'New_Wires__c',
            label: 'New Wires',
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ],
            order: order,
            relation: [
                {
                    action: 'ENABLE',
                    when: [
                        {
                            id: 'Status__c',
                            value: 'Draft'
                        }
                    ]
                }
            ],
            mandatory: true
        })
    }

    buildThirdPartyPayment(order?: number): QuestionBase<any> {
        return new OptionsInlineQuestion({
            section: 'RequestDetails',
            key: 'Is_this_Wire_a_Third_Party_payment__c',
            label: 'Is this Wire a Third Party payment?',
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ],
            isTooltipPresent: true,
            typeOfTooltip: 'help',
            tooltipText: `A third party instruction is any instruction where the beneficiary listed in the instruction is a 
                  different entity than the customer. Any instruction that lists a beneficiary with a different name than 
                  the customer should be flagged as a third party.`,
            order: order,
            relation: [
                {
                    action: 'ENABLE',
                    when: [
                        {
                            id: 'Status__c',
                            value: 'Draft'
                        }
                    ]
                },
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'New_Wires__c',
                            value: 'Yes'
                        }
                    ]
                }
            ],
            mandatory: true
        })
    }

    buildThirdPartyWireCheckbox(order?: number): QuestionBase<any> {
        return new SingleCheckboxQuestion({
            section: 'RequestDetails',
            key: 'I_have_read_the_definition_of_what_a_3rd__c',
            label: 'I have read the definition of what a 3rd party wire is',
            value: false,
            order: order,
            relation: [
                {
                    action: 'ENABLE',
                    when: [
                        {
                            id: 'Status__c',
                            value: 'Draft'
                        }
                    ]
                },
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'New_Wires__c',
                            value: 'Yes'
                        }
                    ]
                }
            ]
        })
    }

    buildPaymentPending(order?: number): QuestionBase<any> {
        return new OptionsInlineQuestion({
            section: 'RequestDetails',
            key: 'Is_Payment_pending__c',
            label: 'Is Payment pending?',
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ],
            order: order,
            relation: [
                {
                    action: 'ENABLE',
                    when: [
                        {
                            id: 'Status__c',
                            value: 'Draft'
                        }
                    ]
                },
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'New_Wires__c',
                            value: 'Yes'
                        }
                    ]
                }
            ],
            mandatory: true
        })
    }

    buildPaymentDate(order?: number): QuestionBase<any> {
        return new DatePickerQuestion({
            section: 'RequestDetails',
            key: 'Payment_date__c',
            label: 'Payment date',
            order: order,
            relation: [
                {
                    action: 'ENABLE',
                    when: [
                        {
                            id: 'Status__c',
                            value: 'Draft'
                        }
                    ]
                },
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Is_Payment_pending__c',
                            value: 'Yes'
                        }
                    ]
                }
            ],
            mandatory: true
        })
    }

    buildLegalSearch(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            section: 'LegalAndBusAcct',
            key: 'LegalSearch',
            label: 'Legal',
            order: order,
            searchable: true,
            template: 'Legal'
        })
    }

    buildLegalSearchForNonCash(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            section: 'RequestDetails',
            key: 'LegalSearch',
            label: 'Legal',
            order: order,
            searchable: true,
            template: 'SPOQLegal'
        })
    }

    buildAlertAcronym(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Alert_Acronym__c',
            label: 'Alert Acronym',
            order: order
        })
    }

    buildCIDLEID(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'CID_LEID__c',
            label: 'CID LEID',
            order: order,
            disabled: true,
            isTooltipPresent: true,
            typeOfTooltip: 'help',
            tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID
                  LEID must be entered by the Facilitator in order to close any new legal account build request.`
        })
    }

    buildContactDetailsLabel(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            section: 'LegalAndBusAcct',
            key: 'Contact Details',
            label: 'Contact Details for Regulatory Documentation Distribution :',
            order: order,
            disabled: true,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Build_Type__c',
                            value: 'New Legal & Bus Acc'
                        }
                    ]
                }
            ]
        })
    }

    buildClientContacted(order?: number, productType?: string): QuestionBase<any> {
        return new DropdownQuestion({
            key: 'Can_the_client_be_contacted__c',
            label: 'Can the client be contacted?',
            defaultOption: productType === 'Prime' ? 'No' : 'Yes',
            order: order,
            selectionChange: true,
            mandatory: true,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Build_Type__c',
                            value: 'New Bus Acc Only'
                        }
                    ]
                }
            ],
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ]
        })
    }

    buildClientContactedAll(order?: number, productType?: string, productSubType?: string): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAndBusAcct',
            key: 'Can_the_client_be_contacted__c',
            label: 'Can the client be contacted?',
            defaultOption: productType === 'Prime' || (productType === 'Equities' && productSubType === 'Derivatives') ? 'No' : 'Yes',
            order: order,
            selectionChange: true,
            mandatory: true,
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ]
        })
    }

    buildNoField(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            key: '',
            label: '',
            order: order,
            displayNone: true
        })
    }

    buildLegalName(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Legal_Name__c',
            label: 'Legal Name',
            order: order,
            isTooltipPresent: true,
            typeOfTooltip: 'help',
            tooltipText: 'Full legal name of the counterparty',
            mandatory: true,
            relation: [
                {
                    action: 'ENABLE',
                    connective: 'AND',
                    when: [
                        {
                            id: 'CID_LEID__c',
                            value: '',
                            operator: '==='
                        }
                    ]
                }
            ]
        })
    }

    buildLegalNameForNonCash(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'RequestDetails',
            key: 'Legal_Name__c',
            label: 'Legal Name',
            order: order,
            mandatory: true,
            relation: [
                {
                    action: 'DISABLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Legal_Id__c',
                            value: '',
                            operator: '!=='
                        }
                    ]
                }
            ]
        })
    }

    buildAlertCode(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Alert_code__c',
            label: 'Alert code',
            order: order
        })
    }

    buildBAID(order?: number, enabledUseRole?: string): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'BA_ID__c',
            label: 'BA ID',
            order: order,
            isTooltipPresent: true,
            //disabled: true,
            typeOfTooltip: 'help',
            tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`,
            // relation: [
            //     {
            //         action: 'ENABLE',
            //         connective: 'OR',
            //         when: [
            //             {
            //                 id: 'User_Role',
            //                 value: 'Facilitator',
            //                 operator: '==='
            //             },
            //             {
            //                 id: 'User_Role',
            //                 value: 'Facilitator Manager',
            //                 operator: '==='
            //             },
            //             {
            //                 id: 'User_Role',
            //                 value: 'Account Approval',
            //                 operator: '==='
            //             },
            //             {
            //                 id: 'User_Role',
            //                 value: 'DCOT',
            //                 operator: '==='
            //             }
            //         ]
            //     }
            // ]
        })
    }

    buildClientContactName(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Client_Contact_Name__c',
            label: 'Client Contact Name',
            order: order,
            mandatory: true,
            relation: [
                {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Can_the_client_be_contacted__c',
                            value: 'Yes'
                        },
                        {
                            id: 'Can_the_client_be_contacted__c',
                            value: ''
                        }
                    ]
                }
            ]
        })
    }

    buildBusAcctName(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Business_Acct_Fund_Name__c',
            label: 'Business Acct / Fund Name',
            order: order,
            mandatory: true
        })
    }

    buildClientType(order?: number, productType?: string, isrequired?: boolean): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAndBusAcct',
            key: 'Client_Type__c',
            label: 'Client Type',
            defaultOption: productType === 'Prime' ? 'INVESTMENT MANAGER' : '',
            order: order,
            required: isrequired ? true : false,
            options: [
                { key: '', value: '--None--' },
                { key: 'AFFILIATES', value: 'AFFILIATES' },
                { key: 'COMPANY', value: 'COMPANY' },
                { key: 'EDUCATIONAL ENTITY', value: 'EDUCATIONAL ENTITY' },
                { key: 'ESTATES / TRUSTS / INDIVIDUALS', value: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'FINANCIAL INSTITUTION', value: 'FINANCIAL INSTITUTION' },
                { key: 'FUNDS', value: 'FUNDS' },
                { key: 'HEALTHCARE', value: 'HEALTHCARE' },
                { key: 'INSURANCE', value: 'INSURANCE' },
                { key: 'INVESTMENT MANAGER', value: 'INVESTMENT MANAGER' },
                { key: 'NON-PROFIT', value: 'NON-PROFIT' },
                { key: 'PENSION / BENEFIT PLANS', value: 'PENSION / BENEFIT PLANS' },
                { key: 'SOVEREIGN / GOV / INTL ORG', value: 'SOVEREIGN / GOV / INTL ORG' }
            ]
        })
    }

    buildExternalSystemList(order?: number): QuestionBase<any> {
        return new MultiselectQuestion({
            section: 'LegalAndBusAcct',
            key: 'External_system_list__c',
            label: 'External system list',
            defaultOption: 'None selected',
            mandatory: true,
            order: order,
            options: [
                { key: 'BBG : BLOOMBERG TRADING SYSTEM', value: 'BBG : BLOOMBERG TRADING SYSTEM' },
                { key: 'BBG12 : BLOOMBERG TRDNG BOOK CALYPSO V12', value: 'BBG12 : BLOOMBERG TRDNG BOOK CALYPSO V12' },
                { key: 'BETA : WCM BETA (SUB-FIRM 136)', value: 'BETA : WCM BETA (SUB-FIRM 136)' },
                { key: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA', value: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA' },
                { key: 'BRWFC : BROADRIDGE - WELLS FARGO & CO', value: 'BRWFC : BROADRIDGE - WELLS FARGO & CO' },
                { key: 'BRWFGC : BROADRIDGE -WELLS FARGO, GR CAY', value: 'BRWFGC : BROADRIDGE -WELLS FARGO, GR CAY' },
                { key: 'BRWFIS : BROADRIDGE -WELLS FARGO INS SEC', value: 'BRWFIS : BROADRIDGE -WELLS FARGO INS SEC' },
                { key: 'BRWFL : BROADRIDGE - WELLS FARGO INTL, LONDON', value: 'BRWFL : BROADRIDGE - WELLS FARGO INTL, LONDON' },
                { key: 'BRWFS : BROADRIDGE - WELLS FARGO SEC', value: 'BRWFS : BROADRIDGE - WELLS FARGO SEC' },
                { key: 'CDCB : CALYPSO DERIVATIVE CLEARING', value: 'CDCB : CALYPSO DERIVATIVE CLEARING' },
                { key: 'CLYP12 : CALYPSO DERIV SYS-RATES&SCP V12', value: 'CLYP12 : CALYPSO DERIV SYS-RATES&SCP V12' },
                { key: 'CLYPS2 : CALYPSO DERIV SYSTEM-CREDIT/SCP', value: 'CLYPS2 : CALYPSO DERIV SYSTEM-CREDIT/SCP' },
                { key: 'CLYPSO : CALYPSO DERIV SYS-GLOBAL RATES', value: 'CLYPSO : CALYPSO DERIV SYS-GLOBAL RATES' },
                { key: 'ENDUR : COMMODITY DERIVATIVES SYSTEM', value: 'ENDUR : COMMODITY DERIVATIVES SYSTEM' },
                { key: 'GDD : GLOBAL DERIVATIVE DOC SYSTEM', value: 'GDD : GLOBAL DERIVATIVE DOC SYSTEM' },
                { key: 'GLGMI : GMI Accounting', value: 'GLGMI : GMI Accounting' },
                { key: 'GMIBD : GMI WELLS FARGO SECURITIES, LLC', value: 'GMIBD : GMI WELLS FARGO SECURITIES, LLC' },
                { key: 'GMIBNK : GMI (WELLS FARGO BANK, NA)', value: 'GMIBNK : GMI (WELLS FARGO BANK, NA)' },
                { key: 'GMICLR : GMI (CLEARING)', value: 'GMICLR : GMI (CLEARING)' },
                { key: 'GMIEB : GMI (EXECUTING BROKER)', value: 'GMIEB : GMI (EXECUTING BROKER)' },
                { key: 'GMIEQO :GMI EQUITIES OPTION NY DESK(DOC)', value: 'GMIEQO :GMI EQUITIES OPTION NY DESK(DOC)' },
                { key: 'GMINT : GMI (WELLS FARGO SECURITIES INTL)', value: 'GMINT : GMI (WELLS FARGO SECURITIES INTL)' },
                { key: 'GMIRSK :GMI WELLS FARGO RISK SERVICE INC', value: 'GMIRSK :GMI WELLS FARGO RISK SERVICE INC' },
                { key: 'GMIUHR : GMI (UNION HAMILTON REINSURANCE LTD.)', value: 'GMIUHR : GMI (UNION HAMILTON REINSURANCE LTD.)' },
                { key: 'GMIWFC :GMI WELLS FARGO COMMODITIES, LLC', value: 'GMIWFC :GMI WELLS FARGO COMMODITIES, LLC' },
                { key: 'GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED', value: 'GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED' },
                { key: 'GMIWFM : GMI (WELLS FARGO FUNDS MANAGEMENT, LLC)', value: 'GMIWFM : GMI (WELLS FARGO FUNDS MANAGEMENT, LLC)' },
                { key: 'IDEAL : IDEAL / IPREO LE LINKAGE SUBSCRIBER', value: 'IDEAL : IDEAL / IPREO LE LINKAGE SUBSCRIBER' },
                { key: 'IMAGIN : IMAGINE', value: 'IMAGIN : IMAGINE' },
                { key: 'LOANET : STOCK BORROW-LOAN ACCOUNT', value: 'LOANET : STOCK BORROW-LOAN ACCOUNT' },
                { key: 'LOANIQ : LOAN SYNDICATION SYSTEM', value: 'LOANIQ : LOAN SYNDICATION SYSTEM' },
                { key: 'MERLGS : MERLIN - GOLDMAN SACHS', value: 'MERLGS : MERLIN - GOLDMAN SACHS' },
                { key: 'MERLJP : MERLIN - JP MORGAN', value: 'MERLJP : MERLIN - JP MORGAN' },
                { key: 'NAPWB : NAPA WBNA', value: 'NAPWB : NAPA WBNA' },
                { key: 'NAPWCM : NAPA WCM', value: 'NAPWCM : NAPA WCM' },
                { key: 'P3BANK : PHASE 3 WBNA (FIRM 53)', value: 'P3BANK : PHASE 3 WBNA (FIRM 53)' },
                { key: 'P3ND20 : WACHOVIA FIRM 20', value: 'P3ND20 : WACHOVIA FIRM 20' },
                { key: 'P3SE20 : PHASE 3 WCM (FIRM 54)', value: 'P3SE20 : PHASE 3 WCM (FIRM 54)' },
                { key: 'P3SK39:PHASE3 WFS (FM39) BRKR SFKEEPING', value: 'P3SK39:PHASE3 WFS (FM39) BRKR SFKEEPING' },
                { key: 'P3SK76:PHASE 3 WFS (FM 76)BANK SFKEEPING', value: 'P3SK76:PHASE 3 WFS (FM 76)BANK SFKEEPING' },
                { key: 'PS : PORTFOLIO', value: 'PS : PORTFOLIO' },
                { key: 'SCRPW : SIMCORP WEST', value: 'SCRPW : SIMCORP WEST' },
                { key: 'WFPSSH: WFPSSH - GOLDMAN SACHS', value: 'WFPSSH: WFPSSH - GOLDMAN SACHS' },
                { key: 'WFTRST : WELLS FARGO CORPORATE TRUST', value: 'WFTRST : WELLS FARGO CORPORATE TRUST' },
                { key: 'ARTS : ANVIL REPO TRADING SYSTEM', value: 'ARTS : ANVIL REPO TRADING SYSTEM' },
                { key: 'CLYPS3 : CALYPSO DERIV SYSTEM-BACK OFFICE/CDBO', value: 'CLYPS3 : CALYPSO DERIV SYSTEM-BACK OFFICE/CDBO' },
                { key: 'BRWFSE : Broadridge-Wells Fargo Securities Europe S.A', value: 'BRWFSE : Broadridge-Wells Fargo Securities Europe S.A' }
            ]
        })
    }

    buildClientContactPhone(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Client_Contact_Phone__c',
            label: 'Client Contact Phone',
            order: order,
            mandatory: true,
            relation: [
                {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Can_the_client_be_contacted__c',
                            value: 'Yes'
                        },
                        {
                            id: 'Can_the_client_be_contacted__c',
                            value: ''
                        }
                    ]
                }
            ]
        })
    }

    buildShortName(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Short_Name__c',
            label: 'Short Name',
            order: order
        })
    }

    buildClientSubType(order?: number, productType?: string, isrequired?: boolean): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAndBusAcct',
            key: 'Client_SubType__c',
            label: 'Client SubType',
            parent: {
                key: 'Client_Type__c',
                value: ''
            },
            defaultOption: productType === 'Prime' ? 'Non Bank Owned Investment Manager' : '',
            order: order,
            required: isrequired ? true : false,
            options: [
                { key: '', value: '-- Please Select --' },
                { key: 'WF Affiliated Bank (WFBNA sub)', value: 'WF Affiliated Bank (WFBNA sub)', parentKey: 'AFFILIATES' },
                { key: 'WF Affiliated Bank (Non-WFBNA sub)', value: 'WF Affiliated Bank (Non-WFBNA sub)', parentKey: 'AFFILIATES' },
                { key: 'WF Affiliated Non-Bank', value: 'WF Affiliated Non-Bank', parentKey: 'AFFILIATES' },
                { key: 'Agriculture, Forestry, Fishing and Hunting', value: 'Agriculture, Forestry, Fishing and Hunting', parentKey: 'COMPANY' },
                { key: 'Air Transportation', value: 'Air Transportation', parentKey: 'COMPANY' },
                { key: 'Arts, Entertainment and Recreation', value: 'Arts, Entertainment and Recreation', parentKey: 'COMPANY' },
                { key: 'Bearer Share Company', value: 'Bearer Share Company', parentKey: 'COMPANY' },
                { key: 'Construction', value: 'Construction', parentKey: 'COMPANY' },
                { key: 'Consumer Financing', value: 'Consumer Financing', parentKey: 'COMPANY' },
                { key: 'Convenience Stores', value: 'Convenience Stores', parentKey: 'COMPANY' },
                { key: 'Dealers in High-Value Goods', value: 'Dealers in High-Value Goods', parentKey: 'COMPANY' },
                { key: 'Deep Sea Freight Transportation', value: 'Deep Sea Freight Transportation', parentKey: 'COMPANY' },
                { key: 'Energy / Utilities', value: 'Energy / Utilities', parentKey: 'COMPANY' },
                { key: 'Equipment Financing', value: 'Equipment Financing', parentKey: 'COMPANY' },
                { key: 'Food / Beverage Services', value: 'Food / Beverage Services', parentKey: 'COMPANY' },
                { key: 'Gaming - Tribal', value: 'Gaming - Tribal', parentKey: 'COMPANY' },
                { key: 'Gaming - Non-Tribal', value: 'Gaming - Non-Tribal', parentKey: 'COMPANY' },
                { key: 'Hotels/Lodging', value: 'Hotels/Lodging', parentKey: 'COMPANY' },
                { key: 'Importer/Exporter', value: 'Importer/Exporter', parentKey: 'COMPANY' },
                { key: 'Land Based Transportation and Warehousing', value: 'Land Based Transportation and Warehousing', parentKey: 'COMPANY' },
                { key: 'Management of Companies and Enterprises', value: 'Management of Companies and Enterprises', parentKey: 'COMPANY' },
                { key: 'Manufacturing', value: 'Manufacturing', parentKey: 'COMPANY' },
                { key: 'Mining', value: 'Mining', parentKey: 'COMPANY' },
                { key: 'Money Service Business', value: 'Money Service Business', parentKey: 'COMPANY' },
                { key: 'Parking Garage(s)', value: 'Parking Garage(s)', parentKey: 'COMPANY' },
                { key: 'Pawnbroker', value: 'Pawnbroker', parentKey: 'COMPANY' },
                { key: 'Professional Service Provider', value: 'Professional Service Provider', parentKey: 'COMPANY' },
                { key: 'Real Estate, Rental, and Leasing', value: 'Real Estate, Rental, and Leasing', parentKey: 'COMPANY' },
                { key: 'Restaurant', value: 'Restaurant', parentKey: 'COMPANY' },
                { key: 'Retail Trade', value: 'Retail Trade', parentKey: 'COMPANY' },
                { key: 'Special Purpose Entity / Vehicle', value: 'Special Purpose Entity / Vehicle', parentKey: 'COMPANY' },
                { key: 'Technology, Media, Telecommunications', value: 'Technology, Media, Telecommunications', parentKey: 'COMPANY' },
                { key: 'Third Party Payment Processors', value: 'Third Party Payment Processors', parentKey: 'COMPANY' },
                { key: 'Travel Agencies', value: 'Travel Agencies', parentKey: 'COMPANY' },
                { key: 'Waste Management', value: 'Waste Management', parentKey: 'COMPANY' },
                { key: 'Wholesale Trade', value: 'Wholesale Trade', parentKey: 'COMPANY' },
                { key: 'Private University', value: 'Private University', parentKey: 'EDUCATIONAL ENTITY' },
                { key: 'Private Schools (K-12)', value: 'Private Schools (K-12)', parentKey: 'EDUCATIONAL ENTITY' },
                { key: 'Public Schools (K-12)', value: 'Public Schools (K-12)', parentKey: 'EDUCATIONAL ENTITY' },
                { key: 'Public University', value: 'Public University', parentKey: 'EDUCATIONAL ENTITY' },
                { key: 'Business Trusts', value: 'Business Trusts', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Estates', value: 'Estates', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Foreign Political Official', value: 'Foreign Political Official', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Individuals', value: 'Individuals', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Investment Clubs', value: 'Investment Clubs', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Sole Proprietor', value: 'Sole Proprietor', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Trusts (Individual)', value: 'Trusts (Individual)', parentKey: 'ESTATES / TRUSTS / INDIVIDUALS' },
                { key: 'Bank Hold Co', value: 'Bank Hold Co', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Broker Dealer', value: 'Broker Dealer', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Central Counterparty/Clearinghouse', value: 'Central Counterparty/Clearinghouse', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Commercial Bank', value: 'Commercial Bank', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Credit Card Company', value: 'Credit Card Company', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Credit Union', value: 'Credit Union', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Escrow Agent', value: 'Escrow Agent', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Exchanges', value: 'Exchanges', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Mortgage Originator', value: 'Mortgage Originator', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Non Govt Cooperative Bank', value: 'Non Govt Cooperative Bank', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Proprietary Trading Desk', value: 'Proprietary Trading Desk', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Thrifts / S&Ls', value: 'Thrifts / S&Ls', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Trust Bank', value: 'Trust Bank', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Yankee Bank', value: 'Yankee Bank', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Commodities Dealer', value: 'Commodities Dealer', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Investment Subsidiary', value: 'Investment Subsidiary', parentKey: 'FINANCIAL INSTITUTION' },
                { key: 'Fund of Funds', value: 'Fund of Funds', parentKey: 'FUNDS' },
                { key: 'Hedge Fund', value: 'Hedge Fund', parentKey: 'FUNDS' },
                { key: 'Money Market Fund', value: 'Money Market Fund', parentKey: 'FUNDS' },
                { key: 'Mutual Fund', value: 'Mutual Fund', parentKey: 'FUNDS' },
                { key: 'Private Equity Fund', value: 'Private Equity Fund', parentKey: 'FUNDS' },
                { key: 'REIT', value: 'REIT', parentKey: 'FUNDS' },
                { key: 'For Profit Healthcare', value: 'For Profit Healthcare', parentKey: 'HEALTHCARE' },
                { key: 'Governmental Healthcare', value: 'Governmental Healthcare', parentKey: 'HEALTHCARE' },
                { key: 'Not for Profit Healthcare', value: 'Not for Profit Healthcare', parentKey: 'HEALTHCARE' },
                { key: 'Nursing Home/Rehab Center', value: 'Nursing Home/Rehab Center', parentKey: 'HEALTHCARE' },
                { key: 'Insurance', value: 'Insurance', parentKey: 'INSURANCE' },
                { key: 'Insurance Hold Co', value: 'Insurance Hold Co', parentKey: 'INSURANCE' },
                { key: 'Re-Insurance', value: 'Re-Insurance', parentKey: 'INSURANCE' },
                { key: 'Bank Owned Investment Manager', value: 'Bank Owned Investment Manager', parentKey: 'INVESTMENT MANAGER' },
                { key: 'Insurance Based Investment Manager', value: 'Insurance Based Investment Manager', parentKey: 'INVESTMENT MANAGER' },
                { key: 'Non Bank Owned Investment Manager', value: 'Non Bank Owned Investment Manager', parentKey: 'INVESTMENT MANAGER' },
                { key: 'CMBS Defeasance Advisor', value: 'CMBS Defeasance Advisor', parentKey: 'INVESTMENT MANAGER' },
                { key: 'Municipal Advisor', value: 'Municipal Advisor', parentKey: 'INVESTMENT MANAGER' },
                { key: 'Charities - Non (Cultural/Membership/Services)', value: 'Charities - Non (Cultural/Membership/Services)', parentKey: 'NON-PROFIT' },
                { key: 'Charities - Cultural/Membership/Services', value: 'Charities - Cultural/Membership/Services', parentKey: 'NON-PROFIT' },
                { key: 'Endowments', value: 'Endowments', parentKey: 'NON-PROFIT' },
                { key: 'Foundations', value: 'Foundations', parentKey: 'NON-PROFIT' },
                { key: 'Religious Entity', value: 'Religious Entity', parentKey: 'NON-PROFIT' },
                { key: 'Non Profit Corporation', value: 'Non Profit Corporation', parentKey: 'NON-PROFIT' },
                { key: 'City Govt Pension / Benefit', value: 'City Govt Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'Company Pension / Benefit', value: 'Company Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'County Govt Pension / Benefit', value: 'County Govt Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'ERISA - Government', value: 'ERISA - Government', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'ERISA - Non Government', value: 'ERISA - Non Government', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'Federal Govt Pension / Benefit', value: 'Federal Govt Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'IRAs', value: 'IRAs', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'Non Profit Pension / Benefit', value: 'Non Profit Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'State Govt/Province Pension / Benefit', value: 'State Govt/Province Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'Union Pension / Benefit', value: 'Union Pension / Benefit', parentKey: 'PENSION / BENEFIT PLANS' },
                { key: 'Authorities/Other Municipal', value: 'Authorities/Other Municipal', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'City', value: 'City', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'County', value: 'County', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Federal Reserve Banks / Central Banks', value: 'Federal Reserve Banks / Central Banks', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Govt Co-Operatives', value: 'Govt Co-Operatives', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Govt Development Bank', value: 'Govt Development Bank', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Govt Sponsored Enterprise', value: 'Govt Sponsored Enterprise', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'International / Supranational Org', value: 'International / Supranational Org', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Native American Tribe', value: 'Native American Tribe', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Non US Embassy / Consulate', value: 'Non US Embassy / Consulate', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Sovereign / Nation', value: 'Sovereign / Nation', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'Sovereign Wealth Fund', value: 'Sovereign Wealth Fund', parentKey: 'SOVEREIGN / GOV / INTL ORG' },
                { key: 'State / Province', value: 'State / Province', parentKey: 'SOVEREIGN / GOV / INTL ORG' }
            ]
        })
    }

    buildCMAName(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'CMA_Name__c',
            label: 'CMA Name',
            order: order,
            relation: [
                {
                    action: 'DISABLE',
                    connective: 'AND',
                    when: [
                        {
                            id: 'CMAId__c',
                            value: 1,
                            operator: '>='
                        }
                    ]
                }
            ]
        })
    }

    buildClientContactEmail(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'Client_Contact_Email__c',
            label: 'Client Contact Email',
            order: order,
            mandatory: true,
            relation: [
                {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Can_the_client_be_contacted__c',
                            value: 'Yes'
                        },
                        {
                            id: 'Can_the_client_be_contacted__c',
                            value: ''
                        }
                    ]
                }
            ]
        })
    }

    getEntityTypeOptions() {
        var options = [
            { key: '', value: '--None--' },
            { key: 'AFFIL - WELLS FARGO AFFILIATE', value: 'AFFIL - WELLS FARGO AFFILIATE' },
            { key: 'ALNACO - ALASKA NATIVE CORP', value: 'ALNACO - ALASKA NATIVE CORP' },
            { key: 'BANKDL - BANK-DEALER', value: 'BANKDL - BANK-DEALER' },
            { key: 'BANKUS - NATIONAL BANK', value: 'BANKUS - NATIONAL BANK' },
            { key: 'BD - BROKER/DEALERS', value: 'BD - BROKER/DEALERS' },
            { key: 'BKCENT - FOREIGN CENTRAL OR REDEV BANK', value: 'BKCENT - FOREIGN CENTRAL OR REDEV BANK' },
            { key: 'BKFOFB - FOREIGN BANKS (FOREIGN BRANCH)', value: 'BKFOFB - FOREIGN BANKS (FOREIGN BRANCH)' },
            { key: 'BKFOUS - FOREIGN BANKS (US BRANCH)', value: 'BKFOUS - FOREIGN BANKS (US BRANCH)' },
            { key: 'BKUSFB - US BANK/FOREIGN BRANCH', value: 'BKUSFB - US BANK/FOREIGN BRANCH' },
            { key: 'CHURCH - CHURCHES', value: 'CHURCH - CHURCHES' },
            { key: 'COMP - COMPANY (NON-EXEMPT)', value: 'COMP - COMPANY (NON-EXEMPT)' },
            { key: 'COOP - AGRICULTURAL COOPERATIVE', value: 'COOP - AGRICULTURAL COOPERATIVE' },
            { key: 'CORP - CORPORATION', value: 'CORP - CORPORATION' },
            { key: 'CREDIT - CREDIT UNIONS', value: 'CREDIT - CREDIT UNIONS' },
            { key: 'CVG - COVERAGE', value: 'CVG - COVERAGE' },
            { key: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM', value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM' },
            { key: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS', value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS' },
            { key: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS', value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS' },
            { key: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE', value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE' },
            { key: 'ESCEXE - ESCROW AGENT-EXEMPT', value: 'ESCEXE - ESCROW AGENT-EXEMPT' },
            { key: 'ESCNON - ESCROW AGENT NON-EXEMPT', value: 'ESCNON - ESCROW AGENT NON-EXEMPT' },
            { key: 'ESTATE - ESTATES', value: 'ESTATE - ESTATES' },
            { key: 'FAFFIL - WELLS FARGO FOREIGN AFFILIATE', value: 'FAFFIL - WELLS FARGO FOREIGN AFFILIATE' },
            { key: 'FEDGOV - FEDERAL GOVERNMENT AGENCY', value: 'FEDGOV - FEDERAL GOVERNMENT AGENCY' },
            { key: 'FOBANK - FOREIGN FINANCIAL INSTITUTION', value: 'FOBANK - FOREIGN FINANCIAL INSTITUTION' },
            { key: 'FOCO - FOREIGN COMPANIES', value: 'FOCO - FOREIGN COMPANIES' },
            { key: 'FOFUND - FOREIGN FUND', value: 'FOFUND - FOREIGN FUND' },
            { key: 'FOGOV - FOREIGN GOVERNMENT/EMBASSIES', value: 'FOGOV - FOREIGN GOVERNMENT/EMBASSIES' },
            { key: 'FOHEDG - FOREIGN HEDGE FUND', value: 'FOHEDG - FOREIGN HEDGE FUND' },
            { key: 'FOIND - FOREIGN INDIVIDUALS', value: 'FOIND - FOREIGN INDIVIDUALS' },
            { key: 'FOINS - FOREIGN INSURANCE COMPANY', value: 'FOINS - FOREIGN INSURANCE COMPANY' },
            { key: 'FOMNY - FOREIGN MONEY REMITTER', value: 'FOMNY - FOREIGN MONEY REMITTER' },
            { key: 'FOSEC - FOREIGN SECURITIES FIRM', value: 'FOSEC - FOREIGN SECURITIES FIRM' },
            { key: 'FUND - FUNDS (MONEY, MUTUAL, ETC.)', value: 'FUND - FUNDS (MONEY, MUTUAL, ETC.)' },
            { key: 'GP - GENERAL PARTNERSHIP', value: 'GP - GENERAL PARTNERSHIP' },
            { key: 'GSE - GOVERNMENT SPONSORED ENTERPRIS', value: 'GSE - GOVERNMENT SPONSORED ENTERPRIS' },
            { key: 'HEDGE - DOMESTIC HEDGE FUND', value: 'HEDGE - DOMESTIC HEDGE FUND' },
            { key: 'INDIV - INDIVIDUALS', value: 'INDIV - INDIVIDUALS' },
            { key: 'INSUR - INSURANCE COMPANIES', value: 'INSUR - INSURANCE COMPANIES' },
            { key: 'INVADV - REGISTERED INVESTMENT ADVISORS', value: 'INVADV - REGISTERED INVESTMENT ADVISORS' },
            { key: 'LLC - LIMITED LIABILITY COMP OR CORP', value: 'LLC - LIMITED LIABILITY COMP OR CORP' },
            { key: 'LLLP - LIMITED LIABILITY LIMITED PART', value: 'LLLP - LIMITED LIABILITY LIMITED PART' },
            { key: 'LLP - LIMITED LIABILITY PARTNERSHIP', value: 'LLP - LIMITED LIABILITY PARTNERSHIP' },
            { key: 'LP - LIMITED PARTNERSHIP', value: 'LP - LIMITED PARTNERSHIP' },
            { key: 'MNYREM - MONEY REMITTER (DOMESTIC)', value: 'MNYREM - MONEY REMITTER (DOMESTIC)' },
            { key: 'MORTCO - MORTGAGE COMPANY', value: 'MORTCO - MORTGAGE COMPANY' },
            { key: 'MUNI - MUNICIPAL GOVERNMENTS', value: 'MUNI - MUNICIPAL GOVERNMENTS' },
            { key: 'NPROFT - NON PROFIT ORGANIZATIONS', value: 'NPROFT - NON PROFIT ORGANIZATIONS' },
            { key: 'PARTNR - PARTNERSHIP', value: 'PARTNR - PARTNERSHIP' },
            { key: 'PLAN - PLANS (BENEFITS,PENSION,ETC.)', value: 'PLAN - PLANS (BENEFITS,PENSION,ETC.)' },
            { key: 'REIT - REAL ESTATE INVESTMENT TRUST', value: 'REIT - REAL ESTATE INVESTMENT TRUST' },
            { key: 'SCHOOL - SCHOOLS', value: 'SCHOOL - SCHOOLS' },
            { key: 'STBANK - STATE CHARTERED BANK', value: 'STBANK - STATE CHARTERED BANK' },
            { key: 'STGOV - STATE GOVERNMENT OR AGENCY', value: 'STGOV - STATE GOVERNMENT OR AGENCY' },
            { key: 'TRIBAL - INDIAN TRIBE', value: 'TRIBAL - INDIAN TRIBE' },
            { key: 'TRUST - TRUST', value: 'TRUST - TRUST' }
        ];
        return options;
    }

    buildCustomerType(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAndBusAcct',
            key: 'Entity_Type__c',
            label: 'Customer Type',
            defaultOption: '',
            order: order,
            options: this.getEntityTypeOptions()
        })
    }

    buildNotes(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            key: 'Notes__c',
            label: 'Notes',
            order: order
        })
    }

    buildAddressSearch(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            section: 'LegalAddressDetails',
            key: 'AddressSearch',
            label: 'Address',
            order: order,
            searchable: true,
            template: 'Address',
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Build_Type__c',
                            value: 'New Bus Acc Only'
                        }
                    ]
                }
            ]
        })
    }

    buildCity(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAddressDetails',
            key: 'City__c',
            label: 'City',
            order: order
        })
    }

    buildState(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAddressDetails',
            key: 'State__c',
            label: 'State',
            defaultOption: '',
            order: order,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Country__c',
                            value: 'US - UNITED STATES'
                        }
                    ]
                }
            ],
            options: this.buildStateOptions()
        })
    }

    buildStateOptions() {
        return [
            { key: '', value: '--None--' },
            { key: 'AK - ALASKA', value: 'AK - ALASKA' },
            { key: 'AL - ALABAMA', value: 'AL - ALABAMA' },
            { key: 'AR - ARKANSAS', value: 'AR - ARKANSAS' },
            { key: 'AZ - ARIZONA', value: 'AZ - ARIZONA' },
            { key: 'CA - CALIFORNIA', value: 'CA - CALIFORNIA' },
            { key: 'CO - COLORADO', value: 'CO - COLORADO' },
            { key: 'CT - CONNECTICUT', value: 'CT - CONNECTICUT' },
            { key: 'DC - DISTRICT OF COLUMBIA', value: 'DC - DISTRICT OF COLUMBIA' },
            { key: 'DE - DELAWARE', value: 'DE - DELAWARE' },
            { key: 'FL - FLORIDA', value: 'FL - FLORIDA' },
            { key: 'GA - GEORGIA', value: 'GA - GEORGIA' },
            { key: 'HI - HAWAII', value: 'HI - HAWAII' },
            { key: 'IA - IOWA', value: 'IA - IOWA' },
            { key: 'ID - IDAHO', value: 'ID - IDAHO' },
            { key: 'IL - ILLINOIS', value: 'IL - ILLINOIS' },
            { key: 'IN - INDIANA', value: 'IN - INDIANA' },
            { key: 'KS - KANSAS', value: 'KS - KANSAS' },
            { key: 'KY - KENTUCKY', value: 'KY - KENTUCKY' },
            { key: 'LA - LOUISIANNA', value: 'LA - LOUISIANNA' },
            { key: 'MA - MASSACHUSETTS', value: 'MA - MASSACHUSETTS' },
            { key: 'MD - MARYLAND', value: 'MD - MARYLAND' },
            { key: 'ME - MAINE', value: 'ME - MAINE' },
            { key: 'MI - MICHIGAN', value: 'MI - MICHIGAN' },
            { key: 'MN - MINNESOTA', value: 'MN - MINNESOTA' },
            { key: 'MO - MISSOURI', value: 'MO - MISSOURI' },
            { key: 'MS - MISSISSIPPI', value: 'MS - MISSISSIPPI' },
            { key: 'MT - MONTANA', value: 'MT - MONTANA' },
            { key: 'NC - NORTH CAROLINA', value: 'NC - NORTH CAROLINA' },
            { key: 'ND - NORTH DAKOTA', value: 'ND - NORTH DAKOTA' },
            { key: 'NE - NEBRASKA', value: 'NE - NEBRASKA' },
            { key: 'NH - NEW HAMPSHIRE', value: 'NH - NEW HAMPSHIRE' },
            { key: 'NJ - NEW JERSEY', value: 'NJ - NEW JERSEY' },
            { key: 'NM - NEW MEXICO', value: 'NM - NEW MEXICO' },
            { key: 'NV - NEVADA', value: 'NV - NEVADA' },
            { key: 'NY - NEW YORK', value: 'NY - NEW YORK' },
            { key: 'OH - OHIO', value: 'OH - OHIO' },
            { key: 'OK - OKLAHOMA', value: 'OK - OKLAHOMA' },
            { key: 'OR - OREGON', value: 'OR - OREGON' },
            { key: 'PA - PENNSYLVANIA', value: 'PA - PENNSYLVANIA' },
            { key: 'RI - RHODE ISLAND', value: 'RI - RHODE ISLAND' },
            { key: 'SC - SOUTH CAROLINA', value: 'SC - SOUTH CAROLINA' },
            { key: 'SD - SOUTH DAKOTA', value: 'SD - SOUTH DAKOTA' },
            { key: 'TN - TENNESSEE', value: 'TN - TENNESSEE' },
            { key: 'TX - TEXAS', value: 'TX - TEXAS' },
            { key: 'UT - UTAH', value: 'UT - UTAH' },
            { key: 'VA - VIRGINIA', value: 'VA - VIRGINIA' },
            { key: 'VT - VERMONT', value: 'VT - VERMONT' },
            { key: 'WA - WASHINGTON', value: 'WA - WASHINGTON' },
            { key: 'WI - WISCONSIN', value: 'WI - WISCONSIN' },
            { key: 'WV - WEST VIRGINIA', value: 'WV - WEST VIRGINIA' },
            { key: 'WY - WYOMING', value: 'WY - WYOMING' }
        ]
    }

    buildCanadianProvinceOptions() {
        return [
            { key: '', value: '--None--' },
            { key: 'AB - ALBERTA', value: 'AB - ALBERTA' },
            { key: 'BC - BRITISH COLUMBIA', value: 'BC - BRITISH COLUMBIA' },
            { key: 'MB - MANITOBA', value: 'MB - MANITOBA' },
            { key: 'NB - NEW BRUNSWICK', value: 'NB - NEW BRUNSWICK' },
            { key: 'NL - NEWFOUNDLAND AND LABRADOR', value: 'NL - NEWFOUNDLAND AND LABRADOR' },
            { key: 'NT - NORTHWEST TERRITORIES', value: 'NT - NORTHWEST TERRITORIES' },

            { key: 'NS - NOVA SCOTIA', value: 'NS - NOVA SCOTIA' },
            { key: 'NU - NUNAVUT', value: 'NU - NUNAVUT' },
            { key: 'ON - ONTARIO', value: 'ON - ONTARIO' },
            { key: 'PE - PRINCE EDWARD ISLAND', value: 'PE - PRINCE EDWARD ISLAND' },
            { key: 'QC - QUEBEC', value: 'QC - QUEBEC' },
            { key: 'SK - SASKATCHEWAN', value: 'SK - SASKATCHEWAN' },
            { key: 'YT - YUKON', value: 'YT - YUKON' }
        ];
    }

    buildCanadianProvince(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAddressDetails',
            key: 'State__c',
            label: 'Canadian Province',
            defaultOption: '',
            order: order,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Country__c',
                            value: 'CA - CANADA'
                        }
                    ]
                }
            ],
            options: this.buildCanadianProvinceOptions()
        })
    }

    buildAddressLine1(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAddressDetails',
            key: 'AddressLine1__c',
            label: 'Address Line1',
            order: order
        })
    }

    buildZip(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAddressDetails',
            key: 'Zip__c',
            label: 'Zip',
            order: order,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Country__c',
                            value: 'CA - CANADA',
                            operator: '!=='
                        }
                    ]
                },
            ]
        })
    }

    buildPostalCode(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAddressDetails',
            key: 'Zip__c',
            label: 'Postal Code',
            order: order,
            mandatory: true,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Country__c',
                            value: 'CA - CANADA'
                        }
                    ]
                }
            ]
        })
    }
    countryOptions() {
        return [
            { key: '', value: '--None--' },
            { key: 'AD - ANDORRA', value: 'AD - ANDORRA' },
            { key: 'AE - UNITED ARAB EMIRATES', value: 'AE - UNITED ARAB EMIRATES' },
            { key: 'AF - AFGHANISTAN', value: 'AF - AFGHANISTAN' },
            { key: 'AG - ANTIGUA AND BARBUDA', value: 'AG - ANTIGUA AND BARBUDA' },
            { key: 'AI - ANGUILLA', value: 'AI - ANGUILLA' },
            { key: 'AL - ALBANIA', value: 'AL - ALBANIA' },
            { key: 'AM - ARMENIA', value: 'AM - ARMENIA' },
            { key: 'AN - NETHERLANDS ANTILLES', value: 'AN - NETHERLANDS ANTILLES' },
            { key: 'AO - ANGOLA', value: 'AO - ANGOLA' },
            { key: 'AQ - ANTARCTICA', value: 'AQ - ANTARCTICA' },
            { key: 'AR - ARGENTINA', value: 'AR - ARGENTINA' },
            { key: 'AS - AMERICAN SAMOA', value: 'AS - AMERICAN SAMOA' },
            { key: 'AT - AUSTRIA', value: 'AT - AUSTRIA' },
            { key: 'AU - AUSTRALIA', value: 'AU - AUSTRALIA' },
            { key: 'AW - ARUBA', value: 'AW - ARUBA' },
            { key: 'AX - ALAND ISLANDS', value: 'AX - ALAND ISLANDS' },
            { key: 'AZ - AZERBAIJAN', value: 'AZ - AZERBAIJAN' },
            { key: 'BA - BOSNIA AND HERZEGOVINA', value: 'BA - BOSNIA AND HERZEGOVINA' },
            { key: 'BB - BARBADOS', value: 'BB - BARBADOS' },
            { key: 'BD - BANGLADESH', value: 'BD - BANGLADESH' },
            { key: 'BE - BELGIUM', value: 'BE - BELGIUM' },
            { key: 'BF - BURKINA FASO', value: 'BF - BURKINA FASO' },
            { key: 'BG - BULGARIA', value: 'BG - BULGARIA' },
            { key: 'BH - BAHRAIN', value: 'BH - BAHRAIN' },
            { key: 'BI - BURUNDI', value: 'BI - BURUNDI' },
            { key: 'BJ - BENIN', value: 'BJ - BENIN' },
            { key: 'BM - BERMUDA', value: 'BM - BERMUDA' },
            { key: 'BN - BRUNEI DARUSSALAM', value: 'BN - BRUNEI DARUSSALAM' },
            { key: 'BO - BOLIVIA', value: 'BO - BOLIVIA' },
            { key: 'BR - BRAZIL', value: 'BR - BRAZIL' },
            { key: 'BS - BAHAMAS', value: 'BS - BAHAMAS' },
            { key: 'BT - BHUTAN', value: 'BT - BHUTAN' },
            { key: 'BV - BOUVET ISLAND', value: 'BV - BOUVET ISLAND' },
            { key: 'BW - BOTSWANA', value: 'BW - BOTSWANA' },
            { key: 'BY - BELARUS', value: 'BY - BELARUS' },
            { key: 'BZ - BELIZE', value: 'BZ - BELIZE' },
            { key: 'CA - CANADA', value: 'CA - CANADA' },
            { key: 'CC - COCOS (KEELING) ISLANDS', value: 'CC - COCOS (KEELING) ISLANDS' },
            { key: 'CD - CONGO,THE DEMOCRATIC REPUBLIC', value: 'CD - CONGO,THE DEMOCRATIC REPUBLIC' },
            { key: 'CF - CENTRAL AFRICAN REPUBLIC', value: 'CF - CENTRAL AFRICAN REPUBLIC' },
            { key: 'CG - CONGO', value: 'CG - CONGO' },
            { key: 'CH - SWITZERLAND', value: 'CH - SWITZERLAND' },
            { key: `CI - COTE D'IVOIRE`, value: `CI - COTE D'IVOIRE` },
            { key: 'CK - COOK ISLANDS', value: 'CK - COOK ISLANDS' },
            { key: 'CL - CHILE', value: 'CL - CHILE' },
            { key: 'CM - CAMEROON', value: 'CM - CAMEROON' },
            { key: 'CN - CHINA', value: 'CN - CHINA' },
            { key: 'CO - COLOMBIA', value: 'CO - COLOMBIA' },
            { key: 'CR - COSTA RICA', value: 'CR - COSTA RICA' },
            { key: 'CS - SERBIA AND MONTENEGRO-DONT USE', value: 'CS - SERBIA AND MONTENEGRO-DONT USE' },
            { key: 'CU - CUBA', value: 'CU - CUBA' },
            { key: 'CV - CAPE VERDE', value: 'CV - CAPE VERDE' },
            { key: 'CX - CHRISTMAS ISLAND', value: 'CX - CHRISTMAS ISLAND' },
            { key: 'CY - CYPRUS', value: 'CY - CYPRUS' },
            { key: 'CZ - CZECH REPUBLIC', value: 'CZ - CZECH REPUBLIC' },
            { key: 'DE - GERMANY', value: 'DE - GERMANY' },
            { key: 'DJ - DJIBOUTI', value: 'DJ - DJIBOUTI' },
            { key: 'DK - DENMARK', value: 'DK - DENMARK' },
            { key: 'DM - DOMINICA', value: 'DM - DOMINICA' },
            { key: 'DO - DOMINICAN REPUBLIC', value: 'DO - DOMINICAN REPUBLIC' },
            { key: 'DZ - ALGERIA', value: 'DZ - ALGERIA' },
            { key: 'EC - ECUADOR', value: 'EC - ECUADOR' },
            { key: 'EE - ESTONIA', value: 'EE - ESTONIA' },
            { key: 'EG - EGYPT', value: 'EG - EGYPT' },
            { key: 'EH - WESTERN SAHARA', value: 'EH - WESTERN SAHARA' },
            { key: 'ER - ERITREA', value: 'ER - ERITREA' },
            { key: 'ES - SPAIN', value: 'ES - SPAIN' },
            { key: 'ET - ETHIOPIA', value: 'ET - ETHIOPIA' },
            { key: 'FI - FINLAND', value: 'FI - FINLAND' },
            { key: 'FJ - FIJI', value: 'FJ - FIJI' },
            { key: 'FK - FALKLAND ISLANDS (MALVINAS)', value: 'FK - FALKLAND ISLANDS (MALVINAS)' },
            { key: 'FM - MICRONESIA,FEDERATED STATES OF', value: 'FM - MICRONESIA,FEDERATED STATES OF' },
            { key: 'FO - FAROE ISLANDS', value: 'FO - FAROE ISLANDS' },
            { key: 'FR - FRANCE', value: 'FR - FRANCE' },
            { key: 'GA - GABON', value: 'GA - GABON' },
            { key: 'GB - UNITED KINGDOM', value: 'GB - UNITED KINGDOM' },
            { key: 'GD - GRENADA', value: 'GD - GRENADA' },
            { key: 'GE - GEORGIA', value: 'GE - GEORGIA' },
            { key: 'GF - FRENCH GUIANA', value: 'GF - FRENCH GUIANA' },
            { key: 'GG - GUERNSEY', value: 'GG - GUERNSEY' },
            { key: 'GH - GHANA', value: 'GH - GHANA' },
            { key: 'GI - GIBRALTAR', value: 'GI - GIBRALTAR' },
            { key: 'GK - GUERNSEY, C.I. - DO NOT USE', value: 'GK - GUERNSEY, C.I. - DO NOT USE' },
            { key: 'GL - GREENLAND', value: 'GL - GREENLAND' },
            { key: 'GM - GAMBIA', value: 'GM - GAMBIA' },
            { key: 'GN - GUINEA', value: 'GN - GUINEA' },
            { key: 'GP - GUADELOUPE', value: 'GP - GUADELOUPE' },
            { key: 'GQ - EQUATORIAL GUINEA', value: 'GQ - EQUATORIAL GUINEA' },
            { key: 'GR - GREECE', value: 'GR - GREECE' },
            { key: 'GS - SOUTH GEORGIA & SOUTH SANDWICH', value: 'GS - SOUTH GEORGIA & SOUTH SANDWICH' },
            { key: 'GT - GUATEMALA', value: 'GT - GUATEMALA' },
            { key: 'GU - GUAM', value: 'GU - GUAM' },
            { key: 'GW - GUINEA-BISSAU', value: 'GW - GUINEA-BISSAU' },
            { key: 'GY - GUYANA', value: 'GY - GUYANA' },
            { key: 'GZ - GAZA STRIP -DO NOT USE', value: 'GZ - GAZA STRIP -DO NOT USE' },
            { key: 'HK - HONG KONG', value: 'HK - HONG KONG' },
            { key: 'HM - HEARD ISLAND AND MCDONALD ISLA', value: 'HM - HEARD ISLAND AND MCDONALD ISLA' },
            { key: 'HN - HONDURAS', value: 'HN - HONDURAS' },
            { key: 'HR - CROATIA', value: 'HR - CROATIA' },
            { key: 'HT - HAITI', value: 'HT - HAITI' },
            { key: 'HU - HUNGARY', value: 'HU - HUNGARY' },
            { key: 'ID - INDONESIA', value: 'ID - INDONESIA' },
            { key: 'IE - IRELAND', value: 'IE - IRELAND' },
            { key: 'IL - ISRAEL', value: 'IL - ISRAEL' },
            { key: 'IM - ISLE OF MAN', value: 'IM - ISLE OF MAN' },
            { key: 'IN - INDIA', value: 'IN - INDIA' },
            { key: 'IO - BRITISH INDIAN OCEAN TERRITORY', value: 'IO - BRITISH INDIAN OCEAN TERRITORY' },
            { key: 'IQ - IRAQ', value: 'IQ - IRAQ' },
            { key: 'IR - IRAN, ISLAMIC REPUBLIC OF', value: 'IR - IRAN, ISLAMIC REPUBLIC OF' },
            { key: 'IS - ICELAND', value: 'IS - ICELAND' },
            { key: 'IT - ITALY', value: 'IT - ITALY' },
            { key: 'JE - JERSEY', value: 'JE - JERSEY' },
            { key: 'JM - JAMAICA', value: 'JM - JAMAICA' },
            { key: 'JO - JORDAN', value: 'JO - JORDAN' },
            { key: 'JP - JAPAN', value: 'JP - JAPAN' },
            { key: 'JT - JOHNSTON ATOLL - DO NOT USE', value: 'JT - JOHNSTON ATOLL - DO NOT USE' },
            { key: 'KA - KARDASSIA - DO NOT USE', value: 'KA - KARDASSIA - DO NOT USE' },
            { key: 'KE - KENYA', value: 'KE - KENYA' },
            { key: 'KG - KYRGYZSTAN', value: 'KG - KYRGYZSTAN' },
            { key: 'KH - CAMBODIA', value: 'KH - CAMBODIA' },
            { key: 'KI - KIRIBATI', value: 'KI - KIRIBATI' },
            { key: 'KM - COMOROS', value: 'KM - COMOROS' },
            { key: 'KN - SAINT KITTS AND NEVIS', value: 'KN - SAINT KITTS AND NEVIS' },
            { key: `KP - KOREA, DEMOCARTIC PEOPLE'S REP`, value: `KP - KOREA, DEMOCARTIC PEOPLE'S REP` },
            { key: 'KR - KOREA, REPUBLIC OF', value: 'KR - KOREA, REPUBLIC OF' },
            { key: 'KW - KUWAIT', value: 'KW - KUWAIT' },
            { key: 'KY - CAYMAN ISLANDS', value: 'KY - CAYMAN ISLANDS' },
            { key: 'KZ - KAZAKHSTAN', value: 'KZ - KAZAKHSTAN' },
            { key: `LA - LAO PEOPLE'S DEMOCRATIC REPUBL`, value: `LA - LAO PEOPLE'S DEMOCRATIC REPUBL` },
            { key: 'LB - LEBANON', value: 'LB - LEBANON' },
            { key: 'LC - SAINT LUCIA', value: 'LC - SAINT LUCIA' },
            { key: 'LI - LIECHTENSTEIN', value: 'LI - LIECHTENSTEIN' },
            { key: 'LK - SRI LANKA', value: 'LK - SRI LANKA' },
            { key: 'LR - LIBERIA', value: 'LR - LIBERIA' },
            { key: 'LS - LESOTHO', value: 'LS - LESOTHO' },
            { key: 'LT - LITHUANIA', value: 'LT - LITHUANIA' },
            { key: 'LU - LUXEMBOURG', value: 'LU - LUXEMBOURG' },
            { key: 'LV - LATVIA', value: 'LV - LATVIA' },
            { key: 'LY - LIBYAN ARAB JAMAHIRIYA', value: 'LY - LIBYAN ARAB JAMAHIRIYA' },
            { key: 'MA - MOROCCO', value: 'MA - MOROCCO' },
            { key: 'MC - MONACO', value: 'MC - MONACO' },
            { key: 'MD - MOLDOVA, REPUBLIC OF', value: 'MD - MOLDOVA, REPUBLIC OF' },
            { key: 'ME - MONTENEGRO', value: 'ME - MONTENEGRO' },
            { key: 'MG - MADAGASCAR', value: 'MG - MADAGASCAR' },
            { key: 'MH - MARSHALL ISLANDS', value: 'MH - MARSHALL ISLANDS' },
            { key: 'MK - MACEDONIA, THE FORMER YUGOSLAV', value: 'MK - MACEDONIA, THE FORMER YUGOSLAV' },
            { key: 'ML - MALI', value: 'ML - MALI' },
            { key: 'MM - MYANMAR', value: 'MM - MYANMAR' },
            { key: 'MN - MONGOLIA', value: 'MN - MONGOLIA' },
            { key: 'MO - MACAO', value: 'MO - MACAO' },
            { key: 'MP - NORTHERN MARIANA ISLANDS', value: 'MP - NORTHERN MARIANA ISLANDS' },
            { key: 'MQ - MARTINIQUE', value: 'MQ - MARTINIQUE' },
            { key: 'MR - MAURITANIA', value: 'MR - MAURITANIA' },
            { key: 'MS - MONTSERRAT', value: 'MS - MONTSERRAT' },
            { key: 'MT - MALTA', value: 'MT - MALTA' },
            { key: 'MU - MAURITIUS', value: 'MU - MAURITIUS' },
            { key: 'MV - MALDIVES', value: 'MV - MALDIVES' },
            { key: 'MW - MALAWI', value: 'MW - MALAWI' },
            { key: 'MX - MEXICO', value: 'MX - MEXICO' },
            { key: 'MY - MALAYSIA', value: 'MY - MALAYSIA' },
            { key: 'MZ - MOZAMBIQUE', value: 'MZ - MOZAMBIQUE' },
            { key: 'NA - NAMIBIA', value: 'NA - NAMIBIA' },
            { key: 'NC - NEW CALEDONIA', value: 'NC - NEW CALEDONIA' },
            { key: 'NE - NIGER', value: 'NE - NIGER' },
            { key: 'NF - NORFOLK ISLAND', value: 'NF - NORFOLK ISLAND' },
            { key: 'NG - NIGERIA', value: 'NG - NIGERIA' },
            { key: 'NI - NICARAGUA', value: 'NI - NICARAGUA' },
            { key: 'NL - NETHERLANDS', value: 'NL - NETHERLANDS' },
            { key: 'NO - NORWAY', value: 'NO - NORWAY' },
            { key: 'NP - NEPAL', value: 'NP - NEPAL' },
            { key: 'NR - NAURU', value: 'NR - NAURU' },
            { key: 'NU - NIUE', value: 'NU - NIUE' },
            { key: 'NZ - NEW ZEALAND', value: 'NZ - NEW ZEALAND' },
            { key: 'OL - OTHER LATIN AMERICA-DO NOT USE', value: 'OL - OTHER LATIN AMERICA-DO NOT USE' },
            { key: 'OM - OMAN', value: 'OM - OMAN' },
            { key: 'PA - PANAMA', value: 'PA - PANAMA' },
            { key: 'PE - PERU', value: 'PE - PERU' },
            { key: 'PF - FRENCH POLYNESIA', value: 'PF - FRENCH POLYNESIA' },
            { key: 'PG - PAPUA NEW GUINEA', value: 'PG - PAPUA NEW GUINEA' },
            { key: 'PH - PHILIPPINES', value: 'PH - PHILIPPINES' },
            { key: 'PK - PAKISTAN', value: 'PK - PAKISTAN' },
            { key: 'PL - POLAND', value: 'PL - POLAND' },
            { key: 'PM - SAINT PIERRE AND MIQUELON', value: 'PM - SAINT PIERRE AND MIQUELON' },
            { key: 'PN - PITCAIRN', value: 'PN - PITCAIRN' },
            { key: 'PR - PUERTO RICO - DO NOT USE', value: 'PR - PUERTO RICO - DO NOT USE' },
            { key: 'PS - PALESTINIAN TERRITORY,OCCUPIED', value: 'PS - PALESTINIAN TERRITORY,OCCUPIED' },
            { key: 'PT - PORTUGAL', value: 'PT - PORTUGAL' },
            { key: 'PW - PALAU', value: 'PW - PALAU' },
            { key: 'PY - PARAGUAY', value: 'PY - PARAGUAY' },
            { key: 'PZ - PANAMA CANAL ZONE - DO NOT USE', value: 'PZ - PANAMA CANAL ZONE - DO NOT USE' },
            { key: 'QA - QATAR', value: 'QA - QATAR' },
            { key: 'RE - REUNION', value: 'RE - REUNION' },
            { key: 'RL - LATIN AMERICA - DO NOT USE', value: 'RL - LATIN AMERICA - DO NOT USE' },
            { key: 'RO - ROMANIA', value: 'RO - ROMANIA' },
            { key: 'RS - SERBIA', value: 'RS - SERBIA' },
            { key: 'RU - RUSSIAN FEDERATION', value: 'RU - RUSSIAN FEDERATION' },
            { key: 'RW - RWANDA', value: 'RW - RWANDA' },
            { key: 'SA - SAUDI ARABIA', value: 'SA - SAUDI ARABIA' },
            { key: 'SB - SOLOMON ISLANDS', value: 'SB - SOLOMON ISLANDS' },
            { key: 'SC - SEYCHELLES', value: 'SC - SEYCHELLES' },
            { key: 'SD - SUDAN', value: 'SD - SUDAN' },
            { key: 'SE - SWEDEN', value: 'SE - SWEDEN' },
            { key: 'SG - SINGAPORE', value: 'SG - SINGAPORE' },
            { key: 'SH - SAINT HELENA', value: 'SH - SAINT HELENA' },
            { key: 'SI - SLOVENIA', value: 'SI - SLOVENIA' },
            { key: 'SJ - SVALBARD AND JAN MAYEN', value: 'SJ - SVALBARD AND JAN MAYEN' },
            { key: 'SK - SLOVAKIA', value: 'SK - SLOVAKIA' },
            { key: 'SL - SIERRA LEONE', value: 'SL - SIERRA LEONE' },
            { key: 'SM - SAN MARINO', value: 'SM - SAN MARINO' },
            { key: 'SN - SENEGAL', value: 'SN - SENEGAL' },
            { key: 'SO - SOMALIA', value: 'SO - SOMALIA' },
            { key: 'SPE - SPEC PURP - EUROPE CONSORTIUM', value: 'SPE - SPEC PURP - EUROPE CONSORTIUM' },
            { key: 'SPL - SPEC PURP - LAT AM CONSORTIUM', value: 'SPL - SPEC PURP - LAT AM CONSORTIUM' },
            { key: 'SPO - SPEC PURP -"OTHER"-DO NOT USE', value: 'SPO - SPEC PURP -"OTHER"-DO NOT USE' },
            { key: 'SR - SURINAME', value: 'SR - SURINAME' },
            { key: 'ST - SAO TOME AND PRINCIPE', value: 'ST - SAO TOME AND PRINCIPE' },
            { key: 'SV - EL SALVADOR', value: 'SV - EL SALVADOR' },
            { key: 'SY - SYRIAN ARAB REPUBLIC', value: 'SY - SYRIAN ARAB REPUBLIC' },
            { key: 'SZ - SWAZILAND', value: 'SZ - SWAZILAND' },
            { key: 'TC - TURKS AND CAICOS ISLANDS', value: 'TC - TURKS AND CAICOS ISLANDS' },
            { key: 'TD - CHAD', value: 'TD - CHAD' },
            { key: 'TF - FRENCH SOUTHERN TERRITORIES', value: 'TF - FRENCH SOUTHERN TERRITORIES' },
            { key: 'TG - TOGO', value: 'TG - TOGO' },
            { key: 'TH - THAILAND', value: 'TH - THAILAND' },
            { key: 'TJ - TAJIKISTAN', value: 'TJ - TAJIKISTAN' },
            { key: 'TK - TOKELAU', value: 'TK - TOKELAU' },
            { key: 'TL - TIMOR-LESTE', value: 'TL - TIMOR-LESTE' },
            { key: 'TM - TURKMENISTAN', value: 'TM - TURKMENISTAN' },
            { key: 'TN - TUNISIA', value: 'TN - TUNISIA' },
            { key: 'TO - TONGA', value: 'TO - TONGA' },
            { key: 'TP - EAST TIMOR - DO NOT USE', value: 'TP - EAST TIMOR - DO NOT USE' },
            { key: 'TR - TURKEY', value: 'TR - TURKEY' },
            { key: 'TT - TRINIDAD AND TOBAGO', value: 'TT - TRINIDAD AND TOBAGO' },
            { key: 'TV - TUVALU', value: 'TV - TUVALU' },
            { key: 'TW - TAIWAN, PROVINCE OF CHINA', value: 'TW - TAIWAN, PROVINCE OF CHINA' },
            { key: 'TZ - TANZANIA, UNITED REPUBLIC OF', value: 'TZ - TANZANIA, UNITED REPUBLIC OF' },
            { key: 'UA - UKRAINE', value: 'UA - UKRAINE' },
            { key: 'UG - UGANDA', value: 'UG - UGANDA' },
            { key: 'UK - UNITED KINGDOM - DO NOT USE', value: 'UK - UNITED KINGDOM - DO NOT USE' },
            { key: 'UM - US MINOR OUTLYING', value: 'UM - US MINOR OUTLYING' },
            { key: 'US - UNITED STATES', value: 'US - UNITED STATES' },
            { key: 'UU - CHRISTMAS ISLAND- DO NOT USE', value: 'UU - CHRISTMAS ISLAND- DO NOT USE' },
            { key: 'UY - URUGUAY', value: 'UY - URUGUAY' },
            { key: 'UZ - UZBEKISTAN', value: 'UZ - UZBEKISTAN' },
            { key: 'VA - HOLY SEE (VATICAN CITY STATE)', value: 'VA - HOLY SEE (VATICAN CITY STATE)' },
            { key: 'VC - SAINT VINCENT & THE GRENADINES', value: 'VC - SAINT VINCENT & THE GRENADINES' },
            { key: 'VE - VENEZUELA', value: 'VE - VENEZUELA' },
            { key: 'VG - VIRGIN ISLANDS, BRITISH', value: 'VG - VIRGIN ISLANDS, BRITISH' },
            { key: 'VI - VIRGIN ISLANDS (US)-DO NOT USE', value: 'VI - VIRGIN ISLANDS (US)-DO NOT USE' },
            { key: 'VN - VIET NAM', value: 'VN - VIET NAM' },
            { key: 'VU - VANUATU', value: 'VU - VANUATU' },
            { key: 'WE - WEST BANK - DO NOT USE', value: 'WE - WEST BANK - DO NOT USE' },
            { key: 'WF - WALLIS AND FUTUNA', value: 'WF - WALLIS AND FUTUNA' },
            { key: 'WR - WESTERN EUROPE REG-DO NOT USE', value: 'WR - WESTERN EUROPE REG-DO NOT USE' },
            { key: 'WS - SAMOA', value: 'WS - SAMOA' },
            { key: 'XA - AFRICAN REG ASSOC', value: 'XA - AFRICAN REG ASSOC' },
            { key: 'XE - WESTERN EUROP REG', value: 'XE - WESTERN EUROP REG' },
            { key: 'XL - LATIN AMERICAN REG', value: 'XL - LATIN AMERICAN REG' },
            { key: 'XM - MULTILATERAL & INTL', value: 'XM - MULTILATERAL & INTL' },
            { key: 'XN - OTHER EUROPE', value: 'XN - OTHER EUROPE' },
            { key: 'XO - OTHER LATIN AMERICA', value: 'XO - OTHER LATIN AMERICA' },
            { key: 'XS - ASIA REGIONAL ASSOC', value: 'XS - ASIA REGIONAL ASSOC' },
            { key: 'YE - YEMEN', value: 'YE - YEMEN' },
            { key: 'YT - MAYOTTE', value: 'YT - MAYOTTE' },
            { key: 'YU - NO LONGER VALID (YUGOSLAVIA)', value: 'YU - NO LONGER VALID (YUGOSLAVIA)' },
            { key: 'ZA - SOUTH AFRICA', value: 'ZA - SOUTH AFRICA' },
            { key: 'ZF - AFRICAN REG ASSOC-DO NOT USE', value: 'ZF - AFRICAN REG ASSOC-DO NOT USE' },
            { key: 'ZM - ZAMBIA', value: 'ZM - ZAMBIA' },
            { key: 'ZO - OTHER INTL & REG - DO NOT USE', value: 'ZO - OTHER INTL & REG - DO NOT USE' },
            { key: 'ZR - ZAIRE - DO NOT USE', value: 'ZR - ZAIRE - DO NOT USE' },
            { key: 'ZW - ZIMBABWE', value: 'ZW - ZIMBABWE' }
        ];
    }
    buildCountry(order?: number, isRequired: boolean = true): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'LegalAddressDetails',
            key: 'Country__c',
            label: 'Country',
            defaultOption: 'US - UNITED STATES',
            selectionChange: true,
            mandatory: isRequired,
            order: order,
            options: this.countryOptions()
        })
    }

    buildAddressLine2(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAddressDetails',
            key: 'AddressLine2__c',
            label: 'Address Line2',
            order: order
        })
    }

    buildAddressLine3(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAddressDetails',
            key: 'AddressLine3__c',
            label: 'Address Line3',
            order: order
        })
    }

    buildHKClassification(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'APACDetails',
            key: 'Hong_Kong_Classification__c',
            label: 'Hong Kong Classification',
            defaultOption: '',
            selectionChange: true,
            order: order,
            mandatory: true,
            options: [
                { key: '', value: 'Please Select' },
                { key: 'Institutional Professional Investor', value: 'Institutional Professional Investor' },
                { key: 'Corporate Professional Investor', value: 'Corporate Professional Investor' }
            ]
        })
    }

    buildProductMarketCoverage(order?: number): QuestionBase<any> {
        return new MultiselectQuestion({
            section: 'APACDetails',
            key: 'Product_group_Market_coverage__c',
            label: 'Product group/ Market coverage',
            defaultOption: 'None selected',
            mandatory: true,
            order: order,
            options: [
                { key: 'Macro - ON Exchange', value: 'Macro - ON Exchange' },
                { key: 'Macro - OFF Exchange', value: 'Macro - OFF Exchange' },
                { key: 'Spread - ON Exchange', value: 'Spread - ON Exchange' },
                { key: 'Spread - OFF Exchange', value: 'Spread - OFF Exchange' },
                { key: 'Structured', value: 'Structured' }
            ],
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Hong_Kong_Classification__c',
                            value: 'Corporate Professional Investor'
                        }
                    ]
                }
            ]
        })
    }

    buildCPILetterComplete(order?: number): QuestionBase<any> {
        return new SingleCheckboxQuestion({
            section: 'APACDetails',
            key: 'CPI_Letter_Complete__c',
            label: `CPI Letter - Complete?`,
            value: false,
            order: order,
            disabled: true,
            relation: [
                {
                    action: 'VISIBLE',
                    when: [
                        {
                            id: 'Hong_Kong_Classification__c',
                            value: 'Corporate Professional Investor'
                        }
                    ]
                }
            ]
        })
    }

    buildAPACComments(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'APACDetails',
            key: 'Comments__c',
            label: 'APAC Comments',
            order: order
        })
    }

    buildAPACStatus(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'APACDetails',
            key: 'APAC_Status__c',
            label: 'APAC Status',
            defaultOption: '',
            order: order,
            disabled: true,
            options: [
                { key: '', value: '' },
                { key: 'Submitted', value: 'Submitted' },
                { key: 'Review', value: 'Review' },
                { key: 'Approved', value: 'Approved' },
                { key: 'Rejected', value: 'Rejected' }
            ]
        })
    }

    buildLongHeader(order?: number, group?: string, label?: string): QuestionBase<any> {
        return new LabelQuestion({
            rowGroupBy: group,
            key: label,
            label: label,
            value: '',
            order: order,
            disabled: true,
            col: 12,
            css: 'title'
        })
    }

    buildPrimeFields(order?: number): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            this.buildLongHeader(order + 100, 'LEGAL', 'Prime Details'),
            new TextboxQuestion({
                section: 'PrimeDetails',
                key: 'Manger_Code__c',
                label: 'Manger Code',
                order: order + 100
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Funding_Tier__c',
                label: 'Funding Tier',
                defaultOption: '',
                order: order + 110,
                options: [
                    { key: '', value: '--None--' },
                    { key: '1', value: '1' },
                    { key: '2', value: '2' },
                    { key: '3', value: '3' }
                ]
            }),
            new LabelQuestion({
                section: 'PrimeDetails',
                key: 'Legal_Business_Account_Relationship__c',
                label: 'Legal Business Account Relationship',
                order: order + 120,
                disabled: true
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Was_FCM_Cross_Margining_document_signed__c',
                label: 'Was FCM Cross Margining document signed?',
                order: order + 130,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Margin_Type__c',
                label: 'Margin Type',
                defaultOption: '',
                order: order + 140,
                options: [
                    { key: '', value: '--None--' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type_Visiblity_UI',
                                value: '',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Margin_Type__c',
                label: 'Margin Type',
                defaultOption: '',
                order: order + 140,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Reg U', value: 'Reg U' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type_Visiblity_UI',
                                value: 'BRWFB',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Margin_Type__c',
                label: 'Margin Type',
                defaultOption: '',
                order: order + 140,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Reg T', value: 'Reg T' },
                    { key: 'Portfolio Manager', value: 'Portfolio Manager' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type_Visiblity_UI',
                                value: 'BRWFS',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Margin_Type__c',
                label: 'Margin Type',
                defaultOption: '',
                order: order + 140,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Reg U', value: 'Reg U' },
                    { key: 'Reg T', value: 'Reg T' },
                    { key: 'Portfolio Manager', value: 'Portfolio Manager' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type_Visiblity_UI',
                                value: 'All',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Ranking__c',
                label: 'Ranking',
                defaultOption: '',
                order: order + 150,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'High', value: 'High' },
                    { key: 'Medium', value: 'Medium' },
                    { key: 'Low', value: 'Low' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'House_Margin_Methodology__c',
                label: 'House Margin Methodology?',
                order: order + 160,
                defaultOption: 'RBM',
                options: [
                    { key: 'RBM', value: 'RBM' },
                    { key: 'SBM', value: 'SBM' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Enable_FCM_Cross_Margining__c',
                label: 'Enable FCM Cross Margining?',
                order: order + 170,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Reg_U_Executed_Or_In_Progress__c',
                label: 'Reg U Executed Or In Progress?',
                defaultOption: 'No',
                order: order + 170,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '==='
                            },
                            {
                                id: 'External_system_list__c',
                                value: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA',
                                operator: '=='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Is_the_U1_document_signed__c',
                label: 'Is the U1 document signed?',
                defaultOption: 'No',
                order: order + 170,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '==='
                            },
                            {
                                id: 'External_system_list__c',
                                value: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA',
                                operator: '=='
                            }
                        ]
                    },
                ]
            }),
            new TextboxQuestion({
                section: 'PrimeDetails',
                key: 'Max_Loan_Amount__c',
                label: 'Max Loan Amount',
                order: order + 170,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '==='
                            },
                            {
                                id: 'External_system_list__c',
                                value: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA',
                                operator: '=='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Was_Swaps_Cross_Margining_document_signe__c',
                label: 'Was Swaps Cross Margining document signed?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Enable_Swaps_Cross_Margining__c',
                label: 'Was Swaps Cross Margining document signed?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Was_Swaps_Cross_Margining_document_signe__c',
                                value: 'Yes',
                                operator: '==='
                            },
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Was_Specific_Deposits_document_signed__c',
                label: 'Was Swaps Cross Margining document signed?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg T',
                                operator: '==='
                            },
                            {
                                id: 'Margin_Type__c',
                                value: 'Portfolio Manager',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Enable_Specific_Deposits__c',
                label: 'Enable Specific Deposits?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Was_Specific_Deposits_document_signed__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'G_MSLA_with_WFPS_document_signed__c',
                label: 'G/MSLA with WFPS document signed?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg T',
                                operator: '==='
                            },
                            {
                                id: 'Margin_Type__c',
                                value: 'Portfolio Manager',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Was_Short_Arranging_Annex_document_signe__c',
                label: 'Was Short Arranging Annex document signed?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg T',
                                operator: '==='
                            },
                            {
                                id: 'Margin_Type__c',
                                value: 'Portfolio Manager',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Enable_Short_Arranging__c',
                label: 'Enable Short Arranging?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'G_MSLA_with_WFPS_document_signed__c',
                                value: 'Yes',
                                operator: '==='
                            },
                            {
                                id: 'Was_Short_Arranging_Annex_document_signe__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new OptionsInlineQuestion({
                section: 'PrimeDetails',
                key: 'Enable_Specific_Deposits__c',
                label: 'Enable Specific Deposits?',
                order: order + 180,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Was_Specific_Deposits_document_signed__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Credit_Tier__c',
                label: 'Credit Tier',
                defaultOption: '',
                order: order + 170,
                options: [
                    { key: '', value: '--None--' },
                    { key: '1', value: '1' },
                    { key: '2', value: '2' },
                    { key: '3', value: '3' },
                    { key: '4', value: '4' },
                    { key: '5', value: '5' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '!=='
                            },
                            {
                                id: 'External_system_list__c',
                                value: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA',
                                operator: '!='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Send_Confirmation_To_Client__c',
                label: 'Send Confirmation To Client?',
                defaultOption: '',
                order: order + 190,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Send_Statement_To_Client__c',
                label: 'Send Statement To Client?',
                defaultOption: '',
                order: order + 200,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Hardcopy', value: 'Hardcopy' },
                    { key: 'Electronic', value: 'Electronic' }
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Trade_Payment_Type__c',
                label: 'Trade Payment Type',
                defaultOption: '',
                order: order + 210,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Wire', value: 'Wire' },
                    { key: 'Money Market', value: 'Money Market' }
                ]
            }),
            new TextboxQuestion({
                section: 'PrimeDetails',
                key: 'MMF_Fund_Agent__c',
                label: 'MMF Fund Agent',
                order: order + 220,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Trade_Payment_Type__c',
                                value: 'Money Market',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new TextboxQuestion({
                section: 'PrimeDetails',
                key: 'MM_Portfolio__c',
                label: 'MM Portfolio',
                order: order + 220,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Trade_Payment_Type__c',
                                value: 'Money Market',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'PrimeDetails',
                key: 'Credit_Tier__c',
                label: 'Credit Tier',
                defaultOption: '',
                order: order + 220,
                options: [
                    { key: '', value: '--None--' },
                    { key: '1', value: '1' },
                    { key: '2', value: '2' },
                    { key: '3', value: '3' },
                    { key: '4', value: '4' },
                    { key: '5', value: '5' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Margin_Type__c',
                                value: 'Reg U',
                                operator: '==='
                            },
                            {
                                id: 'External_system_list__c',
                                value: 'BRWFB : BROADRIDGE - WELLS FARGO BANK NA',
                                operator: '=='
                            }
                        ]
                    },
                ]
            }),
            new LabelQuestion({
                section: 'PrimeDetails',
                key: 'Margin_Type_Visiblity_UI',
                label: 'Margin_Type_Visiblity_UI',
                value: '',
                order: order + 220,
                displayNone: true
            })

        ];
        return questions.sort((a, b) => a.order - b.order);
    }

    buildSettlementType(order?: number, productType?: string, defaltValue?: string): QuestionBase<any> {
        var options = productType === 'Fixed Income' ? [{ key: 'Regular', value: 'Regular' }, { key: 'Extended', value: 'Extended' }]
            : productType === 'Equities' ? [{ key: 'Regular', value: 'Regular' }] : productType === 'Loan Sales' ? [{ key: 'Extended', value: 'Extended' }] : [{ key: '', value: '--None--' }]

        // return new DropdownQuestion({
        //     key: 'Settlement_Type__c',
        //     label: 'Settlement Type',
        //     mandatory: true,
        //     selectionChange: true,
        //     defaultOption: defaltValue ? defaltValue : 'Regular',
        //     isTooltipPresent: true,
        //     typeOfTooltip: 'help',
        //     tooltipText: '"Regular" settlement assumes <=T+3. "Extended" settlement assumes >=T+3 and will indicate to the Facilitator that credit underwriting is required.',
        //     order: order,
        //     options: options
        // });

        // return new LabelQuestion({
        //     key: 'Settlement_Type__c',
        //     label: 'Settlement Type',
        //     mandatory: true,
        //     value: defaltValue,
        //     order: order,
        //     displayNone: false
        // })

        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'Settlement_Type__c',
            label: 'Settlement Type',
            mandatory: true,
            value: defaltValue,
            order: order,
            disabled: true
        })
    }

    buildIsSafekeepingRequired(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Is_safekeeping_required__c',
            label: 'Is safekeeping required?',
            mandatory: true,
            defaultOption: 'No',
            selectionChange: true,
            isTooltipPresent: true,
            typeOfTooltip: 'help',
            tooltipText: "Safekeeping is required if WFS needs to be the custodian on the client's asset.",
            order: order,
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ]
        });
    }

    buildSafekeepingType(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Safekeeping_Type__c',
            label: 'Safekeeping Type',
            mandatory: true,
            selectionChange: true,
            defaultOption: '',
            order: order,
            relation: [
                {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Is_safekeeping_required__c',
                            value: 'Yes'
                        }
                    ]
                }
            ],
            options: [
                { key: '', value: '--None--' },
                { key: 'Bank', value: 'Bank' }
            ]
        })
    }

    buildCreditLimit(order?: number, isMandatory?: boolean): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'RequestDetails',
            key: 'Credit_limit__c',
            label: 'Credit Limit ($ MM)',
            order: order,
            relation: [
                {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Settlement_Type__c',
                            value: 'Extended'
                        }
                    ]
                }
            ],
            mandatory: isMandatory
        });
    }

    buildTenorRequested(order?: number, isMandatory?: boolean): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'RequestDetails',
            key: 'Tenor_Requested__c',
            label: 'Tenor Requested (Mos)',
            order: order,
            relation: [
                {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'Settlement_Type__c',
                            value: 'Extended'
                        }
                    ]
                }
            ],
            mandatory: isMandatory
        });
    }

    buildCMAId(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'CMAId__c',
            label: 'CMA Id',
            order: order,
            disabled: true,
            displayNone: true
        });
    }

    buildIsNewCMA(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'IsNewCMA__c',
            label: 'IsNewCMA',
            order: order,
            disabled: true,
            displayNone: true
        });
    }

    buildClientId(order?: number): QuestionBase<any> {
        return new TextboxQuestion({
            section: 'LegalAndBusAcct',
            key: 'ClientId__c',
            label: 'Client Id',
            order: order, //4920,
            disabled: true
        });
    }

    buildLoanIQType(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'LoanIQ_Type__c',
            label: 'Loan IQ Build Type',
            mandatory: true,
            defaultOption: 'Lender',
            order: order,
            options: [
                { key: 'Lender', value: 'Lender' },
                { key: 'Borrower', value: 'Borrower' },
                { key: 'Guarantor', value: 'Guarantor' }
            ]
        });
    }

    buildDepartmentLoanIQ(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Department_LoanIQ__c',
            label: 'Department (LoanIQ)',
            mandatory: true,
            defaultOption: '',
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'ABF - Asset Backed Finance', value: 'ABF - Asset Backed Finance' },
                { key: 'ACP - Avalon Capital Partners (Aircraft)', value: 'ACP - Avalon Capital Partners (Aircraft)' },
                { key: 'BBG - Business Banking Group', value: 'BBG - Business Banking Group' },
                { key: 'CIB - Corporate Investment Bank', value: 'CIB - Corporate Investment Bank' },
                { key: 'CLD - Community Lending Division', value: 'CLD - Community Lending Division' },
                { key: 'CLI - Community Lending & Investment', value: 'CLI - Community Lending & Investment' },
                { key: 'CMCLB - Commercial Banking', value: 'CMCLB - Commercial Banking' },
                { key: 'COAF - Commercial Operating Asses Finance SLI', value: 'COAF - Commercial Operating Asses Finance SLI' },
                { key: 'CORPT - Corporate Trust', value: 'CORPT - Corporate Trust' },
                { key: 'CR - Consumer and Retail', value: 'CR - Consumer and Retail' },
                { key: 'CREBU - Commercial Real Estate Business', value: 'CREBU - Commercial Real Estate Business' },
                { key: 'CRE - CRE', value: 'CRE - CRE' },
                { key: 'DSV - Dealer Services', value: 'DSV - Dealer Services' },
                { key: 'ENERC - Energy Capital', value: 'ENERC - Energy Capital' },
                { key: 'ENERG - Energy Group', value: 'ENERG - Energy Group' },
                { key: 'FIG - Financial Inst', value: 'FIG - Financial Inst' },
                { key: 'FRANL - Franchise Lending', value: 'FRANL - Franchise Lending' },
                { key: 'FRONT - Lenders', value: 'FRONT - Lenders' },
                { key: 'GAMIN - Gaming', value: 'GAMIN - Gaming' },
                { key: 'GBANK - CBG Global', value: 'GBANK - CBG Global' },
                { key: 'GBC - General Bank Commercial', value: 'GBC - General Bank Commercial' },
                { key: 'GCS - Global Capital Solutions', value: 'GCS - Global Capital Solutions' },
                { key: 'GFID - GFI Domestic', value: 'GFID - GFI Domestic' },
                { key: 'GFI - Global Financial Institutions', value: 'GFI - Global Financial Institutions' },
                { key: 'GIB - Government & Institution Banking', value: 'GIB - Government & Institution Banking' },
                { key: 'GREFS - General Bank-RE/FS', value: 'GREFS - General Bank-RE/FS' },
                { key: 'HBF - Homebuilder Finance', value: 'HBF - Homebuilder Finance' },
                { key: 'HEALT - Healthcare', value: 'HEALT - Healthcare' },
                { key: 'HFG - Hospitality Finance Group', value: 'HFG - Hospitality Finance Group' },
                { key: 'IND - Industrials', value: 'IND - Industrials' },
                { key: 'ITS - International Trade Services', value: 'ITS - International Trade Services' },
                { key: 'LAG - Credit Resolution Group', value: 'LAG - Credit Resolution Group' },
                { key: 'LSG - Lending Solutions', value: 'LSG - Lending Solutions' },
                { key: 'MEDIA - Media', value: 'MEDIA - Media' },
                { key: 'MMRE - Middle Market Real Estate', value: 'MMRE - Middle Market Real Estate' },
                { key: 'PPG - Principal Investment', value: 'PPG - Principal Investment' },
                { key: 'REBG - Real Estate Banking Group', value: 'REBG - Real Estate Banking Group' },
                { key: 'REG - Real Estate Group', value: 'REG - Real Estate Group' },
                { key: 'REMAG - Real Estate Managed Assets Group', value: 'REMAG - Real Estate Managed Assets Group' },
                { key: 'REMB - Real Estate Merchant Banking', value: 'REMB - Real Estate Merchant Banking' },
                { key: 'RESTA - Restaurant Finance', value: 'RESTA - Restaurant Finance' },
                { key: 'RMBS - RMBS Sales and Trading', value: 'RMBS - RMBS Sales and Trading' },
                { key: 'SAF - Structured Asset Finance', value: 'SAF - Structured Asset Finance' },
                { key: 'SBGRE - Total Small Business Group_Res', value: 'SBGRE - Total Small Business Group_Res' },
                { key: 'SECIN - Securities Investment', value: 'SECIN - Securities Investment' },
                { key: 'SFS - Financial Sponsors', value: 'SFS - Financial Sponsors' },
                { key: 'SGADM - Ssg Admin/Other', value: 'SGADM - Ssg Admin/Other' },
                { key: 'SGWBI - Ssg Wbi Assets', value: 'SGWBI - Ssg Wbi Assets' },
                { key: 'SSG - Special Situations Group', value: 'SSG - Special Situations Group' },
                { key: 'SUBSC - Subscription Finance', value: 'SUBSC - Subscription Finance' },
                { key: 'TMT - Technology, Media & Telecom', value: 'TMT - Technology, Media & Telecom' },
                { key: 'TRADE - Trade Services', value: 'TRADE - Trade Services' },
                { key: 'USCB - Corporate Banking U.S.', value: 'USCB - Corporate Banking U.S.' },
                { key: 'UTIL - Utilities', value: 'UTIL - Utilities' },
                { key: 'WCPM - Wholesale Credit Portfolio Mgmt', value: 'WCPM - Wholesale Credit Portfolio Mgmt' },
                { key: 'WEALT - Wealth Management', value: 'WEALT - Wealth Management' },
                { key: 'WFCF - Wells Fargo Capital Finance', value: 'WFCF - Wells Fargo Capital Finance' },
                { key: 'WFMCS - Wells Fargo Municipal Capital Strategies', value: 'WFMCS - Wells Fargo Municipal Capital Strategies' },
                { key: 'WPLT - Loan Trading', value: 'WPLT - Loan Trading' }
            ]
        });
    }

    buildExpenseCode(order?: number): QuestionBase<any>[] {
        // return new TextboxQuestion({
        //     key: 'Expense_Code__c',
        //     label: 'Expense Code',
        //     order: order,
        //     disabled: false,
        //     displayNone: true
        // })
        return [
            new LookupQuestion({
                section: 'RequestDetails',
                key: 'Expense_Code_Description',
                label: 'Expense Code',
                order: order,
                template: 'Expense Code',
                mandatory: true
            }),
            new LabelQuestion({
                section: 'RequestDetails',
                key: 'Expense_Code__c',
                label: 'Expense_Code__c',
                order: 1,
                displayNone: true
            })
        ];
    }

    buildPrimarySIC(order?: number): QuestionBase<any>[] {
        return [
            new LookupQuestion({
                section: 'RequestDetails',
                key: 'Primary_SIC_Description',
                label: 'Primary SIC (NAIC)',
                order: order,
                template: 'Primary SIC',
                mandatory: true
            }),
            new LabelQuestion({
                section: 'RequestDetails',
                key: 'Primary_SIC__c',
                label: 'Primary_SIC__c',
                order: 1,
                displayNone: true
            })
        ];
    }

    buildLegalCode(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Legal_Code__c',
            label: 'Legal Code',
            selectionChange: true,
            mandatory: true,
            defaultOption: '',
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: '011', value: '011' },
                { key: '015', value: '015' },
                { key: '020', value: '020' },
                { key: '025', value: '025' },
                { key: '030', value: '030' },
                { key: '035', value: '035' },
                { key: '040', value: '040' },
                { key: '045', value: '045' },
                { key: '050', value: '050' },
                { key: '101', value: '101' },
                { key: '102', value: '102' },
                { key: '105', value: '105' },
                { key: '106', value: '106' },
                { key: '107', value: '107' },
                { key: '108', value: '108' },
                { key: '109', value: '109' },
                { key: '110', value: '110' },
                { key: '111', value: '111' },
                { key: '112', value: '112' },
                { key: '200', value: '200' },
                { key: '201', value: '201' },
                { key: '208', value: '208' },
                { key: '209', value: '209' },
                { key: '212', value: '212' },
                { key: '213', value: '213' },
                { key: '215', value: '215' },
                { key: '216', value: '216' },
                { key: '220', value: '220' },
                { key: '300', value: '300' },
                { key: '610', value: '610' },
                { key: '612', value: '612' },
                { key: '650', value: '650' },
                { key: '651', value: '651' },
                { key: '660', value: '660' },
                { key: '665', value: '665' },
                { key: '700', value: '700' },
                { key: '211', value: '211' }
            ]
        })
    }

    buildCustomerClassification(order?: number): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Customer_Classification__c',
            label: 'Customer Classification',
            mandatory: true,
            defaultOption: '',
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'Individual', value: 'Individual' },
                { key: 'Sole Proprietorship', value: 'Sole Proprietorship' },
                { key: 'General Partnerships', value: 'General Partnerships' },
                { key: 'Limited Partnerships', value: 'Limited Partnerships' },
                { key: 'Association', value: 'Association' },
                { key: 'Joint Venture', value: 'Joint Venture' },
                { key: 'Corporations', value: 'Corporations' },
                { key: 'Limited Liability Company', value: 'Limited Liability Company' },
                { key: 'Limited Liability Partnership', value: 'Limited Liability Partnership' },
                { key: 'NDFI-COMMERCIAL EQUITY REIT', value: 'NDFI-COMMERCIAL EQUITY REIT' },
                { key: 'NDFI-COMMERCIAL MORTGAGE REIT', value: 'NDFI-COMMERCIAL MORTGAGE REIT' },
                { key: 'NDFI-Investment Bank', value: 'NDFI-Investment Bank' },
                { key: 'NDFI-Insurance Company', value: 'NDFI-Insurance Company' },
                { key: 'NDFI-Non -Profit Insurance Company', value: 'NDFI-Non -Profit Insurance Company' },
                { key: 'NDFI-Lend Agcy/Co that Extend Credit', value: 'NDFI-Lend Agcy/Co that Extend Credit' },
                { key: 'NDFI-Non-Profit Lend Agcy/Co Ext Credit', value: 'NDFI-Non-Profit Lend Agcy/Co Ext Credit' },
                { key: 'NDFI-Holdiing Co of Other Deposit Instit', value: 'NDFI-Holdiing Co of Other Deposit Instit' },
                { key: 'NDFI-Asset Management', value: 'NDFI-Asset Management' },
                { key: 'NDFI CLOs', value: 'NDFI CLOs' },
                { key: 'Foreign Domiciled Business', value: 'Foreign Domiciled Business' },
                { key: 'Foreign Government', value: 'Foreign Government' },
                { key: 'Foreign Central Bank', value: 'Foreign Central Bank' },
                { key: 'Foreign Branches of US Banks', value: 'Foreign Branches of US Banks' },
                { key: 'Non-CmBG Borrower', value: 'Non-CmBG Borrower' },
                { key: 'Foreign Banks & Fgn Branches of Fgn Bank', value: 'Foreign Banks & Fgn Branches of Fgn Bank' },
                { key: 'Non-Profit', value: 'Non-Profit' },
                { key: 'Trust', value: 'Trust' },
                { key: 'US Branches of Foreign Banks', value: 'US Branches of Foreign Banks' },
                { key: 'Wells Fargo and Company Affiliates', value: 'Wells Fargo and Company Affiliates' },
                { key: 'Domestic Banks', value: 'Domestic Banks' },
                { key: 'Other Financial Insitutions', value: 'Other Financial Insitutions' },
                { key: 'State or Local Government Entities, Agencies,', value: 'State or Local Government Entities, Agencies,' },
                { key: 'US Government', value: 'US Government' },
                { key: 'US Government Agencies', value: 'US Government Agencies' },
                { key: 'US Government Sponsored Enterprise', value: 'US Government Sponsored Enterprise' },
                { key: 'Borrowers Not Elsewhere Classified', value: 'Borrowers Not Elsewhere Classified' },
                { key: 'Fed Fund Line Borrower', value: 'Fed Fund Line Borrower' }
            ]
        })
    }

    buildCountryofIncorporation(order?: number, ): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Country_of_Incorporation__c',
            label: 'Country of Incorporation',
            defaultOption: '',
            //selectionChange: true,
            mandatory: true,
            order: order,
            options: this.countryOptions()
        });
    }

    buildMiFIDIIRiskReducing(order?: number, ): QuestionBase<any> {
        return new OptionsInlineQuestion({
            key: 'MiFID_II_Risk_Reducing__c',
            label: 'MiFID II Risk Reducing',
            options: [
                { key: 'Yes', value: 'Yes' },
                { key: 'No', value: 'No' }
            ],
            order: order,
            relation: [
                {
                    action: 'DISABLE',
                    connective: 'OR',
                    when: [
                        {
                            id: 'External_system_list__c',
                            value: 'GMIBD : GMI WELLS FARGO SECURITIES, LLC',
                            operator: '!='
                        },
                        {
                            id: 'External_system_list__c',
                            value: 'GMICLR : GMI (CLEARING)',
                            operator: '!='
                        },
                        {
                            id: 'External_system_list__c',
                            value: 'GMIWFL : GMI WELLS FARGO SECURITIES INTL LIMITED',
                            operator: '!='
                        }
                    ]
                }
            ],
            mandatory: true
        })
    }

    buildTypeofDocumentationRequest(order?: number, ): QuestionBase<any> {
        return new DropdownQuestion({
            key: 'Type_of_Documentation_Request__c',
            label: 'Type of Documentation Request',
            mandatory: true,
            selectionChange: true,
            isTooltipPresent: true,
            defaultOption: 'ISDA (rate/commodity/credit swaps and options)',
            typeOfTooltip: 'help',
            tooltipText: `Questions on completing this form should be directed to FP Sales Servicing at 415-644-7870`,
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'ISDA (rate/commodity/credit swaps and options)', value: 'ISDA (rate/commodity/credit swaps and options)' },
                { key: '2002 NAESB (North American Energy Standards Board)', value: '2002 NAESB (North American Energy Standards Board)' },
                { key: '2006 NAESB (North American Energy Standards Board)', value: '2006 NAESB (North American Energy Standards Board)' },
                { key: 'Amendment to Existing Agreement', value: 'Amendment to Existing Agreement' },
                { key: 'Compensation Agreement', value: 'Compensation Agreement' },
                { key: 'Confidentiality Agreement', value: 'Confidentiality Agreement' },
                { key: 'FIA-ISDA Cleared Derivatives Execution Agreement', value: 'FIA-ISDA Cleared Derivatives Execution Agreement' },
                { key: 'FPA (Forward Purchase Agreement)', value: 'FPA (Forward Purchase Agreement)' },
                { key: 'Foreign Exchange Master Agreement', value: 'Foreign Exchange Master Agreement' },
                { key: 'FX Documentation Request', value: 'FX Documentation Request' },
                { key: 'FX Documentation Request for Dodd Frank', value: 'FX Documentation Request for Dodd Frank' },
                { key: 'GMRA (Global Master Repurchase Agreement)', value: 'GMRA (Global Master Repurchase Agreement)' },
                { key: 'Hedge Review Only - No Documentation Requested', value: 'Hedge Review Only - No Documentation Requested' },
                { key: 'ISDA DF Protocol', value: 'ISDA DF Protocol' },
                { key: 'Long Form Confirmation', value: 'Long Form Confirmation' },
                { key: 'MRA (Master Repurchase Agreement)', value: 'MRA (Master Repurchase Agreement)' },
                { key: 'MSFTA (Master Securities Forward Transaction Agreement)', value: 'MSFTA (Master Securities Forward Transaction Agreement)' },
                { key: 'Muni Gas Prepay', value: 'Muni Gas Prepay' },
                { key: 'Other', value: 'Other' },
                { key: 'Participation Agreement', value: 'Participation Agreement' },
                { key: 'Physical Ags', value: 'Physical Ags' },
                { key: 'Physical Metals', value: 'Physical Metals' },
                { key: 'Physical NGL (Natural Gas Liquids)', value: 'Physical NGL (Natural Gas Liquids)' },
                { key: 'Physical Power', value: 'Physical Power' },
                { key: 'Pipeline Agreement', value: 'Pipeline Agreement' },
                { key: 'Prime Brokerage Master Agreement', value: 'Prime Brokerage Master Agreement' },
                { key: 'Rate Management Agreement', value: 'Rate Management Agreement' },
                { key: 'Terms of Business', value: 'Terms of Business' },
                { key: 'TOB (Tender Option Bond)', value: 'TOB (Tender Option Bond)' },
                { key: 'TRPO/Master Claims Purchase Agreement', value: 'TRPO/Master Claims Purchase Agreement' }
            ]
        });
    }

    buildTypeofDocumentationRequestForRequestDetailsForSwaps(order?: number, ): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Type_of_Documentation_Request__c',
            label: 'Type of Documentation Request',
            mandatory: true,
            selectionChange: true,
            isTooltipPresent: true,
            defaultOption: 'ISDA (rate/commodity/credit swaps and options)',
            typeOfTooltip: 'help',
            tooltipText: `Questions on completing this form should be directed to FP Sales Servicing at 415-644-7870`,
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'ISDA (rate/commodity/credit swaps and options)', value: 'ISDA (rate/commodity/credit swaps and options)' },
                { key: '2002 NAESB (North American Energy Standards Board)', value: '2002 NAESB (North American Energy Standards Board)' },
                { key: '2006 NAESB (North American Energy Standards Board)', value: '2006 NAESB (North American Energy Standards Board)' },
                { key: 'Amendment to Existing Agreement', value: 'Amendment to Existing Agreement' },
                { key: 'Compensation Agreement', value: 'Compensation Agreement' },
                { key: 'Confidentiality Agreement', value: 'Confidentiality Agreement' },
                { key: 'FIA-ISDA Cleared Derivatives Execution Agreement', value: 'FIA-ISDA Cleared Derivatives Execution Agreement' },
                { key: 'FPA (Forward Purchase Agreement)', value: 'FPA (Forward Purchase Agreement)' },
                { key: 'Foreign Exchange Master Agreement', value: 'Foreign Exchange Master Agreement' },
                { key: 'FX Documentation Request', value: 'FX Documentation Request' },
                { key: 'FX Documentation Request for Dodd Frank', value: 'FX Documentation Request for Dodd Frank' },
                { key: 'GMRA (Global Master Repurchase Agreement)', value: 'GMRA (Global Master Repurchase Agreement)' },
                { key: 'Hedge Review Only - No Documentation Requested', value: 'Hedge Review Only - No Documentation Requested' },
                { key: 'ISDA DF Protocol', value: 'ISDA DF Protocol' },
                { key: 'Long Form Confirmation', value: 'Long Form Confirmation' },
                { key: 'MRA (Master Repurchase Agreement)', value: 'MRA (Master Repurchase Agreement)' },
                { key: 'MSFTA (Master Securities Forward Transaction Agreement)', value: 'MSFTA (Master Securities Forward Transaction Agreement)' },
                { key: 'Muni Gas Prepay', value: 'Muni Gas Prepay' },
                { key: 'Other', value: 'Other' },
                { key: 'Participation Agreement', value: 'Participation Agreement' },
                { key: 'Physical Ags', value: 'Physical Ags' },
                { key: 'Physical Metals', value: 'Physical Metals' },
                { key: 'Physical NGL (Natural Gas Liquids)', value: 'Physical NGL (Natural Gas Liquids)' },
                { key: 'Physical Power', value: 'Physical Power' },
                { key: 'Pipeline Agreement', value: 'Pipeline Agreement' },
                { key: 'Prime Brokerage Master Agreement', value: 'Prime Brokerage Master Agreement' },
                { key: 'Rate Management Agreement', value: 'Rate Management Agreement' },
                { key: 'Terms of Business', value: 'Terms of Business' },
                { key: 'TOB (Tender Option Bond)', value: 'TOB (Tender Option Bond)' },
                { key: 'TRPO/Master Claims Purchase Agreement', value: 'TRPO/Master Claims Purchase Agreement' }
            ],
            // relation: [
            //     {
            //         action: 'VISIBLE',
            //         connective: 'AND',
            //         when: [
            //             {
            //                 id: 'Product_Sub_Type_MS__c',
            //                 value: 'CDS Single Name',
            //                 operator: '!=='
            //             },
            //             {
            //                 id: 'Product_Sub_Type_MS__c',
            //                 value: 'CDS Index (SEF)',
            //                 operator: '!=='
            //             }
            //         ]
            //     }
            // ]
        });
    }

    buildTypeofDocumentationRequestForRequestDetailsForEquities(order?: number, ): QuestionBase<any> {
        return new DropdownQuestion({
            section: 'RequestDetails',
            key: 'Type_of_Documentation_Request__c',
            label: 'Type of Documentation Request',
            mandatory: true,
            selectionChange: true,
            isTooltipPresent: true,
            defaultOption: 'ISDA (rate/commodity/credit swaps and options)',
            typeOfTooltip: 'help',
            tooltipText: `Questions on completing this form should be directed to FP Sales Servicing at 415-644-7870`,
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'ISDA (rate/commodity/credit swaps and options)', value: 'ISDA (rate/commodity/credit swaps and options)' },
                { key: '2002 NAESB (North American Energy Standards Board)', value: '2002 NAESB (North American Energy Standards Board)' },
                { key: '2006 NAESB (North American Energy Standards Board)', value: '2006 NAESB (North American Energy Standards Board)' },
                { key: 'Amendment to Existing Agreement', value: 'Amendment to Existing Agreement' },
                { key: 'Compensation Agreement', value: 'Compensation Agreement' },
                { key: 'Confidentiality Agreement', value: 'Confidentiality Agreement' },
                { key: 'FIA-ISDA Cleared Derivatives Execution Agreement', value: 'FIA-ISDA Cleared Derivatives Execution Agreement' },
                { key: 'FPA (Forward Purchase Agreement)', value: 'FPA (Forward Purchase Agreement)' },
                { key: 'Foreign Exchange Master Agreement', value: 'Foreign Exchange Master Agreement' },
                { key: 'FX Documentation Request', value: 'FX Documentation Request' },
                { key: 'FX Documentation Request for Dodd Frank', value: 'FX Documentation Request for Dodd Frank' },
                { key: 'GMRA (Global Master Repurchase Agreement)', value: 'GMRA (Global Master Repurchase Agreement)' },
                { key: 'Hedge Review Only - No Documentation Requested', value: 'Hedge Review Only - No Documentation Requested' },
                { key: 'ISDA DF Protocol', value: 'ISDA DF Protocol' },
                { key: 'Long Form Confirmation', value: 'Long Form Confirmation' },
                { key: 'MRA (Master Repurchase Agreement)', value: 'MRA (Master Repurchase Agreement)' },
                { key: 'MSFTA (Master Securities Forward Transaction Agreement)', value: 'MSFTA (Master Securities Forward Transaction Agreement)' },
                { key: 'Muni Gas Prepay', value: 'Muni Gas Prepay' },
                { key: 'Other', value: 'Other' },
                { key: 'Participation Agreement', value: 'Participation Agreement' },
                { key: 'Physical Ags', value: 'Physical Ags' },
                { key: 'Physical Metals', value: 'Physical Metals' },
                { key: 'Physical NGL (Natural Gas Liquids)', value: 'Physical NGL (Natural Gas Liquids)' },
                { key: 'Physical Power', value: 'Physical Power' },
                { key: 'Pipeline Agreement', value: 'Pipeline Agreement' },
                { key: 'Prime Brokerage Master Agreement', value: 'Prime Brokerage Master Agreement' },
                { key: 'Rate Management Agreement', value: 'Rate Management Agreement' },
                { key: 'Terms of Business', value: 'Terms of Business' },
                { key: 'TOB (Tender Option Bond)', value: 'TOB (Tender Option Bond)' },
                { key: 'TRPO/Master Claims Purchase Agreement', value: 'TRPO/Master Claims Purchase Agreement' }
            ]
        });
    }

    buildTypeofDocumentationRequestCDSForRequestDetails(order?: number, ): QuestionBase<any> {
        return new DropdownQuestion({
            key: 'Type_of_Documentation_Request_CDS__c',
            label: 'Type of Documentation Request (CDS)',
            mandatory: true,
            selectionChange: true,
            isTooltipPresent: false,
            defaultOption: 'FIA-ISDA & ECP Verification',
            order: order,
            options: [
                { key: '', value: '--None--' },
                { key: 'FIA-ISDA & ECP Verification', value: 'FIA-ISDA & ECP Verification' },
                { key: 'ECP Verification only', value: 'ECP Verification only' }
            ],
            // relation: [
            //     {
            //         action: 'VISIBLE',
            //         connective: 'OR',
            //         when: [
            //             {
            //                 id: 'Product_Sub_Type_MS__c',
            //                 value: 'CDS Single Name',
            //                 operator: '==='
            //             },
            //             {
            //                 id: 'Product_Sub_Type_MS__c',
            //                 value: 'CDS Index (SEF)',
            //                 operator: '==='
            //             }
            //         ]
            //     }
            // ]
        });
    }

    buildMarketerSearch(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            section: 'RequestDetails',
            key: 'marketerSearch',
            label: 'Marketer Search',
            order: order,
            searchable: true,
            disabled: false,
            template: 'Marketer'
        })
    }

    buildMarketer(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'Marketer__ui',
            label: 'Marketer',
            order: order,
            mandatory: true,
            disabled: true,
        })
    }

    buildBranchLocation(order?: number): QuestionBase<any> {
        return new TextAreaQuestion({
            section: 'RequestDetails',
            key: 'Branch_Location__ui',
            label: 'Branch Location',
            order: order,
            mandatory: true,
            disabled: true,
        })
    }

    buildFields(productType?: string, productSubType?: string, buildType?: string,
        wfEntity?: string, role?: string, requestStatus?: string, currentUserName?: string, settlementType?: string, amlStatus?: string): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        const wfEntityString = wfEntity.toString();
        switch (productType) {
            case 'Fixed Income':
                switch (productSubType) {
                    case 'Cash':
                    case 'Overnight Repo':
                    case 'MBS':
                    case 'Repo':
                    case 'Rev Repo':
                    case 'Tri-Party Repo':
                        questions = [
                            new LabelQuestion({
                                key: 'User_Role',
                                label: 'User Role',
                                value: role,
                                order: 1,
                                displayNone: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Is_Template__c',
                                label: 'Is_Template',
                                value: false,
                                order: 2,
                                displayNone: true
                            }),
                            this.buildBuildType(buildType),
                            this.buildWFEntity(wfEntity),
                            this.buildSalesAssistant(currentUserName),
                            this.buildCreatedDate(),
                            this.buildProductType(productType),
                            this.buildProductSubType(productSubType, 'Product_Sub_Type__c', 600),
                            this.buildCOBAMNumber(700),
                            this.buildLastModifiedDate(800),
                            this.buildSettlementType(900, productType, settlementType),
                            this.buildRelationshipType(1000),



                            /* New Lookup control test start*/
                            // this.buildSalesPersonSearch(1100),
                            //this.buildSalesPersonTrader(1600),
                            new LookupQuestion({
                                section: 'RequestDetails',
                                key: 'SPTRSearch',
                                label: 'Sales Person/Trader Search',
                                order: 1100,
                                template: 'Salesperson/Trader',
                                mandatory: true
                            }),
                            /* Nw Lookup control test end */
                            this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
                            (wfEntityString.search('WFSIL') >= 0 || wfEntityString.search('WFBNA - LB') >= 0 || wfEntityString.search('WFSE') >= 0)
                                ? this.buildMiFIDIIClientCategorization(1300) : this.buildEmptyField(1300),
                            this.buildIsSafekeepingRequired(1400),
                            this.buildSafekeepingType(1500),

                            new LabelQuestion({
                                section: 'RequestDetails',
                                key: '1600',
                                label: '',
                                order: 1600,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Is_safekeeping_required__c',
                                                value: 'No'
                                            }
                                        ]
                                    }
                                ],
                                disabled: true
                            }),
                            new LabelQuestion({
                                section: 'RequestDetails',
                                key: '1700',
                                label: '',
                                order: 1700,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: false
                                            }
                                        ]
                                    }
                                ],
                                disabled: true
                            }),
                            new TextboxQuestion({
                                section: 'RequestDetails',
                                key: 'Template_Name__c',
                                label: 'Template Name',
                                order: 1700,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    }
                                ]
                            }),
                            this.buildCreditLimit(1800, true),
                            this.buildTenorRequested(1900, true),
                            this.buildPrimeBrokerAccount(2000),
                            this.buildTradePending(2100),
                            new LabelQuestion({
                                section: 'RequestDetails',
                                key: '2200',
                                label: '',
                                order: 2200,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'OR',
                                        when: [
                                            {
                                                id: 'Settlement_Type__c',
                                                value: 'Regular'
                                            }
                                        ]
                                    }
                                ],
                                disabled: true
                            }),
                            this.buildNewWires(2300),
                            this.buildThirdPartyPayment(2400),
                            this.buildThirdPartyWireCheckbox(2500),
                            this.buildPaymentPending(2600),
                            this.buildPaymentDate(2700)
                        ];

                        questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                        questions = questions.concat(this.buildLegalAddressFields());

                        questions = questions.concat(this.buildAPACFields(wfEntityString));
                        questions = questions.concat(this.buildDocumentMatrixFields());

                        if (requestStatus !== 'Draft') {
                            if ((role.toString() !== 'Requester' && role.toString() !== 'Requester NonCash')
                                && (productType === 'Fixed Income' || productType === 'Equities'
                                    || (productSubType.toString() === 'PB' || productSubType.toString() === 'DVP' || productSubType.toString() === 'Margin Roll Up'))
                            ) {
                                questions = questions.concat(this.buildFINRAFields());
                            }
                            questions = questions.concat(this.buildWorkItemIndicator());
                            questions = questions.concat(this.buildFacilitatorFields());
                            questions = questions.concat(this.buildAMLFields());
                        }

                        questions = questions.concat(this.buildCallbackAndThirdPartyFields());
                        return questions.sort((a, b) => a.order - b.order);
                    default:
                        break;
                }
            case 'Equities':
                switch (productSubType) {
                    case 'Cash':
                        questions = [
                            new LabelQuestion({
                                key: 'User_Role',
                                label: 'User Role',
                                value: role,
                                order: 1,
                                displayNone: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Is_Template__c',
                                label: 'Is_Template',
                                value: false,
                                order: 2,
                                displayNone: true
                            }),
                            this.buildBuildType(buildType),
                            this.buildWFEntity(wfEntity),
                            this.buildSalesAssistant(currentUserName),
                            this.buildCreatedDate(),
                            this.buildProductType(productType),
                            this.buildProductSubType(productSubType, 'Product_Sub_Type__c', 600),
                            this.buildCOBAMNumber(700),
                            this.buildLastModifiedDate(800),
                            this.buildSettlementType(900, productType, settlementType),
                            this.buildRelationshipType(1000),

                            /* New Lookup control test start*/
                            //this.buildSalesPersonSearch(1100),
                            //this.buildSalesPersonTrader(1700),
                            new LookupQuestion({
                                key: 'SPTRSearch',
                                label: 'Sales Person/Trader Search',
                                order: 1100,
                                template: 'Salesperson/Trader',
                                mandatory: true
                            }),
                            /* Nw Lookup control test end */



                            this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
                            (wfEntityString.search('WFSIL') >= 0 || wfEntityString.search('WFBNA - LB') >= 0 || wfEntityString.search('WFSE') >= 0)
                                ? this.buildMiFIDIIClientCategorization(1300) : this.buildEmptyField(1300),

                            // new LabelQuestion({
                            //     key: '1600',
                            //     label: '',
                            //     order: 1600,
                            //     relation: [
                            //         {
                            //             action: 'VISIBLE',
                            //             connective: 'OR',
                            //             when: [
                            //                 {
                            //                     id: 'Product_Type__c',
                            //                     value: 'Equities'
                            //                 }
                            //             ]
                            //         }
                            //     ],
                            //     disabled: true
                            // }),
                            // this.buildCreditLimit(1800),
                            // this.buildTenorRequested(1900),
                            this.buildPrimeBrokerAccount(1600),
                            this.buildTradePending(1700),
                            new LabelQuestion({
                                key: '1800',
                                label: '',
                                order: 1800,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: false
                                            }
                                        ]
                                    }
                                ],
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'Template_Name__c',
                                label: 'Template Name',
                                order: 1800,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    }
                                ]
                            }),

                            this.buildNewWires(2300),
                            this.buildThirdPartyPayment(2400),
                            this.buildThirdPartyWireCheckbox(2500),
                            this.buildPaymentPending(2600),
                            this.buildPaymentDate(2700)
                        ];

                        questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                        questions = questions.concat(this.buildLegalAddressFields());

                        questions = questions.concat(this.buildAPACFields(wfEntityString));
                        questions = questions.concat(this.buildDocumentMatrixFields());
                        if (requestStatus !== 'Draft') {
                            questions = questions.concat(this.buildWorkItemIndicator());
                            questions = questions.concat(this.buildFacilitatorFields());
                            questions = questions.concat(this.buildAMLFields());
                        }

                        questions = questions.concat(this.buildCallbackAndThirdPartyFields());
                        return questions.sort((a, b) => a.order - b.order);
                    case 'Derivatives':
                        questions = this.buildNonCashRequestDetails(productType, productSubType, buildType,
                            wfEntity, role, requestStatus, currentUserName, settlementType);

                        return questions.sort((a, b) => a.order - b.order);
                }
            case 'Prime':
                switch (productSubType) {
                    case 'PB':
                    case 'Margin Roll up':
                        questions = [
                            new LabelQuestion({
                                key: 'User_Role',
                                label: 'User Role',
                                value: role,
                                order: 1,
                                displayNone: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Is_Template__c',
                                label: 'Is_Template',
                                value: false,
                                order: 2,
                                displayNone: true
                            }),
                            this.buildBuildType(buildType),
                            this.buildWFEntity(wfEntity),
                            this.buildSalesAssistant(currentUserName),
                            this.buildCreatedDate(),
                            this.buildProductType(productType),
                            this.buildProductSubType(productSubType, 'Product_Sub_Type__c', 600),
                            this.buildCOBAMNumber(700),
                            this.buildLastModifiedDate(800),
                            new DropdownQuestion({
                                key: 'Account_Type__c',
                                label: 'Account Type',
                                mandatory: true,
                                defaultOption: '',
                                order: 900,
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Institutional', value: 'Institutional' },
                                    { key: 'Individual or Employee', value: 'Individual or Employee' },
                                    { key: 'CMTA', value: 'CMTA' },
                                    { key: 'Prime Broker', value: 'Prime Broker' }
                                ]
                            }),

                            /* New Lookup control test start*/
                            // this.buildSalesPersonSearch(1000),
                            // this.buildSalesPersonTrader(1100),
                            new LookupQuestion({
                                key: 'SPTRSearch',
                                label: 'Sales Person/Trader Search',
                                order: 1000,
                                template: 'Salesperson/Trader',
                                mandatory: true
                            }),
                            /* Nw Lookup control test end */
                            this.buildTradePending(1100),
                            this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
                            this.buildRelationshipType(1300),
                            this.buildPrimeBrokerAccount(1400),
                            //this.buildTradePending(1500),
                            //this.buildNewWires(1600),
                            this.buildNewWires(1500),
                            new LabelQuestion({
                                key: '1600',
                                label: '',
                                order: 1600,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: false
                                            }
                                        ]
                                    }
                                ],
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'Template_Name__c',
                                label: 'Template Name',
                                order: 1600,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    }
                                ]
                            }),

                            this.buildThirdPartyPayment(1700),
                            this.buildThirdPartyWireCheckbox(1800),
                            this.buildPaymentPending(1900),
                            this.buildPaymentDate(2000)
                        ];

                        questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                        questions = questions.concat(this.buildLegalAddressFields());

                        questions = questions.concat(this.buildAPACFields(wfEntityString));
                        questions = questions.concat(this.buildDocumentMatrixFields());
                        let order: number = 5400;
                        questions = questions.concat(this.buildPrimeFields(order));
                        if (requestStatus !== 'Draft') {
                            questions = questions.concat(this.buildWorkItemIndicator());
                            questions = questions.concat(this.buildFacilitatorFields());
                            questions = questions.concat(this.buildAMLFields());
                        }
                        questions = questions.concat(this.buildCallbackAndThirdPartyFields());
                        return questions.sort((a, b) => a.order - b.order);
                    case 'DVP':
                        questions = [
                            new LabelQuestion({
                                key: 'User_Role',
                                label: 'User Role',
                                value: '',
                                order: 1,
                                displayNone: true
                            }),
                            new SingleCheckboxQuestion({
                                key: 'Is_Template__c',
                                label: 'Is_Template',
                                value: false,
                                order: 2,
                                displayNone: true
                            }),
                            this.buildBuildType(buildType),
                            this.buildWFEntity(wfEntity),
                            this.buildSalesAssistant(currentUserName),
                            this.buildCreatedDate(),
                            this.buildProductType(productType),
                            this.buildProductSubType(productSubType, 'Product_Sub_Type__c', 600),
                            this.buildCOBAMNumber(700),
                            this.buildLastModifiedDate(800),
                            new DropdownQuestion({
                                key: 'Account_Type__c',
                                label: 'Account Type',
                                mandatory: true,
                                defaultOption: '',
                                order: 900,
                                options: [
                                    { key: '', value: '--None--' },
                                    { key: 'Institutional', value: 'Institutional' },
                                    { key: 'Individual or Employee', value: 'Individual or Employee' },
                                    { key: 'CMTA', value: 'CMTA' },
                                    { key: 'Prime Broker', value: 'Prime Broker' }
                                ]
                            }),

                            /* New Lookup control test start*/
                            // this.buildSalesPersonSearch(1000),
                            // this.buildSalesPersonTrader(1100),
                            new LookupQuestion({
                                key: 'SPTRSearch',
                                label: 'Sales Person/Trader Search',
                                order: 1000,
                                template: 'Salesperson/Trader',
                                mandatory: true
                            }),
                            /* Nw Lookup control test end */
                            this.buildTradePending(1100),
                            this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
                            this.buildRelationshipType(1300),
                            this.buildPrimeBrokerAccount(1400),
                            //this.buildTradePending(1500),
                            //this.buildNewWires(1600),
                            this.buildNewWires(1500),
                            new LabelQuestion({
                                key: '1600',
                                label: '',
                                order: 1600,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: false
                                            }
                                        ]
                                    }
                                ],
                                disabled: true
                            }),
                            new TextboxQuestion({
                                key: 'Template_Name__c',
                                label: 'Template Name',
                                order: 1600,
                                relation: [
                                    {
                                        action: 'VISIBLE',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    },
                                    {
                                        action: 'REQUIRED',
                                        connective: 'AND',
                                        when: [
                                            {
                                                id: 'Is_Template__c',
                                                operator: '==',
                                                value: true
                                            }
                                        ]
                                    }
                                ]
                            }),

                            this.buildThirdPartyPayment(1700),
                            this.buildThirdPartyWireCheckbox(1800),
                            this.buildPaymentPending(1900),
                            this.buildPaymentDate(2000)
                        ];

                        questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                        questions = questions.concat(this.buildLegalAddressFields());

                        questions = questions.concat(this.buildAPACFields(wfEntityString));
                        questions = questions.concat(this.buildDocumentMatrixFields());
                        const orderDVP = 5100;
                        questions = questions.concat(this.buildPrimeFields(orderDVP));
                        if (requestStatus !== 'Draft') {
                            questions = questions.concat(this.buildWorkItemIndicator());
                            questions = questions.concat(this.buildFacilitatorFields());
                            questions = questions.concat(this.buildAMLFields());
                        }
                        return questions.sort((a, b) => a.order - b.order);
                }
            case 'FCM':
                questions = [
                    new LabelQuestion({
                        key: 'User_Role',
                        label: 'User Role',
                        value: role,
                        order: 1,
                        displayNone: true
                    }),
                    new SingleCheckboxQuestion({
                        key: 'Is_Template__c',
                        label: 'Is_Template',
                        value: false,
                        order: 2,
                        displayNone: true
                    }),
                    this.buildBuildType(buildType),
                    this.buildWFEntity(wfEntity),
                    this.buildSalesAssistant(currentUserName),
                    this.buildCreatedDate(),
                    this.buildProductType(productType),
                    this.buildProductSubType(productSubType, 'Product_Sub_Type_MS__c', 600),
                    this.buildCOBAMNumber(700),
                    this.buildLastModifiedDate(800),
                    this.buildPrimeBrokerAccount(900),
                    this.buildRelationshipType(1000),
                    /* New Lookup control test start*/
                    // this.buildSalesPersonSearch(1000),
                    // this.buildSalesPersonTrader(1700),
                    new LookupQuestion({
                        key: 'SPTRSearch',
                        label: 'Sales Person/Trader Search',
                        order: 1000,
                        template: 'Salesperson/Trader',
                        mandatory: true
                    }),
                    /* Nw Lookup control test end */
                    this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
                    (wfEntityString.search('WFSIL') >= 0 || wfEntityString.search('WFSE') >= 0 || wfEntityString.search('WFSE') >= 0)
                        ? this.buildMiFIDIIClientCategorization(1300) : this.buildEmptyField(1300),

                    (wfEntityString.search('WFSIL') >= 0 || wfEntityString.search('WFSE') >= 0 || wfEntityString.search('WFSLLC - US') >= 0)
                        ? this.buildMiFIDIIRiskReducing(1600) : this.buildNoField(1600),

                    this.buildTradePending(2000),

                    new LabelQuestion({
                        key: '2100',
                        label: '',
                        order: 2100,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: false
                                    }
                                ]
                            }
                        ],
                        disabled: true
                    }),
                    new TextboxQuestion({
                        key: 'Template_Name__c',
                        label: 'Template Name',
                        order: 2100,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: true
                                    }
                                ]
                            },
                            {
                                action: 'REQUIRED',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: true
                                    }
                                ]
                            }
                        ]
                    }),
                    this.buildNewWires(2300),
                    this.buildThirdPartyPayment(2400),
                    this.buildThirdPartyWireCheckbox(2500),
                    this.buildPaymentPending(2600),
                    this.buildPaymentDate(2700)
                ];

                questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                questions = questions.concat(this.buildLegalAddressFields());

                questions = questions.concat(this.buildAPACFields(wfEntityString));
                questions = questions.concat(this.buildDocumentMatrixFields());
                if (requestStatus !== 'Draft') {
                    questions = questions.concat(this.buildWorkItemIndicator());
                    questions = questions.concat(this.buildFacilitatorFields());
                    questions = questions.concat(this.buildAMLFields());
                }

                questions = questions.concat(this.buildCallbackAndThirdPartyFields());
                return questions.sort((a, b) => a.order - b.order);
            case 'Loan Sales':
                questions = [
                    new LabelQuestion({
                        key: 'User_Role',
                        label: 'User Role',
                        value: role,
                        order: 1,
                        displayNone: true
                    }),
                    new SingleCheckboxQuestion({
                        key: 'Is_Template__c',
                        label: 'Is_Template',
                        value: false,
                        order: 2,
                        displayNone: true
                    }),
                    this.buildBuildType(buildType),
                    this.buildWFEntity(wfEntity),
                    this.buildSalesAssistant(currentUserName),
                    this.buildCreatedDate(),
                    this.buildProductType(productType),
                    //this.buildRelationshipType(600),
                    this.buildSettlementType(600, productType, settlementType),
                    this.buildCOBAMNumber(700),
                    this.buildLastModifiedDate(800),
                    this.buildCreditLimit(900, false),
                    this.buildTenorRequested(1000, false),
                    /* New Lookup control test start*/
                    // this.buildSalesPersonSearch(1100),
                    // this.buildSalesPersonTrader(1500),
                    new LookupQuestion({
                        key: 'SPTRSearch',
                        label: 'Sales Person/Trader Search',
                        order: 1100,
                        template: 'Salesperson/Trader',
                        mandatory: true
                    }),
                    /* Nw Lookup control test end */
                    this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
                    this.buildLoanIQType(1300),
                    this.buildDepartmentLoanIQ(1400),
                    //this.buildSalesPersonTrader(1500),
                    this.buildRelationshipType(1500),
                    new LabelQuestion({
                        key: '1800',
                        label: '',
                        order: 1800,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: false
                                    }
                                ]
                            }
                        ],
                        disabled: true
                    }),
                    new TextboxQuestion({
                        key: 'Template_Name__c',
                        label: 'Template Name',
                        order: 1800,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: true
                                    }
                                ]
                            },
                            {
                                action: 'REQUIRED',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: true
                                    }
                                ]
                            }
                        ]
                    }),

                    //this.buildExpenseCode(1700),
                    //this.buildPrimarySIC(1800),
                    this.buildLegalCode(1900),
                    this.buildCustomerClassification(2000),
                    //this.buildRelationshipType(2100),
                    this.buildNewWires(2300),
                    this.buildThirdPartyPayment(2400),
                    this.buildThirdPartyWireCheckbox(2500),
                    this.buildPaymentPending(2600),
                    this.buildPaymentDate(2700)
                ];
                questions = questions.concat(this.buildExpenseCode(1600));
                questions = questions.concat(this.buildPrimarySIC(1700));
                questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                questions = questions.concat(this.buildLegalAddressFields());

                questions = questions.concat(this.buildAPACFields(wfEntityString));
                questions = questions.concat(this.buildDocumentMatrixFields());
                if (requestStatus !== 'Draft') {
                    questions = questions.concat(this.buildWorkItemIndicator());
                    questions = questions.concat(this.buildFacilitatorFields());
                    questions = questions.concat(this.buildAMLFields());
                }

                questions = questions.concat(this.buildCallbackAndThirdPartyFields());

                return questions.sort((a, b) => a.order - b.order);
            case 'Agency':
                questions = [
                    new LabelQuestion({
                        key: 'User_Role',
                        label: 'User Role',
                        value: role,
                        order: 1,
                        displayNone: true
                    }),
                    new SingleCheckboxQuestion({
                        key: 'Is_Template__c',
                        label: 'Is_Template',
                        value: false,
                        order: 2,
                        displayNone: true
                    }),
                    this.buildBuildType(buildType),
                    this.buildWFEntity(wfEntity),
                    this.buildSalesAssistant(currentUserName),
                    this.buildCreatedDate(),
                    this.buildProductType(productType),
                    new DropdownQuestion({
                        section: 'RequestDetails',
                        key: 'Is_WCIS_ID_available__c',
                        label: 'Is WCIS ID available?',
                        mandatory: true,
                        defaultOption: '',
                        order: 600,
                        options: [
                            { key: '', value: '--None--' },
                            { key: 'Yes', value: 'Yes' },
                            { key: 'No', value: 'No' }
                        ]
                    }),
                    this.buildCOBAMNumber(700),
                    this.buildLastModifiedDate(800),
                    new DropdownQuestion({
                        section: 'RequestDetails',
                        key: 'Institutional_Individual_Bank__c',
                        label: 'Institutional/Individual/ Bank',
                        mandatory: true,
                        defaultOption: '',
                        order: 900,
                        options: [
                            { key: '', value: '--None--' },
                            { key: 'Institutional', value: 'Institutional' },
                            { key: 'Individual', value: 'Individual' },
                            { key: 'Bank', value: 'Bank' }
                        ]
                    }),
                    new TextboxQuestion({
                        section: 'RequestDetails',
                        key: 'WCIS_ID__c',
                        label: 'WCIS ID',
                        mandatory: false,
                        order: 1000,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_WCIS_ID_available__c',
                                        value: 'Yes',
                                        operator: '==='
                                    }
                                ]
                            }
                        ]
                    }),
                    new LabelQuestion({
                        key: '1000',
                        label: '',
                        order: 1000,
                        disabled: true,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_WCIS_ID_available__c',
                                        value: 'Yes',
                                        operator: '!=='
                                    }
                                ]
                            }
                        ]
                    }),
                    this.buildRelationshipType(1100),
                    this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),

                    //this.buildPrimarySIC(1400),
                    this.buildLegalCode(1500),
                    this.buildCustomerClassification(1600),
                    this.buildLoanIQType(1650),
                    this.buildDepartmentLoanIQ(1700),
                    this.buildCountryofIncorporation(1800),
                    new DropdownQuestion({
                        section: 'RequestDetails',
                        key: 'Internal_Risk_Rating__c',
                        label: 'Internal Risk Rating',
                        mandatory: true,
                        defaultOption: '',
                        order: 1900,
                        options: [
                            { key: '', value: '--None--' },
                            { key: '0 - Not Entered', value: '0 - Not Entered' },
                            { key: '15 - Prime Borrowers', value: '15 - Prime Borrowers' },
                            { key: '25 - Near Prime Borrowers', value: '25 - Near Prime Borrowers' },
                            { key: '35 - Strong Borrowers', value: '35 - Strong Borrowers' },
                            { key: '40 - Acceptable Borrowers - Transitional Grade', value: '40 - Acceptable Borrowers - Transitional Grade' },
                            { key: '42 - Acceptable Borrowers - Strong', value: '42 - Acceptable Borrowers - Strong' },
                            { key: '45 - Acceptable Borrowers - Average', value: '45 - Acceptable Borrowers - Average' },
                            { key: '48 - Acceptable Borrowers - Weak', value: '48 - Acceptable Borrowers - Weak' },
                            { key: '50 - Generally Acceptable Borrowers - Transitional', value: '50 - Generally Acceptable Borrowers - Transitional' },
                            { key: '52 - Generally Acceptable Borrowers - Strong', value: '52 - Generally Acceptable Borrowers - Strong' },
                            { key: '55 - Generally Acceptable Borrowers - Average', value: '55 - Generally Acceptable Borrowers - Average' },
                            { key: '58 - Generally Acceptable Borrowers - Weak', value: '58 - Generally Acceptable Borrowers - Weak' },
                            { key: '65 - Special Mention Borrowers', value: '65 - Special Mention Borrowers' },
                            { key: '75 - Substandard Borrowers', value: '75 - Substandard Borrowers' },
                            { key: '85 - Doubtful Borrowers', value: '85 - Doubtful Borrowers' },
                            { key: '95 - Loss Borrowers', value: '95 - Loss Borrowers' }
                        ]
                    }),
                    new DropdownQuestion({
                        section: 'RequestDetails',
                        key: 'External_Risk_Rating_Type__c',
                        label: 'External Risk Rating Type',
                        mandatory: true,
                        defaultOption: '',
                        order: 2000,
                        options: [
                            { key: '', value: '--None--' },
                            { key: 'A.M. Best', value: 'A.M. Best' },
                            { key: 'Commercial Paper - Fitch\'s', value: 'Commercial Paper - Fitch\'s' },
                            { key: 'Commercial Paper Moody\'s', value: 'Commercial Paper Moody\'s' },
                            { key: 'Commercial Paper S & P', value: 'Commercial Paper S & P' },
                            { key: 'Long Term Debt - DBRS', value: 'Long Term Debt - DBRS' },
                            { key: 'Long Term Debt -Fitch', value: 'Long Term Debt -Fitch' },
                            { key: 'Long Term debt -Moodys', value: 'Long Term debt -Moodys' },
                            { key: 'Long Term debt -S&P', value: 'Long Term debt -S&P' },
                            { key: 'Long Term Duff & Phelps', value: 'Long Term Duff & Phelps' },
                            { key: 'Moody\'s', value: 'Moody\'s' },
                            { key: 'S & P', value: 'S & P' },
                            { key: 'Senior Debt - Fitch\'s', value: 'Senior Debt - Fitch\'s' }
                        ]
                    }),
                    new TextboxQuestion({
                        section: 'RequestDetails',
                        key: 'External_Risk_Rating__c',
                        label: 'External Risk Rating',
                        order: 2100,
                        disabled: false,
                        // displayNone: true
                    }),
                    this.buildNewWires(2300),
                    new LabelQuestion({
                        key: '2350',
                        label: '',
                        order: 2350,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: false
                                    }
                                ]
                            }
                        ],
                        disabled: true
                    }),
                    new TextboxQuestion({
                        key: 'Template_Name__c',
                        label: 'Template Name',
                        order: 2350,
                        relation: [
                            {
                                action: 'VISIBLE',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: true
                                    }
                                ]
                            },
                            {
                                action: 'REQUIRED',
                                connective: 'AND',
                                when: [
                                    {
                                        id: 'Is_Template__c',
                                        operator: '==',
                                        value: true
                                    }
                                ]
                            }
                        ]
                    }),
                    this.buildThirdPartyPayment(2400),
                    this.buildThirdPartyWireCheckbox(2500),
                    this.buildPaymentPending(2600),
                    this.buildPaymentDate(2700)
                ];
                questions = questions.concat(this.buildExpenseCode(1300));
                questions = questions.concat(this.buildPrimarySIC(1400));
                questions = questions.concat(this.buildLegalAndBusAcctFields(wfEntityString, productType));

                questions = questions.concat(this.buildLegalAddressFields());

                questions = questions.concat(this.buildAPACFields(wfEntityString));
                questions = questions.concat(this.buildDocumentMatrixFields());
                if (requestStatus !== 'Draft') {
                    questions = questions.concat(this.buildWorkItemIndicator());
                    questions = questions.concat(this.buildFacilitatorFields());
                    questions = questions.concat(this.buildAMLFields());
                }

                questions = questions.concat(this.buildCallbackAndThirdPartyFields());

                return questions.sort((a, b) => a.order - b.order);
            case 'Swaps':
                questions = this.buildNonCashRequestDetails(productType, productSubType, buildType,
                    wfEntity, role, requestStatus, currentUserName);
                return questions.sort((a, b) => a.order - b.order);
            case 'FX':
                questions = this.buildFXRequestDetails(productType, productSubType, buildType,
                    wfEntity, role, requestStatus, currentUserName);
                return questions.sort((a, b) => a.order - b.order);
            default:
                break;
        }
    }

    buildNonCashRequestDetails(productType?: string, productSubType?: string, buildType?: string,
        wfEntity?: string, role?: string, requestStatus?: string, currentUserName?: string, settlementType?: string, amlStatus?: string): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        var wfEntityString = wfEntity.toString();
        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: role,
                order: 1,
                displayNone: true
            }),
            this.buildBuildType(buildType),
            this.buildWFEntity(wfEntity),
            this.buildSalesAssistant(currentUserName),
            this.buildCreatedDate(),
            this.buildProductType(productType),
            (productType && productType === 'Swaps') ? this.buildProductSubType(productSubType, 'Product_Sub_Type_MS__c', 600) : this.buildProductSubType(productSubType, 'Product_Sub_Type__c', 600),
            this.buildCOBAMNumber(700),
            this.buildLastModifiedDate(800),
            new LabelQuestion({
                section: 'RequestDetails',
                key: '900',
                label: '',
                order: 900,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Product_Sub_Type__c',
                                value: 'CDS Single Name',
                                operator: '!=='
                            },
                            {
                                id: 'Product_Sub_Type__c',
                                value: 'CDS Index (SEF)',
                                operator: '!=='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'RequestDetails',
                key: 'Is_documentation_required__c',
                label: 'Is documentation required?',
                mandatory: true,
                defaultOption: '',
                order: 900,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Product_Sub_Type__c',
                                value: 'CDS Single Name',
                                operator: '==='
                            },
                            {
                                id: 'Product_Sub_Type__c',
                                value: 'CDS Index (SEF)',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            this.buildSettlementType(1000, productType, settlementType),
            (wfEntityString.search('WFSIL') >= 0 || wfEntityString.search('WFBNA - LB') >= 0 || wfEntityString.search('WFSE') >= 0)
                ? this.buildMiFIDIIClientCategorization(1100) : this.buildEmptyField(1100),

            (requestStatus && requestStatus !== 'Draft') ?
                new DropdownQuestion({
                    section: 'RequestDetails',
                    key: 'StaticDataStatus__c',
                    label: 'Static Data Status',
                    order: 1200,
                    //disabled: disabled,
                    defaultOption: '',
                    options: [
                        { key: '', value: '--None--' },
                        { key: 'GDD Requested', value: 'GDD Requested' },
                        { key: 'GDD Approved', value: 'GDD Approved' },
                        { key: 'Trading Externals Requested', value: 'Trading Externals Requested' },
                        { key: 'Approved', value: 'Approved' }
                    ]
                }) : this.buildEmptyField(1200),
            this.buildQueueStatus(requestStatus, 1300, role, buildType, amlStatus),


            this.buildBAID(1400),
            this.buildClientContactedAll(1500, productType, productSubType),
            this.buildMarketerSearch(1600),

            (productType && productType === 'Swaps') ?
                (productSubType
                    && (productSubType.indexOf('CDS Single Name') > -1 || productSubType.indexOf('CDS Index (SEF)') > -1))
                    ? this.buildTypeofDocumentationRequestCDSForRequestDetails(1700) : this.buildTypeofDocumentationRequestForRequestDetailsForSwaps(1700)
                : this.buildTypeofDocumentationRequestForRequestDetailsForEquities(1700),
            this.buildExternalSystemList(1800),
            new TextboxQuestion({
                section: 'RequestDetails',
                key: 'Customer_Contact__c',
                label: 'Customer Contact',
                order: 1900,
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Can_the_client_be_contacted__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            this.buildMarketer(2000),
            (productSubType.indexOf('CDS Single Name') > -1 || productSubType.indexOf('CDS Index (SEF)') > -1)
                ? new TextboxQuestion({
                    section: 'RequestDetails',
                    key: 'Customer_LEI_GMEI_CICI__c',
                    label: 'Customer LEI/GMEI/CICI',
                    order: 2100,
                    mandatory: false
                }) : this.buildEmptyField(2100),

            (productSubType.indexOf('CDS Single Name') > -1 || productSubType.indexOf('CDS Index (SEF)') > -1)
                ? new TextboxQuestion({
                    section: 'RequestDetails',
                    key: 'ICE_Short_Code__c',
                    label: 'ICE Short Code',
                    order: 2200,
                    mandatory: false
                }) : this.buildEmptyField(2200),

            (productSubType.indexOf('CDS Single Name') > -1 || productSubType.search('CDS Index (SEF)') > -1)
                ? new TextboxQuestion({
                    section: 'RequestDetails',
                    key: 'ICE_Counterparty_Type__c',
                    label: 'ICE Counterparty Type',
                    order: 2300,
                    mandatory: false
                }) : this.buildEmptyField(2300),

            this.buildBranchLocation(2400),
            this.buildNewWires(2500),
            this.buildThirdPartyPayment(2600),
            this.buildThirdPartyWireCheckbox(2700),
            this.buildPaymentPending(2800),
            this.buildPaymentDate(2900),
            this.buildNotes(3000),
            this.buildLegalSearchForNonCash(5000),
            new LabelQuestion({
                section: 'RequestDetails',
                key: 'WCIS_ID__c',
                label: 'WCIS ID',
                order: 5100,
                disabled: true,
            }),
            new DropdownQuestion({
                section: 'RequestDetails',
                key: 'CustomerType__c',
                label: 'Line of Business',
                mandatory: true,
                defaultOption: '',
                order: 5200,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Asset-Backed Finance', value: 'Asset-Backed Finance' },
                    { key: 'Government Investment Bank/Municipal Products Group', value: 'Government Investment Bank/Municipal Products Group' },
                    { key: 'Business Banking/Dealer Services', value: 'Business Banking/Dealer Services' },
                    { key: 'Hedge Fund', value: 'Hedge Fund' },
                    { key: 'Commercial Real Estate/Real Estate Capital Markets', value: 'Commercial Real Estate/Real Estate Capital Markets' },
                    { key: 'Institutional/Emerging Markets', value: 'Institutional/Emerging Markets' },
                    { key: 'Community Lending & Investment', value: 'Community Lending & Investment' },
                    { key: 'Regional Commercial Banking Office', value: 'Regional Commercial Banking Office' },
                    { key: 'Corporate Banking Group', value: 'Corporate Banking Group' },
                    { key: 'Wealth Management/Wealth Brokerage Retirement', value: 'Wealth Management/Wealth Brokerage Retirement' },
                    { key: 'Global Banking', value: 'Global Banking' },
                    { key: 'Wells Fargo Capital Finance', value: 'Wells Fargo Capital Finance' },
                    { key: 'Global Financial Institutions', value: 'Global Financial Institutions' },
                    { key: 'Other', value: 'Other' }
                ]
            }),
            this.buildLegalNameForNonCash(5210),
            new LabelQuestion({
                section: 'RequestDetails',
                key: 'Legal_Id__c',
                label: 'CID LEID',
                order: 5220,
                disabled: true,
            }),
            new TextboxQuestion({
                section: 'RequestDetails',
                key: 'Other_Customer_Type_Desc__c',
                label: 'Other Line of Business Desc',
                order: 5230,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'CustomerType__c',
                                value: 'Other',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            // new LabelQuestion({
            //     key: 'Other_Customer_Type_Desc__c_5500',
            //     label: '',
            //     order: 5500,
            //     disabled: true,
            //     relation: [
            //         {
            //             action: 'VISIBLE',
            //             //connective: 'AND',
            //             when: [
            //                 {
            //                     id: 'CustomerType__c',
            //                     value: 'Other',
            //                     operator: '!=='
            //                 }
            //             ]
            //         }
            //     ]
            // }),
        ];

        questions = questions.concat(this.buildAPACFields(wfEntityString, 5300));
        questions = questions.concat(this.buildDocumentMatrixFields(5500));

        if (requestStatus !== 'Draft') {
            questions = questions.concat(this.buildWorkItemIndicatorForNonCash());
            questions = questions.concat(this.buildNonCashFacilitatorFields(6000, 'DCOT'));
            questions = questions.concat(this.buildAMLFields(7000));
        }

        questions = questions.concat(this.buildCallbackAndThirdPartyFields());
        return questions.sort((a, b) => a.order - b.order);
    }

    buildFXRequestDetails(productType?: string, productSubType?: string, buildType?: string,
        wfEntity?: string, role?: string, requestStatus?: string, currentUserName?: string, amlStatus?: string): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        var wfEntityString = wfEntity.toString();
        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: role,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                key: 'ShowMiFidField',
                label: 'ShowMiFidField',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                key: 'IsFxOnline',
                label: '',
                order: 1,
                displayNone: true
            }),
            this.buildBuildType(buildType),
            this.buildWFEntity(wfEntity),
            this.buildSalesAssistant(currentUserName),
            this.buildCreatedDate(),
            this.buildProductType(productType),
            this.buildCMRID(role),
            this.buildCOBAMNumber(700),
            this.buildLastModifiedDate(800),
            this.buildTypeofDocumentationRequest(900),
            this.buildBAID(1000),
            (requestStatus && requestStatus !== 'Draft') ?
                new DropdownQuestion({
                    section: 'RequestDetails',
                    key: 'StaticDataStatus__c',
                    label: 'Static Data Status',
                    order: 1100,
                    //disabled: disabled,
                    defaultOption: '',
                    options: [
                        { key: '', value: '--None--' },
                        { key: 'GDD Requested', value: 'GDD Requested' },
                        { key: 'GDD Approved', value: 'GDD Approved' },
                        { key: 'Trading Externals Requested', value: 'Trading Externals Requested' },
                        { key: 'Approved', value: 'Approved' }
                    ]
                }) : this.buildEmptyField(1100),

            this.buildQueueStatus(requestStatus, 1200, role, buildType, amlStatus),
            new DropdownQuestion({
                section: 'RequestDetails',
                key: 'MiFID_II_Client_Categorization__c',
                label: 'MiFID II Client Categorization',
                mandatory: true,
                selectionChange: true,
                defaultOption: '',
                order: 1300,
                options: [
                    { key: '', value: '-- Please Select --' },
                    { key: 'Per Se Professional Client', value: 'Per Se Professional Client' },
                    { key: 'Elective Professional Client', value: 'Elective Professional Client' },
                    { key: 'Per Se Eligible Counterparty', value: 'Per Se Eligible Counterparty' },
                    { key: 'Elective Eligible Counterparty', value: 'Elective Eligible Counterparty' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'ShowMiFidField',
                                operator: '===',
                                value: 'Yes'
                            }
                        ]
                    },
                ]
            }),
            new LabelQuestion({
                section: 'RequestDetails',
                key: '1300',
                label: '',
                order: 1300,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'ShowMiFidField',
                                operator: '!==',
                                value: 'Yes'
                            }
                        ]
                    },
                ]
            }),

            new DropdownQuestion({
                section: 'RequestDetails',
                key: 'Is_Calypso_V12_Required__c',
                label: 'Is Calypso V12 Required?',
                defaultOption: '',
                mandatory: true,
                order: 1400,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ]
            }),

            (requestStatus && requestStatus !== 'Draft') ? new AutoCompleteQuestion({
                section: 'RequestDetails',
                key: 'FX_Static_Data_Assignee__c',
                label: 'FX Static Data Assignee',
                order: 2001,
                mandatory: true,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'FX Static Data',
                relation: [
                    {
                        action: "VISIBLE",
                        //connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'FX Static Data'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        //connective: 'OR',
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }

                ]
            }) : this.buildEmptyField(2001),

            (requestStatus && requestStatus !== 'Draft') ? new DropdownQuestion({
                section: 'RequestDetails',
                key: 'FX_Static_Data_Status__c',
                label: 'FX Static Data Status',
                mandatory: true,
                defaultOption: 'Draft',
                order: 1600,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Draft', value: 'Draft' }
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        //connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                ]
            }) : this.buildEmptyField(1600),

            this.buildMarketerSearch(1800),
            this.buildMarketer(1900),
            this.buildBranchLocation(2000),
            role === 'FX Static Data' ?
                new TextboxQuestion({
                    section: 'RequestDetails',
                    key: 'CMNE_Number__c',
                    label: 'CMNE #',
                    //disabled: true,
                    order: 1500
                }) :
                new TextboxQuestion({
                    section: 'RequestDetails',
                    key: 'CMNE_Number__c',
                    label: 'CMNE #',
                    disabled: true,
                    order: 1500
                }),

            this.buildNewWires(2100),
            this.buildThirdPartyPayment(2200),
            this.buildThirdPartyWireCheckbox(2300),
            this.buildPaymentPending(2400),
            this.buildPaymentDate(2500),
            this.buildNotes(3000),
            this.buildLegalSearchForNonCash(5000),
            new LabelQuestion({
                section: 'RequestDetails',
                key: 'WCIS_ID__c',
                label: 'WCIS ID',
                order: 5100,
                disabled: true,
            }),
            new DropdownQuestion({
                section: 'RequestDetails',
                key: 'CustomerType__c',
                label: 'Line of Business',
                mandatory: true,
                defaultOption: '',
                order: 5200,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Asset-Backed Finance', value: 'Asset-Backed Finance' },
                    { key: 'Government Investment Bank/Municipal Products Group', value: 'Government Investment Bank/Municipal Products Group' },
                    { key: 'Business Banking/Dealer Services', value: 'Business Banking/Dealer Services' },
                    { key: 'Hedge Fund', value: 'Hedge Fund' },
                    { key: 'Commercial Real Estate/Real Estate Capital Markets', value: 'Commercial Real Estate/Real Estate Capital Markets' },
                    { key: 'Institutional/Emerging Markets', value: 'Institutional/Emerging Markets' },
                    { key: 'Community Lending & Investment', value: 'Community Lending & Investment' },
                    { key: 'Regional Commercial Banking Office', value: 'Regional Commercial Banking Office' },
                    { key: 'Corporate Banking Group', value: 'Corporate Banking Group' },
                    { key: 'Wealth Management/Wealth Brokerage Retirement', value: 'Wealth Management/Wealth Brokerage Retirement' },
                    { key: 'Global Banking', value: 'Global Banking' },
                    { key: 'Wells Fargo Capital Finance', value: 'Wells Fargo Capital Finance' },
                    { key: 'Global Financial Institutions', value: 'Global Financial Institutions' },
                    { key: 'Other', value: 'Other' }
                ]
            }),
            this.buildLegalNameForNonCash(5210),
            new LabelQuestion({
                section: 'RequestDetails',
                key: 'Legal_Id__c',
                label: 'CID LEID',
                order: 5220,
                disabled: true,
            }),
            new TextboxQuestion({
                section: 'RequestDetails',
                key: 'Other_Customer_Type_Desc__c',
                label: 'Other Line of Business Desc',
                order: 5230,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'CustomerType__c',
                                value: 'Other',
                                operator: '==='
                            }
                        ]
                    }
                ]
            })
        ];

        questions = questions.concat(this.buildAPACFields(wfEntityString, 5300));
        questions = questions.concat(this.buildDocumentMatrixFields(5500));

        if (requestStatus !== 'Draft') {
            questions = questions.concat(this.buildWorkItemIndicatorForNonCash());
            questions = questions.concat(this.buildNonCashFacilitatorFields(6000, 'DCOT'));
            questions = questions.concat(this.buildFXAMLFields(7000));
            questions = questions.concat(this.buildFXOLFields());
        }

        questions = questions.concat(this.buildCallbackAndThirdPartyFields());
        return questions.sort((a, b) => a.order - b.order);
    }
    buildWorkItemIndicatorField(fieldName: string, fieldLabel: string, uiFieldName: string, order: number) {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new LabelQuestion({
                section: 'RequestDetails',
                key: fieldName,
                label: fieldLabel,
                order: order,
                displayNone: true,
                disabled: true,
            }),
            new IndicatorQuestion({
                section: 'RequestDetails',
                key: uiFieldName,
                label: fieldLabel,
                order: order,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: fieldName,
                                value: 'Pending'
                            },
                            {
                                id: fieldName,
                                value: 'Complete'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                key: order.toString(),
                label: '',
                order: order,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: fieldName,
                                value: 'Pending'
                            },
                            {
                                id: fieldName,
                                value: 'Complete'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                key: order.toString(),
                label: '',
                order: order,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: fieldName,
                                value: 'Pending'
                            },
                            {
                                id: fieldName,
                                value: 'Complete'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                key: order.toString(),
                label: '',
                order: order,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: fieldName,
                                value: 'Pending'
                            },
                            {
                                id: fieldName,
                                value: 'Complete'
                            }
                        ]
                    }
                ]
            })
        ];

        return questions.sort((a, b) => a.order - b.order);
    }
    buildWorkItemIndicator() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            this.buildLongHeader(2750, 'WORKITEM', 'WorkItem Details')
        ];

        questions = questions.concat(this.buildWorkItemIndicatorField('Reg_Requirements__c', 'Regulatory Requirements', 'Reg_Requirements__ui', 2750));
        questions = questions.concat(this.buildWorkItemIndicatorField('AML_Requirements__c', 'CDD Requirements', 'AML_Requirements__ui', 2750));
        questions = questions.concat(this.buildWorkItemIndicatorField('Tax_Requirements__c', 'Tax Requirements', 'Tax_Requirements__ui', 2750));
        questions = questions.concat(this.buildWorkItemIndicatorField('Documentation_Requirements__c', 'Documentation Requirements', 'Documentation_Requirements__ui', 2750));
        questions = questions.concat(this.buildWorkItemIndicatorField('Secondary_Review__c', 'Secondary Review', 'Secondary_Review__ui', 2750));

        return questions.sort((a, b) => a.order - b.order);
    }

    buildWorkItemIndicatorForNonCash() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            this.buildLongHeader(2950, 'WORKITEM', 'WorkItem Details')
        ];

        questions = questions.concat(this.buildWorkItemIndicatorField('Reg_Requirements__c', 'Regulatory Requirements', 'Reg_Requirements__ui', 2950));
        questions = questions.concat(this.buildWorkItemIndicatorField('CDD_Requirements__c', 'CDD Requirements', 'CDD_Requirements__ui', 2950));
        questions = questions.concat(this.buildWorkItemIndicatorField('Tax_Requirements__c', 'Tax Requirements', 'Tax_Requirements__ui', 2950));
        questions = questions.concat(this.buildWorkItemIndicatorField('Documentation_Requirements__c', 'Documentation Requirements', 'Documentation_Requirements__ui', 2950));
        questions = questions.concat(this.buildWorkItemIndicatorField('Secondary_Review__c', 'Secondary Review', 'Secondary_Review__ui', 2950));

        return questions.sort((a, b) => a.order - b.order);
    }

    buildLegalAndBusAcctFields(wfEntity: string, productType: string) {
        let questions: QuestionBase<any>[] = [];
        questions = [
            this.buildLongHeader(2800, 'LEGAL', 'Legal & Business Account Details'),
            this.buildLegalSearch(3200),
            this.buildAlertAcronym(3300),
            this.buildCIDLEID(3400),
            (wfEntity.search('WFSIL') >= 0 || wfEntity.search('WFSE') >= 0)
                ? this.buildContactDetailsLabel(3500) : this.buildNoField(3500),
            (wfEntity.search('WFSIL') >= 0 || wfEntity.search('WFSE') >= 0)
                ? this.buildClientContacted(3500, productType) : this.buildClientContactedAll(3500, productType),
            this.buildLegalName(3600),
            this.buildAlertCode(3700),
            this.buildBAID(3800),
            this.buildClientContactName(3900),
            new LabelQuestion({
                section: 'LegalAndBusAcct',
                key: '3900',
                label: '',
                order: 3900,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Can_the_client_be_contacted__c',
                                value: 'No'
                            }
                        ]
                    }
                ],
                disabled: true
            }),
            this.buildBusAcctName(4000),
            this.buildClientType(4100, productType),
            this.buildExternalSystemList(4200),
            this.buildClientContactPhone(4300),
            new LabelQuestion({
                section: 'LegalAndBusAcct',
                key: '4300',
                label: '',
                order: 4300,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Can_the_client_be_contacted__c',
                                value: 'No'
                            }
                        ]
                    }
                ],
                disabled: true
            }),
            this.buildShortName(4400),
            this.buildClientSubType(4500, productType),
            this.buildCMAName(4600),
            this.buildClientContactEmail(4700),
            new LabelQuestion({
                section: 'LegalAndBusAcct',
                key: '4700',
                label: '',
                order: 4700,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Can_the_client_be_contacted__c',
                                value: 'No'
                            }
                        ]
                    }
                ],
                disabled: true
            }),
            productType === 'Loan Sales' || productType === 'Agency' ? new TextboxQuestion({
                section: 'LegalAndBusAcct',
                key: 'MEI__c',
                label: 'MEI',
                order: 4800
            }) : new LabelQuestion({
                section: 'LegalAndBusAcct',
                key: '4800',
                label: '',
                order: 4800,
                disabled: true
            }),
            this.buildCustomerType(4900),
            this.buildCMAId(4910),
            this.buildIsNewCMA(4915),
            this.buildClientId(4920),
            this.buildNotes(5100)
        ];

        return questions.sort((a, b) => a.order - b.order);
    }
    buildLegalAddressFields
        () {
        let questions: QuestionBase<any>[] = [];
        questions = [
            this.buildLongHeader(5105, 'LEGAL', 'Legal Address Section'),
            this.buildAddressSearch(5110),
            new LabelQuestion({
                section: 'LegalAddressDetails',
                key: '5110',
                label: '',
                order: 5110,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Build_Type__c',
                                value: 'New Legal & Bus Acc'
                            }
                        ]
                    }
                ],
                disabled: true
            }),
            this.buildCity(5120),
            this.buildState(5130),
            this.buildCanadianProvince(5130),
            new LabelQuestion({
                section: 'LegalAddressDetails',
                key: '5130',
                label: '',
                order: 5130,
                disabled: true
            }),
            new LabelQuestion({
                section: 'LegalAddressDetails',
                key: '5130',
                label: '',
                order: 5130,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country__c',
                                value: 'CA - CANADA',
                                operator: '!=='
                            },
                            {
                                id: 'Country__c',
                                value: 'US - UNITED STATES',
                                operator: '!=='
                            }
                        ]
                    }
                ],
                disabled: true
            }),
            //this.buildEmptyField(5140),
            this.buildAddressLine1(5140),
            this.buildZip(5160),
            this.buildPostalCode(5160),
            this.buildCountry(5170),
            this.buildEmptyField(5180),
            this.buildAddressLine2(5190),
            this.buildAddressLine3(5200)
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildAPACFields(wfEntity: string, order: number = 5210): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            (wfEntity.search('WFSAL') >= 0)
                ? this.buildLongHeader(order, 'LEGAL', 'APAC Details Section') : this.buildNoField(5210),
            (wfEntity.search('WFSAL') >= 0)
                ? this.buildHKClassification(order + 20) : this.buildNoField(order + 20),
            (wfEntity.search('WFSAL') >= 0)
                ? this.buildProductMarketCoverage(order + 30) : this.buildNoField(order + 30),
            (wfEntity.search('WFSAL') >= 0)
                ? this.buildCPILetterComplete(order + 40) : this.buildNoField(order + 40),
            (wfEntity.search('WFSAL') >= 0)
                ? this.buildAPACComments(order + 60) : this.buildNoField(order + 60),
            (wfEntity.search('WFSAL') >= 0)
                ? this.buildAPACStatus(order + 50) : this.buildNoField(order + 50),
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildFINRAFields(): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            // this.buildEmptyField(4950),
            // this.buildEmptyField(4951),
            new DropdownQuestion({
                section: 'LegalAndBusAcct',
                key: 'FINRA_4210_Classification_Type__c',
                label: 'FINRA 4210 Classification Type',
                defaultOption: '',
                mandatory: true,
                order: 4960,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'FINRA Member', value: 'FINRA Member' },
                    { key: 'Broker dealer registered with the SEC', value: 'Broker dealer registered with the SEC' },
                    { key: 'Domestic bank as defined in Section 3(a)(6) of the Exchange Act', value: 'Domestic bank as defined in Section 3(a)(6) of the Exchange Act' },
                    { key: 'Domestic Savings Association as defined in Seciont 3(b) of the Federal Deposit Insurance Act, the deposits of which are insured by the FDIC', value: 'Domestic Savings Association as defined in Seciont 3(b) of the Federal Deposit Insurance Act, the deposits of which are insured by the FDIC' },
                    { key: 'Domestic Insurance Company as defined in Section 2(a)(17) of the Investment Company Act of 1940', value: 'Domestic Insurance Company as defined in Section 2(a)(17) of the Investment Company Act of 1940' },
                    { key: 'Domestic Investment Company registered with the SEC under the Investment Company Act of 1940', value: 'Domestic Investment Company registered with the SEC under the Investment Company Act of 1940' },
                    { key: 'Domestic State or Political subdivision', value: 'Domestic State or Political subdivision' },
                    { key: 'A pension or profit sharing plan subject to ERISA or of an agency of the United States or of a state or a political subdivision thereof', value: 'A pension or profit sharing plan subject to ERISA or of an agency of the United States or of a state or a political subdivision thereof' },
                    { key: 'None of the above', value: 'None of the above' },
                    { key: 'NR - Not Reviewed', value: 'NR - Not Reviewed' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Facilitator'
                            },
                            {
                                id: 'User_Role',
                                value: 'Facilitator Manager'
                            }
                        ]
                    },
                ]
            }),

            new LabelQuestion({
                section: 'LegalAndBusAcct',
                key: '4970',
                label: '',
                order: 4970,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FINRA_4210_Classification_Type__c',
                                value: 'NR - Not Reviewed',
                                operator: '!=='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'LegalAndBusAcct',
                key: 'FINRA_4210_Person_Test__c',
                label: 'FINRA 4210 Person Test',
                defaultOption: '',
                mandatory: true,
                order: 4970,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Persons - Registered Securities & Regulatory Reporting', value: 'Persons - Registered Securities & Regulatory Reporting' },
                    { key: 'Persons - Audited Financials & Risk Analysis', value: 'Persons - Audited Financials & Risk Analysis' },
                    { key: 'Does not meet Person test - Financials reviewed', value: 'Does not meet Person test - Financials reviewed' },
                    { key: 'Does not meet Person test - Unable to locate financials', value: 'Does not meet Person test - Unable to locate financials' },
                    { key: 'Does not meet Person test - Client will not provide financials', value: 'Does not meet Person test - Client will not provide financials' },
                    { key: 'NR - Not Reviewed', value: 'NR - Not Reviewed' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FINRA_4210_Classification_Type__c',
                                value: 'NR - Not Reviewed'
                            }
                        ]
                    },
                ]
            }),

            new LabelQuestion({
                section: 'LegalAndBusAcct',
                key: '4980',
                label: '',
                order: 4980,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'NR - Not Reviewed',
                                operator: '!=='
                            },
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'Does not meet Person test - Financials reviewed',
                                operator: '!=='
                            },
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'Does not meet Person test - Client will not provide financials',
                                operator: '!=='
                            },
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'Does not meet Person test - Unable to locate financials',
                                operator: '!=='
                            }
                        ]
                    },
                ]
            }),
            new DropdownQuestion({
                section: 'LegalAndBusAcct',
                key: 'FINRA_4210_Enhanced_Classification__c',
                label: 'FINRA 4210 Enhanced Classification',
                defaultOption: '',
                mandatory: true,
                order: 4980,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Federal Banking Agency', value: 'Federal Banking Agency' },
                    { key: 'Central Bank', value: 'Central Bank' },
                    { key: 'Multinational Central Bank', value: 'Multinational Central Bank' },
                    { key: 'Foreign Sovereign', value: 'Foreign Sovereign' },
                    { key: 'Multilateral Development Bank', value: 'Multilateral Development Bank' },
                    { key: 'Bank of International Settlements', value: 'Bank of International Settlements' },
                    { key: 'Mortgage Banker', value: 'Mortgage Banker' },
                    { key: 'None of the above', value: 'None of the above' },
                    { key: 'NR - Not Reviewed', value: 'NR - Not Reviewed' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'NR - Not Reviewed',
                                operator: '==='
                            },
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'Does not meet Person test - Financials reviewed',
                                operator: '==='
                            },
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'Does not meet Person test - Client will not provide financials',
                                operator: '==='
                            },
                            {
                                id: 'FINRA_4210_Person_Test__c',
                                value: 'Does not meet Person test - Unable to locate financials',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            new LabelQuestion({
                key: '4990',
                label: '',
                order: 4990,
                disabled: true,
            })
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildDocumentMatrixFields(order: number = 5300): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            //Document Matrix fields starts
            new LabelQuestion({
                section: 'DocumentMatrix',
                rowGroupBy: 'LEGAL',
                col: 12,
                key: '_' + order.toString(),
                label: 'Document Matrix Section',
                value: '',
                order: order,
                disabled: true,
                css: 'title',
                // relation: [
                //     {
                //         action: 'VISIBLE',
                //         //connective: 'OR',
                //         when: [
                //             {
                //                 id: "Status__c",
                //                 value: "Draft",
                //                 operator: "!=="
                //             }
                //         ]
                //     }
                // ]
            }),
            new DropdownQuestion({
                section: 'DocumentMatrix',
                key: 'CDD_Type__c',
                label: 'CDD Type',
                defaultOption: '',
                selectionChange: true,
                order: order + 10,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Individuals, Joint Account holders, IRAs, Custodian', value: 'Individuals, Joint Account holders, IRAs, Custodian' },
                    { key: 'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)', value: 'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)' },
                    { key: 'General Partnerships', value: 'General Partnerships' },
                    { key: 'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)', value: 'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)' },
                    { key: 'Trusts with Regulated Trustees', value: 'Trusts with Regulated Trustees' },
                    { key: 'Trusts with Unregulated Trustees', value: 'Trusts with Unregulated Trustees' },
                    { key: 'US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]. US Regulated Credit or Financial Institutions', value: 'US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]. US Regulated Credit or Financial Institutions' },
                    { key: 'Non-US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisors, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]', value: 'Non-US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisors, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]' },
                    { key: 'Company Listed on Approved Exchange and Subsidiaries', value: 'Company Listed on Approved Exchange and Subsidiaries' },
                    { key: 'Pension Plans', value: 'Pension Plans' },
                    { key: 'Local/Domestic Government and Public Authorities / Public Utilities', value: 'Local/Domestic Government and Public Authorities / Public Utilities' },
                    { key: 'Foreign Government and Public Authorities [i.e., other Government- Regulated Entities, Consulates, Embassies, Foreign Ministries/Mission, Honorary Consul and Sovereign Wealth Funds]', value: 'Foreign Government and Public Authorities [i.e., other Government- Regulated Entities, Consulates, Embassies, Foreign Ministries/Mission, Honorary Consul and Sovereign Wealth Funds]' },
                    { key: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits [including Educational Institutions, Research Institutes, Churches, Professional Associations and Lobby Groups]', value: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits [including Educational Institutions, Research Institutes, Churches, Professional Associations and Lobby Groups]' },
                    { key: 'Central Banks, National Monetary Authorities and Supranational Organizations', value: 'Central Banks, National Monetary Authorities and Supranational Organizations' },
                    { key: 'Estates', value: 'Estates' },
                    { key: 'Personal Investment / Holding Companies or Sole Proprietorships', value: 'Personal Investment / Holding Companies or Sole Proprietorships' },
                    { key: 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)', value: 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)' },
                    { key: 'Wells Fargo & Co. Affiliates and Subsidiaries', value: 'Wells Fargo & Co. Affiliates and Subsidiaries' }
                ],
                // relation: [
                //     {
                //         action: "VISIBLE",
                //         //connective: "OR",
                //         when: [
                //             {
                //                 id: "Status__c",
                //                 value: "Draft",
                //                 operator: "!=="
                //             }
                //         ]
                //     },
                //     {
                //         action: 'ENABLE',
                //         connective: 'AND',
                //         when: [
                //             {
                //                 id: 'User_Role',
                //                 value: 'Facilitator'
                //             },
                //             {
                //                 id: 'User_Role',
                //                 value: 'Facilitator Manager'
                //             }
                //         ]
                //     },
                //     {
                //         action: 'REQUIRED',
                //         //connective: 'OR',
                //         when: [
                //             {
                //                 id: "Status__c",
                //                 value: "Draft",
                //                 operator: "!=="
                //             }
                //         ]
                //     }

                // ]
            }),
            new DropdownQuestion({
                section: 'DocumentMatrix',
                key: 'CDD_Sub_Type__c',
                label: 'CDD Sub Type',
                defaultOption: '',
                order: order + 20,
                parent: {
                    key: 'CDD_Type__c',
                    value: ''
                },
                mandatory: true,
                options: [
                    // { key: '', value: '--None--' },
                    { key: 'Operating', value: 'Operating', parentKey: 'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)' },
                    { key: 'Unregistered Investment Advisor', value: 'Unregistered Investment Advisor', parentKey: 'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)' },
                    { key: 'Fund', value: 'Fund', parentKey: 'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)' },
                    { key: 'Fund', value: 'Fund', parentKey: 'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)' },
                    { key: 'Operating Limited Partnership or LLP', value: 'Operating Limited Partnership or LLP', parentKey: 'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)' },
                    { key: 'Unregistered Investment Manager / Advisor', value: 'Unregistered Investment Manager / Advisor', parentKey: 'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)' },
                    { key: 'Companies on Approved Exchange', value: 'Companies on Approved Exchange', parentKey: 'Company Listed on Approved Exchange and Subsidiaries' },
                    { key: 'Subsidiary of Listed Parent (>50% Ownership)', value: 'Subsidiary of Listed Parent (>50% Ownership)', parentKey: 'Company Listed on Approved Exchange and Subsidiaries' },
                    { key: 'Non-US Regulated Credit or Financial Institutions: Banks', value: 'Non-US Regulated Credit or Financial Institutions: Banks', parentKey: 'Non-US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisors, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]' },
                    { key: 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds', value: 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds', parentKey: 'Non-US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisors, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]' },
                    { key: 'ERISA', value: 'ERISA', parentKey: 'Pension Plans' },
                    { key: 'Non ERISA', value: 'Non ERISA', parentKey: 'Pension Plans' },
                    { key: 'State, Municipal, or Government Pension Plan', value: 'State, Municipal, or Government Pension Plan', parentKey: 'Pension Plans' },
                    { key: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds', value: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds', parentKey: 'Foreign Government and Public Authorities [i.e., other Government- Regulated Entities, Consulates, Embassies, Foreign Ministries/Mission, Honorary Consul and Sovereign Wealth Funds]' },
                    { key: 'Foreign Government and Public Authorities: Consulates', value: 'Foreign Government and Public Authorities: Consulates', parentKey: 'Foreign Government and Public Authorities [i.e., other Government- Regulated Entities, Consulates, Embassies, Foreign Ministries/Mission, Honorary Consul and Sovereign Wealth Funds]' },
                    { key: 'Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts', value: 'Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts', parentKey: 'Foreign Government and Public Authorities [i.e., other Government- Regulated Entities, Consulates, Embassies, Foreign Ministries/Mission, Honorary Consul and Sovereign Wealth Funds]' },
                    { key: 'Central Bank', value: 'Central Bank', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations' },
                    { key: 'National Monetary authority', value: 'National Monetary authority', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations' },
                    { key: 'Supranational Organization', value: 'Supranational Organization', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations' },
                    { key: 'Personal Investment or Holding Co.', value: 'Personal Investment or Holding Co.', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships' },
                    { key: 'Sole Proprietorship', value: 'Sole Proprietorship', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Individuals, Joint Account holders, IRAs, Custodian' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'General Partnerships' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Trusts with Regulated Trustees' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Trusts with Unregulated Trustees' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'US Regulated Credit or Financial Institutions [including Broker-Dealers, Banks, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds]. US Regulated Credit or Financial Institutions' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Local/Domestic Government and Public Authorities / Public Utilities' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits [including Educational Institutions, Research Institutes, Churches, Professional Associations and Lobby Groups]' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Estates' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)' },
                    { key: '--N/A--', value: '--N/A--', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries' },
                ],
                // relation: [
                //     {
                //         action: "VISIBLE",
                //         connective: "OR",
                //         when: [
                //             {
                //                 id: "CDD_Type__c",
                //                 value: "",
                //                 operator: "!=="
                //             }
                //         ]
                //     },
                //     {
                //         action: 'ENABLE',
                //         connective: 'AND',
                //         when: [
                //             {
                //                 id: 'User_Role',
                //                 value: 'Facilitator'
                //             },
                //             {
                //                 id: 'User_Role',
                //                 value: 'Facilitator Manager'
                //             }
                //         ]
                //     }//,
                //     // {
                //     //     action: 'REQUIRED',
                //     //     connective: 'OR',
                //     //     when: [
                //     //         {
                //     //             id: "CDD_Type__c",
                //     //             value: "",
                //     //             operator: "!=="
                //     //         }
                //     //     ]
                //     // }

                // ]
            }),
            new DropdownQuestion({
                section: 'DocumentMatrix',
                key: 'CDD_Type_And_Sub_Type__c',
                label: 'CDD Type And Sub Type',
                defaultOption: '',
                displayNone: true,
                order: order + 20,
                parent: {
                    key: 'CDD_Type__c',
                    value: ''
                },
                options: [
                    { key: 'Individuals, Joint Account holders, IRAs, Custodian', value: 'Individuals, Joint Account holders, IRAs, Custodian' },
                    { key: 'Operating_Operating', value: 'Operating_Operating' },
                    { key: 'Operating_Unregistered Investment Advisor', value: 'Operating_Unregistered Investment Advisor' },
                    { key: 'Operating_Fund', value: 'Operating_Fund' },
                    { key: 'General Partnerships', value: 'General Partnerships' },
                    { key: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP', value: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP' },
                    { key: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', value: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor' },
                    { key: 'Limited Partnerships or Limited Liability Partnerships_Fund', value: 'Limited Partnerships or Limited Liability Partnerships_Fund' },
                    { key: 'Trusts with Regulated Trustees', value: 'Trusts with Regulated Trustees' },
                    { key: 'Trusts with Unregulated Trustees', value: 'Trusts with Unregulated Trustees' },
                    { key: 'US Regulated Credit or Financial Institutions', value: 'US Regulated Credit or Financial Institutions' },
                    { key: 'Non-US Regulated Credit or Financial Institutions: Banks', value: 'Non-US Regulated Credit or Financial Institutions: Banks' },
                    { key: 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds', value: 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds' },
                    { key: 'Company Listed on Approved Exchange and Subsidiaries_Companies on Approved Exchange', value: 'Company Listed on Approved Exchange and Subsidiaries_Companies on Approved Exchange' },
                    { key: 'Company Listed on Approved Exchange and Subsidiaries_Subsidiary of Listed Parent (>50% Ownership)', value: 'Company Listed on Approved Exchange and Subsidiaries_Subsidiary of Listed Parent (>50% Ownership)' },
                    { key: 'Pension Plans_ERISA', value: 'Pension Plans_ERISA' },
                    { key: 'Pension Plans_Non ERISA', value: 'Pension Plans_Non ERISA' },
                    { key: 'Pension Plans_State, Municipal, or Government Pension Plan', value: 'Pension Plans_State, Municipal, or Government Pension Plan' },
                    { key: 'Local/Domestic Government and Public Authorities / Public Utilities', value: 'Local/Domestic Government and Public Authorities / Public Utilities' },
                    { key: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds', value: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds' },
                    { key: 'Foreign Government and Public Authorities: Consulates', value: 'Foreign Government and Public Authorities: Consulates' },
                    { key: 'Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts', value: 'Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts' },
                    { key: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits', value: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits' },
                    { key: 'Central Banks, National Monetary Authorities and Supranational Organizations_Central Bank', value: 'Central Banks, National Monetary Authorities and Supranational Organizations_Central Bank' },
                    { key: 'Central Banks, National Monetary Authorities and Supranational Organizations_National Monetary authority', value: 'Central Banks, National Monetary Authorities and Supranational Organizations_National Monetary authority' },
                    { key: 'Central Banks, National Monetary Authorities and Supranational Organizations_Supranational Organization', value: 'Central Banks, National Monetary Authorities and Supranational Organizations_Supranational Organization' },
                    { key: 'Estates', value: 'Estates' },
                    { key: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', value: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.' },
                    { key: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', value: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship' },
                    { key: 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)', value: 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)' },
                    { key: 'Wells Fargo & Co. Affiliates and Subsidiaries', value: 'Wells Fargo & Co. Affiliates and Subsidiaries' }
                ]
            }),
            this.buildEmptyField(order + 30),
            this.buildEmptyField(order + 35),
            new ListQuestion({
                section: 'DocumentMatrix',
                key: 'Matrix_Document__c',
                label: 'AML Requirement',
                defaultOption: 'None selected',
                mandatory: true,
                order: order + 40,
                parent: {
                    key: 'CDD_Type_And_Sub_Type__c',
                    value: ''
                },
                options: [
                    { key: '• Proof of verification for individual with authority to open the account - driver license, passport, any govt issued ID', value: '• Proof of verification for individual with authority to open the account - driver license, passport, any govt issued ID', parentKey: 'Individuals, Joint Account holders, IRAs, Custodian', disableOption: true },
                    { key: '• Certificate of incorporation / Certificate of formation / Certificate of good standing / Articles of organization or equivalent evidencing filing', value: '• Certificate of incorporation / Certificate of formation / Certificate of good standing / Articles of organization or equivalent evidencing filing', parentKey: 'Operating_Operating', disableOption: true },
                    { key: '• Memorandum and Articles of Incorporation / Operating agreement / LLC agreement or equivalent evidencing filing', value: '• Memorandum and Articles of Incorporation / Operating agreement / LLC agreement or equivalent evidencing filing', parentKey: 'Operating_Operating', disableOption: true },
                    { key: '• Individual with significant control to direct the Legal Entity', value: '• Individual with significant control to direct the Legal Entity', parentKey: 'Operating_Operating', disableOption: true },
                    { key: '• Corporate resolutions / Letter of authority / Certificate of incumbency', value: '• Corporate resolutions / Letter of authority / Certificate of incumbency', parentKey: 'Operating_Operating', disableOption: true },
                    { key: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Operating_Operating', disableOption: true },

                    { key: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Operating_Operating', disableOption: true },
                    { key: '• Certificate of incorporation / Certificate of formation / Certificate of good standing / Articles of organization or equivalent evidencing filing', value: '• Certificate of incorporation / Certificate of formation / Certificate of good standing / Articles of organization or equivalent evidencing filing', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Memorandum and Articles of Incorporation / Operating agreement / LLC agreement or equivalent evidencing filing', value: '• Memorandum and Articles of Incorporation / Operating agreement / LLC agreement or equivalent evidencing filing', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Individual with significant control to direct the Legal Entity', value: '• Individual with significant control to direct the Legal Entity', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Corporate resolutions / Letter of authority / Certificate of incumbency', value: '• Corporate resolutions / Letter of authority / Certificate of incumbency', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Representation & warranties letter', value: '• Representation & warranties letter', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Operating_Unregistered Investment Advisor', disableOption: true },
                    { key: '• Offering Memo / Prospectus ( Required for Prime Services Funds)', value: '• Offering Memo / Prospectus ( Required for Prime Services Funds)', parentKey: 'Operating_Fund', disableOption: true },
                    { key: '• Formation documents as required by appropriate entity type( Required for Prime Services Funds)', value: '• Formation documents as required by appropriate entity type( Required for Prime Services Funds)', parentKey: 'Operating_Fund', disableOption: true },
                    { key: '• If fund is a master and has feeders, also ID them according to customer type ( Required for Prime Services Funds)', value: '• If fund is a master and has feeders, also ID them according to customer type ( Required for Prime Services Funds)', parentKey: 'Operating_Fund', disableOption: true },
                    { key: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'General Partnerships', disableOption: true },
                    { key: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'General Partnerships', disableOption: true },
                    { key: '• Proof of verification for individual with authority to open the account - Driver\'s license (US person only), Passport, or other Govt Issued ID', value: '• Proof of verification for individual with authority to open the account - Driver\'s license (US person only), Passport, or other Govt Issued ID', parentKey: 'General Partnerships', disableOption: true },
                    { key: '• Partnership Agreement or equivalent official verification of the existence of the General Partnership', value: '• Partnership Agreement or equivalent official verification of the existence of the General Partnership', parentKey: 'General Partnerships', disableOption: true },
                    { key: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP', disableOption: true },
                    { key: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP', disableOption: true },
                    { key: '• Proof of verification for individual with authority to open the account- Driver\'s license (US person only), Passport, or other Govt Issued ID for every General Partner', value: '• Proof of verification for individual with authority to open the account- Driver\'s license (US person only), Passport, or other Govt Issued ID for every General Partner', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP', disableOption: true },
                    { key: '• Limited Partnership Agreement', value: '• Limited Partnership Agreement', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP', disableOption: true },
                    { key: '• Certificate of Limited Partnership bearing official stamp or seal evidencing filing', value: '• Certificate of Limited Partnership bearing official stamp or seal evidencing filing', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Operating Limited Partnership or LLP', disableOption: true },
                    { key: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Legal Ownership - Shareholders or Members current within one-year (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', disableOption: true },
                    { key: '• Representation & warranties letter', value: '• Representation & warranties letter', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', disableOption: true },
                    { key: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', value: '• Beneficial ownership form (**down to 25% for Domestic Entities, 10% for Foreign or High Risk Entities)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', disableOption: true },
                    { key: '• Proof of verification for individual with authority to open the account- Driver\'s license (US person only), Passport, or other Govt Issued ID for every General Partner', value: '• Proof of verification for individual with authority to open the account- Driver\'s license (US person only), Passport, or other Govt Issued ID for every General Partner', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', disableOption: true },
                    { key: '• Limited Partnership Agreement', value: '• Limited Partnership Agreement', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', disableOption: true },
                    { key: '• Certificate of Limited Partnership bearing official stamp or seal evidencing filing', value: '• Certificate of Limited Partnership bearing official stamp or seal evidencing filing', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Unregistered Investment Manager / Advisor', disableOption: true },
                    { key: '• Offering Memo / Prospectus ( Required for Prime Services Funds)', value: '• Offering Memo / Prospectus ( Required for Prime Services Funds)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Fund', disableOption: true },
                    { key: '• Formation documents as required by appropriate entity type( Required for Prime Services Funds)', value: '• Formation documents as required by appropriate entity type( Required for Prime Services Funds)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Fund', disableOption: true },
                    { key: '• If fund is a master and has feeders, also ID them according to customer type ( Required for Prime Services Funds)', value: '• If fund is a master and has feeders, also ID them according to customer type ( Required for Prime Services Funds)', parentKey: 'Limited Partnerships or Limited Liability Partnerships_Fund', disableOption: true },
                    { key: '• Trust Agreement - OR - Trustee Certification, Declaration Page, and Signature page', value: '• Trust Agreement - OR - Trustee Certification, Declaration Page, and Signature page', parentKey: 'Trusts with Regulated Trustees', disableOption: true },
                    { key: '• Identify and Verify Settlors, Protectors, and Grantors as per Customer Type', value: '• Identify and Verify Settlors, Protectors, and Grantors as per Customer Type', parentKey: 'Trusts with Regulated Trustees', disableOption: true },
                    { key: '• Proof of regulation for trustee', value: '• Proof of regulation for trustee', parentKey: 'Trusts with Regulated Trustees', disableOption: true },
                    { key: '• Trust Agreement - OR - Trustee Certification, Declaration Page, and Signature page', value: '• Trust Agreement - OR - Trustee Certification, Declaration Page, and Signature page', parentKey: 'Trusts with Unregulated Trustees', disableOption: true },
                    { key: '• Identify and Verify Settlors, Protectors, and Grantors as per Customer Type', value: '• Identify and Verify Settlors, Protectors, and Grantors as per Customer Type', parentKey: 'Trusts with Unregulated Trustees', disableOption: true },
                    { key: '• Proof of regulation (e.g. printout from regulator\'s website)', value: '• Proof of regulation (e.g. printout from regulator\'s website)', parentKey: 'US Regulated Credit or Financial Institutions', disableOption: true },
                    { key: '• Proof of regulation (e.g. printout from regulator\'s website)', value: '• Proof of regulation (e.g. printout from regulator\'s website)', parentKey: 'Non-US Regulated Credit or Financial Institutions: Banks', disableOption: true },
                    { key: '• Wolfsberg Questionnaire or AMLQ', value: '• Wolfsberg Questionnaire or AMLQ', parentKey: 'Non-US Regulated Credit or Financial Institutions: Banks', disableOption: true },
                    { key: '• Full Legal Name of Key Management', value: '• Full Legal Name of Key Management', parentKey: 'Non-US Regulated Credit or Financial Institutions: Banks', disableOption: true },
                    { key: '• Full Legal Name of Owners that Control >10%', value: '• Full Legal Name of Owners that Control >10%', parentKey: 'Non-US Regulated Credit or Financial Institutions: Banks', disableOption: true },
                    { key: '• USA PATRIOT Act Certification', value: '• USA PATRIOT Act Certification', parentKey: 'Non-US Regulated Credit or Financial Institutions: Banks', disableOption: true },
                    { key: '• Proof of regulation (e.g. printout from regulator\'s website)', value: '• Proof of regulation (e.g. printout from regulator\'s website)', parentKey: 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds', disableOption: true },
                    { key: '• Full Legal Name of Key Management', value: '• Full Legal Name of Key Management', parentKey: '11', disableOption: true },
                    { key: '• Full Legal Name of Owners that Control >10%', value: '• Full Legal Name of Owners that Control >10%', parentKey: 'Non-US Regulated Credit or Financial Institutions: including Broker-Dealers, Investment Advisers, Trust Companies, Credit Unions, Insurance Companies and Mutual Funds', disableOption: true },
                    { key: '• Exchange printout', value: '• Exchange printout', parentKey: 'Company Listed on Approved Exchange and Subsidiaries_Companies on Approved Exchange', disableOption: true },
                    { key: '• S1 Form (if going public and will be listed on Approved Exchange)', value: '• S1 Form (if going public and will be listed on Approved Exchange)', parentKey: 'Company Listed on Approved Exchange and Subsidiaries_Companies on Approved Exchange', disableOption: true },
                    { key: '• Exchange printout', value: '• Exchange printout', parentKey: 'Company Listed on Approved Exchange and Subsidiaries_Subsidiary of Listed Parent (>50% Ownership)', disableOption: true },
                    { key: '• SEC Filing (10k, Exhibit 21) or other official document demonstrating ownership by the parent', value: '• SEC Filing (10k, Exhibit 21) or other official document demonstrating ownership by the parent', parentKey: 'Company Listed on Approved Exchange and Subsidiaries_Subsidiary of Listed Parent (>50% Ownership)', disableOption: true },
                    { key: '• Verification of ERISA (one of the following is required)', value: '• Verification of ERISA (one of the following is required)', parentKey: 'Pension Plans_ERISA', disableOption: true },
                    { key: ' a) IRS form 5500 or', value: ' a) IRS form 5500 or', parentKey: 'Pension Plans_ERISA', disableOption: true },
                    { key: ' b) Copy of plan', value: ' b) Copy of plan', parentKey: 'Pension Plans_ERISA', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Pension Plans_Non ERISA', disableOption: true },
                    { key: '• Printout from website demonstrating', value: '• Printout from website demonstrating', parentKey: 'Pension Plans_State, Municipal, or Government Pension Plan', disableOption: true },
                    { key: ' a) Law authorizing plan', value: ' a) Law authorizing plan', parentKey: 'Pension Plans_State, Municipal, or Government Pension Plan', disableOption: true },
                    { key: ' b) Description of beneficiary class', value: ' b) Description of beneficiary class', parentKey: 'Pension Plans_State, Municipal, or Government Pension Plan', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Pension Plans_State, Municipal, or Government Pension Plan', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Local/Domestic Government and Public Authorities / Public Utilities', disableOption: true },
                    { key: '• Printout from official website or formation documents', value: '• Printout from official website or formation documents', parentKey: 'Local/Domestic Government and Public Authorities / Public Utilities', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds', disableOption: true },
                    { key: '• Printout from official website or formation documents', value: '• Printout from official website or formation documents', parentKey: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds', disableOption: true },
                    { key: '• Proof of regulation (e.g. printout from regulator\'s website)', value: '• Proof of regulation (e.g. printout from regulator\'s website)', parentKey: 'Foreign Government and Public Authorities: Other Government - Regulated Entities, Sovereign Wealth Funds', disableOption: true },
                    { key: '• Letter from the U.S. Department of State -OR- Screen print from the U.S. Department of State website confirming foreign consulate established in U.S.', value: '• Letter from the U.S. Department of State -OR- Screen print from the U.S. Department of State website confirming foreign consulate established in U.S.', parentKey: 'Foreign Government and Public Authorities: Consulates', disableOption: true },
                    { key: '• Letter signed by the Ambassador, minister, or other foreign official', value: '• Letter signed by the Ambassador, minister, or other foreign official', parentKey: 'Foreign Government and Public Authorities: Agencies, Embassies, Foreign Ministries/Mission, Honorary Consuls, Trade Offices, and Trusts', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits', disableOption: true },
                    { key: '• Guidestar form 990', value: '• Guidestar form 990', parentKey: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits', disableOption: true },
                    { key: '• Official website printout', value: '• Official website printout', parentKey: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits', disableOption: true },
                    { key: '• Full legal name of Directors, Trustees, and/or Senior Management', value: '• Full legal name of Directors, Trustees, and/or Senior Management', parentKey: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits', disableOption: true },
                    { key: '• Formation documents as required by appropriate entity type', value: '• Formation documents as required by appropriate entity type', parentKey: 'Charities, Foundations, Non-Profit Organizations (NPO), Non-Governmental Organizations (NGO), Other Incorporated Non-Profits', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations_Central Bank', disableOption: true },
                    { key: '• Printout from independent website (e.g. IMF or Bankers Almanac)', value: '• Printout from independent website (e.g. IMF or Bankers Almanac)', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations_Central Bank', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations_National Monetary authority', disableOption: true },
                    { key: '• Official website printout', value: '• Official website printout', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations_National Monetary authority', disableOption: true },
                    { key: '• List of Authorized persons/signatories and titles', value: '• List of Authorized persons/signatories and titles', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations_Supranational Organization', disableOption: true },
                    { key: '• Constitutional document or By laws', value: '• Constitutional document or By laws', parentKey: 'Central Banks, National Monetary Authorities and Supranational Organizations_Supranational Organization', disableOption: true },
                    { key: '• Will -OR- Letter of Administration', value: '• Will -OR- Letter of Administration', parentKey: 'Estates', disableOption: true },
                    { key: '• Formation documents as required by appropriate entity type', value: '• Formation documents as required by appropriate entity type', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', disableOption: true },
                    { key: '• Proof of verification for all Beneficial Owners- Driver\'s license (US person only), Passport, or other Govt Issued ID', value: '• Proof of verification for all Beneficial Owners- Driver\'s license (US person only), Passport, or other Govt Issued ID', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', disableOption: true },
                    { key: '• Beneficial ownership form ( Must account for 100% Ownership)', value: '• Beneficial ownership form ( Must account for 100% Ownership)', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', disableOption: true },
                    { key: '• Full Legal Name of Shareholders, Members or LPs', value: '• Full Legal Name of Shareholders, Members or LPs', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', disableOption: true },
                    { key: '• Documentation of Source of Wealth ( For Clients with Risk Rating = 4 OR 5)', value: '• Documentation of Source of Wealth ( For Clients with Risk Rating = 4 OR 5)', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', disableOption: true },
                    { key: '• Full Legal Name of Key Management', value: '• Full Legal Name of Key Management', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Personal Investment or Holding Co.', disableOption: true },
                    { key: '• Government-issued', value: '• Government-issued', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', disableOption: true },
                    { key: ' a) Business license, or', value: ' a) Business license, or', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', disableOption: true },
                    { key: ' b) Trade Name Certificate, or', value: ' b) Trade Name Certificate, or', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', disableOption: true },
                    { key: ' c) DBA license', value: ' c) DBA license', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', disableOption: true },
                    { key: '• Proof of verification - Driver\'s license (US person only), Passport, or other Govt Issued ID', value: '• Proof of verification - Driver\'s license (US person only), Passport, or other Govt Issued ID', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', disableOption: true },
                    { key: '• Documentation of Source of Wealth', value: '• Documentation of Source of Wealth', parentKey: 'Personal Investment / Holding Companies or Sole Proprietorships_Sole Proprietorship', disableOption: true },
                    { key: '• Formation documents as required by appropriate entity type', value: '• Formation documents as required by appropriate entity type', parentKey: 'Wells Fargo & Co. Special Purpose Vehicles (SPVs) and Special Purpose Entities (SPEs)', disableOption: true },
                    { key: '• Email from WFC [Legal and Compliance], external counsel, or Corp Secretary including:', value: '• Email from WFC [Legal and Compliance], external counsel, or Corp Secretary including:', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true },
                    { key: ' a) Full Legal Name, Registered Address, TIN', value: ' a) Full Legal Name, Registered Address, TIN', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true },
                    { key: ' b) Subsidiary/Affiliate Confirmation', value: ' b) Subsidiary/Affiliate Confirmation', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true },
                    { key: ' c) Ownership structure', value: ' c) Ownership structure', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true },
                    { key: ' d) Nature of business', value: ' d) Nature of business', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true },
                    { key: ' e) Regulated / Non-Regulated', value: ' e) Regulated / Non-Regulated', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true },
                    { key: ' f) Confirmation that additional relevant information will be provided upon request', value: ' f) Confirmation that additional relevant information will be provided upon request', parentKey: 'Wells Fargo & Co. Affiliates and Subsidiaries', disableOption: true }
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "CDD_Type_And_Sub_Type__c",
                                value: "",
                                operator: "!=="
                            },
                            {
                                id: "CDD_Type_And_Sub_Type__c",
                                value: null,
                                operator: "!=="
                            }
                        ]
                    }
                ]
            })
            //Document Matrix fields ends
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildFacilitatorFields(order: number = 5500, facilitatorFilter: string = 'Facilitator, Facilitator Manager'): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            //Facilitator fields starts
            new LabelQuestion({
                section: 'FacilitatorDetails',
                rowGroupBy: 'LEGAL',
                col: 12,
                key: 'Facilitator_5500',
                label: 'Facilitator Section',
                value: '',
                order: order,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            //this.buildPrimaryFacilitator(5501),
            new AutoCompleteQuestion({
                section: 'FacilitatorDetails',
                key: 'Primary_Facilitator__c',
                label: 'Primary Facilitator',
                order: order + 1,
                mandatory: true,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: facilitatorFilter,
                relation: [
                    {
                        action: "VISIBLE",
                        //connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'DISABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator'
                            },
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator Manager'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        //connective: 'OR',
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }

                ]
            }),

            new MultiselectQuestion({
                section: 'FacilitatorDetails',
                key: 'Document_Status__c',
                label: 'Docs Complete',
                defaultOption: '',
                mandatory: false,
                order: order + 300,
                options: [
                    { key: 'AML Doc Status', value: 'AML Doc Status' },
                    { key: 'Credit Doc Status', value: 'Credit Doc Status' },
                    { key: 'Tax Doc Status', value: 'Tax Doc Status' },
                    { key: 'Other Docs Status', value: 'Other Docs Status' }

                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'DISABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator'
                            },
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator Manager'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }

                ]
            }),

            new AutoCompleteQuestion({
                section: 'FacilitatorDetails',
                key: 'Secondary_Facilitator__c',
                label: 'Secondary Facilitator',
                order: order + 400,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: facilitatorFilter,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'DISABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator'
                            },
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator Manager'
                            }
                        ]
                    }
                ]
            }),

            this.buildEmptyField(order + 400),
            this.buildEmptyField(order + 500),
            this.buildEmptyField(order + 600),
            new TextboxQuestion({
                section: 'FacilitatorDetails',
                key: 'WCIS_ID__c',
                label: 'WCIS ID',
                order: order + 100,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'DISABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator'
                            },
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator Manager'
                            }
                        ]
                    },
                ]
            }),
            new TextboxQuestion({
                section: 'FacilitatorDetails',
                key: 'CSTN_ID__c',
                label: 'CSTN ID',
                order: order + 200,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'DISABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator'
                            },
                            {
                                id: 'User_Role',
                                operator: "!==",
                                value: 'Facilitator Manager'
                            }
                        ]
                    },
                ]
            }),
            // this.buildEmptyField(6400),
            // this.buildEmptyField(6500),
            //Facilitator Section Ends
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildNonCashFacilitatorFields(order: number = 5500, facilitatorFilter: string = 'DCOT'): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            //Facilitator fields starts
            new LabelQuestion({
                rowGroupBy: 'LEGAL',
                col: 12,
                key: 'Facilitator_5500',
                label: 'Facilitator Section',
                value: '',
                order: order,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            //this.buildPrimaryFacilitator(5501),
            new AutoCompleteQuestion({
                section: 'FacilitatorDetails',
                key: 'Primary_Facilitator__c',
                label: 'Primary Facilitator',
                order: order + 1,
                mandatory: true,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: facilitatorFilter,
                relation: [
                    {
                        action: "VISIBLE",
                        //connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'DCOT'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        //connective: 'OR',
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }

                ]
            }),

            this.buildEmptyField(order + 300),

            new AutoCompleteQuestion({
                section: 'FacilitatorDetails',
                key: 'Secondary_Facilitator__c',
                label: 'Secondary Facilitator',
                order: order + 400,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: facilitatorFilter,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'DCOT'
                            }
                        ]
                    },
                ]
            }),

            this.buildEmptyField(order + 400),
            this.buildEmptyField(order + 500),
            this.buildEmptyField(order + 600),
            this.buildEmptyField(order + 200),

            new TextboxQuestion({
                section: 'FacilitatorDetails',
                key: 'CSTN_ID__c',
                label: 'CSTN ID',
                order: order + 100,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'DCOT'
                            }
                        ]
                    }
                ]
            }),
            // this.buildEmptyField(6400),
            // this.buildEmptyField(6500),
            //Facilitator Section Ends
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildAMLFields(order: number = 6599): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            //AML Section Starts
            new LabelQuestion({
                section: 'AMLDetails',
                rowGroupBy: 'CALLBACK',
                col: 12,
                key: 'callback_' + order,
                label: 'AML Section',
                value: '',
                order: order,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                section: 'AMLDetails',
                key: 'AML_Status__c',
                label: 'AML Status',
                defaultOption: '',
                order: order,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Ready In CSTN/CRMS', value: 'Ready In CSTN/CRMS' },
                    { key: 'EDD Required', value: 'EDD Required' },
                    { key: 'Approved in CSTN/CRMS', value: 'Approved in CSTN/CRMS' },
                    { key: 'Memo in Progress', value: 'Memo in Progress' },
                    { key: 'Memo Pending RM Approval', value: 'Memo Pending RM Approval' },
                    { key: 'Memo Pending WFCRC Approval', value: 'Memo Pending WFCRC Approval' },
                    { key: 'CSTN down - AML rejected', value: 'CSTN down - AML rejected' },
                    { key: 'CSTN down - AML Approved', value: 'CSTN down - AML Approved' },
                    { key: 'Rejected in CSTN/CRMS', value: 'Rejected in CSTN/CRMS' }
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),

            new AutoCompleteQuestion({
                section: 'AMLDetails',
                key: 'AMLCaseManager__c',
                label: 'AML Case Manager',
                order: order + 200,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'AML KYC',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'AML KYC'
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                section: 'AMLDetails',
                key: 'CIP_CDD_Verified__c',
                label: 'CIP/CDD Verified',
                defaultOption: '',
                order: order + 300,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'AMLDetails',
                key: 'EDD_Required__c',
                label: 'EDD Required',
                defaultOption: '',
                order: order + 400,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                section: 'AMLDetails',
                key: 'High_Risk__c',
                label: 'High Risk',
                defaultOption: '',
                order: order + 500,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                section: 'AMLDetails',
                key: 'Risk_Rating__c',
                label: 'Risk Rating',
                defaultOption: '',
                order: order + 600,
                options: [
                    { key: '', value: '--None--' },
                    { key: '1', value: '1' },
                    { key: '2', value: '2' },
                    { key: '3', value: '3' },
                    { key: '4', value: '4' },
                    { key: '5', value: '5' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),

            new AutoCompleteQuestion({
                section: 'AMLDetails',
                key: 'EDDCaseManager__c',
                label: 'EDD Case Manager',
                order: order + 700,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'AML EDD',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "EDD_Required__c",
                                value: "Yes",
                                operator: "==="

                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'AML KYC'
                            }
                        ]
                    }
                ]
            }),
            //AML Section Ends
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildFXAMLFields(order: number = 6599): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            //AML Section Starts
            new LabelQuestion({
                rowGroupBy: 'CALLBACK',
                col: 12,
                key: 'callback_' + order,
                label: 'AML Section',
                value: '',
                order: order,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                key: 'AML_Status__c',
                label: 'AML Status',
                defaultOption: '',
                order: order,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Ready In CSTN/CRMS', value: 'Ready In CSTN/CRMS' },
                    { key: 'EDD Required', value: 'EDD Required' },
                    { key: 'Approved in CSTN/CRMS', value: 'Approved in CSTN/CRMS' },
                    { key: 'Memo in Progress', value: 'Memo in Progress' },
                    { key: 'Memo Pending RM Approval', value: 'Memo Pending RM Approval' },
                    { key: 'Memo Pending WFCRC Approval', value: 'Memo Pending WFCRC Approval' },
                    { key: 'CSTN down - AML rejected', value: 'CSTN down - AML rejected' },
                    { key: 'CSTN down - AML Approved', value: 'CSTN down - AML Approved' },
                    { key: 'Rejected in CSTN/CRMS', value: 'Rejected in CSTN/CRMS' }
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),

            new AutoCompleteQuestion({
                key: 'AMLCaseManager__c',
                label: 'AML Case Manager',
                order: order + 200,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'AML KYC',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'AML KYC'
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                key: 'CIP_CDD_Verified__c',
                label: 'CIP/CDD Verified',
                defaultOption: '',
                order: order + 300,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                key: 'EDD_Required__c',
                label: 'EDD Required',
                defaultOption: '',
                order: order + 400,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                key: 'High_Risk__c',
                label: 'High Risk',
                defaultOption: '',
                order: order + 500,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                key: 'Risk_Rating__c',
                label: 'Risk Rating',
                defaultOption: '',
                order: order + 600,
                options: [
                    { key: '', value: '--None--' },
                    { key: '1', value: '1' },
                    { key: '2', value: '2' },
                    { key: '3', value: '3' },
                    { key: '4', value: '4' },
                    { key: '5', value: '5' },
                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),

            new AutoCompleteQuestion({
                key: 'EDDCaseManager__c',
                label: 'EDD Case Manager',
                order: order + 700,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'AML EDD',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            },
                            {
                                id: "EDD_Required__c",
                                value: "Yes",
                                operator: "==="

                            },
                            {
                                id: "Is_Calypso_V12_Required__c",
                                value: "Yes",
                                operator: "==="
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'AML KYC'
                            }
                        ]
                    }
                ]
            }),
            //AML Section Ends
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildFXOLFields() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            //AML Section Starts
            new LabelQuestion({
                rowGroupBy: 'CALLBACK',
                col: 12,
                key: 'callback_' + 7900,
                label: 'FXOL Section',
                value: '',
                order: 7900,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'FXOL',
                key: 'FXOL_Setup_Status__c',
                label: 'FXOL Setup Status',
                defaultOption: '',
                order: 7910,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Ready for Implementation', value: 'Ready for Implementation' },
                    { key: 'Pending Implementation', value: 'Pending Implementation' },
                    { key: 'Implementation Complete – Assigned to eFX Sales', value: 'Implementation Complete – Assigned to eFX Sales' },
                    { key: 'Training Scheduled', value: 'Training Scheduled' },
                    { key: 'FXOL Training Complete', value: 'FXOL Training Complete' },
                    { key: 'Training Not Required', value: 'Training Not Required' },
                    { key: 'FXOL Rejected', value: 'FXOL Rejected' },

                ],
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            new DatePickerQuestion({
                section: 'FXOL',
                key: 'eFX_Sales_Specialist_assigned_date__c',
                label: 'eFX Sales Specialist assigned date',
                order: 7920,
                disabled: true,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ],
                mandatory: true
            }),
            this.buildEmptyField(7930),
            this.buildEmptyField(7935),
            new AutoCompleteQuestion({
                section: 'FXOL',
                key: 'Assigned_eFX_Service_Specialist__r',
                label: 'Assigned eFX Service Specialist',
                order: 7940,
                value: ' ',
                api: 'Lookup/users/',
                filterCriteria: 'FXOL',
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'FXOL'
                            },
                        ]
                    },
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            new DatePickerQuestion({
                section: 'FXOL',
                key: 'eFX_Service_Specialist_assigned_date__c',
                label: 'eFX Service Specialist assigned date',
                order: 7950,
                disabled: true,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ],
                mandatory: true
            }),
            this.buildEmptyField(7960),
            this.buildEmptyField(7965),
            new AutoCompleteQuestion({
                section: 'FXOL',
                key: 'Assigned_eFX_Sales_Specialist_for_Traini__r',
                label: 'Assigned eFX Sales Specialist for Training',
                order: 7970,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'FXOL',
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'FXOL'
                            },
                        ]
                    },
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ]
            }),
            new DatePickerQuestion({
                section: 'FXOL',
                key: 'Scheduled_Training_Date__c',
                label: 'Scheduled Training Date',
                order: 7980,
                disabled: true,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ],
                mandatory: true
            }),
            new DatePickerQuestion({
                section: 'FXOL',
                key: 'Training_Completion_Date__c',
                label: 'Training Completion Date',
                order: 7990,
                disabled: true,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "AND",
                        when: [
                            {
                                id: "Status__c",
                                value: "Draft",
                                operator: "!=="
                            }
                        ]
                    }
                ],
                mandatory: true
            }),
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildCallbackAndThirdPartyFields(): QuestionBase<any>[] {
        let callbackQuestions: QuestionBase<any>[] = [];
        callbackQuestions = [
            // callback Section starts
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                col: 12,
                key: 'Intermediary_Bank_Routing_Details_Visibility',
                label: 'Intermediary_Bank_Routing_Details_Visibility',
                value: 'No',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                col: 12,
                key: 'callback_8000',
                label: 'Callback and ThirdParty Section',
                value: '',
                order: 8000,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),

            new AutoCompleteQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_Analyst__r',
                label: 'Callback Analyst',
                order: 8001,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'Client Services',
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Client Services'
                            },
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [

                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - No Answer"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Technical Error"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback - Supervisory Principal Approved"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Possible Fraud"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Complete - Client Validated"
                            },


                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'Analyst_Performing_Callback_for_Prime__c',
                label: 'Analyst Performing Callback (for Prime)',
                order: 8001,
                mandatory: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_8100',
                label: 'Counterparty Contact That Provided The Wire Instructions',
                value: '',
                order: 8100,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_8100',
                label: '',
                value: '',
                order: 8100,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),

            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_Status__c',
                label: 'Callback Status',
                value: 'Callback Required',
                order: 8200,
                col: 6,
                mandatory: true,
                options: [
                    { key: 'Callback Required', value: 'Callback Required' },
                    { key: 'Callback Performed - No Answer', value: 'Callback Performed - No Answer' },
                    { key: 'Callback Complete - Client Validated', value: 'Callback Complete - Client Validated' },
                    { key: 'Callback Performed - Technical Error', value: 'Callback Performed - Technical Error' },
                    { key: 'Callback Performed - Possible Fraud', value: 'Callback Performed - Possible Fraud' },
                    { key: 'Callback - Supervisory Principal Approved', value: 'Callback - Supervisory Principal Approved' },
                    { key: 'Callback - Supervisory Principal Rejected', value: 'Callback - Supervisory Principal Rejected' },
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_Name1__c',
                label: 'Name 1',
                order: 8300,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            // new LabelQuestion({
            //     rowGroupBy: 'CALLBACK',
            //     key: 'callback_8300',
            //     label: '',
            //     value: '',
            //     order: 8300,
            //     col: 3,
            //     relation: [
            //         {
            //             action: 'VISIBLE',
            //             connective: 'AND',
            //             when: [
            //                 {
            //                     id: 'New_Wires__c',
            //                     value: 'Yes'
            //                 },
            //                 {
            //                     id: 'Is_Prime_Account__c',
            //                     value: 'Yes'
            //                 }
            //             ]
            //         }

            //     ]
            // }),

            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_Phone1__c',
                label: 'Phone 1',
                order: 8400,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            // new LabelQuestion({
            //     rowGroupBy: 'CALLBACK',
            //     key: 'callback_8400',
            //     label: '',
            //     value: '',
            //     order: 8400,
            //     col: 3,
            //     relation: [
            //         {
            //             action: 'VISIBLE',
            //             connective: 'AND',
            //             when: [
            //                 {
            //                     id: 'New_Wires__c',
            //                     value: 'Yes'
            //                 },
            //                 {
            //                     id: 'Is_Prime_Account__c',
            //                     value: 'Yes'
            //                 }
            //             ]
            //         }

            //     ]
            // }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1000',
                label: 'Beneficiary',
                value: '',
                order: 8500,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1001',
                label: 'Counterparty Contact For Callbacks',
                value: '',
                order: 8600,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_8600',
                label: '',
                value: '',
                order: 8600,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'beneficiary_ID_Type__c',
                label: 'Beneficiary Account Type',
                order: 8700,
                col: 6,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: '\"GENERAL LEDGER\" - Beneficiary\'s account with beneficiary bank- WFBNA only. \n \"UNSPECIFIED\" - used for other scenarios such as ABA instructions',

                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'DDA', value: 'DDA' },
                    { key: 'General Ledger', value: 'General Ledger' },
                    { key: 'UNSPECIFIED', value: 'UNSPECIFIED' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]


                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_for_CB_Name1__c',
                label: 'Name 1',
                order: 8800,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_8800',
                label: '',
                value: '',
                order: 8800,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_CB_Phone_1__c',
                label: 'Phone 1',
                order: 8900,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_8900',
                label: '',
                value: '',
                order: 8900,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'beneficiary_Name__c',
                label: 'Beneficiary Name',
                order: 9000,
                col: 6,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: 'Name on recipient account',

                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_CB_Name_2__c',
                label: 'Name 2',
                order: 9100,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_9100',
                label: '',
                value: '',
                order: 9100,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_CB_Phone_2__c',
                label: 'Phone 2',
                order: 9200,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_9200',
                label: '',
                value: '',
                order: 9200,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'beneficiary_ID__c',
                label: 'Account # (Beneficiary Bank ID)',
                order: 9300,
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_CB_Name_3__c',
                label: 'Name 3',
                order: 9400,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_9400',
                label: '',
                value: '',
                order: 9400,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'counterparty_Contact_CB_Phone_3__c',
                label: 'Phone 3',
                order: 9500,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_9500',
                label: '',
                value: '',
                order: 9500,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1400',
                label: 'Beneficiary Bank/Financial Institution /Other',
                value: '',
                order: 9600,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new SingleCheckboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'two_distinct_individuals_confirm_instruc__c',
                label: 'Two distinct individuals to provide and separately confirm the instructions are not available for this client',
                value: false,
                order: 9700,
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ],

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_9700',
                label: '',
                value: '',
                order: 9700,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'beneficiary_Bank_Financial_Institution_O__c',
                label: 'Beneficiary Bank/Financial Institution/Other ID Type',
                order: 9800,
                col: 6,
                defaultOption: '',
                selectionChange: true,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: '\"ROUTING NUMBER (ABA)\" - 9 digit code for US banks. \n \"ACCOUNT NUMBER (DDA)\" - The beneficiary bank\'s account #. \n  \"GENERAL LEDGER\" - The beneficiary bank\'s account #- WFBNA only. \n \"UNSPECIFIED\" - used for other scenarios such as ABA instructions',

                options: [
                    { key: '', value: '--None--' },
                    { key: 'Routing Number (ABA)', value: 'Routing Number (ABA)' },
                    { key: 'Account Number (DDA)', value: 'Account Number (DDA)' },
                    { key: 'General Ledger', value: 'General Ledger' },
                    { key: 'Unspecified', value: 'Unspecified' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1400',
                label: 'Callback Verification',
                value: '',
                order: 9900,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_9900',
                label: '',
                value: '',
                order: 9900,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'bank_FI_Name__c',
                label: 'Bank/FI Name',
                order: 10000,
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_Verification_Contact_Name__c',
                label: 'Contact Name',
                order: 10100,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Client Services'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [

                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - No Answer"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Technical Error"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback - Supervisory Principal Approved"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Possible Fraud"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Complete - Client Validated"
                            },


                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_10100',
                label: '',
                value: '',
                order: 10100,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_Verification_Contact_Number__c',
                label: 'Contact Number',
                order: 10200,
                col: 3,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Client Services'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [

                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - No Answer"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Technical Error"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback - Supervisory Principal Approved"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Possible Fraud"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Complete - Client Validated"
                            },


                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_10200',
                label: '',
                value: '',
                order: 10200,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'account_Number_Bank_FI_ID__c',
                label: 'Account Number (Bank/FI ID)',
                order: 10300,
                col: 6,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: 'If DDA selected in Bene Account Type, then include DDA Acct #; if ABA selected then input routing number',

                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new DatePickerQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_Date_Time__c',
                label: 'Callback Date/Time',
                order: 10400,
                col: 3,
                hasTime: true,
                template: 'callback_Time__c',
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Client Services'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [

                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - No Answer"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Technical Error"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback - Supervisory Principal Approved"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Possible Fraud"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Complete - Client Validated"
                            },


                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_10400',
                label: '',
                value: '',
                order: 10400,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'No_Of_Attempts__c',
                label: 'No Of Attempts',
                order: 10500,
                col: 3,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_10500',
                label: '',
                value: '',
                order: 10500,
                col: 3,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '10600',
                label: '',
                order: 10600,
                col: 6,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),


            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'Callback_Notes__c',
                label: 'Callback Notes',
                order: 10700,
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Client Services'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_10700',
                label: '',
                value: '',
                order: 10700,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),

            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1500',
                label: 'Intermediary Bank Routing Details',
                value: '',
                order: 10800,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                    // {
                    //     action: 'VISIBLE',
                    //     connective: 'OR',
                    //     when: [
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: ''
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Account Number (DDA)'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'General Ledger'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Unspecified'
                    //         },
                    //     ]
                    // },
                    // {
                    //     action: 'VISIBLE',
                    //     connective: 'AND',
                    //     when: [
                    //         {
                    //             id: 'New_Wires__c',
                    //             value: 'Yes'
                    //         }
                    //     ]
                    // }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_10900',
                label: '',
                value: '',
                order: 10900,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                    // {
                    //     action: 'VISIBLE',
                    //     connective: 'OR',
                    //     when: [
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: ''
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Account Number (DDA)'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'General Ledger'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Unspecified'
                    //         },
                    //     ]
                    // },
                    // {
                    //     action: 'VISIBLE',
                    //     connective: 'OR',
                    //     when: [
                    //         {
                    //             id: 'New_Wires__c',
                    //             value: 'Yes'
                    //         }
                    //     ]
                    // }
                ]
            }),
            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'intermediary_Bank_ID_Type__c',
                label: 'Intermediary Bank ID Type',
                order: 11000,
                col: 6,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Routing Number (ABA)', value: 'Routing Number (ABA)' },

                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]


                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                    // {
                    //     action: 'VISIBLE',
                    //     connective: 'OR',
                    //     when: [
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: ''
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Account Number (DDA)'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'General Ledger'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Unspecified'
                    //         },
                    //     ]
                    // }


                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_11050',
                label: '',
                value: '',
                order: 11050,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),

            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'intermediary_Bank_Name__c',
                label: 'Intermediary Bank Name',
                order: 11100,
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_11150',
                label: '',
                value: '',
                order: 11150,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'routing_Number_Intermediary_Bank_ID__c',
                label: 'Routing Number (Intermediary Bank ID)',
                order: 11200,
                col: 6,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                    // {
                    //     action: 'VISIBLE',
                    //     connective: 'OR',
                    //     when: [
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: ''
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Account Number (DDA)'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'General Ledger'
                    //         },
                    //         {
                    //             id: 'beneficiary_Bank_Financial_Institution_O__c',
                    //             value: 'Unspecified'
                    //         },
                    //     ]
                    // }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1810',
                label: '',
                value: '',
                order: 11300,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Intermediary_Bank_Routing_Details_Visibility',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_1500',
                label: 'Other Instructions',
                value: '',
                order: 11400,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '2200',
                label: '',
                value: '',
                order: 11500,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'other_Instructions__c',
                label: 'Other Instructions',
                order: 11600,
                col: 6,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: 'Use this field for further credit, reference # and other data for which there are no fields above. Please do not use this field for data which has a designated field above',
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),

            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'source_Type__c',
                label: 'Source Type',
                order: 11700,
                col: 6,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'E-Mail', value: 'E-Mail' },
                    { key: 'Fax', value: 'Fax' },
                    { key: 'Mail', value: 'Mail' },
                    { key: 'Other', value: 'Other' },

                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]


                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'verification_Source__c',
                label: 'Verification Source',
                order: 11800,
                col: 6,
                relation: [

                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Client Services'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [

                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - No Answer"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Technical Error"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback - Supervisory Principal Approved"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Performed - Possible Fraud"
                            },
                            {
                                id: "callback_Status__c",
                                value: "Callback Complete - Client Validated"
                            },
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'New_Wires__c',
                                value: 'Yes'
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'source_Type_Other__c',
                label: 'Source Type Other',
                order: 11900,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'source_Type__c',
                                value: 'Other'
                            }
                        ]

                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'source_Type__c',
                                value: 'Other'
                            }
                        ]


                    }

                ]
            }),


            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '2280',
                label: '',
                value: '',
                order: 12000,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'source_Type__c',
                                value: ''
                            },
                            {
                                id: 'source_Type__c',
                                value: 'Fax'
                            },
                            {
                                id: 'source_Type__c',
                                value: 'E-Mail'
                            },
                            {
                                id: 'source_Type__c',
                                value: 'Mail'
                            }
                        ]

                    },


                ]

            }),



            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '12100',
                label: 'Exception Approval',
                value: '',
                order: 12100,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'callback_Status__c',
                                value: 'Callback Performed - No Answer'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Approved'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Rejected'
                            },
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '12200',
                label: '',
                value: '',
                order: 12200,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'callback_Status__c',
                                value: 'Callback Performed - No Answer'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Approved'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Rejected'
                            },
                        ]
                    }
                ]
            }),


            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'desk_Head_Approver_Name__c',
                label: 'Supervisory Principal Approver Name',
                order: 12300,
                col: 6,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'callback_Status__c',
                                value: 'Callback Performed - No Answer'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Approved'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Rejected'
                            },
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'desk_Head_Callback_Exception_App_Time__c',
                label: 'Supervisory Principal Callback Exception Approval Timestamp',
                order: 12400,
                col: 6,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'callback_Status__c',
                                value: 'Callback Performed - No Answer'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Approved'
                            },
                            {
                                id: 'callback_Status__c',
                                value: 'Callback - Supervisory Principal Rejected'
                            },
                        ]
                    }
                ]
            }),



            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '12500',
                label: 'Third Party Exception',
                value: '',
                order: 12500,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            }
                        ]

                    }
                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: '12600',
                label: '',
                value: '',
                order: 12600,
                disabled: true,
                col: 6,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            }
                        ]

                    },


                ]

            }),

            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_form_Completed_By__c',
                label: 'Form Completed By',
                order: 12700,
                col: 6,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            }
                        ]

                    },


                ]

            }),

            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'telephone__c',
                label: 'Telephone',
                order: 12800,
                col: 6,

                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]


                    }

                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_12800',
                label: '',
                value: '',
                order: 12800,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new DatePickerQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_form_Completed_Date__c',
                label: 'Form Completion Date',
                order: 12800,
                col: 6,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            }
                        ]

                    }


                ]

            }),

            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'fax__c',
                label: 'Fax',
                order: 12900,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },

                ]
            }),
            new LabelQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'callback_12900',
                label: '',
                value: '',
                order: 12900,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'business_Unit_Requesting_Exception__c',
                label: 'Business Unit Requesting Exception',
                order: 13000,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]


                    }

                ]
            }),
            new DatePickerQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'Third_Party_Approval_Timestamp__c',
                label: 'Approval Timestamp',
                order: 13000,
                col: 6,
                hasTime: true,
                template: 'callback_Time__c',
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]

                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'Yes'
                            }
                        ]

                    }
                ]
            }),
            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_Request_Type__c',
                label: 'Request Type',
                order: 13100,
                col: 6,
                defaultOption: '',
                mandatory: true,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'One-Off', value: 'One-Off' },
                    { key: 'Annual', value: 'Annual' },


                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    }
                ]
            }),
            new TextboxQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'policy_Exception_Justification__c',
                label: 'Policy Exception Justification',
                order: 13200,
                col: 6,

                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]


                    }

                ]
            }),
            new DropdownQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_Exception_Approval_Status__c',
                label: 'Exception Approval Status',
                value: 'Third Party Exception - Approval required',
                order: 13300,
                col: 6,
                disabled: true,
                options: [
                    { key: 'Third Party Exception - Approval required', value: 'Third Party Exception - Approval required' },
                    { key: 'Third Party Exception - Supervisory Principal Approved', value: 'Third Party Exception - Supervisory Principal Approved' },
                    { key: 'Third Party Exception - Supervisory Principal Rejected', value: 'Third Party Exception - Supervisory Principal Rejected' },

                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    }
                ]

            }),

            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_Desk_Head_Approval__c',
                label: 'Supervisory Principal Approver Name',
                value: '',
                order: 13400,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    }
                ]

            }),

            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_Approval_Timestamp__c',
                label: 'Approval Timestamp',
                value: '',
                order: 13500,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    }
                ]

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'supervisor_Principal_Comments__c',
                label: 'Supervisor Principal Comments',
                value: '',
                order: 13600,
                disabled: true,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_this_Wire_a_Third_Party_payment__c',
                                value: 'Yes'
                            },
                            {
                                id: 'Is_Prime_Account__c',
                                value: 'No'
                            }
                        ]

                    }
                ]
            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SalesPerson_Emp_Key_Id__c',
                label: 'Supervisor Principal Comments',
                order: 13700,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'Marketer__c',
                label: 'Marketer__c',
                order: 13800,
                displayNone: true

            }),

            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SalesPerson_GroupName__c',
                label: 'SalesPerson_GroupName__c',
                order: 13900,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SalesPerson_Percent__c',
                label: 'SalesPerson_Percent__c',
                order: 14000,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SalesCategory__c',
                label: 'SalesCategory__c',
                order: 14100,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SalesCategoryId__c',
                label: 'SalesCategoryId__c',
                order: 14200,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SalesCategoryType__c',
                label: 'SalesCategoryType__c',
                order: 14300,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'Branch_Location__c',
                label: 'Branch_Location__c',
                order: 14400,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'SPTR_Email__c',
                label: 'SPTR_Email__c',
                order: 14500,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'supervisor__c',
                label: 'supervisor__c',
                order: 14600,
                displayNone: true

            }),
            new TextAreaQuestion({
                rowGroupBy: 'CALLBACK',
                key: 'supervisor_Email__c',
                label: 'supervisor_Email__c',
                order: 14700,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'supervisor_Id__c',
                label: 'supervisor_Id__c',
                order: 14800,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'delegate_Id__c',
                label: 'delegate_Id__c',
                order: 14900,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'delegate_Email__c',
                label: 'delegate_Email__c',
                order: 15000,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'sequenceId__c',
                label: 'sequenceId__c',
                order: 15100,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'existing_Thirdparty__c',
                label: 'existing_Thirdparty__c',
                order: 15200,
                displayNone: true

            }),
            new TextAreaQuestion({
                section: 'CallbackAndThirdPartyDetails',
                rowGroupBy: 'CALLBACK',
                key: 'third_Party_Desk_Head_App_ID__c',
                label: 'third_Party_Desk_Head_App_ID__c',
                order: 15300,
                displayNone: true

            }),
            //Callback Section ends
        ];

        return callbackQuestions.sort((a, b) => a.order - b.order);
    }

    buildTaxInformationFields(cobamRole: string, cmrId?: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            this.buildTaxReviewStatus(cobamRole),
            new TextAreaQuestion({
                section: 'TaxInformationDetails',
                key: 'TaxRequestType__c',
                label: 'Tax Request Type',
                order: 200,
                disabled: true
            }),
            new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'Entity_Type__c',
                label: 'Entity Type',
                defaultOption: '',
                order: 300,
                options: this.getEntityTypeOptions()
            }),
            this.buildFXStaticDataTaxStatus(cmrId),
            new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'Is_Entity_disrega__c',
                label: 'Is Entity Disregarded?',
                mandatory: true,
                order: 500,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new LabelQuestion({
                section: 'TaxInformationDetails',
                key: 'TaxParentLegalSearch',
                label: 'Tax Parent Legal Search',
                order: 600,
                searchable: true,
                template: 'Legal'
            }),
            new AutoCompleteQuestion({
                section: 'TaxInformationDetails',
                key: 'PrimaryTaxOwner__c',
                label: 'Primary Tax Owner',
                order: 700,
                mandatory: true,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'Tax Profile I',
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Tax Profile I'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: "TaxReviewStatus__c",
                                value: "Pending Review - Unassigned",
                                operator: "!=="
                            },
                            {
                                id: "TaxReviewStatus__c",
                                value: "",
                                operator: "!=="
                            }
                        ]
                    }

                ]
            }),
            new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'Is_a_Parent_build_needed__c',
                label: 'Is a parent build needed?',
                mandatory: true,
                order: 800,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Is_Entity_disrega__c',
                                value: 'Yes',
                                operator: "==="
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        when: [
                            {
                                id: "Is_Entity_disrega__c",
                                value: 'Yes',
                                operator: "==="
                            }
                        ]
                    }

                ]
            }),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'Parent_Legal_Name__c',
                label: 'Tax Parent Legal Name',
                order: 900,
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Is_a_Parent_build_needed__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        when: [
                            {
                                id: "Is_a_Parent_build_needed__c",
                                value: 'Yes',
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            new AutoCompleteQuestion({
                section: 'TaxInformationDetails',
                key: 'SecondaryTaxOwner__c',
                label: 'Secondary Tax Owner',
                order: 1000,
                mandatory: true,
                value: '',
                api: 'Lookup/users/',
                filterCriteria: 'Tax Profile I',
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'User_Role',
                                value: 'Tax Profile I'
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'OR',
                        when: [
                            {
                                id: "TaxReviewStatus__c",
                                value: "Pending Review - Unassigned",
                                operator: "!=="
                            },
                            {
                                id: "TaxReviewStatus__c",
                                value: "",
                                operator: "!=="
                            }
                        ]
                    }

                ]
            }),
            new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'Is_CRS_Forms_Included__c',
                label: 'CRS Form Included?',
                mandatory: true,
                order: 1100,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new LabelQuestion({
                section: 'TaxInformationDetails',
                key: 'Parent_LEID__c',
                label: 'Tax Parent LEID',
                order: 1200,
                disabled: true,
            }),
            new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'TaxFormType__c',
                label: 'Counterparty Tax form type',
                mandatory: true,
                order: 1300,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'W-9', value: 'W-9' },
                    { key: 'W-8ECI', value: 'W-8ECI' },
                    { key: 'W-8EXP', value: 'W-8EXP' },
                    { key: 'W-8BEN', value: 'W-8BEN' },
                    { key: 'W-8BEN-E', value: 'W-8BEN-E' },
                    { key: 'W-8BEN-E(Chapter 4 Only)', value: 'W-8BEN-E(Chapter 4 Only)' },
                    { key: 'W-8IMY', value: 'W-8IMY' },
                    { key: 'CRS Self Cert', value: 'CRS Self Cert' }
                ]
            }),
            this.buildEmptyField(1400),
            this.buildEmptyField(1500),
            new LabelQuestion({
                section: 'TaxInformationDetails',
                rowGroupBy: 'TaxInformation',
                col: 12,
                key: 'TaxInformation_1600',
                label: 'Underlying Forms for W-8IMY',
                value: '',
                order: 1600,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'TaxInformationDetails',
                rowGroupBy: 'TaxInformationDetai',
                key: 'TypeofTaxForm',
                label: 'Type of Tax Form',
                value: 'Number of Tax Forms',
                disabled: true,
                order: 1700,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'TaxInformationDetails',
                rowGroupBy: 'TaxInformationDetai',
                key: 'TotalNumberofTaxForms',
                label: 'Total Number of Tax Forms',
                disabled: true,
                order: 1800,
                col: 6,
                // relation: [
                //     {
                //         action: 'VISIBLE',
                //         //connective: 'OR',
                //         when: [
                //             {
                //                 id: "TaxFormType__c",
                //                 value: "W-8IMY",
                //                 operator: "==="
                //             }
                //         ]
                //     }
                // ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(1900),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_9__c',
                label: 'W-9',
                order: 2000,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(2100),
            this.buildEmptyFieldForTaxInformationDetail(2200),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_8ECI__c',
                label: 'W-8ECI',
                order: 2300,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(2400),
            this.buildEmptyFieldForTaxInformationDetail(2500),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_8EXP__c',
                label: 'W-8EXP',
                order: 2600,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(2700),
            this.buildEmptyFieldForTaxInformationDetail(2800),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_8BEN__c',
                label: 'W-8BEN',
                order: 2900,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(3000),
            this.buildEmptyFieldForTaxInformationDetail(3100),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_8BEN_E__c',
                label: 'W-8BEN-E',
                order: 3200,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(3300),
            this.buildEmptyFieldForTaxInformationDetail(3400),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_8BEN_E_Chapter_4_Only__c',
                label: 'W-8BEN-E(Chapter 4 Only)',
                order: 3500,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(3600),
            this.buildEmptyFieldForTaxInformationDetail(3700),
            new TextboxQuestion({
                section: 'TaxInformationDetails',
                key: 'W_8IMY__c',
                label: 'W-8IMY',
                order: 3800,
                col: 6,
                relation: [
                    {
                        action: 'VISIBLE',
                        //connective: 'OR',
                        when: [
                            {
                                id: "TaxFormType__c",
                                value: "W-8IMY",
                                operator: "==="
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyFieldForTaxInformationDetail(3900),
            this.buildEmptyFieldForTaxInformationDetail(4000)
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildEmptyFieldForTaxInformationDetail(order?: number): QuestionBase<any> {
        return new LabelQuestion({
            section: 'TaxInformationDetails',
            key: order.toString(),
            label: '',
            order: order,
            disabled: true,
            relation: [
                {
                    action: 'VISIBLE',
                    //connective: 'OR',
                    when: [
                        {
                            id: "TaxFormType__c",
                            value: "W-8IMY",
                            operator: "==="
                        }
                    ]
                }
            ]
        })
    }

    private buildTaxReviewStatus(cobamRole: string) {
        if (cobamRole === 'FX Static Data') {
            return new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'TaxReviewStatus__c',
                label: 'WFS Tax Review Status',
                mandatory: true,
                order: 100,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Pending Review - Unassigned', value: 'Pending Review - Unassigned' },
                    { key: 'Pending Review - Assigned', value: 'Pending Review - Assigned' },
                    { key: 'Pending Corporate Tax Guidance', value: 'Pending Corporate Tax Guidance' },
                    { key: 'Review in Process', value: 'Review in Process' },
                    { key: 'Approved - Pending LEID', value: 'Approved - Pending LEID' },
                    { key: 'Approved - Pending Upload', value: 'Approved - Pending Upload' },
                    { key: 'Approved – Complete', value: 'Approved – Complete' },
                    { key: 'Rejected', value: 'Rejected' },
                    { key: 'Resubmitted', value: 'Resubmitted' }
                ]
            })
        }
        else {
            return new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'TaxReviewStatus__c',
                label: 'Tax Review Status',
                mandatory: true,
                order: 100,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Pending Review - Unassigned', value: 'Pending Review - Unassigned' },
                    { key: 'Pending Review - Assigned', value: 'Pending Review - Assigned' },
                    { key: 'Pending Corporate Tax Guidance', value: 'Pending Corporate Tax Guidance' },
                    { key: 'Review in Process', value: 'Review in Process' },
                    { key: 'Approved - Pending LEID', value: 'Approved - Pending LEID' },
                    { key: 'Approved - Pending Upload', value: 'Approved - Pending Upload' },
                    { key: 'Approved – Complete', value: 'Approved – Complete' },
                    { key: 'Rejected', value: 'Rejected' },
                    { key: 'Resubmitted', value: 'Resubmitted' }
                ]
            })
        }
    }

    private buildFXStaticDataTaxStatus(cmrId?: string) {
        if (cmrId) {
            return new DropdownQuestion({
                section: 'TaxInformationDetails',
                key: 'FXStaticDataTaxStatus__c',
                label: 'FX Static Data Tax Status',
                mandatory: true,
                order: 400,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Submitted for WFS review', value: 'Submitted for WFS review' },
                    { key: 'In Good Order – WFS validation complete', value: 'In Good Order – WFS validation complete' },
                    { key: 'In Good Order-Pending R2K (Reason to Know)', value: 'In Good Order-Pending R2K (Reason to Know)' },
                    { key: 'In Good Order  – Complete', value: 'In Good Order  – Complete' },
                    { key: 'Not In Good Order - Rejected', value: 'Not In Good Order - Rejected' },
                    { key: 'Not in Good Order –Rejected (R2K)', value: 'Not in Good Order –Rejected (R2K)' }
                ]
            })
        }
        else {
            return this.buildEmptyField(400)
        }
    }

    getLookup(): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL + 'Lookup/lookup/?objectName=COBAM__c'
        );
    }

    getRecordTypes(): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL + 'Lookup/RecordTypes/'
        );
    }

    buildInternalContactFields(cobamRole: string, internalContactType: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'InternalContactType__c',
                label: 'InternalContactType__c',
                value: internalContactType,
                order: 1,
                displayNone: true
            }),
            new TextAreaQuestion({
                section: 'InternalContactDetails',
                key: 'Employee_Name__c',
                label: internalContactType, //'Relationship Manager',
                order: 100,
                value: '',
                disabled: true,
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Search',
                label: '',
                order: 200,
                searchable: true,
                disabled: false,
                template: internalContactType //'Relationship Manager'
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Employee_Id__c',
                label: 'Employee_Id__c',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Employee_Email__c',
                label: 'Employee_Email__c',
                order: 1,
                displayNone: true
            }),
        ];

        if (internalContactType === 'Marketer') {
            questions = questions.concat(this.buildMarketerFields());
        }
        return questions.sort((a, b) => a.order - b.order);
    }

    buildMarketerFields() {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Branch_Location__c',
                label: 'Branch_Location__c',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Marketer_Supervisor__c',
                label: 'Marketer_Supervisor__c',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Marketer_Supervisor_Id__c',
                label: 'Marketer_Supervisor_Id__c',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Marketer_Supervisor_Email__c',
                label: 'Marketer_Supervisor_Email__c',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Marketer_Delegate_Id__c',
                label: 'Marketer_Delegate_Id__c',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'InternalContactDetails',
                key: 'Marketer_Delegate_Email__c',
                label: 'Marketer_Delegate_Email__c',
                order: 1,
                displayNone: true
            }),
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildEntityInformationFields(cobamRole: string) {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                disabled: true,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_Id__c',
                label: 'CID LEID',
                order: 2,
                disabled: true,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'EntityInformation',
                col: 6,
                key: 'EntityInformation_100',
                label: 'Entity Information Details',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),
            this.buildEmptyField(200),
            this.buildLegalNameForNonCash(300),
            (cobamRole === 'Requester NonCash' || cobamRole === 'Requester FX' || cobamRole === 'FX Static Data' || cobamRole === 'FXOL' || cobamRole === 'Requester')
                ? new TextboxQuestion({
                    section: 'EntityInformationDetails',
                    key: 'RequesterTax__ui',
                    label: 'Tax Id',
                    order: 400,
                    //mandatory: true,
                    relation: [
                        {
                            action: 'VISIBLE',
                            connective: 'AND',
                            when: [
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'INDIV - INDIVIDUALS',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'FOIND - FOREIGN INDIVIDUALS',
                                    operator: '!=='
                                }
                            ]
                        },
                        {
                            action: 'REQUIRED',
                            connective: 'AND',
                            when: [
                                {
                                    id: 'Country_Organized__c',
                                    value: 'US - UNITED STATES',
                                    operator: '==='
                                }
                            ]
                        }
                    ]
                }) : new TextboxQuestion({
                    section: 'EntityInformationDetails',
                    key: 'Tax_Id__c',
                    label: 'Tax Id',
                    order: 400,
                    mandatory: true,
                    relation: [
                        {
                            action: 'VISIBLE',
                            connective: 'AND',
                            when: [
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'INDIV - INDIVIDUALS',
                                    operator: '!=='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'FOIND - FOREIGN INDIVIDUALS',
                                    operator: '!=='
                                }
                            ]
                        },
                        {
                            action: 'REQUIRED',
                            connective: 'AND',
                            when: [
                                {
                                    id: 'Country_Organized__c',
                                    value: 'US - UNITED STATES',
                                    operator: '==='
                                }
                            ]
                        }
                    ]
                }),
            (cobamRole === 'Requester NonCash' || cobamRole === 'Requester FX' || cobamRole === 'FX Static Data' || cobamRole === 'FXOL' || cobamRole === 'Requester')
                ? new TextboxQuestion({
                    section: 'EntityInformationDetails',
                    key: 'RequesterSSN__ui',
                    label: 'SSN',
                    order: 400,
                    //mandatory: true,
                    relation: [
                        {
                            action: 'VISIBLE',
                            connective: 'OR',
                            when: [
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'INDIV - INDIVIDUALS',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'FOIND - FOREIGN INDIVIDUALS',
                                    operator: '==='
                                }
                            ]
                        }
                    ]
                }) : new TextboxQuestion({
                    section: 'EntityInformationDetails',
                    key: 'SSN__c',
                    label: 'SSN',
                    order: 400,
                    mandatory: true,
                    relation: [
                        {
                            action: 'VISIBLE',
                            connective: 'OR',
                            when: [
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'INDIV - INDIVIDUALS',
                                    operator: '==='
                                },
                                {
                                    id: 'Entity_Type__c',
                                    value: 'FOIND - FOREIGN INDIVIDUALS',
                                    operator: '==='
                                }
                            ]
                        }
                    ]
                }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Entity_Relation_Type__c',
                label: 'Entity Relation Type',
                mandatory: true,
                defaultOption: 'COUNTERPARTY',
                order: 500,
                options: [
                    { key: 'COUNTERPARTY', value: 'COUNTERPARTY' },
                    { key: 'BENEFICIAL OWNER', value: 'BENEFICIAL OWNER' }
                ]
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Entity_Type__c',
                label: 'Entity Type',
                mandatory: true,
                defaultOption: '',
                order: 600,
                options: this.getEntityTypeOptions()
            }),
            this.buildClientType(700, null, true),
            this.buildClientSubType(800, null, true),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Country_Organized__c',
                label: 'Country Organized',
                defaultOption: 'US - UNITED STATES',
                selectionChange: true,
                mandatory: true,
                order: 900,
                options: this.countryOptions()
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'StateOrProvinceOrganized__c',
                label: 'StateOrProvinceOrganized',
                defaultOption: '',
                order: 1000,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'US - UNITED STATES'
                            }
                        ]
                    }
                ],
                options: [
                    { key: '', value: '--None--' },
                    { key: 'AK - ALASKA', value: 'AK - ALASKA' },
                    { key: 'AL - ALABAMA', value: 'AL - ALABAMA' },
                    { key: 'AR - ARKANSAS', value: 'AR - ARKANSAS' },
                    { key: 'AZ - ARIZONA', value: 'AZ - ARIZONA' },
                    { key: 'CA - CALIFORNIA', value: 'CA - CALIFORNIA' },
                    { key: 'CO - COLORADO', value: 'CO - COLORADO' },
                    { key: 'CT - CONNECTICUT', value: 'CT - CONNECTICUT' },
                    { key: 'DC - DISTRICT OF COLUMBIA', value: 'DC - DISTRICT OF COLUMBIA' },
                    { key: 'DE - DELAWARE', value: 'DE - DELAWARE' },
                    { key: 'FL - FLORIDA', value: 'FL - FLORIDA' },
                    { key: 'GA - GEORGIA', value: 'GA - GEORGIA' },
                    { key: 'HI - HAWAII', value: 'HI - HAWAII' },
                    { key: 'IA - IOWA', value: 'IA - IOWA' },
                    { key: 'ID - IDAHO', value: 'ID - IDAHO' },
                    { key: 'IL - ILLINOIS', value: 'IL - ILLINOIS' },
                    { key: 'IN - INDIANA', value: 'IN - INDIANA' },
                    { key: 'KS - KANSAS', value: 'KS - KANSAS' },
                    { key: 'KY - KENTUCKY', value: 'KY - KENTUCKY' },
                    { key: 'LA - LOUISIANNA', value: 'LA - LOUISIANNA' },
                    { key: 'MA - MASSACHUSETTS', value: 'MA - MASSACHUSETTS' },
                    { key: 'MD - MARYLAND', value: 'MD - MARYLAND' },
                    { key: 'ME - MAINE', value: 'ME - MAINE' },
                    { key: 'MI - MICHIGAN', value: 'MI - MICHIGAN' },
                    { key: 'MN - MINNESOTA', value: 'MN - MINNESOTA' },
                    { key: 'MO - MISSOURI', value: 'MO - MISSOURI' },
                    { key: 'MS - MISSISSIPPI', value: 'MS - MISSISSIPPI' },
                    { key: 'MT - MONTANA', value: 'MT - MONTANA' },
                    { key: 'NC - NORTH CAROLINA', value: 'NC - NORTH CAROLINA' },
                    { key: 'ND - NORTH DAKOTA', value: 'ND - NORTH DAKOTA' },
                    { key: 'NE - NEBRASKA', value: 'NE - NEBRASKA' },
                    { key: 'NH - NEW HAMPSHIRE', value: 'NH - NEW HAMPSHIRE' },
                    { key: 'NJ - NEW JERSEY', value: 'NJ - NEW JERSEY' },
                    { key: 'NM - NEW MEXICO', value: 'NM - NEW MEXICO' },
                    { key: 'NV - NEVADA', value: 'NV - NEVADA' },
                    { key: 'NY - NEW YORK', value: 'NY - NEW YORK' },
                    { key: 'OH - OHIO', value: 'OH - OHIO' },
                    { key: 'OK - OKLAHOMA', value: 'OK - OKLAHOMA' },
                    { key: 'OR - OREGON', value: 'OR - OREGON' },
                    { key: 'PA - PENNSYLVANIA', value: 'PA - PENNSYLVANIA' },
                    { key: 'RI - RHODE ISLAND', value: 'RI - RHODE ISLAND' },
                    { key: 'SC - SOUTH CAROLINA', value: 'SC - SOUTH CAROLINA' },
                    { key: 'SD - SOUTH DAKOTA', value: 'SD - SOUTH DAKOTA' },
                    { key: 'TN - TENNESSEE', value: 'TN - TENNESSEE' },
                    { key: 'TX - TEXAS', value: 'TX - TEXAS' },
                    { key: 'UT - UTAH', value: 'UT - UTAH' },
                    { key: 'VA - VIRGINIA', value: 'VA - VIRGINIA' },
                    { key: 'VT - VERMONT', value: 'VT - VERMONT' },
                    { key: 'WA - WASHINGTON', value: 'WA - WASHINGTON' },
                    { key: 'WI - WISCONSIN', value: 'WI - WISCONSIN' },
                    { key: 'WV - WEST VIRGINIA', value: 'WV - WEST VIRGINIA' },
                    { key: 'WY - WYOMING', value: 'WY - WYOMING' }
                ]
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'StateOrProvinceOrganized__c',
                label: 'StateOrProvinceOrganized',
                defaultOption: '',
                order: 1000,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'CA - CANADA'
                            }
                        ]
                    }
                ],
                options: [
                    { key: '', value: '--None--' },
                    { key: 'AB - ALBERTA', value: 'AB - ALBERTA' },
                    { key: 'BC - BRITISH COLUMBIA', value: 'BC - BRITISH COLUMBIA' },
                    { key: 'MB - MANITOBA', value: 'MB - MANITOBA' },
                    { key: 'NB - NEW BRUNSWICK', value: 'NB - NEW BRUNSWICK' },
                    { key: 'NL - NEWFOUNDLAND AND LABRADOR', value: 'NL - NEWFOUNDLAND AND LABRADOR' },
                    { key: 'NT - NORTHWEST TERRITORIES', value: 'NT - NORTHWEST TERRITORIES' },
                    { key: 'NS - NOVA SCOTIA', value: 'NS - NOVA SCOTIA' },
                    { key: 'NU - NUNAVUT', value: 'NU - NUNAVUT' },
                    { key: 'ON - ONTARIO', value: 'ON - ONTARIO' },
                    { key: 'PE - PRINCE EDWARD ISLAND', value: 'PE - PRINCE EDWARD ISLAND' },
                    { key: 'QC - QUEBEC', value: 'QC - QUEBEC' },
                    { key: 'SK - SASKATCHEWAN', value: 'SK - SASKATCHEWAN' },
                    { key: 'YT - YUKON', value: 'YT - YUKON' }
                ]
            }),
            new TextboxQuestion({
                section: 'EntityInformationDetails',
                key: 'Government_ID_Number__c',
                label: 'Government ID Number',
                order: 1000,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'US - UNITED STATES',
                                operator: '!=='
                            },
                            {
                                id: 'Country_Organized__c',
                                value: 'CA - CANADA',
                                operator: '!=='
                            }
                        ]
                    }
                ],
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Government_ID_Type__c',
                label: 'Government ID Type',
                defaultOption: '',
                mandatory: true,
                order: 1100,
                options: this.buildGovermentIdTypeOptions(),
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'US - UNITED STATES',
                                operator: '!=='
                            },
                            {
                                id: 'Country_Organized__c',
                                value: 'CA - CANADA',
                                operator: '!=='
                            }
                        ]
                    }
                ],
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                key: '1200',
                label: '',
                order: 1200,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'US - UNITED STATES',
                                operator: '!=='
                            },
                            {
                                id: 'Country_Organized__c',
                                value: 'CA - CANADA',
                                operator: '!=='
                            }
                        ]
                    }
                ],
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Government_ID_Issuer__c',
                label: 'Government ID Issuer',
                defaultOption: 'US - UNITED STATES',
                mandatory: true,
                order: 1300,
                options: this.countryOptions().concat({ key: 'ZZ - Z COUNTRY', value: 'ZZ - Z COUNTRY' }),
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'US - UNITED STATES',
                                operator: '!=='
                            },
                            {
                                id: 'Country_Organized__c',
                                value: 'CA - CANADA',
                                operator: '!=='
                            }
                        ]
                    }
                ],
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                key: '1400',
                label: '',
                order: 1400,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_Organized__c',
                                value: 'US - UNITED STATES',
                                operator: '!=='
                            },
                            {
                                id: 'Country_Organized__c',
                                value: 'CA - CANADA',
                                operator: '!=='
                            }
                        ]
                    }
                ],
            }),
            new DatePickerQuestion({
                section: 'EntityInformationDetails',
                key: 'Date_Of_Birth__c',
                label: 'Date Of Birth',
                order: 1500,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Entity_Type__c',
                                value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                operator: '==='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                operator: '==='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                operator: '==='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                operator: '==='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'INDIV - INDIVIDUALS',
                                operator: '==='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'FOIND - FOREIGN INDIVIDUALS',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                key: '1500',
                label: '',
                order: 1500,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Entity_Type__c',
                                value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'INDIV - INDIVIDUALS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'FOIND - FOREIGN INDIVIDUALS',
                                operator: '!=='
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyField(1600),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'EntityInformation',
                col: 6,
                key: 'EntityInformation_1700',
                label: 'Entity Address',
                value: '',
                order: 1700,
                disabled: true,
                css: 'title'
            }),
            this.buildEmptyField(1800),
            new TextboxQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_Address1__c',
                label: 'Address1',
                order: 1900,
                mandatory: true,
            }),
            new TextboxQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_Address2__c',
                label: 'Address2',
                order: 2000,
            }),
            new TextboxQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_City__c',
                label: 'City',
                order: 2100,
                mandatory: true,
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_State__c',
                label: 'State',
                defaultOption: '',
                order: 2200,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Legal_Country__c',
                                value: 'US - UNITED STATES'
                            }
                        ]
                    }
                ],
                options: [
                    { key: '', value: '--None--' },
                    { key: 'AK - ALASKA', value: 'AK - ALASKA' },
                    { key: 'AL - ALABAMA', value: 'AL - ALABAMA' },
                    { key: 'AR - ARKANSAS', value: 'AR - ARKANSAS' },
                    { key: 'AZ - ARIZONA', value: 'AZ - ARIZONA' },
                    { key: 'CA - CALIFORNIA', value: 'CA - CALIFORNIA' },
                    { key: 'CO - COLORADO', value: 'CO - COLORADO' },
                    { key: 'CT - CONNECTICUT', value: 'CT - CONNECTICUT' },
                    { key: 'DC - DISTRICT OF COLUMBIA', value: 'DC - DISTRICT OF COLUMBIA' },
                    { key: 'DE - DELAWARE', value: 'DE - DELAWARE' },
                    { key: 'FL - FLORIDA', value: 'FL - FLORIDA' },
                    { key: 'GA - GEORGIA', value: 'GA - GEORGIA' },
                    { key: 'HI - HAWAII', value: 'HI - HAWAII' },
                    { key: 'IA - IOWA', value: 'IA - IOWA' },
                    { key: 'ID - IDAHO', value: 'ID - IDAHO' },
                    { key: 'IL - ILLINOIS', value: 'IL - ILLINOIS' },
                    { key: 'IN - INDIANA', value: 'IN - INDIANA' },
                    { key: 'KS - KANSAS', value: 'KS - KANSAS' },
                    { key: 'KY - KENTUCKY', value: 'KY - KENTUCKY' },
                    { key: 'LA - LOUISIANNA', value: 'LA - LOUISIANNA' },
                    { key: 'MA - MASSACHUSETTS', value: 'MA - MASSACHUSETTS' },
                    { key: 'MD - MARYLAND', value: 'MD - MARYLAND' },
                    { key: 'ME - MAINE', value: 'ME - MAINE' },
                    { key: 'MI - MICHIGAN', value: 'MI - MICHIGAN' },
                    { key: 'MN - MINNESOTA', value: 'MN - MINNESOTA' },
                    { key: 'MO - MISSOURI', value: 'MO - MISSOURI' },
                    { key: 'MS - MISSISSIPPI', value: 'MS - MISSISSIPPI' },
                    { key: 'MT - MONTANA', value: 'MT - MONTANA' },
                    { key: 'NC - NORTH CAROLINA', value: 'NC - NORTH CAROLINA' },
                    { key: 'ND - NORTH DAKOTA', value: 'ND - NORTH DAKOTA' },
                    { key: 'NE - NEBRASKA', value: 'NE - NEBRASKA' },
                    { key: 'NH - NEW HAMPSHIRE', value: 'NH - NEW HAMPSHIRE' },
                    { key: 'NJ - NEW JERSEY', value: 'NJ - NEW JERSEY' },
                    { key: 'NM - NEW MEXICO', value: 'NM - NEW MEXICO' },
                    { key: 'NV - NEVADA', value: 'NV - NEVADA' },
                    { key: 'NY - NEW YORK', value: 'NY - NEW YORK' },
                    { key: 'OH - OHIO', value: 'OH - OHIO' },
                    { key: 'OK - OKLAHOMA', value: 'OK - OKLAHOMA' },
                    { key: 'OR - OREGON', value: 'OR - OREGON' },
                    { key: 'PA - PENNSYLVANIA', value: 'PA - PENNSYLVANIA' },
                    { key: 'RI - RHODE ISLAND', value: 'RI - RHODE ISLAND' },
                    { key: 'SC - SOUTH CAROLINA', value: 'SC - SOUTH CAROLINA' },
                    { key: 'SD - SOUTH DAKOTA', value: 'SD - SOUTH DAKOTA' },
                    { key: 'TN - TENNESSEE', value: 'TN - TENNESSEE' },
                    { key: 'TX - TEXAS', value: 'TX - TEXAS' },
                    { key: 'UT - UTAH', value: 'UT - UTAH' },
                    { key: 'VA - VIRGINIA', value: 'VA - VIRGINIA' },
                    { key: 'VT - VERMONT', value: 'VT - VERMONT' },
                    { key: 'WA - WASHINGTON', value: 'WA - WASHINGTON' },
                    { key: 'WI - WISCONSIN', value: 'WI - WISCONSIN' },
                    { key: 'WV - WEST VIRGINIA', value: 'WV - WEST VIRGINIA' },
                    { key: 'WY - WYOMING', value: 'WY - WYOMING' }
                ]
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_State__c',
                label: 'Canada Province',
                defaultOption: '',
                order: 2200,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Legal_Country__c',
                                value: 'CA - CANADA'
                            }
                        ]
                    }
                ],
                options: [
                    { key: '', value: '--None--' },
                    { key: 'AB - ALBERTA', value: 'AB - ALBERTA' },
                    { key: 'BC - BRITISH COLUMBIA', value: 'BC - BRITISH COLUMBIA' },
                    { key: 'MB - MANITOBA', value: 'MB - MANITOBA' },
                    { key: 'NB - NEW BRUNSWICK', value: 'NB - NEW BRUNSWICK' },
                    { key: 'NL - NEWFOUNDLAND AND LABRADOR', value: 'NL - NEWFOUNDLAND AND LABRADOR' },
                    { key: 'NT - NORTHWEST TERRITORIES', value: 'NT - NORTHWEST TERRITORIES' },
                    { key: 'NS - NOVA SCOTIA', value: 'NS - NOVA SCOTIA' },
                    { key: 'NU - NUNAVUT', value: 'NU - NUNAVUT' },
                    { key: 'ON - ONTARIO', value: 'ON - ONTARIO' },
                    { key: 'PE - PRINCE EDWARD ISLAND', value: 'PE - PRINCE EDWARD ISLAND' },
                    { key: 'QC - QUEBEC', value: 'QC - QUEBEC' },
                    { key: 'SK - SASKATCHEWAN', value: 'SK - SASKATCHEWAN' },
                    { key: 'YT - YUKON', value: 'YT - YUKON' }
                ]
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                key: '2200',
                label: '',
                order: 2200,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Legal_Country__c',
                                operator: '!==',
                                value: 'US - UNITED STATES'
                            },
                            {
                                id: 'Legal_Country__c',
                                operator: '!==',
                                value: 'CA - CANADA'
                            }
                        ]
                    }
                ],
            }),
            new TextboxQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_Zip__c',
                label: 'Zip',
                order: 2300,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Legal_Country__c',
                                operator: '!==',
                                value: 'CA - CANADA'
                            }
                        ]
                    }
                ],
            }),
            new TextboxQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_Zip__c',
                label: 'Postal Code',
                order: 2300,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Legal_Country__c',
                                operator: '===',
                                value: 'CA - CANADA'
                            }
                        ]
                    }
                ],
            }),
            new DropdownQuestion({
                section: 'EntityInformationDetails',
                key: 'Legal_Country__c',
                label: 'Country',
                defaultOption: 'US - UNITED STATES',
                selectionChange: true,
                mandatory: true,
                order: 2400,
                options: this.countryOptions()
            }),
            this.buildCMAName(2500),
            this.buildCMAId(2600),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                key: 'CreateOrSelectCMA__c',
                label: 'Coverage Master Alias (CMA)',
                displayNone: true,
                order: 2700,
                options: [
                    { key: 'Select existing CMA', value: 'Select existing CMA' },
                    { key: 'Create New CMA', value: 'Create New CMA' }
                ]
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                col: 12,
                key: 'KYC_100',
                label: 'KYC',
                value: '',
                order: 100,
                disabled: true,
                css: 'title',
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Entity_Type__c',
                                value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'INDIV - INDIVIDUALS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'FOIND - FOREIGN INDIVIDUALS',
                                operator: '!=='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsNonUSExeOrAffiliates__c',
                label: 'Does this entity have any executives or affiliates who are Non-US Persons?',
                displayNone: false,
                order: 200,
                required: true,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `A non-U.S. person is either: • an individual who is not a citizen of the United States or • an entity that is not created or organized in the United States nor under the law of the United States or of any U.S. state`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Entity_Type__c',
                                value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'INDIV - INDIVIDUALS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'FOIND - FOREIGN INDIVIDUALS',
                                operator: '!=='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsInternetGamblingBussiness__c',
                label: 'Does this entity engage in an internet gambling business?',
                displayNone: false,
                required: true,
                order: 300,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `The Unlawful Internet Gambling Enforcement Act (AKA Reg. GG) requires banks to demonstrate through written policies and procedures that they are taking certain precautions when opening commercial accounts Internet gambling entities. This would include entities where gamblers can upload funds, make bets, or play the games that are offered and then cash out any winnings. This includes online poker, online casinos, online sports betting, online bingo and mobile gambling.`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Entity_Type__c',
                                value: 'EMP - WELLS FARGO EMPLOYEE-NON-WCM',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPBKF - WELLS FARGO EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPFAM - SECTION 20 EMP FAMILY MEMBERS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'EMPS20 - WELLS FARGO SEC 20 EMPLOYEE',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'INDIV - INDIVIDUALS',
                                operator: '!=='
                            },
                            {
                                id: 'Entity_Type__c',
                                value: 'FOIND - FOREIGN INDIVIDUALS',
                                operator: '!=='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                col: 12,
                key: 'OCC_400',
                label: 'OCC',
                value: '',
                order: 400,
                disabled: true,
                css: 'title'
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'isClientRegOCustomer__c',
                label: 'Is this Client a Reg O customer?',
                displayNone: false,
                required: true,
                order: 500,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'HasappropriateExecutionofTransaction__c',
                label: 'Has the appropriate credit officer approved the execution of this transaction?',
                displayNone: false,
                required: true,
                order: 600,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'isClientRegOCustomer__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsTransactionHedge__c',
                label: 'Is the proposed derivative transaction being to hedge or mitigate the client\'s commercial risk?',
                displayNone: false,
                required: true,
                order: 700,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsInLegalDispute__c',
                label: 'Has the counterparty instituted in the past, or is it currently engaged in a dispute or litigation with Wells Fargo or of its affiliates or any other seller of derivative products?',
                displayNone: false,
                required: true,
                order: 800,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new LabelQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                col: 12,
                key: 'SPE_900',
                label: 'SPE',
                value: '',
                order: 900,
                disabled: true,
                css: 'title'
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecSPESPV__c',
                label: 'Will the underlying exposures/assets be owned by a special purpose vehicle (SPV)/SPE?',
                displayNone: false,
                required: true,
                order: 1000,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `Special purpose entities (SPEs) are companies organized for a specific purpose, the activities of which are significantly limited to those appropriate to accomplish a specific purpose, and the structure of which is intended to isolate the credit risk of the special purpose entity. SPEs are not operating companies, collective investment funds, pension funds, 1940 Act funds, small business investment companies, community development investments or other non-regulated funds.  As private equity funds and hedge funds (actively managed funds) are included in the definition of non-regulated funds under financial sector entities, Wells Fargo also excludes them from SPEs.<br> 
                Investment firms generally do not produce goods or provide services beyond the business of investing, reinvesting, holding or trading in financial assets.  It is Wells Fargo’s policy to classify passive investment firms, or investment firms that do not exercise unfettered control, as SPEs.  This would also exclude private equity funds and hedge funds as they are not passive investment firms due to their managers having the ability to exercise unfettered control.    Investment firms are considered passive and meet the definition of an SPE unless all of the criteria cited below are met:<br>
               
                a.	The investment firm is actively managed by one or more investment advisers such that the composition of its investment portfolio can change over time in furtherance of the firm’s investment strategy, and is not static.
                b.	The investment firm, as managed by its investment adviser, retains broad discretion to execute or change the manner in which it executes its investment strategy, including with respect to the composition of its investment portfolio and the type and amount of leverage employed in its investment strategy. 
                c.	The investment firm, as managed by its investment adviser, retains broad discretion to use a variety of instruments and transactions to execute its investment strategy. 
                d.	The investment firm, as managed by its investment adviser, has the broad discretion and ability to control the size of the firm through the issuance of variable amounts of debt, or through the issuance and redemption of shares or ownership interests.
                e.	The investment firm, as managed by its investment adviser, retains broad discretion to distribute or reinvest cash proceeds generated by the firm’s underlying assets.`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecSPERiskTransferred__c',
                label: 'Will all or a portion of the credit risk of one or more underlying exposures be transferred to one or more third parties?',
                displayNone: false,
                required: true,
                order: 1100,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `The SPE is not consolidated on WFC’s balance sheet. Wells Fargo retains credit exposure which may be in form of security, loan, repo, derivative (credit and non-credit), receivable (servicer cash advance) or guarantee.`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'IsSecSPESPV__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecSPERiskSeparated__c',
                label: 'Will the credit risk associated with the underlying exposures be separated into at least two tranches reflecting different levels of seniority?',
                displayNone: false,
                required: true,
                order: 1200,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `In order for a transaction to qualify as a securitization, the risk in the underlying assets must represent the credit risk, and the credit risk must be divided into at least two tranches, a junior and a senior tranche, where the junior tranche absorbs the impact of any credit risk before payments to the senior tranche are affected. Equity tranche (overcollateralization) is considered a credit tranche.  Two tranche SPEs (loan/repo and equity tranche) qualify as Yes. Mortgage-backed pass through securities (for example those guaranteed by FHLMC and FNMA) that feature various maturities but do not involve the tranching of credit risk do NOT qualify as a securitization.`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'IsSecSPESPV__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecSPEPerformanceExposure__c',
                label: 'Will performance of the securitization exposure depend on the performance of the underlying exposure(s)?',
                displayNone: false,
                required: true,
                order: 1300,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `If WFC does not have full recourse to Sponsor / Originator (full 100% guarantee of losses) the transaction qualifies as Yes. Covered Bonds do not meet the definition of a securitization, because the counterparty risk is to the originator`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'IsSecSPESPV__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecSPEAllFinancialExp__c',
                label: 'Will all or substantially all of the underlying exposures be financial exposures?',
                displayNone: false,
                required: true,
                order: 1400,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `The underlying assets backing the exposure must be primarily financial in nature (e.g. loans, commitments, credit derivatives, guarantees, receivables, asset-backed securities, mortgage-backed securities, other debt securities, or equity securities).  A specialized loan to finance the construction or acquisition of large-scale projects (for example, airports or power plants), objects (for example, ships, aircraft, or satellites), or commodities (for example, reserves, inventories, precious metals, oil, or natural gas) generally would not be a securitization exposure because the assets backing the loan typically are nonfinancial assets (the facility, object, or commodity being financed).`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'IsSecSPESPV__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecuritizationSPE__c',
                label: 'Securitization SPE',
                defaultOption: 'No',
                displayNone: false,
                required: true,
                disabled: true,
                order: 1500,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EntityInformationDetails',
                rowGroupBy: 'ComplianceQuestions',
                key: 'IsSecSPESeniorTransaction__c',
                label: 'Does the derivative have seniority in the transaction?',
                displayNone: false,
                required: true,
                order: 1600,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `Seniority is defined as having a first priority claim on the cash flows from the underlying exposures of the securitization SPE (notwithstanding amounts due under interest rate or currency derivative contracts, fees due, or other similar payments).`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'IsSecSPESPV__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
        ];

        return questions.sort((a, b) => a.order - b.order);
    }


    buildDocumentationRequestFields(cobamRole: string, cmrId?: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'DocumentationRequestDetails',
                rowGroupBy: 'DocumentationRequest',
                col: 12,
                key: 'Documentation Request_100',
                label: 'Documentation Request Form',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),
            this.buildTypeofDocumentationRequest(200),
            new TextboxQuestion({
                section: 'DocumentationRequestDetails',
                key: 'OtherDocRequestTypeDesc__c',
                label: 'New Documentation Requested',
                order: 300,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Type_of_Documentation_Request__c',
                                value: 'Other',
                                operator: '==='
                            }
                        ]
                    }
                ],
            }),
            new MultiselectQuestion({
                section: 'DocumentationRequestDetails',
                key: 'Dodd_Frank_Documentation__ui',
                label: 'Dodd-Frank Documentation',
                defaultOption: 'None selected',
                mandatory: true,
                order: 400,
                options: [
                    { key: 'Terms of Business', value: 'Terms of Business' },
                    { key: 'ISDA DF Protocol', value: 'ISDA DF Protocol' },
                    { key: 'Other', value: 'Other' },
                    { key: 'ECP Customer Certification (One-Page Form for Non-ECP Customers)', value: 'ECP Customer Certification (One-Page Form for Non-ECP Customers)' },

                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'Type_of_Documentation_Request__c',
                                value: 'ISDA (rate/commodity/credit swaps and options)'
                            },
                            {
                                id: 'Type_of_Documentation_Request__c',
                                value: 'Amendment to Existing Agreement'
                            },
                            {
                                id: 'Type_of_Documentation_Request__c',
                                value: 'FX Documentation Request'
                            },
                            {
                                id: 'Type_of_Documentation_Request__c',
                                value: 'FX Documentation Request for Dodd Frank'
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'DocumentationRequestDetails',
                key: 'TermsofBusinessSent2Cust__c',
                label: 'Has the Terms of Business already been sent to the customer?',
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                order: 500,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Dodd_Frank_Documentation__ui',
                                value: 'Terms of Business',
                                operator: '=='
                            }
                        ]
                    }
                ],
                mandatory: true
            }),
            new OptionsInlineQuestion({
                section: 'DocumentationRequestDetails',
                key: 'HasCustSubmittedISDAProtocol__c',
                label: 'Has customer submitted the ISDA Protocol via Markit?',
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                order: 600,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Dodd_Frank_Documentation__ui',
                                value: 'ISDA DF Protocol',
                                operator: '=='
                            },
                            {
                                id: 'Product_Type__c',
                                value: 'FX',
                                operator: '==='
                            },

                        ]
                    }
                ],
                mandatory: true
            }),
            new TextboxQuestion({
                section: 'DocumentationRequestDetails',
                key: 'DFOtherText__c',
                label: 'DFOtherText',
                order: 700,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Dodd_Frank_Documentation__ui',
                                value: 'Other',
                                operator: '=='
                            }
                        ]
                    }
                ],
            }),
            new TextboxQuestion({
                section: 'DocumentationRequestDetails',
                key: 'ExTrAgmntInPlace__c',
                label: 'What existing trading agreement is being amended?',
                order: 800,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Type_of_Documentation_Request__c',
                                value: 'Amendment to Existing Agreement',
                                operator: '==='
                            }
                        ]
                    }
                ],
            }),
            new OptionsInlineQuestion({
                section: 'DocumentationRequestDetails',
                key: 'DocumentationCoverMore__c',
                label: 'Will the requested Documentation cover more than one entity?',
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `e.g. joint and several counterparties, umbrella arrangement, or an investment manager relationship`,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                order: 900,
                mandatory: true
            }),
            new OptionsInlineQuestion({
                section: 'DocumentationRequestDetails',
                key: 'AreEntitiesOutsideUS__c',
                label: 'Are any of the entities based outside of the United States?',
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                order: 1000,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'DocumentationCoverMore__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ],
            }),
            new DropdownQuestion({
                section: 'DocumentationRequestDetails',
                key: 'WF_Trading_Entity__c',
                label: 'WF Trading Entity',
                mandatory: true,
                defaultOption: 'Wells Fargo Bank, N.A.',
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `Please select the WF entity where the derivative will be executed out of.`,
                order: 1100,
                options: [
                    { key: 'Wells Fargo Bank, N.A.', value: 'Wells Fargo Bank, N.A.' },
                    { key: 'Wells Fargo Credit, Inc.', value: 'Wells Fargo Credit, Inc.' },
                    { key: 'Wells Fargo Equipment Finance, Inc.', value: 'Wells Fargo Equipment Finance, Inc.' },
                    { key: 'Wells Fargo & Company', value: 'Wells Fargo & Company' },
                    { key: 'Wells Fargo Commodities, LLC', value: 'Wells Fargo Commodities, LLC' },
                    { key: 'WFC Holdings Corporation', value: 'WFC Holdings Corporation' },
                    { key: 'Wells Fargo Securities, LLC', value: 'Wells Fargo Securities, LLC' },
                    { key: 'Wells Fargo Securities International Limited', value: 'Wells Fargo Securities International Limited' },
                    { key: 'Wells Fargo Bank International', value: 'Wells Fargo Bank International' },
                    { key: 'Wells Fargo Capital Finance, LLC.', value: 'Wells Fargo Capital Finance, LLC.' },

                ]
            }),
            new DropdownQuestion({
                section: 'DocumentationRequestDetails',
                key: 'AggregateRelationshipMPE__c',
                label: 'Aggregate Relationship MPE: (Actual Value:0)',
                mandatory: true,
                defaultOption: 'Less than $750,000',
                order: 1200,
                options: [
                    { key: 'Less than $750,000', value: 'Less than $750,000' },
                    { key: '$750,000 to $5,000,000', value: '$750,000 to $5,000,000' },
                    { key: 'Greater than $5,000,000', value: 'Greater than $5,000,000' },
                    { key: 'NONE', value: 'NONE' },

                ]
            }),
            new DropdownQuestion({
                section: 'DocumentationRequestDetails',
                key: 'Account_Sub_Type__c',
                label: 'Account Sub Type',
                mandatory: true,
                defaultOption: 'NON FIDUCIARY',
                order: 1300,
                options: [
                    { key: 'NON FIDUCIARY', value: 'NON FIDUCIARY' },
                    { key: 'FIDUCIARY', value: 'FIDUCIARY' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'DocumentationRequestDetails',
                key: 'Wealth_FA_disclosure_form_required__c',
                label: 'Wealth FA disclosure form required',
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                order: 1400,
                relation: [
                    {
                        action: 'REQUIRED',
                        when: [
                            {
                                id: 'CustomerType__c',
                                value: 'Wealth Management/Wealth Brokerage Retirement',
                                operator: '==='
                            }
                        ]
                    }
                ],
            }),
            new TextAreaQuestion({
                section: 'DocumentationRequestDetails',
                key: 'Comments__c',
                label: 'Comments',
                order: 1500
            }),
            new DropdownQuestion({
                section: 'DocumentationRequestDetails',
                key: 'CustomerType__c',
                label: 'Line of Business',
                mandatory: true,
                defaultOption: '',
                order: 1600,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Asset-Backed Finance', value: 'Asset-Backed Finance' },
                    { key: 'Government Investment Bank/Municipal Products Group', value: 'Government Investment Bank/Municipal Products Group' },
                    { key: 'Business Banking/Dealer Services', value: 'Business Banking/Dealer Services' },
                    { key: 'Hedge Fund', value: 'Hedge Fund' },
                    { key: 'Commercial Real Estate/Real Estate Capital Markets', value: 'Commercial Real Estate/Real Estate Capital Markets' },
                    { key: 'Institutional/Emerging Markets', value: 'Institutional/Emerging Markets' },
                    { key: 'Community Lending & Investment', value: 'Community Lending & Investment' },
                    { key: 'Regional Commercial Banking Office', value: 'Regional Commercial Banking Office' },
                    { key: 'Corporate Banking Group', value: 'Corporate Banking Group' },
                    { key: 'Wealth Management/Wealth Brokerage Retirement', value: 'Wealth Management/Wealth Brokerage Retirement' },
                    { key: 'Global Banking', value: 'Global Banking' },
                    { key: 'Wells Fargo Capital Finance', value: 'Wells Fargo Capital Finance' },
                    { key: 'Global Financial Institutions', value: 'Global Financial Institutions' },
                    { key: 'Other', value: 'Other' }
                ]
            }),
            new TextboxQuestion({
                section: 'DocumentationRequestDetails',
                key: 'Other_Customer_Type_Desc__c',
                label: 'Other Line of Business Desc',
                order: 1700,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'CustomerType__c',
                                value: 'Other',
                                operator: '==='
                            }
                        ]
                    }
                ]
            })
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildFXDocumentationRequestFields(cobamRole: string, cmrId?: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new MultiselectQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'FX_Specific_Products__ui',
                label: 'FX Specific Products (Select all that apply)',
                defaultOption: 'None selected',
                mandatory: false,
                order: 1800,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `* This product requires a tax form for onboarding purposes. ** If this client is an option only client, please contact your DoCO rep.`,
                options: [
                    { key: 'FX EYD', value: 'FX EYD' },
                    { key: 'FX Online', value: 'FX Online' },
                    { key: 'FX Forward', value: 'FX Forward *' },
                    { key: 'FX Option', value: 'FX Option **' },
                    { key: 'FX Multi Currency Account', value: 'FX Multi Currency Account *' },
                    { key: 'FX Spot', value: 'FX Spot' },
                    { key: 'FX NDF', value: 'FX NDF *' },
                    { key: 'FX Swap', value: 'FX Swap *' },
                    { key: 'FX Offshore Time Deposit', value: 'FX Offshore Time Deposit *' },
                    { key: 'FX Window Forward', value: 'FX Window Forward *' },

                ]
            }),
            new OptionsInlineQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Will_collateral_be_required_for_FX_trade__c',
                label: 'Will collateral be required for FX trades?',
                mandatory: true,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `* This product requires a tax form for onboarding purposes. ** If this client is an option only client, please contact your DoCO rep.`,
                order: 1900,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]

            }),
            new MultiselectQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'FX_Master_Agreement_Type__ui',
                label: 'FX Master Agreement Type',
                defaultOption: 'None selected',
                mandatory: false,
                order: 2000,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `# Foreign Specified Affiliates listed on an Annex A of a multi-party FXMA may require further diligence if an individual SPOQ is not included for each entity.`,
                options: [
                    { key: 'Corporate', value: 'Corporate' },
                    { key: 'Joint and Several Multi-Party', value: 'Joint and Several Multi-Party' },
                    { key: 'Multiparty (with parent guaranty)', value: 'Multiparty (with parent guaranty) #' },
                    { key: 'Co-Bank (Spot only)', value: 'Co-Bank (Spot only)' },
                    { key: 'Natural Person', value: 'Natural Person' },
                    { key: 'Trust', value: 'Trust' },
                    { key: 'Custom- Consult DoCO CPMG', value: 'Custom- Consult DoCO CPMG' },
                    { key: 'Wells Fargo Capital Finance', value: 'Wells Fargo Capital Finance' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Master_Agreement_Type__c',
                                value: 'FX Master Agreement',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Is_FXOL_Client__c',
                label: 'Will you be completing the eChannels tab at this time?',
                order: 2100,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Specific_Products__ui',
                                value: 'FX Online',
                                operator: '=='
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        when: [
                            {
                                id: 'FX_Specific_Products__ui',
                                value: 'FX Online',
                                operator: '=='
                            }
                        ]
                    }
                ]

            }),
            new DropdownQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Master_Agreement_Type__c',
                label: 'Which Master Agreement type is required?',
                selectionChange: true,
                order: 2200,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'FX Master Agreement', value: 'FX Master Agreement' },
                    { key: 'ISDA MASTER', value: 'ISDA MASTER' },
                    { key: 'FX Master Agreement Status Acknowledgement', value: 'FX Master Agreement Status Acknowledgement' },
                    { key: 'Master Agreement already on file', value: 'Master Agreement already on file' }
                ]
            }),
            new LabelQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: '2300',
                label: '',
                order: 2300,
                disabled: true
            }),
            new OptionsInlineQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'IsCustPooledInvestment__c',
                label: `Is customer a Pooled Investment Vehicle, Financial Institution, Gov't or Gov't owned entity or Highly Regulated/ Other non-traditional entity type?`,
                //mandatory: true,
                order: 2400,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Master_Agreement_Type__c',
                                value: 'FX Master Agreement',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new MultiselectQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Amendment__ui',
                label: 'Amendment',
                defaultOption: 'None selected',
                mandatory: false,
                order: 2500,
                options: [
                    { key: 'Amendment to Annex A', value: 'Amendment to Annex A' },
                    { key: 'Amendment to make Standalone FX Master Agreement Multi-Party', value: 'Amendment to make Standalone FX Master Agreement Multi-Party' },
                    { key: 'Amendment to add Credit Terms', value: 'Amendment to add Credit Terms' },
                    { key: 'Amendment to add Additional Termination Event', value: 'Amendment to add Additional Termination Event' }
                ]
            }),
            new MultiselectQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'FX_Credit_Support_Document__ui',
                label: 'FX Credit Support Document',
                defaultOption: 'None selected',
                mandatory: false,
                order: 2600,
                options: [
                    { key: 'Guaranty', value: 'Guaranty' }
                ]
            }),
            // new LabelQuestion({
            //     rowGroupBy: 'FXDocumentationRequestHeader',
            //     col: 4,
            //     key: 'FXService/ProductSpecificAgreements_100',
            //     label: 'FX Service/Product Specific Agreements',
            //     value: '',
            //     order: 2700,
            //     disabled: true,
            //     css: 'title'
            // }),
            // new LabelQuestion({
            //     rowGroupBy: 'FXDocumentationRequestHeader',
            //     col: 4,
            //     key: 'Documentation Request_100',
            //     label: '',
            //     value: '',
            //     order: 2700,
            //     disabled: true,
            //     css: 'title'
            // }),
            // new LabelQuestion({
            //     rowGroupBy: 'FXDocumentationRequestHeader',
            //     col: 4,
            //     key: 'FXDueDiligenceAffirmationForm_100',
            //     label: 'FX Due Diligence Affirmation Form',
            //     value: '',
            //     order: 2700,
            //     disabled: true,
            //     css: 'title'
            // }),
            new MultiselectQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'FX_Service_Product_Specific_Agreements__c',
                label: 'FX Service/Product Specific Agreements',
                defaultOption: 'None selected',
                mandatory: false,
                order: 2700,
                options: [
                    { key: 'FXOL Standalone', value: 'FXOL Standalone' },
                    { key: 'Time Deposit Agreement', value: 'Time Deposit Agreement' },
                    { key: 'FXOL Service Description', value: 'FXOL Service Description' },
                    { key: 'Enhanced Yield Deposit Service Description', value: 'Enhanced Yield Deposit Service Description' },
                    { key: 'FXOL Fee Schedule', value: 'FXOL Fee Schedule' },
                    { key: 'Consumer Joint Account', value: 'Consumer Joint Account' },
                    { key: 'CEO Online Agreement', value: 'CEO Online Agreement' },
                    { key: 'Authorization for Direct Payment Domestic ACH', value: 'Authorization for Direct Payment Domestic ACH' },
                    { key: 'RSA Secure ID Token Request Form', value: 'RSA Secure ID Token Request Form' },
                    { key: 'RMB Onshore letter', value: 'RMB Onshore letter' },
                    { key: 'CEO Self Admin Form', value: 'CEO Self Admin Form' },
                    { key: 'Additional Requested Document(s)', value: 'Additional Requested Document(s)' }
                ]
            }),
            new MultiselectQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'FX_Specific_Currencies__ui',
                label: 'FX Specific Currencies',
                defaultOption: 'None selected',
                mandatory: false,
                order: 2800,
                options: [
                    { key: 'Chinese RMB', value: 'Chinese RMB' }
                ]
            }),
            new DropdownQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'FX_Due_Diligence_Affirmation_Form__c',
                label: 'FX Due Diligence Affirmation Form',
                mandatory: true,
                order: 2900,
                options: [
                    { key: 'Send DDAF to RM for completion', value: 'Send DDAF to RM for completion' },
                    { key: 'BBG - DDAF N/A', value: 'BBG - DDAF N/A' },
                    { key: 'DDAF on file', value: 'DDAF on file' }
                ]

            }),
            new TextboxQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Additional_Requested_Documents__c',
                label: 'Additional Requested Document(s)',
                order: 3000,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Credit_Support_Document__c',
                                value: 'Additional Requested Document(s)',
                                operator: '=='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: '3000',
                label: '',
                order: 3000,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Credit_Support_Document__c',
                                value: 'Additional Requested Document(s)',
                                operator: '!='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequestHeader',
                col: 12,
                key: 'CountryandLicensing_100',
                label: 'Country and Licensing',
                value: '',
                order: 3300,
                disabled: true,
                css: 'title'
            }),
            new DropdownQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Country_and_Licensing__c',
                label: 'What country is the marketing/customer discussion taking place?',
                mandatory: true,
                order: 3600,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'United States', value: 'United States' },
                    { key: 'United Kingdom', value: 'United Kingdom' },
                    { key: 'Other', value: 'Other' }
                ]
            }),
            new TextboxQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: 'Country_and_Licensing_Other__c',
                label: 'Other Country and Licensing',
                order: 3700,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_and_Licensing__c',
                                value: 'Other',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: '3700',
                label: '',
                order: 3700,
                disabled: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'Country_and_Licensing__c',
                                value: 'Other',
                                operator: '!=='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'FXDocumentationRequestDetails',
                rowGroupBy: 'FXDocumentationRequest',
                key: '3800',
                label: '',
                order: 3800,
                disabled: true
            })
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildCustomerContactDocumentationFields(cobamRole: string, recordTypeName: string, recordTypeId: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'RecordTypeName',
                label: 'RecordTypeName',
                value: recordTypeName,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'RecordTypeId',
                label: 'RecordTypeId',
                value: recordTypeId,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactDocumentationDetails',
                rowGroupBy: 'CustomerContact',
                col: 12,
                key: 'CustomerContactForDocumentation_100',
                label: 'Customer Contact for Documentation',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),

        ];

        questions = questions.concat(this.buildCustomerContactCommonFields(true));
        return questions.sort((a, b) => a.order - b.order);
    }

    buildCustomerContactLegalCounselFields(cobamRole: string, recordTypeId: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                section: 'CustomerContactLegalCounsel',
                key: 'RecordTypeName',
                label: 'RecordTypeName',
                value: 'Legal Counsel',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactLegalCounsel',
                key: 'RecordTypeId',
                label: 'RecordTypeId',
                value: recordTypeId,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactLegalCounsel',
                rowGroupBy: 'CustomerContact',
                col: 12,
                key: 'CustomerContactForLegalCounsel_100',
                label: 'Customer Contact for Legal Counsel',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),

        ];

        questions = questions.concat(this.buildCustomerContactCommonFields());
        return questions.sort((a, b) => a.order - b.order);
    }

    buildCustomerContactSettlementInvoicesFields(cobamRole: string, recordTypeId: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                section: 'CustomerContactSettlementInvoices',
                key: 'RecordTypeName',
                label: 'RecordTypeName',
                value: 'Settlement',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactSettlementInvoices',
                key: 'RecordTypeId',
                label: 'RecordTypeId',
                value: recordTypeId,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactSettlementInvoices',
                rowGroupBy: 'CustomerContact',
                col: 12,
                key: 'CustomerContactForSettlementInvoices_100',
                label: 'Customer Contact for Settlement Invoices',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),

        ];

        questions = questions.concat(this.buildCustomerContactCommonFields());
        return questions.sort((a, b) => a.order - b.order);
    }

    buildCustomerContactFXConfirmationsFields(cobamRole: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'CustomerContactFXConfirmations',
                rowGroupBy: 'CustomerContact',
                col: 12,
                key: 'FXConfirmations_100',
                label: 'FX Confirmations',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),
            //new OptionsQuestion({
            new DropdownQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'FX_Confirmations__c',
                label: 'FX Confirmations',
                order: 200,
                defaultOption: '',
                mandatory: true,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'FX Online', value: 'FX Online' },
                    { key: 'Email', value: 'Email' }
                ]
            }),
            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'Fx_Conf_Contact_Name__c',
                label: 'Contact Name',
                order: 300,
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Confirmations__c',
                                value: 'Email',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Confirmations__c',
                                value: 'Email',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            this.buildEmptyField(400),
            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'Fx_Conf_Contact_Email__c',
                label: 'Email',
                order: 500,
                mandatory: true,
                relation: [
                    {
                        action: 'ENABLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Confirmations__c',
                                value: 'Email',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'REQUIRED',
                        connective: 'AND',
                        when: [
                            {
                                id: 'FX_Confirmations__c',
                                value: 'Email',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'CustomerContactFXConfirmations',
                rowGroupBy: 'CustomerContact',
                col: 12,
                key: 'FXMTMReporting_100',
                label: 'FX MTM Reporting',
                value: '',
                order: 600,
                disabled: true,
                css: 'title'
            }),
            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'FX_Contact_Name_1__c',
                label: 'Contact Name 1',
                order: 700,
                mandatory: true
            }),
            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'FX_Contact_Email_Address1__c',
                label: 'Contact Email Address 1',
                order: 800,
                mandatory: true
            }),

            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'FX_Contact_Name_2__c',
                label: 'Contact Name 2',
                order: 900,
                mandatory: true
            }),
            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'FX_Contact_Email_Address2__c',
                label: 'Contact Email Address 2',
                order: 1000,
                mandatory: true
            }),

            new LabelQuestion({
                section: 'CustomerContactFXConfirmations',
                rowGroupBy: 'CustomerContact',
                col: 12,
                key: 'FXCustomerDocuments_100',
                label: 'Who will send the documents to the customer?',
                value: '',
                order: 1100,
                disabled: true,
                css: 'title'
            }),
            new DropdownQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'Who_will_send_the_docs_to_the_customer__c',
                label: 'Who will send the documents to the customer?',
                order: 1200,
                defaultOption: '',
                mandatory: true,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'DoCO - Static data to send directly to customer', value: 'DoCO - Static data to send directly to customer' },
                    { key: 'DoCO - CPMG to send to customer', value: 'DoCO - CPMG to send to customer' },
                    { key: 'Front Office to send to customer', value: 'Front Office to send to customer' }

                ]
            }),
            new TextboxQuestion({
                section: 'CustomerContactFXConfirmations',
                key: 'Additional_Instructions__c',
                label: 'Additional Instructions',
                order: 1300,
            })

        ];

        //questions = questions.concat(this.buildCustomerContactCommonFields(true));
        return questions.sort((a, b) => a.order - b.order);
    }

    // buildCustomerContactFXMTMReportingFields(cobamRole: string){
    //     let questions: QuestionBase<any>[] = [];

    //     questions = [
    //         new LabelQuestion({
    //             key: 'User_Role',
    //             label: 'User Role',
    //             value: cobamRole,
    //             order: 1,
    //             displayNone: true
    //         }),
    //         new LabelQuestion({
    //             rowGroupBy: 'CustomerContact',
    //             col: 12,
    //             key: 'FXMTMReporting_100',
    //             label: 'FX MTM Reporting',
    //             value: '',
    //             order: 100,
    //             disabled: true,
    //             css: 'title'
    //         }),
    //         new TextboxQuestion({
    //             key: 'FX_Contact_Name_1__c',
    //             label: 'Contact Name 1',
    //             order: 200,
    //             mandatory: true
    //         }),
    //         new TextboxQuestion({
    //             key: 'FX_Contact_Email_Address1__c',
    //             label: 'Contact Email Address 1',
    //             order: 300,
    //             mandatory: true
    //         }),

    //         new TextboxQuestion({
    //             key: 'FX_Contact_Name_2__c',
    //             label: 'Contact Name 2',
    //             order: 400,
    //             mandatory: true
    //         }),
    //         new TextboxQuestion({
    //             key: 'FX_Contact_Email_Address2__c',
    //             label: 'Contact Email Address 2',
    //             order: 500,
    //             mandatory: true
    //         }),
    //     ];

    //     return questions.sort((a, b) => a.order - b.order);
    // }

    // buildCustomerContactFXCustomerDocumentsFields(cobamRole: string){
    //     let questions: QuestionBase<any>[] = [];

    //     questions = [
    //         new LabelQuestion({
    //             key: 'User_Role',
    //             label: 'User Role',
    //             value: cobamRole,
    //             order: 1,
    //             displayNone: true
    //         }),
    //         new LabelQuestion({
    //             rowGroupBy: 'CustomerContact',
    //             col: 12,
    //             key: 'FXCustomerDocuments_100',
    //             label: 'Who will send the documents to the customer?',
    //             value: '',
    //             order: 100,
    //             disabled: true,
    //             css: 'title'
    //         }),
    //         new DropdownQuestion({
    //             key: 'Who_will_send_the_docs_to_the_customer__c',
    //             label: 'Who will send the documents to the customer?',
    //             order: 200,
    //             defaultOption: '',
    //             mandatory: true,
    //             options: [
    //                 { key: '', value: '--None--' },
    //                 { key: 'DoCO - Static data to send directly to customer', value: 'DoCO - Static data to send directly to customer' },
    //                 { key: 'DoCO - CPMG to send to customer', value: 'DoCO - CPMG to send to customer' },
    //                 { key: 'Front Office to send to customer', value: 'Front Office to send to customer' }

    //             ]
    //         }),
    //         new TextboxQuestion({
    //             key: 'Additional_Instructions__c',
    //             label: 'Additional Instructions',
    //             order: 300,
    //         })
    //     ];

    //     return questions.sort((a, b) => a.order - b.order);
    // }


    private buildCustomerContactCommonFields(areContactFieldsRequired: boolean = false) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'RecordType',
                label: 'RecordType',
                value: '',
                order: 1,
                displayNone: true
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Contact_Name__c',
                label: 'Contact Name',
                order: 200,
                mandatory: areContactFieldsRequired
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Contact_Title__c',
                label: 'Contact Title',
                order: 300
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Email__c',
                label: 'Email',
                order: 400,
                placeholder: areContactFieldsRequired ? "Either Email or Fax is required" : '',
                mandatory: areContactFieldsRequired
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Phone__c',
                label: 'Phone',
                order: 500,
                mandatory: areContactFieldsRequired
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Fax__c',
                label: 'Fax',
                order: 600,
                placeholder: areContactFieldsRequired ? "Either Email or Fax is required" : '',
                mandatory: areContactFieldsRequired
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Address1__c',
                label: 'Address',
                order: 700
            }),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'City__c',
                label: 'City',
                order: 800
            }),
            this.buildState(900),
            this.buildCanadianProvince(900),
            new TextboxQuestion({
                section: 'CustomerContactDocumentationDetails',
                key: 'Zip__c',
                label: 'Zip',
                order: 1000,
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'Country__c',
                                value: 'US - UNITED STATES',
                                operator: '==='
                            }
                        ]
                    },
                ]
            }),
            this.buildPostalCode(1000),
            this.buildCountry(1100, false)
        ];
        return questions.sort((a, b) => a.order - b.order);
    }


    buildLoanAndCreditSupportFields(cobamRole: string, cmrId?: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'LoanAndCreditSupportDetails',
                rowGroupBy: 'LoanAndCreditSupport',
                col: 12,
                key: 'LoanFacilityInformation_100',
                label: 'Loan Facility Information',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Loan_Facility__c',
                label: 'Loan Facility',
                order: 200,
                mandatory: true,
                options: [
                    { key: 'None', value: 'None' },
                    { key: 'ExistingOrAnticipated', value: 'ExistingOrAnticipated' }
                ]
            }),
            new DropdownQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'WF_Loan_Entity__c',
                label: 'WF Loan Entity',
                defaultOption: '',
                order: 300,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Wells Fargo Bank, N.A.', value: 'Wells Fargo Bank, N.A.' },
                    { key: 'Wells Fargo Financial Leasing, Inc.', value: 'Wells Fargo Financial Leasing, Inc.' },
                    { key: 'Wells Fargo Preferred Capital, Inc.', value: 'Wells Fargo Preferred Capital, Inc.' },
                    { key: 'Other', value: 'Other' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Loan_Facility__c',
                                value: 'ExistingOrAnticipated',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'WF_Loan_Entity_Other__c',
                label: 'WF Loan Entity Other',
                order: 400,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'AND',
                        when: [
                            {
                                id: 'WF_Loan_Entity__c',
                                value: 'Other',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Syndicated__c',
                label: 'Syndicated',
                mandatory: true,
                defaultOption: '',
                order: 500,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Loan_Facility__c',
                                value: 'ExistingOrAnticipated',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DatePickerQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Date_of_Loan_Agreement__c',
                label: 'Date of Loan Agreement',
                order: 600,
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Loan_Facility__c',
                                value: 'ExistingOrAnticipated',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Loan_Facility__c',
                                value: 'ExistingOrAnticipated',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextAreaQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Comments__c',
                label: 'Comments',
                order: 700
            }),
            new LabelQuestion({
                section: 'LoanAndCreditSupportDetails',
                rowGroupBy: 'LoanAndCreditSupport',
                col: 12,
                key: 'CreditSupport_100',
                label: 'Credit Support ',
                value: '',
                order: 800,
                disabled: true,
                css: 'title'
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Will_Credit_Approval_require_derivative__c',
                label: `Will Credit Approval require derivative transactions to be secured?:* `,
                mandatory: true,
                order: 900,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new SingleCheckboxQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Via_loan_facility__c',
                label: 'Via loan facility(i.e. Security Agreement/Deed of Trust/Mortgage)',
                value: false,
                order: 1000,
                relation: [
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Will_Credit_Approval_require_derivative__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new SingleCheckboxQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'WFS_Prepare_a_Credit_Su__c',
                label: 'WFS Documentation to prepare a Credit Support Annex (e.g. Cash Collateral held by WFS)',
                value: false,
                order: 1100,
                relation: [
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Will_Credit_Approval_require_derivative__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Does_Credit_Support_Annex_need_to_be_VM__c',
                label: `Does Credit Support Annex need to be VM Compliant?`,
                order: 1200,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                // relation: [
                //     {
                //         action: 'ENABLE',
                //         //connective: 'AND',
                //         when: [
                //             {
                //                 id: 'WFS_Prepare_a_Credit_Su__c',
                //                 value: 'true',
                //                 operator: '=='
                //             }
                //         ]
                //     }
                // ]
            }),
            new TextAreaQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Credit_Support_Comments__c',
                label: 'Comments',
                order: 1300
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Require_derivative_transaction__c',
                label: `Will the Line of Business credit approvers require derivative transactions to be guaranteed?`,
                mandatory: true,
                order: 1400,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'SwapGuarantorVerification__c',
                label: `Will any Guarantors be required to complete a Swap Guarantor Verification Form in accordance with Wells Fargo's Essential Guarantor policy?`,
                order: 1500,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Is_any_guarantor_a_trust__c',
                label: `Is any guarantor a trust?`,
                order: 1600,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Transaction_guaranteed_via_loan_facility__c',
                label: `Is the derivative transaction guaranteed via the loan facility?`,
                order: 1700,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Documentation_to_prepare_a_guarantee__c',
                label: `Is WFS Documentation to prepare a guarantee?`,
                order: 1800,
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextAreaQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Legal_Name_of_Guarantor_s__c',
                label: 'Legal Name of Guarantor(s)',
                order: 1900,
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Require_derivative_transaction__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextAreaQuestion({
                section: 'LoanAndCreditSupportDetails',
                key: 'Credit_Support_Comments_2__c',
                label: 'Comments',
                order: 2000
            }),
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildEChannelsFields(cobamRole: string) {
        let questions: QuestionBase<any>[] = [];

        questions = [
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'EChannels',
                key: 'IsFxOnline',
                label: '',
                order: 1,
                displayNone: true
            }),
            new LabelQuestion({
                section: 'EChannels',
                rowGroupBy: 'EChannels',
                col: 12,
                key: 'EChannels_100',
                label: 'FX Specific Channels',
                value: '',
                order: 100,
                disabled: true,
                css: 'title'
            }),
            new LabelQuestion({
                section: 'EChannels',
                key: 'MarketerFXSpecialist',
                label: 'FX Specialist',
                disabled: true,
                order: 100
            }),
            new LabelQuestion({
                section: 'EChannels',
                key: 'RelationshipManager',
                label: 'Relationship Manager',
                disabled: true,
                order: 200
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Company_Names__c',
                label: 'Company Name(s)',
                order: 300,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Company_CMR_IDs__c',
                label: 'Company CMR ID(s)',
                order: 400,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new OptionsInlineQuestion({
                section: 'EChannels',
                key: 'Is_the_counterparty_already_setup_on_CEO__c',
                label: 'Is the counterparty already setup on CEO?',
                options: [
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                order: 500,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'CEO_Company_ID__c',
                label: 'CEO ID',
                order: 600,
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Is_the_counterparty_already_setup_on_CEO__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Is_the_counterparty_already_setup_on_CEO__c',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'EChannels',
                key: 'Who_will_perform_the_CEO_ID_setup__c',
                label: 'Who will perform the CEO ID setup',
                order: 700,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'TMSC', value: 'TMSC' },
                    { key: 'FXOL', value: 'FiduFXOLciary' }
                ],
                relation: [
                    {
                        action: 'REQUIRED',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Is_the_counterparty_already_setup_on_CEO__c',
                                value: 'No',
                                operator: '==='
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        //connective: 'AND',
                        when: [
                            {
                                id: 'Is_the_counterparty_already_setup_on_CEO__c',
                                value: 'No',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'EChannels',
                key: 'Part_of_a_Family_Setup__c',
                label: 'Part of a Family Setup',
                order: 800,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Parent_CMR_ID_for_a_Family_Setup__c',
                label: 'Parent CMR ID for a Family Setup',
                order: 900
            }),
            new DropdownQuestion({
                section: 'EChannels',
                key: 'Net_New_FXOL_Implementation__c',
                label: 'Net New FXOL Implementation',
                order: 1000,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'EChannels',
                key: 'Add_Account_to_FXOL_Setup__c',
                label: 'Add Account to FXOL Setup',
                order: 1100,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
                section: 'EChannels',
                key: 'ProvideTwoCounterpartyAdministratorNames',
                label: 'Provide two Counterparty administrator names',
                order: 1200,
                disabled: true,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Counterparty_Name1__c',
                label: 'Name 1',
                order: 1300,
                mandatory: true,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Counterparty_Name2__c',
                label: 'Name 2',
                order: 1400,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'EChannels',
                key: 'IndicateStatusOfDualCustodyException__c',
                label: 'OR Indicate status of Dual Custody Exception',
                order: 1500,
                defaultOption: '',
                mandatory: true,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Waiver Approved', value: 'Waiver Approved' },
                    { key: 'Not Required', value: 'Not Required' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new MultiselectQuestion({
                section: 'EChannels',
                key: 'Waiver_Type__c',
                label: 'Waiver Type',
                defaultOption: 'None selected',
                mandatory: true,
                order: 1600,
                options: [
                    { key: 'Transactional', value: 'Transactional' },
                    { key: 'Administrative', value: 'Administrative' }
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        when: [
                            {
                                id: 'IndicateStatusOfDualCustodyException__c',
                                value: 'Waiver Approved'
                            }
                        ]
                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Company_Contact_Names__c',
                label: 'Company Contact Name(s)',
                order: 1700,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Company_Contact_Email__c',
                label: 'Company Contact Email',
                order: 1800,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'Company_Contact_Phone__c',
                label: 'Company Contact Phone',
                order: 1900,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new DropdownQuestion({
                section: 'EChannels',
                key: 'MCA_Implementation__c',
                label: 'MCA Implementation',
                order: 2000,
                defaultOption: '',
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Yes', value: 'Yes' },
                    { key: 'No', value: 'No' }
                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'MCA_Accounts__c',
                label: 'MCA Account Number(s)',
                order: 2100,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new TextboxQuestion({
                section: 'EChannels',
                key: 'DDA_Account_Numbers__c',
                label: 'DDA Account Number(s)',
                order: 2200,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            new MultiselectQuestion({
                section: 'EChannels',
                key: 'Foreign_Exchange_Products__c',
                label: 'Additional Online FX products (Select all that apply)',
                defaultOption: 'None selected',
                mandatory: false,
                order: 2300,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `**Select if not setting trades against DDA/MCA/already set-up Debit ACH. *Forward Tenor requests REQUIRE a credit line be in place PRIOR to submitting this form. Do not request FORWARD tenor without validating that an approved forward line is in place in Adaptive.`,
                options: [
                    { key: 'Spot', value: 'Spot' },
                    { key: 'GCC (Global Check Clearing)', value: 'GCC (Global Check Clearing)' },
                    { key: 'Foreign Draft', value: 'Foreign Draft' },
                    { key: 'Forward/Window/Swap', value: 'Forward/Window/Swap' },
                    { key: 'Netting', value: 'Netting' },
                    { key: 'Wire Funding', value: 'Wire Funding' }

                ],
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'IsFxOnline',
                                value: 'Yes',
                                operator: '==='
                            }
                        ]
                    }
                ]
            }),
            // new LabelQuestion({
            //     key: 'FXOLStatusLastUpdatedBy',
            //     label: 'FXOL Status Last Updated by',
            //     order: 2400,
            //     disabled: true,
            // }),
        ];

        return questions.sort((a, b) => a.order - b.order);
    }

    buildGovermentIdTypeOptions() {
        return [
            { key: '', value: '--None--' },
            { key: 'AR - Adoption Record', value: 'AR - Adoption Record' },
            { key: 'AIREG - Anguilla Company Number', value: 'AIREG - Anguilla Company Number' },
            { key: 'ARTAX - Argentina Taxpayer Id', value: 'ARTAX - Argentina Taxpayer Id' },
            { key: 'AUT - Autorites Des Marches Financieres', value: 'AUT - Autorites Des Marches Financieres' },
            { key: 'AUBN - Australian Business Number', value: 'AUBN - Australian Business Number' },
            { key: 'AUCR - Austrian Commercial Register Id', value: 'AUCR - Austrian Commercial Register Id' },
            { key: 'AUFMA - Austrian Financial Market Authority Routing Number', value: 'AUFMA - Austrian Financial Market Authority Routing Number' },
            { key: 'AUVAT - Austrian Tax (VAT) Id Number', value: 'AUVAT - Austrian Tax (VAT) Id Number' },
            { key: 'BAHINC - Bahamas Incorporation Number', value: 'BAHINC - Bahamas Incorporation Number' },
            { key: 'BARREG - Barbados company registrar', value: 'BARREG - Barbados company registrar' },
            { key: 'BAHBL - Bahamas Business License', value: 'BAHBL - Bahamas Business License' },
            { key: 'BAHELP - Bahamas Exempted LP Act No.', value: 'BAHELP - Bahamas Exempted LP Act No.' },
            { key: 'BELGIUM - BELGIUM COMPANY NUMBER', value: 'BELGIUM - BELGIUM COMPANY NUMBER' },
            { key: 'BHCOM - Bahrain Commerce Registration No.', value: 'BHCOM - Bahrain Commerce Registration No.' },
            { key: 'BMGN - Bermuda Government Number', value: 'BMGN - Bermuda Government Number' },
            { key: 'BMINC - Bermuda Incorporation Number', value: 'BMINC - Bermuda Incorporation Number' },
            { key: 'BONIT - Bolivian NIT', value: 'BONIT - Bolivian NIT' },
            { key: 'BZREG - Brasilian Registration ID', value: 'BZREG - Brasilian Registration ID' },
            { key: 'BVIREG - British Virgin Islands Corporate Registration Number', value: 'BVIREG - British Virgin Islands Corporate Registration Number' },
            { key: 'CBN - Canadian Business Number', value: 'CBN - Canadian Business Number' },
            { key: 'CVMQ - Canadian Commission des Valuers Mobilieres du Quebec', value: 'CVMQ - Canadian Commission des Valuers Mobilieres du Quebec' },
            { key: 'CNFD - Canadian Fed Docs ID', value: 'CNFD - Canadian Fed Docs ID' },
            { key: 'CNRD - Canadian NRD Number', value: 'CNRD - Canadian NRD Number' },
            { key: 'CRA - Canadian Revenue Agency Nbr', value: 'CRA - Canadian Revenue Agency Nbr' },
            { key: 'CAYMA - Cayman Islands Monetary Authority', value: 'CAYMA - Cayman Islands Monetary Authority' },
            { key: 'CAYREG - Cayman Registrar of Companies', value: 'CAYREG - Cayman Registrar of Companies' },
            { key: 'CAYPART - Cayman Registrar of Limited Partnerships', value: 'CAYPART - Cayman Registrar of Limited Partnerships' },
            { key: 'CAYTRU - Cayman Registrar of Trusts', value: 'CAYTRU - Cayman Registrar of Trusts' },
            { key: 'CD - Cedula', value: 'CD - Cedula' },
            { key: 'CD3 - CD3 Approved', value: 'CD3 - CD3 Approved' },
            { key: 'CB - Central Bank Issued Id', value: 'CB - Central Bank Issued Id' },
            { key: 'CBRD - Central Business Register of Denmark', value: 'CBRD - Central Business Register of Denmark' },
            { key: 'CHRUT - Chilean Rol Unico Tributario', value: 'CHRUT - Chilean Rol Unico Tributario' },
            { key: 'CHTX - Chilean Tax Id', value: 'CHTX - Chilean Tax Id' },
            { key: 'CNID - Chinese Institution Id', value: 'CNID - Chinese Institution Id' },
            { key: 'CRUE - Columbian RUE - Consulta Registro Mercantil', value: 'CRUE - Columbian RUE - Consulta Registro Mercantil' },
            { key: 'COTX - Colombian Tax ID', value: 'COTX - Colombian Tax ID' },
            { key: 'HREC - Croatian Chamber of Economy Number', value: 'HREC - Croatian Chamber of Economy Number' },
            { key: 'CYPRC - Cypriot Companies Registration Authority Number', value: 'CYPRC - Cypriot Companies Registration Authority Number' },
            { key: 'CZBK - Czech Republic Bank Identity Code', value: 'CZBK - Czech Republic Bank Identity Code' },
            { key: 'DKID - Danish Trade & Business Auth. ID', value: 'DKID - Danish Trade & Business Auth. ID' },
            { key: 'DOTX - Dominican Republic RNC (tax id)', value: 'DOTX - Dominican Republic RNC (tax id)' },
            { key: 'DL - Drivers License', value: 'DL - Drivers License' },
            { key: 'N/DTR ID - Netherlands/Dutch Trade Register ID', value: 'N/DTR ID - Netherlands/Dutch Trade Register ID' },
            { key: 'NLCC - Dutch Chamber of Commerce Id', value: 'NLCC - Dutch Chamber of Commerce Id' },
            { key: 'NLCR - Dutch Commercial Register Number', value: 'NLCR - Dutch Commercial Register Number' },
            { key: 'DAFM - Dutch (AFM) Autoriteit Financiele Markten', value: 'DAFM - Dutch (AFM) Autoriteit Financiele Markten' },
            { key: 'DSVM - Dutch SVM Code', value: 'DSVM - Dutch SVM Code' },
            { key: 'NLEURO - Dutch EURONEXD Id', value: 'NLEURO - Dutch EURONEXD Id' },
            { key: 'NLTX - Dutch Tax Number', value: 'NLTX - Dutch Tax Number' },
            { key: 'ECTX - Ecuador Taxpayer ID', value: 'ECTX - Ecuador Taxpayer ID' },
            { key: 'ESNIT - NIT El Salvador', value: 'ESNIT - NIT El Salvador' },
            { key: 'NORORG - Norway Organization Number (Bronnoysundregistrene)', value: 'NORORG - Norway Organization Number (Bronnoysundregistrene)' },
            { key: 'FGIIN - Foreign Govt Issued Identification Number', value: 'FGIIN - Foreign Govt Issued Identification Number' },
            { key: 'FCRN - French Company Registration No.', value: 'FCRN - French Company Registration No.' },
            { key: 'RCS - FRENCH RCS/INFOGREFFE', value: 'RCS - FRENCH RCS/INFOGREFFE' },
            { key: 'GBA-FIN - German BA-FIN Registration No.', value: 'GBA-FIN - German BA-FIN Registration No.' },
            { key: 'HRB - German Handels Register/Trade Register', value: 'HRB - German Handels Register/Trade Register' },
            { key: 'DETX - German Tax Registration No.', value: 'DETX - German Tax Registration No.' },
            { key: 'GTRD - German Trade Registration Number', value: 'GTRD - German Trade Registration Number' },
            { key: 'GRREG - Greek Company Registration Number', value: 'GRREG - Greek Company Registration Number' },
            { key: 'GUATX - Guatemalan Tax Id', value: 'GUATX - Guatemalan Tax Id' },
            { key: 'GKRN - Guernsey CI Incorporation Registration No.', value: 'GKRN - Guernsey CI Incorporation Registration No.' },
            { key: 'HRTN - Honduras Registro Tributario Nacional', value: 'HRTN - Honduras Registro Tributario Nacional' },
            { key: 'HKRN - Hong Kong Business Registration Number', value: 'HKRN - Hong Kong Business Registration Number' },
            { key: 'HKBL - Hong Kong Monetary Auth License', value: 'HKBL - Hong Kong Monetary Auth License' },
            { key: 'HKSFC - Hong Kong Securities & Futures Commission', value: 'HKSFC - Hong Kong Securities & Futures Commission' },
            { key: 'HFSA - Hungarian Financial Supervisory Auth ID No.', value: 'HFSA - Hungarian Financial Supervisory Auth ID No.' },
            { key: 'INSL - Insurance License ID', value: 'INSL - Insurance License ID' },
            { key: 'IBCN - International Business Company Number', value: 'IBCN - International Business Company Number' },
            { key: 'IRCN - Ireland Registered Company Number', value: 'IRCN - Ireland Registered Company Number' },
            { key: 'ICID - Israeli Corporate ID', value: 'ICID - Israeli Corporate ID' },
            { key: 'IFSRA - Irish Banking Regulator Id', value: 'IFSRA - Irish Banking Regulator Id' },
            { key: 'ITCED - Italian CED BORA Id', value: 'ITCED - Italian CED BORA Id' },
            { key: 'ITCR - Italian Commerical Registry of Trieste', value: 'ITCR - Italian Commerical Registry of Trieste' },
            { key: 'JPBK - Bank of Japan Clearing Member Certification No.', value: 'JPBK - Bank of Japan Clearing Member Certification No.' },
            { key: 'JAPCO NUM - JAPAN COMPANY NUMBER', value: 'JAPCO NUM - JAPAN COMPANY NUMBER' },
            { key: 'JFSA - Japanese Financial Services Agency (FSA)', value: 'JFSA - Japanese Financial Services Agency (FSA)' },
            { key: 'JFSC - JFSC COMPANIES ID', value: 'JFSC - JFSC COMPANIES ID' },
            { key: 'JMREG - Jamaican Registar of Companies Id', value: 'JMREG - Jamaican Registar of Companies Id' },
            { key: 'JRCN - Jersey CI Registered Company Number', value: 'JRCN - Jersey CI Registered Company Number' },
            { key: 'KOR - Korea (Republic of) Tax Id', value: 'KOR - Korea (Republic of) Tax Id' },
            { key: 'CRC - Kuwait Commerical Registration Certificate', value: 'CRC - Kuwait Commerical Registration Certificate' },
            { key: 'LABK - Laos State Bank Id', value: 'LABK - Laos State Bank Id' },
            { key: 'LUXBR - Luxembourg Business Registration Number', value: 'LUXBR - Luxembourg Business Registration Number' },
            { key: 'LUXREG - Le Registre du Commerce Luxembourg', value: 'LUXREG - Le Registre du Commerce Luxembourg' },
            { key: 'LUXTX - Luxembourg Tax Id', value: 'LUXTX - Luxembourg Tax Id' },
            { key: 'CSSF - Commission de Surveillance du Secteur Financier Luxembourg', value: 'CSSF - Commission de Surveillance du Secteur Financier Luxembourg' },
            { key: 'LUXREC - Recueil Des Societes et Associations', value: 'LUXREC - Recueil Des Societes et Associations' },
            { key: 'MORN - Macau Business Registration No.', value: 'MORN - Macau Business Registration No.' },
            { key: 'MSE - Madrid Stock Exchange Firm Code No.', value: 'MSE - Madrid Stock Exchange Firm Code No.' },
            { key: 'MALY - Malaysian Company ID', value: 'MALY - Malaysian Company ID' },
            { key: 'MD - Marriage or Divorce Record', value: 'MD - Marriage or Divorce Record' },
            { key: 'MAUR - MAURITIUS GOV\'T ID', value: 'MAUR - MAURITIUS GOV\'T ID' },
            { key: 'MC - Matricula Consular', value: 'MC - Matricula Consular' },
            { key: 'MXRFC - Mexican RFC', value: 'MXRFC - Mexican RFC' },
            { key: 'MR - Military Records', value: 'MR - Military Records' },
            { key: 'NFTX - Netherlands Foreign Tax id', value: 'NFTX - Netherlands Foreign Tax id' },
            { key: 'NZCN - New Zealand Company Number', value: 'NZCN - New Zealand Company Number' },
            { key: 'KNID - St Kitts/Nevis Company ID', value: 'KNID - St Kitts/Nevis Company ID' },
            { key: 'MONBL - Montserrat Fin Services Bus License', value: 'MONBL - Montserrat Fin Services Bus License' },
            { key: 'PRUCN - Panama RUC Number', value: 'PRUCN - Panama RUC Number' },
            { key: 'PP - Passport', value: 'PP - Passport' },
            { key: 'POLCB - Polish Central Bank Head Office Id', value: 'POLCB - Polish Central Bank Head Office Id' },
            { key: 'PERS - Persoons Nummer - Aruba', value: 'PERS - Persoons Nummer - Aruba' },
            { key: 'PERUC - Peruvian RUC number', value: 'PERUC - Peruvian RUC number' },
            { key: 'PHIR - Philippine Internal Revenue Id', value: 'PHIR - Philippine Internal Revenue Id' },
            { key: 'PORTX - Portugal Tax ID', value: 'PORTX - Portugal Tax ID' },
            { key: 'RA - Resident Alien Card', value: 'RA - Resident Alien Card' },
            { key: 'SLOV TAX - SLOVENIAN TAX CODE', value: 'SLOV TAX - SLOVENIAN TAX CODE' },
            { key: 'RMBK - Romanian Central Bank ID', value: 'RMBK - Romanian Central Bank ID' },
            { key: 'SC - School ID Card', value: 'SC - School ID Card' },
            { key: 'SCOTID - Scotland Government ID', value: 'SCOTID - Scotland Government ID' },
            { key: 'SOS - Secretary of State File ID', value: 'SOS - Secretary of State File ID' },
            { key: 'SEC - Securities Exch Comm Number', value: 'SEC - Securities Exch Comm Number' },
            { key: 'SPCO - Singapore Company Number', value: 'SPCO - Singapore Company Number' },
            { key: 'SACRA - SINGAPORE ACCOUNTING & CORPORATE REGULATORY AUTHORITY', value: 'SACRA - SINGAPORE ACCOUNTING & CORPORATE REGULATORY AUTHORITY' },
            { key: 'SPMA - Monetary Authority of Singapore', value: 'SPMA - Monetary Authority of Singapore' },
            { key: 'SBID - Spanish Bank Registration No.', value: 'SBID - Spanish Bank Registration No.' },
            { key: 'ZABK - South African Banking License', value: 'ZABK - South African Banking License' },
            { key: 'SISF - Spanish Investment Services Firm Official Reg. No.', value: 'SISF - Spanish Investment Services Firm Official Reg. No.' },
            { key: 'ESTAX - Spanish Agencia Tributaria', value: 'ESTAX - Spanish Agencia Tributaria' },
            { key: 'SRTX - Suriname Tax Id', value: 'SRTX - Suriname Tax Id' },
            { key: 'SWOR - Swedish Organization Registration Number', value: 'SWOR - Swedish Organization Registration Number' },
            { key: 'FOJ - Swiss Federal Office of Justice Id', value: 'FOJ - Swiss Federal Office of Justice Id' },
            { key: 'SBC - Swiss Banking Commission', value: 'SBC - Swiss Banking Commission' },
            { key: 'SAT - Superintendencia de Administración Tributaria', value: 'SAT - Superintendencia de Administración Tributaria' },
            { key: 'RN - Swiss Registration Number', value: 'RN - Swiss Registration Number' },
            { key: 'VQF ID - Switzerland VQF, Zug ID', value: 'VQF ID - Switzerland VQF, Zug ID' },
            { key: 'TWBL - Taiwan Ministry of Finance Bus License', value: 'TWBL - Taiwan Ministry of Finance Bus License' },
            { key: 'TTC - Trinidad & Tobago Company Number', value: 'TTC - Trinidad & Tobago Company Number' },
            { key: 'TCID - Turks & Caicos Company Registration Number', value: 'TCID - Turks & Caicos Company Registration Number' },
            { key: 'TKCHAM - Turkish Chamber of Commerce', value: 'TKCHAM - Turkish Chamber of Commerce' },
            { key: 'UAEID - United Arab Emirates ID', value: 'UAEID - United Arab Emirates ID' },
            { key: 'UKCERT - UK Certificate of Incorporation', value: 'UKCERT - UK Certificate of Incorporation' },
            { key: 'UKCH - UK Companies House Id', value: 'UKCH - UK Companies House Id' },
            { key: 'UK UTR - UK Unique Taxpayer Reference', value: 'UK UTR - UK Unique Taxpayer Reference' },
            { key: 'UKFCA - UK FCA Registration No', value: 'UKFCA - UK FCA Registration No' },
            { key: 'UKFSA - UK FSA Registration No.', value: 'UKFSA - UK FSA Registration No.' },
            { key: 'UK NIN - UK National Insurance No.', value: 'UK NIN - UK National Insurance No.' },
            { key: 'URUC - Uruguay Numero de RUC', value: 'URUC - Uruguay Numero de RUC' },
            { key: 'USSTID - US State Level id', value: 'USSTID - US State Level id' },
            { key: 'USTX - US Taxpayer Id', value: 'USTX - US Taxpayer Id' },
            { key: 'USRA - US Resident Alien Id', value: 'USRA - US Resident Alien Id' },
            { key: 'VENID - Venezuela Issued Id', value: 'VENID - Venezuela Issued Id' },
            { key: 'VENRIF - Venezuela RIF', value: 'VENRIF - Venezuela RIF' },
            { key: 'OCN - ONTARIO CORPORATION NUMBER', value: 'OCN - ONTARIO CORPORATION NUMBER' }
        ];
    }

    getClientType(clientTypeValue: string): string {
        let clientTypeVal: string;
        switch (clientTypeValue.trim()) {
            case "1":
                clientTypeVal = 'AFFILIATES';
                break;
            case "2":
                clientTypeVal = 'COMPANY';
                break;
            case "3":
                clientTypeVal = 'EDUCATIONAL ENTITY';
                break;
            case "4":
                clientTypeVal = 'ESTATES / TRUSTS / INDIVIDUALS';
                break;
            case "5":
                clientTypeVal = 'FINANCIAL INSTITUTION';
                break;
            case "6":
                clientTypeVal = 'FUNDS';
                break;
            case "7":
                clientTypeVal = 'HEALTHCARE';
                break;
            case "8":
                clientTypeVal = 'INSURANCE';
                break;
            case "9":
                clientTypeVal = 'INVESTMENT MANAGER';
                break;
            case "10":
                clientTypeVal = 'NON-PROFIT';
                break;
            case "11":
                clientTypeVal = 'PENSION / BENEFIT PLANS';
                break;
            case "12":
                clientTypeVal = 'SOVEREIGN / GOV / INTL ORG';
                break;
            default:
                clientTypeVal = '';
                break;
        }

        return clientTypeVal;
    }

    getClientSubType(clientSubTypeValue: string): string {
        let clientSubTypeVal: string;
        switch (clientSubTypeValue.trim()) {
            case "1":
                clientSubTypeVal = 'WF Affiliated Bank (WFBNA sub)';
                break;
            case "2":
                clientSubTypeVal = 'WF Affiliated Bank (Non-WFBNA sub)';
                break;
            case "3":
                clientSubTypeVal = 'WF Affiliated Non-Bank';
                break;
            case "4":
                clientSubTypeVal = 'Agriculture, Forestry, Fishing and Hunting';
                break;
            case "5":
                clientSubTypeVal = 'Air Transportation';
                break;
            case "6":
                clientSubTypeVal = 'Arts, Entertainment and Recreation';
                break;
            case "7":
                clientSubTypeVal = 'Bearer Share Company';
                break;
            case "8":
                clientSubTypeVal = 'Construction';
                break;
            case "9":
                clientSubTypeVal = 'Consumer Financing';
                break;
            case "10":
                clientSubTypeVal = 'Convenience Stores';
                break;
            case "11":
                clientSubTypeVal = 'Dealers in High-Value Goods';
                break;
            case "12":
                clientSubTypeVal = 'Deep Sea Freight Transportation';
                break;
            case "13":
                clientSubTypeVal = 'Energy / Utilities';
                break;
            case "14":
                clientSubTypeVal = 'Equipment Financing';
                break;
            case "15":
                clientSubTypeVal = 'Food / Beverage Services';
                break;
            case "16":
                clientSubTypeVal = 'Gaming - Tribal';
                break;
            case "17":
                clientSubTypeVal = 'Gaming - Non-Tribal';
                break;
            case "18":
                clientSubTypeVal = 'Hotels/Lodging';
                break;
            case "19":
                clientSubTypeVal = 'Importer/Exporter';
                break;
            case "20":
                clientSubTypeVal = 'Land Based Transportation and Warehousing';
                break;
            case "21":
                clientSubTypeVal = 'Management of Companies and Enterprises';
                break;
            case "22":
                clientSubTypeVal = 'Manufacturing';
                break;
            case "23":
                clientSubTypeVal = 'Mining';
                break;
            case "24":
                clientSubTypeVal = 'Money Service Business';
                break;
            case "25":
                clientSubTypeVal = 'Parking Garage(s)';
                break;
            case "26":
                clientSubTypeVal = 'Pawnbroker';
                break;
            case "27":
                clientSubTypeVal = 'Professional Service Provider';
                break;
            case "28":
                clientSubTypeVal = 'Real Estate, Rental, and Leasing';
                break;
            case "29":
                clientSubTypeVal = 'Restaurant';
                break;
            case "30":
                clientSubTypeVal = 'Retail Trade';
                break;
            case "31":
                clientSubTypeVal = 'Special Purpose Entity / Vehicle';
                break;
            case "32":
                clientSubTypeVal = 'Technology, Media, Telecommunications';
                break;
            case "33":
                clientSubTypeVal = 'Third Party Payment Processors';
                break;
            case "34":
                clientSubTypeVal = 'Travel Agencies';
                break;
            case "35":
                clientSubTypeVal = 'Waste Management';
                break;
            case "36":
                clientSubTypeVal = 'Wholesale Trade';
                break;
            case "37":
                clientSubTypeVal = 'Private University';
                break;
            case "38":
                clientSubTypeVal = 'Private Schools (K-12)';
                break;
            case "39":
                clientSubTypeVal = 'Public Schools (K-12)';
                break;
            case "40":
                clientSubTypeVal = 'Public University';
                break;
            case "41":
                clientSubTypeVal = 'Business Trusts';
                break;
            case "42":
                clientSubTypeVal = 'Estates';
                break;
            case "43":
                clientSubTypeVal = 'Foreign Political Official';
                break;
            case "44":
                clientSubTypeVal = 'Individuals';
                break;
            case "45":
                clientSubTypeVal = 'Investment Clubs';
                break;
            case "46":
                clientSubTypeVal = 'Sole Proprietor';
                break;
            case "47":
                clientSubTypeVal = 'Trusts (Individual)';
                break;
            case "48":
                clientSubTypeVal = 'Bank Hold Co';
                break;
            case "49":
                clientSubTypeVal = 'Broker Dealer';
                break;
            case "50":
                clientSubTypeVal = 'Central Counterparty/Clearinghouse';
                break;
            case "51":
                clientSubTypeVal = 'Commercial Bank';
                break;
            case "52":
                clientSubTypeVal = 'Credit Card Company';
                break;
            case "53":
                clientSubTypeVal = 'Credit Union';
                break;
            case "54":
                clientSubTypeVal = 'Escrow Agent';
                break;
            case "55":
                clientSubTypeVal = 'Exchanges';
                break;
            case "56":
                clientSubTypeVal = 'Mortgage Originator';
                break;
            case "57":
                clientSubTypeVal = 'Non Govt Cooperative Bank';
                break;
            case "58":
                clientSubTypeVal = 'Proprietary Trading Desk';
                break;
            case "59":
                clientSubTypeVal = 'Thrifts / S&Ls';
                break;
            case "60":
                clientSubTypeVal = 'Trust Bank';
                break;
            case "61":
                clientSubTypeVal = 'Yankee Bank';
                break;
            case "62":
                clientSubTypeVal = 'Commodities Dealer';
                break;
            case "63":
                clientSubTypeVal = 'Investment Subsidiary';
                break;
            case "64":
                clientSubTypeVal = 'Fund of Funds';
                break;
            case "65":
                clientSubTypeVal = 'Hedge Fund';
                break;
            case "66":
                clientSubTypeVal = 'Money Market Fund';
                break;
            case "67":
                clientSubTypeVal = 'Mutual Fund';
                break;
            case "68":
                clientSubTypeVal = 'Private Equity Fund';
                break;
            case "69":
                clientSubTypeVal = 'REIT';
                break;
            case "70":
                clientSubTypeVal = 'For Profit Healthcare';
                break;
            case "71":
                clientSubTypeVal = 'Governmental Healthcare';
                break;
            case "72":
                clientSubTypeVal = 'Not for Profit Healthcare';
                break;
            case "73":
                clientSubTypeVal = 'Nursing Home/Rehab Center';
                break;
            case "74":
                clientSubTypeVal = 'Insurance';
                break;
            case "75":
                clientSubTypeVal = 'Insurance Hold Co';
                break;
            case "76":
                clientSubTypeVal = 'Re-Insurance';
                break;
            case "77":
                clientSubTypeVal = 'Bank Owned Investment Manager';
                break;
            case "78":
                clientSubTypeVal = 'Insurance Based Investment Manager';
                break;
            case "79":
                clientSubTypeVal = 'Non Bank Owned Investment Manager';
                break;
            case "80":
                clientSubTypeVal = 'CMBS Defeasance Advisor';
                break;
            case "81":
                clientSubTypeVal = 'Municipal Advisor';
                break;
            case "82":
                clientSubTypeVal = 'Charities - Non (Cultural/Membership/Services)';
                break;
            case "83":
                clientSubTypeVal = 'Charities - Cultural/Membership/Services';
                break;
            case "84":
                clientSubTypeVal = 'Endowments';
                break;
            case "85":
                clientSubTypeVal = 'Foundations';
                break;
            case "86":
                clientSubTypeVal = 'Religious Entity';
                break;
            case "87":
                clientSubTypeVal = 'Non Profit Corporation';
                break;
            case "88":
                clientSubTypeVal = 'City Govt Pension / Benefit';
                break;
            case "89":
                clientSubTypeVal = 'Company Pension / Benefit';
                break;
            case "90":
                clientSubTypeVal = 'County Govt Pension / Benefit';
                break;
            case "91":
                clientSubTypeVal = 'ERISA - Government';
                break;
            case "92":
                clientSubTypeVal = 'ERISA - Non Government';
                break;
            case "93":
                clientSubTypeVal = 'Federal Govt Pension / Benefit';
                break;
            case "94":
                clientSubTypeVal = 'IRAs';
                break;
            case "95":
                clientSubTypeVal = 'Non Profit Pension / Benefit';
                break;
            case "96":
                clientSubTypeVal = 'State Govt/Province Pension / Benefit';
                break;
            case "97":
                clientSubTypeVal = 'Union Pension / Benefit';
                break;
            case "98":
                clientSubTypeVal = 'Authorities/Other Municipal';
                break;
            case "99":
                clientSubTypeVal = 'City';
                break;
            case "100":
                clientSubTypeVal = 'County';
                break;
            case "101":
                clientSubTypeVal = 'Federal Reserve Banks / Central Banks';
                break;
            case "102":
                clientSubTypeVal = 'Govt Co-Operatives';
                break;
            case "103":
                clientSubTypeVal = 'Govt Development Bank';
                break;
            case "104":
                clientSubTypeVal = 'Govt Sponsored Enterprise';
                break;
            case "105":
                clientSubTypeVal = 'International / Supranational Org';
                break;
            case "106":
                clientSubTypeVal = 'Native American Tribe';
                break;
            case "107":
                clientSubTypeVal = 'Non US Embassy / Consulate';
                break;
            case "108":
                clientSubTypeVal = 'Sovereign / Nation';
                break;
            case "109":
                clientSubTypeVal = 'Sovereign Wealth Fund';
                break;
            case "110":
                clientSubTypeVal = 'State / Province';
                break;
            default:
                clientSubTypeVal = '';
                break;
        }
        return clientSubTypeVal;
    }
}