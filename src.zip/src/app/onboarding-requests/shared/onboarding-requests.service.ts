import { Injectable } from '@angular/core';
import { DropdownQuestion } from 'src/app/Common/dynamic-form-models/question-dropdown';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { MultiselectQuestion } from 'src/app/Common/dynamic-form-models/question-multiselect';
import { ApiService } from 'src/app/Common/services/api.service';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { LabelQuestion } from 'src/app/Common/dynamic-form-models/question-label';

@Injectable({
    providedIn: 'root'
})
export class OnboardingRequestsService {
    constructor(private apiService: ApiService) {
        console.log('Service instantiated');
    }

    getCurrentUser(): Observable<any> {
        return this.apiService.Get(
            environment.BASEURL + 'Lookup/currentUser'
        );
    }

    getColumnDefinations() {
        return this.apiService.Get(environment.BASEURL + 'Onboarding/getColumnDefinations/');
    }

    getRequests(paramObj: any): Observable<any> {
        let pgParams = new HttpParams();
        pgParams = pgParams.set(
          'searchInputModel',
          JSON.stringify(paramObj ? paramObj : undefined)
        );
        return this.apiService.Get(environment.BASEURL + 'Onboarding/GetRequests/', pgParams);
      }

    buildRequestFormFields() {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new DropdownQuestion({
                key: 'BuildType',
                label: 'Build Type',
                mandatory: true,
                defaultOption: 'New Legal & Bus Acc',
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `"New Legal & Bus Acc" is a net new client relationship that requires a legal (parent) and a business (child) account. A "Business Acc" assumes there is an existing relationship with the legal level account and only a new sub-account is required.`,
                order: 100,
                options: [
                    { key: 'New Legal & Bus Acc', value: 'New Legal & Bus Acc' },
                    { key: 'New Bus Acc Only', value: 'New Bus Acc Only' }
                ]
            }),
            new MultiselectQuestion({
                key: 'WFEntity',
                label: 'WF Entity',
                mandatory: true,
                defaultOption: 'None Selected',
                order: 200,
                options: [
                    { key: 'WFSIL', value: 'WFSIL' },
                    { key: 'WFSJ', value: 'WFSJ' },
                    { key: 'WFSAL', value: 'WFSAL' },
                    { key: 'WFSLLC - Singapore Branch', value: 'WFSLLC - Singapore Branch' },
                    { key: 'WFSLLC - US', value: 'WFSLLC - US' },
                    { key: 'WFBI', value: 'WFBI' },
                    { key: 'WFBNA - US', value: 'WFBNA - US' },
                    { key: 'WFBNA - LB', value: 'WFBNA - LB' },
                    { key: 'WFSC LTD', value: 'WFSC LTD' },
                    { key: 'WFS Prime Services', value: 'WFS Prime Services' },
                    { key: 'WFBNA - Canada Branch', value: 'WFBNA - Canada Branch' },
                    { key: 'WFSE', value: 'WFSE' }
                ]
            }),
            new DropdownQuestion({
                key: 'ProductType',
                label: 'Product Type',
                mandatory: true,
                defaultOption: '',
                selectionChange: true,
                order: 300,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Fixed Income', value: 'Fixed Income' },
                    { key: 'Equities', value: 'Equities' },
                    { key: 'Prime', value: 'Prime' },
                    { key: 'FCM', value: 'FCM' },
                    { key: 'Agency', value: 'Agency' },
                    { key: 'Loan Sales', value: 'Loan Sales' },
                    { key: 'Swaps', value: 'Swaps' },
                    { key: 'FX', value: 'FX' }
                ]
            }),
            new DropdownQuestion({
                key: 'SettlementType',
                label: 'Settlement Type',
                mandatory: true,
                defaultOption: '',
                selectionChange: true,
                parent: {
                    key: 'ProductType',
                    value: ''
                },
                order: 325,
                options: [
                    { key: '', value: '-- Please Select --', parentKey: 'Fixed Income' },
                    { key: 'Regular', value: 'Regular', parentKey: 'Fixed Income' },
                    { key: 'Extended', value: 'Extended', parentKey: 'Fixed Income' },
                    { key: 'Regular', value: 'Regular', parentKey: 'Equities' },
                    { key: 'Extended', value: 'Extended', parentKey: 'Loan Sales' },
                ],
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'ProductType',
                                value: 'Fixed Income'
                            },
                            {
                                id: 'ProductType',
                                value: 'Loan Sales'
                            },
                            {
                                id: 'ProductType',
                                value: 'Equities'
                            },
                            {
                                id: 'ProductType',
                                value: ''
                            }
                        ]
                    }
                ],
            }),
            new DropdownQuestion({
                key: 'ProductSettlementType',
                label: 'ProductSettlementType',
                defaultOption: '',
                displayNone: true,
                order: 350,
                parent: {
                    key: 'ProductType',
                    value: ''
                },
                showWhen: {
                    key: 'ProductType',
                    value: '1'
                },
                options: [
                    { key: 'Fixed IncomeExtended', value: 'Fixed IncomeExtended' },
                    { key: 'Fixed Income', value: 'Fixed Income' },
                    { key: 'Fixed IncomeRegular', value: 'Fixed IncomeRegular' },
                    { key: 'EquitiesRegular', value: 'EquitiesRegular' },
                    { key: 'Loan SalesExtended', value: 'Loan SalesExtended' },
                    { key: 'Swaps', value: 'Swaps' },
                    { key: 'Prime', value: 'Prime' },
                    { key: 'FCM', value: 'FCM' },
                    { key: 'Agency', value: 'Agency' },
                    { key: 'Equities', value: 'Equities' },
                    { key: 'Loan Sales', value: 'Loan Sales' },
                ]
            }),
            new DropdownQuestion({
                key: 'ProductSubType',
                label: 'Product Sub Type',
                parent: {
                    key: 'ProductSettlementType',
                    value: ''
                },
                order: 400,
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'ProductType',
                                value: 'Fixed Income'
                            },
                            {
                                id: 'ProductType',
                                value: 'Prime'
                            },
                            {
                                id: 'ProductType',
                                value: 'Equities'
                            }
                        ]
                    }
                ],
                options: [
                    { key: '', value: '-- Please Select --' },
                    { key: 'Cash', value: 'Cash', parentKey: 'Fixed IncomeRegular' },
                    { key: 'Overnight Repo', value: 'Overnight Repo', parentKey: 'Fixed IncomeRegular' },
                    { key: 'MBS', value: 'MBS', parentKey: 'Fixed IncomeExtended' },
                    { key: 'Repo', value: 'Repo', parentKey: 'Fixed IncomeExtended' },
                    { key: 'Rev Repo', value: 'Rev Repo', parentKey: 'Fixed IncomeExtended' },
                    { key: 'Tri-Party Repo', value: 'Tri-Party Repo', parentKey: 'Fixed IncomeExtended' },
                    { key: 'Cash', value: 'Cash', parentKey: 'EquitiesRegular' },
                    { key: 'Derivatives', value: 'Derivatives', parentKey: 'EquitiesRegular' },
                    { key: 'PB', value: 'PB', parentKey: 'Prime' },
                    { key: 'DVP', value: 'DVP', parentKey: 'Prime' },
                    { key: 'Margin Roll up', value: 'Margin Roll up', parentKey: 'Prime' }
                ]
            }),
            new MultiselectQuestion({
                key: 'ProductSubType',
                label: 'Product Sub Type',
                parent: {
                    key: 'ProductType',
                    value: ''
                },
                mandatory: true,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                            {
                                id: 'ProductType',
                                value: 'FCM'
                            },
                            {
                                id: 'ProductType',
                                value: 'Swaps'
                            }
                        ]
                    }
                ],
                order: 500,
                options: [
                    { key: 'Futures', value: 'Futures', parentKey: 'FCM' },
                    { key: 'Interest Rate Swap', value: 'Interest Rate Swap', parentKey: 'FCM' },
                    { key: 'Credit Default Swap', value: 'Credit Default Swap', parentKey: 'FCM' },
                    { key: 'Interest Rate', value: 'Interest Rate', parentKey: 'Swaps' },
                    { key: 'Commodity', value: 'Commodity', parentKey: 'Swaps' },
                    { key: 'FX/Cross currency', value: 'FX/Cross currency', parentKey: 'Swaps' },
                    { key: 'CDS Single Name', value: 'CDS Single Name', parentKey: 'Swaps' },
                    { key: 'CDS Index (SEF)', value: 'CDS Index (SEF)', parentKey: 'Swaps' }
                ]
            })
        ];
        return questions.sort((a, b) => a.order - b.order);
    }
}
