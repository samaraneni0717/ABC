export class OnboardingRequest {
    CobamId: string;
    CobamNumber: string;
    LegalName: string;
    BusinessAccountName: string;
    ProductType: string;
    ProductSubType: string;
}
