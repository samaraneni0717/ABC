import { TestBed, inject } from '@angular/core/testing';

import { OnboardingRequestService } from './onboarding-request.service';

describe('OnboardingRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OnboardingRequestService]
    });
  });

  it('should be created', inject([OnboardingRequestService], (service: OnboardingRequestService) => {
    expect(service).toBeTruthy();
  }));
});
