import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { OnboardingRequest } from './onboarding-request.model';
import { Global } from '../../Common/shared/global';
import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class OnboardingRequestService {
    indLoading = false;
    selectedOnboardingRequest: OnboardingRequest;
    onboardingRequestList: OnboardingRequest[];
    constructor(private http: Http) { }

    postOnboardingRequest(request: OnboardingRequest) {
        const body = JSON.stringify(request);
        const headerOptions = new Headers({ 'Content-Type': 'application/json' });
        const requestOptions = new RequestOptions({ method: RequestMethod.Post, headers: headerOptions });

        return this.http.post(environment.BASEURL + 'OnboardingRequest', body, requestOptions).pipe(map(x => x.json()));
    }

    putOnboardingRequest(id, request) {
        const body = JSON.stringify(request);
        const headerOptions = new Headers({ 'Content-Type': 'application/json' });
        const requestOptions = new RequestOptions({ method: RequestMethod.Put, headers: headerOptions });
        return this.http.put(environment.BASEURL + 'OnboardingRequest/' + id,
            body,
            requestOptions).pipe(map(res => res.json()));
    }

    getOnboardingRequestList(reqType: string) {
   
        this.indLoading = true;
        this.http.get(environment.BASEURL + 'OnboardingRequest/' + reqType)
            .pipe(map((data: Response) => {
                return data.json() as OnboardingRequest[];
                
            })).toPromise().then(x => {
                this.onboardingRequestList = x;
                this.indLoading = false;
            });
    }

    deleteOnboardingRequest(id: string) {
        return this.http.delete(environment.BASEURL + 'OnboardingRequest/' + id).pipe(map(res => res.json()));
    }
}
