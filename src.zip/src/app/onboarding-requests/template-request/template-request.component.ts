import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-request',
  templateUrl: './template-request.component.html',
  styleUrls: ['./template-request.component.css']
})
export class TemplateRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
