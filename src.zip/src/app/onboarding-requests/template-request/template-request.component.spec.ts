import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateRequestComponent } from './template-request.component';

describe('TemplateRequestComponent', () => {
  let component: TemplateRequestComponent;
  let fixture: ComponentFixture<TemplateRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
