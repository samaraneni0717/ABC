import {
    Component,
    OnInit,
    ViewEncapsulation,
    Input
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { MatDialog } from '@angular/material';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { SPOQ_CustomerContact } from '../Models/spoq_CustomerContact';
import { RecordType } from '../Models/recordType';

@Component({
    selector: 'app-onboarding-customer-contact',
    templateUrl: './onboarding-customer-contact.component.html',
    styleUrls: ['./onboarding-customer-contact.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class CustomerContactComponent implements OnInit {
    @Input() productType: string = '';
    spoq_customerContacts: SPOQ_CustomerContact[] = [];

    recordTypes: RecordType[] = [];

    customerContactDocumentationFormFields: QuestionBase<any>[] = [];
    customerContactDocumentationForm: FormGroup;

    customerContactLegalCounselFormFields: QuestionBase<any>[] = [];
    customerContactLegalCounselForm: FormGroup;

    customerContactSettlementInvoicesFormFields: QuestionBase<any>[] = [];
    customerContactSettlementInvoicesForm: FormGroup;

    customerContactFXConfirmationsFormFields: QuestionBase<any>[] = [];
    customerContactFXConfirmationsForm: FormGroup;
    onboardingRole: string;

    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private authService: AuthService) {

    }

    ngOnInit(): void {
        //debugger
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.spoq_customerContacts = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_CustomerContacts;
        this.onboardingDetailRequestService.getRecordTypes().subscribe(data => {
            if (data) {
                this.recordTypes = data;
                this.BuildPage();
            }
        });

        //this.BuildPage('Requester');
    }

    BuildPage() {
        // debugger

        if (this.productType !== 'FX') {
            if (this.recordTypes != null && this.recordTypes.length > 0 && this.recordTypes.filter(r => r.Name === 'Documentation').length > 0) {
                this.customerContactDocumentationFormFields = this.onboardingDetailRequestService.buildCustomerContactDocumentationFields(this.onboardingRole, this.recordTypes.filter(r => r.Name === 'Documentation')[0].Name, this.recordTypes.filter(r => r.Name === 'Documentation')[0].Id);
                this.customerContactDocumentationForm = this.qcs.toFormGroup(this.customerContactDocumentationFormFields);
            }

            if (this.recordTypes != null && this.recordTypes.length > 0 && this.recordTypes.filter(r => r.Name === 'Legal Counsel').length > 0) {
                this.customerContactLegalCounselFormFields = this.onboardingDetailRequestService.buildCustomerContactLegalCounselFields(this.onboardingRole, this.recordTypes.filter(r => r.Name === 'Legal Counsel')[0].Id);
                this.customerContactLegalCounselForm = this.qcs.toFormGroup(this.customerContactLegalCounselFormFields);
            }

            if (this.recordTypes != null && this.recordTypes.length > 0 && this.recordTypes.filter(r => r.Name === 'Settlement').length > 0) {
                this.customerContactSettlementInvoicesFormFields = this.onboardingDetailRequestService.buildCustomerContactSettlementInvoicesFields(this.onboardingRole, this.recordTypes.filter(r => r.Name === 'Settlement')[0].Id);
                this.customerContactSettlementInvoicesForm = this.qcs.toFormGroup(this.customerContactSettlementInvoicesFormFields);
            }
        } else if (this.productType === 'FX') {
            if (this.recordTypes != null && this.recordTypes.length > 0 && this.recordTypes.filter(r => r.Name === 'FX_CustomerContact').length > 0) {
                this.customerContactDocumentationFormFields = this.onboardingDetailRequestService.buildCustomerContactDocumentationFields(this.onboardingRole, this.recordTypes.filter(r => r.Name === 'FX_CustomerContact')[0].Name, this.recordTypes.filter(r => r.Name === 'FX_CustomerContact')[0].Id);
                this.customerContactDocumentationForm = this.qcs.toFormGroup(this.customerContactDocumentationFormFields);

                this.customerContactFXConfirmationsFormFields = this.onboardingDetailRequestService.buildCustomerContactFXConfirmationsFields(this.onboardingRole);
                this.customerContactFXConfirmationsForm = this.qcs.toFormGroup(this.customerContactFXConfirmationsFormFields);
            }
        }

        if (this.spoq_customerContacts != null && this.spoq_customerContacts.length > 0) {
            if (this.productType !== 'FX') {
                if (this.spoq_customerContacts.filter(c => c.RecordTypeName === 'Documentation').length > 0) {
                    const spoq_CustomerContactDocumentation = this.spoq_customerContacts.filter(c => c.RecordTypeName === 'Documentation')[0];
                    for (const prop of Object.keys(spoq_CustomerContactDocumentation)) {
                        if (this.customerContactDocumentationForm.controls[prop]) {
                            this.customerContactDocumentationForm.controls[prop].setValue(spoq_CustomerContactDocumentation[prop]);
                        }
                    }
                }

                if (this.spoq_customerContacts.filter(c => c.RecordTypeName === 'Legal Counsel').length > 0) {
                    const spoq_CustomerContactLegalCounsel = this.spoq_customerContacts.filter(c => c.RecordTypeName === 'Legal Counsel')[0];
                    for (const prop of Object.keys(spoq_CustomerContactLegalCounsel)) {
                        if (this.customerContactLegalCounselForm.controls[prop]) {
                            this.customerContactLegalCounselForm.controls[prop].setValue(spoq_CustomerContactLegalCounsel[prop]);
                        }
                    }
                }

                if (this.spoq_customerContacts.filter(c => c.RecordTypeName === 'Settlement').length > 0) {
                    let spoq_CustomerContactSettlement = this.spoq_customerContacts.filter(c => c.RecordTypeName === 'Settlement')[0];
                    for (const prop of Object.keys(spoq_CustomerContactSettlement)) {
                        if (this.customerContactSettlementInvoicesForm.controls[prop]) {
                            this.customerContactSettlementInvoicesForm.controls[prop].setValue(spoq_CustomerContactSettlement[prop]);
                        }
                    }
                }
            }
            else if (this.productType === 'FX') {
                if (this.spoq_customerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact').length > 0) {
                    let spoq_CustomerContactDocumentation = this.spoq_customerContacts.filter(c => c.RecordTypeName === 'FX_CustomerContact')[0];
                    for (const prop of Object.keys(spoq_CustomerContactDocumentation)) {
                        if (this.customerContactDocumentationForm.controls[prop]) {
                            this.customerContactDocumentationForm.controls[prop].setValue(spoq_CustomerContactDocumentation[prop]);
                        }
                    }

                    for (const prop of Object.keys(spoq_CustomerContactDocumentation)) {
                        if (this.customerContactFXConfirmationsForm.controls[prop]) {
                            this.customerContactFXConfirmationsForm.controls[prop].setValue(spoq_CustomerContactDocumentation[prop]);
                        }
                    }
                }
            }
        }
        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
            case 'Account Approval':
            case 'FX Static Data':
            case 'FXOL':
            case 'Client Services':
            case 'Tax Profile I':
            case 'AML EDD':
            case 'AML KYC':
                this.DisableCustomerContactDocumentationFieldsSection();
                this.DisableCustomerContactFXConfirmationsFieldsSection();
                this.DisableCustomerContactLegalCounselFieldsSection();
                this.DisableCustomerContactSettlementInvoicesFieldsSection();
                break;
            default:
                break;
        }
    }

    copyContactDetails(type: string) {
        switch (type) {
            case 'Legal Counsel':
                for (const prop of Object.keys(this.customerContactDocumentationForm.controls)) {
                    if (prop !== 'Id' && prop !== 'Name' && prop !== 'RecordType' && prop !== 'RecordTypeName') {
                        if (this.customerContactLegalCounselForm.controls[prop]) {
                            this.customerContactLegalCounselForm.controls[prop].setValue(this.customerContactDocumentationForm.controls[prop].value);
                        }
                    }
                }
                break;
            case 'Settlement':
                for (const prop of Object.keys(this.customerContactDocumentationForm.controls)) {
                    if (prop !== 'Id' && prop !== 'Name' && prop !== 'RecordType' && prop !== 'RecordTypeName') {
                        if (this.customerContactSettlementInvoicesForm.controls[prop]) {
                            this.customerContactSettlementInvoicesForm.controls[prop].setValue(this.customerContactDocumentationForm.controls[prop].value);
                        }
                    }
                }
                break;
            default:
                break;
        }
    }


    DisableCustomerContactDocumentationFieldsSection() {
        const filteredFields = this.customerContactDocumentationFormFields.filter(f => f.section && f.section === 'CustomerContactDocumentationDetails');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.customerContactDocumentationForm.controls[element.key]) {
                    this.customerContactDocumentationForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableCustomerContactLegalCounselFieldsSection() {
        const filteredFields = this.customerContactLegalCounselFormFields.filter(f => f.section && f.section === 'CustomerContactLegalCounsel');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.customerContactLegalCounselForm.controls[element.key]) {
                    this.customerContactLegalCounselForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableCustomerContactSettlementInvoicesFieldsSection() {
        const filteredFields = this.customerContactSettlementInvoicesFormFields.filter(f => f.section && f.section === 'CustomerContactSettlementInvoices');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.customerContactSettlementInvoicesForm.controls[element.key]) {
                    this.customerContactSettlementInvoicesForm.controls[element.key].disable();
                }
            });
        }
    }

    DisableCustomerContactFXConfirmationsFieldsSection() {
        const filteredFields = this.customerContactFXConfirmationsFormFields.filter(f => f.section && f.section === 'CustomerContactFXConfirmations');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.customerContactFXConfirmationsForm.controls[element.key]) {
                    this.customerContactFXConfirmationsForm.controls[element.key].disable();
                }
            });
        }
    }
}
