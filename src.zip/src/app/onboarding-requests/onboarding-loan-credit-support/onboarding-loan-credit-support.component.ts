import {
    Component,
    OnInit,
    ViewEncapsulation,
    Input,
    ChangeDetectorRef
} from '@angular/core';
import { QuestionControlService } from 'src/app/Common/dynamic-form-services/question-control.service';
import { OnboardingDetailRequestService } from '../shared/services/onboarding-detail-request.service';
import { MatDialog } from '@angular/material';
import { AlertService } from 'src/app/Common/services/alert.service';
import { AuthService } from 'src/app/Common/Auth/auth-service.service';
import { QuestionBase } from 'src/app/Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { SPOQ_LoanAndCreditSupport } from '../Models/spoq_LoanAndCreditSupport';
import { Subscription } from 'rxjs';


@Component({
    selector: 'app-onboarding-loan-credit-support',
    templateUrl: './onboarding-loan-credit-support.component.html',
    styleUrls: ['./onboarding-loan-credit-support.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class LoanAndCreditSupportComponent implements OnInit {
    spoq_LoanAndCreditSupport: SPOQ_LoanAndCreditSupport;

    loanAndCreditSupportFormFields: QuestionBase<any>[] = [];
    loanAndCreditSupportForm: FormGroup;
    onboardingRole: string;
    private subscriptions: Subscription[] = [];

    constructor(private qcs: QuestionControlService,
        private onboardingDetailRequestService: OnboardingDetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private authService: AuthService,
        private cdRef: ChangeDetectorRef) {

    }

    ngOnInit(): void {
        //debugger
        this.onboardingRole = this.onboardingDetailRequestService.currentUser.COBAM_Role__c;
        this.spoq_LoanAndCreditSupport = this.onboardingDetailRequestService.onboardingRequest.SPOQ_DocumentationRequest__r.SPOQ_LoanAndCreditSupport;
        this.BuildPage();
    }

    BuildPage() {
        this.loanAndCreditSupportFormFields = this.onboardingDetailRequestService.buildLoanAndCreditSupportFields(this.onboardingRole);
        this.loanAndCreditSupportForm = this.qcs.toFormGroup(this.loanAndCreditSupportFormFields);

        this.cdRef.detectChanges();

        for (const prop of Object.keys(this.spoq_LoanAndCreditSupport)) {
            if (this.loanAndCreditSupportForm.controls[prop]) {
                this.loanAndCreditSupportForm.controls[prop].setValue(this.spoq_LoanAndCreditSupport[prop]);
            }
        }

        this.enableDisableLoanFacilityFields();

        if (this.loanAndCreditSupportForm.controls['WFS_Prepare_a_Credit_Su__c'].value) {
            this.loanAndCreditSupportFormFields.filter(f => f.key === 'Does_Credit_Support_Annex_need_to_be_VM__c')[0].disabled = false;
        } else {
            this.loanAndCreditSupportFormFields.filter(f => f.key === 'Does_Credit_Support_Annex_need_to_be_VM__c')[0].disabled = true;
        }

        if (this.loanAndCreditSupportForm.get('WFS_Prepare_a_Credit_Su__c')) {
            this.subscriptions.push(
                this.loanAndCreditSupportForm.get('WFS_Prepare_a_Credit_Su__c')
                    .valueChanges.subscribe(() =>
                        this.onWFSPrepareACreditSuChange()
                    )
            );
        }

        switch (this.onboardingRole) {
            case 'Facilitator':
            case 'Facilitator Manager':
            case 'Account Approval':
            case 'FX Static Data':
            case 'FXOL':
            case 'Client Services':
            case 'Tax Profile I':
            case 'AML EDD':
            case 'AML KYC':
                this.DisableLoanAndCreditSupportDetailsSection();
                break;
            default:
                break;
        }
    }
    DisableLoanAndCreditSupportDetailsSection() {
        const filteredFields = this.loanAndCreditSupportFormFields.filter(f => f.section && f.section === 'LoanAndCreditSupportDetails');
        if (filteredFields && filteredFields.length > 0) {
            console.log(filteredFields);
            filteredFields.forEach(element => {
                if (this.loanAndCreditSupportForm.controls[element.key]) {
                    this.loanAndCreditSupportForm.controls[element.key].disable();
                }
            });
        }
    }
    enableDisableLoanFacilityFields() {
        if (this.loanAndCreditSupportForm.controls['Loan_Facility__c'] && this.loanAndCreditSupportForm.controls['Loan_Facility__c'].value === 'ExistingOrAnticipated') {
            this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'] ? this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'].setValue('') : null;
            this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'] ? this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'].enable() : null;

            this.loanAndCreditSupportForm.controls['WF_Loan_Entity_Other__c'] ? this.loanAndCreditSupportForm.controls['WF_Loan_Entity_Other__c'].setValue('') : null;

            this.loanAndCreditSupportForm.controls['Syndicated__c'] ? this.loanAndCreditSupportForm.controls['Syndicated__c'].setValue('') : null;
            this.loanAndCreditSupportForm.controls['Syndicated__c'] ? this.loanAndCreditSupportForm.controls['Syndicated__c'].enable() : null;

            this.loanAndCreditSupportForm.controls['Date_of_Loan_Agreement__c'] ? this.loanAndCreditSupportForm.controls['Date_of_Loan_Agreement__c'].setValue(null) : null;
        }
        else {
            this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'] ? this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'].setValue('') : null;
            this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'] ? this.loanAndCreditSupportForm.controls['WF_Loan_Entity__c'].disable() : null;

            this.loanAndCreditSupportForm.controls['WF_Loan_Entity_Other__c'] ? this.loanAndCreditSupportForm.controls['WF_Loan_Entity_Other__c'].setValue('') : null;

            this.loanAndCreditSupportForm.controls['Syndicated__c'] ? this.loanAndCreditSupportForm.controls['Syndicated__c'].setValue('') : null;
            this.loanAndCreditSupportForm.controls['Syndicated__c'] ? this.loanAndCreditSupportForm.controls['Syndicated__c'].disable() : null;

            this.loanAndCreditSupportForm.controls['Date_of_Loan_Agreement__c'] ? this.loanAndCreditSupportForm.controls['Date_of_Loan_Agreement__c'].setValue(null) : null;
        }
    }

    onWFSPrepareACreditSuChange() {
        this.loanAndCreditSupportForm.controls['Does_Credit_Support_Annex_need_to_be_VM__c'].setValue(null);
        if (this.loanAndCreditSupportForm.controls['WFS_Prepare_a_Credit_Su__c'].value) {
            this.loanAndCreditSupportFormFields.filter(f => f.key === 'Does_Credit_Support_Annex_need_to_be_VM__c')[0].disabled = false;
        }
        else {
            this.loanAndCreditSupportFormFields.filter(f => f.key === 'Does_Credit_Support_Annex_need_to_be_VM__c')[0].disabled = true;
        }
    }

    openSearchModal(template, legalTemplate, cobamLookupTemplate, value: string): void {
    }

    onOptionsinlineSelectionChange(template, value: string) {
        switch (value) {
            case 'Loan_Facility__c':
                this.enableDisableLoanFacilityFields()
                break;
            case 'Will_Credit_Approval_require_derivative__c':
                this.loanAndCreditSupportForm.controls['Via_loan_facility__c'].setValue(null);
                this.loanAndCreditSupportForm.controls['WFS_Prepare_a_Credit_Su__c'].setValue(null);
                this.loanAndCreditSupportForm.controls['Does_Credit_Support_Annex_need_to_be_VM__c'].setValue(null);
                break;
            case 'Require_derivative_transaction__c':
                this.loanAndCreditSupportForm.controls['SwapGuarantorVerification__c'].setValue(null);
                this.loanAndCreditSupportForm.controls['Is_any_guarantor_a_trust__c'].setValue(null);
                this.loanAndCreditSupportForm.controls['Transaction_guaranteed_via_loan_facility__c'].setValue(null);
                this.loanAndCreditSupportForm.controls['Documentation_to_prepare_a_guarantee__c'].setValue(null);
                this.loanAndCreditSupportForm.controls['Legal_Name_of_Guarantor_s__c'].setValue(null);
                break;
            default:
                break;
        }
    }

    onOptionsDropDownSelectionChange(value: string) {

    }

    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
        this.subscriptions = [];
    }
}