import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';
import { CashRequestsService } from '../../Common/services/client-build-request.service';
import { BaseManagerComponent } from '../../Common/shell-manager/base.manager.component';
import { ToastrService } from 'ngx-toastr';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
@Component({
  selector: 'app-search',
  templateUrl: './app-search.component.html',
  styleUrls: ['./app-search.component.css']
})
export class AppSearchComponent extends BaseManagerComponent implements OnInit {

    @Input() searchTitle: string;     
    @Output() selectRowData: EventEmitter<any> = new EventEmitter<any>();

    searchQuestions: QuestionBase<any>[] = [];
    searchForm: FormGroup;

    searchQuestions1: QuestionBase<any>[] = [];
    searchForm1: FormGroup;

    payLoad = '';
    SearchComplete = false;   
    constructor(private cashRequestsService: CashRequestsService, private qcs: QuestionControlService,      
        private toastr: ToastrService) {
        super();
    }

    ngOnInit() {
        
        this.searchData = [];
        this.SearchComplete = false;
        if (this.searchTitle) {     
            this.searchQuestions = this.cashRequestsService.getFieldConfigForSeachLookUp(this.searchTitle);
            this.searchForm = this.qcs.toFormGroup(this.searchQuestions);

            this.searchQuestions1 = this.cashRequestsService.getFieldConfigForSeachLookUp(this.searchTitle);
            this.searchForm1 = this.qcs.toFormGroup(this.searchQuestions1);
        }      

  }


    selectRow(value: any) {       
     this.selectRowData.emit(value);     
  }

    onSearchSubmit(buttonType: any) {
        this.SearchComplete = false;
        this.searchData = [];
        const result = Object.assign({}, this.searchForm.value);
        this.payLoad = JSON.stringify(result);

        if (this.searchTitle === 'BA') {
            this.columns = [
                { columnDef: 'BusinessAcctName', header: 'Business Acct Name' },
                { columnDef: 'BusAcctId', header: 'Bus Acct Id' },
            ];
            this.cashRequestsService.searchBA(JSON.parse(this.payLoad))
                .then(
                ba => {
                    this.SearchComplete = true;
                    this.searchData.push(ba);
                }
                );
        } else if (this.searchTitle === 'Legal') {
            if (buttonType === 'DB') {
                this.columns = [
                    { columnDef: 'LegalName', header: 'Legal Name' },
                    { columnDef: 'LegalId', header: 'Legal Id' },
                ];
                this.cashRequestsService.searchLegal(JSON.parse(this.payLoad))
                    .then(
                    Legal => {
                        this.SearchComplete = true;

                        this.searchData.push(Legal);
                    }
                    );
            }
            else if (buttonType === 'WCIS') {
                const result1 = Object.assign({}, this.searchForm1.value);
               
                this.columns = [
                    { columnDef: 'BusinessAcctName', header: 'Business Acct Name' },
                    { columnDef: 'BusAcctId', header: 'Bus Acct Id' },
                ];
                this.cashRequestsService.searchLegal(JSON.parse(JSON.stringify(result1)))
                    .then(
                    ba => {
                        this.SearchComplete = true;
                        this.searchData.push(ba);
                    }
                    );
            }
        }
        else if (this.searchTitle === 'WCIS') {

            this.columns = [
                { columnDef: 'LegalName', header: 'Legal Name' },
                { columnDef: 'LegalId', header: 'Legal Id' },
            ];
            this.cashRequestsService.searchLegal(JSON.parse(this.payLoad))
                .then(
                Legal => {
                    this.SearchComplete = true;

                    this.searchData.push(Legal);
                }
                );
        }
        this.toastr.success('Completed!', this.searchTitle + ' Search');
    }
}
