import { Component, Input, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { AuthService } from '../Auth/auth-service.service';
/*
@Pipe({ name: 'safe' })
export class SafePipe implements PipeTransform {
    constructor(private sanitizer: DomSanitizer) { }
    transform(url) {
       return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
}
*/

@Component({
  selector: 'app-attachment',
  templateUrl: './attachment.component.html',
  styleUrls: ['./attachment.component.css']
})
export class AttachmentComponent implements OnInit {
  @Input() Id: any;
  url: string;

  // url: string = Global.SalesforceUrl + 'skuid__ui?page=COBAM_AttachFiles_VK&id=a5I2a0000009RU3EAM';
  constructor(private authService: AuthService) {
  }

  ngOnInit() {
    //this.url = environment.SALESFORCEURL + 'skuid__ui?page=COBAM_AttachFiles&id=' + this.Id;
    this.url = this.authService.configuration.SALESFORCEURL + 'skuid__ui?page=COBAM_AttachFiles&id=' + this.Id;
    console.log('The URL in attach file is', this.url);
  }

}

