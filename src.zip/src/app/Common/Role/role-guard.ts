import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, ActivatedRoute, CanActivateChild } from '@angular/router';
import { AuthService } from '../Auth/auth-service.service';

@Injectable()
export class RoleGuard implements CanActivate {

  constructor(public authService: AuthService, public router: Router,  private activatedRoute: ActivatedRoute) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
   
    if (this.authService.isLoggednIn() && this.authService.HasCIDBrowserAccess()) {
        return true;  
    }
    else {
        this.router.navigate(['notauthorized']);
        return false;
    }  
  }

}