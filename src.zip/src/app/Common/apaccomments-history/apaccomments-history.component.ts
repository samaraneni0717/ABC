import { Component, OnInit, Input } from '@angular/core';
import { DetailRequestService } from 'src/app/maintenance-requests/shared/services/mt-detail-request.service';
import { DetailTableHeaderService } from 'src/app/maintenance-requests/shared/services/mt-detail-table-header.service';

@Component({
  selector: 'app-apaccomments-history',
  templateUrl: './apaccomments-history.component.html',
  styleUrls: ['./apaccomments-history.component.css']
})
export class ApaccommentsHistoryComponent implements OnInit {

  @Input() Id: any;
  displayedColumns: any[];
  @Input() APACCommentsHistoryTableData: any;
  headerColumnCount: any;
  constructor(
      private detailRequestService: DetailRequestService,
      private dths: DetailTableHeaderService
  ) {

  }

  ngOnInit() {
    this.displayedColumns = this.dths.getTableHeaders('APACCommentsHistory');
    this.headerColumnCount = this.displayedColumns.length * 2;
  }

}
