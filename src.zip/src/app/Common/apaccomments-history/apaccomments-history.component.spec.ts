import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApaccommentsHistoryComponent } from './apaccomments-history.component';

describe('ApaccommentsHistoryComponent', () => {
  let component: ApaccommentsHistoryComponent;
  let fixture: ComponentFixture<ApaccommentsHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApaccommentsHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApaccommentsHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
