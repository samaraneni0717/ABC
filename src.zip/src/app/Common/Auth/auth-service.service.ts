import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { AlertService } from '../services/alert.service';
import { ApiService } from '../services/api.service'

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User, Configuration } from '../models/User';
import 'rxjs/add/operator/retry';
import 'rxjs/add/operator/retryWhen';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/map';
import { environment } from '../../../environments/environment';
import { HttpParams } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    userDetail: User;
    configuration: Configuration;

    constructor(private myRoute: Router, private http: Http, private alertService: AlertService, private apiService: ApiService) { }

    logIn() {
        this.logInUser().retryWhen((err) => err.delay(5000)).subscribe((userdtls: User) => {
            if (userdtls != null) {
                //console.log("logInUser Returned", new Date());
                this.userDetail = userdtls;
                localStorage.removeItem('LoggedInUser');
                localStorage.setItem('LoggedInUser', this.userDetail.UNumber);
                localStorage.removeItem('HasCIDBrowserAccess');
                localStorage.removeItem('HasRequesterMaintenanceAccess');
                localStorage.setItem('HasCIDBrowserAccess', this.userDetail.HasCIDBrowserAccess ? "true" : "false");
                localStorage.setItem('HasRequesterMaintenanceAccess', this.userDetail.HasRequesterMaintenanceAccess ? "true" : "false");
                this.alertService.indLoading = false;
            } else {
                this.alertService.warn('Something went wrong please Try Again!');
            }
        },
            (error) => {
                console.error(error);
                this.alertService.warn('Not able to communicate with Service Please try Again');
                this.alertService.indLoading = false;
            });
    }

    getConfiguration() {
        //console.log("getConfiguration", new Date());
        this.apiService.Get<Configuration>(environment.BASEURL + 'User/ConfigValues').subscribe((configuration: Configuration) => {

            if(configuration != null){
                //console.log("getConfiguration Returned", new Date());
                this.configuration = configuration;
            }
          },
          (error) => {
              console.error(error);
              this.alertService.warn('Not able to communicate with Service Please try Again');
              this.alertService.indLoading = false;
          });;
    }

    

    logInUser(): Observable<User> {
       // console.log("logInUser", new Date());
        this.alertService.indLoading = true;
        const url = environment.BASEURL + 'User';
        return this.apiService.Get<User>(url);
    }

    checkCIDBrowserAccess(): Observable<User> {
        return this.logInUser();
    }

    hasAPACReportAccess(): Observable<any> {
        
        return this.apiService.Get<any>(environment.BASEURL + 'User/HasAPACReportAccess');
    }

    handleErrorPromise(error: Response | any) {
    }

    getToken() {
        return localStorage.getItem('LoggedInUser');
    }

    isLoggednIn() {
        return this.getToken() !== null;
    }

    getLoggedInUser() {
        return localStorage.getItem('LoggedInUser');
    }

    HasCIDBrowserAccess(): boolean {
        return (localStorage.getItem('HasCIDBrowserAccess') === "true")
    }

    logout() {
        localStorage.removeItem('LoggedInUser');
        this.myRoute.navigate(['']);
    }

    get HasRequesterMaintenanceAccess() {
        return (localStorage.getItem('HasRequesterMaintenanceAccess') === "true");
    }
}
