import { QuestionBase } from './question-base';

export class AutoCompleteQuestion extends QuestionBase<string> {
    controlType = 'AutoComplete';
    type: string;
  
    constructor(options: {} = {}) {
      super(options);
      this.type = (options as any)['type'] || '';
    }
  }