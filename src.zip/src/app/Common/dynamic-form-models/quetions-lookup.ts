import { QuestionBase } from './question-base';

export class LookupQuestion extends QuestionBase<string> {
  controlType = 'lookup';
  type: string;
  constructor(options: {} = {}) {
    super(options);
    this.type = (options as any)['type'] || '';
  }
}
