import { QuestionBase } from './question-base';

export class SingleCheckboxQuestion extends QuestionBase<boolean> {
  controlType = 'singlecheckbox';
}
