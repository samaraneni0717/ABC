import { QuestionBase } from './question-base';

export class OptionsInlineQuestion extends QuestionBase<string> {
  controlType = 'optionsinline';
  options: { key: string; value: string }[] = [];

  constructor(options: {} = {}) {
    super(options);
    this.options = (options as any)['options'] || '';
  }
}
