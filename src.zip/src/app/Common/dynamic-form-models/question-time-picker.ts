import { QuestionBase } from './question-base';

export class TimePickerQuestion extends QuestionBase<string> {
    controlType = 'time-picker';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = (options as any)['type'] || '';
  }
}
