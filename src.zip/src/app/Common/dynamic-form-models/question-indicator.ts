import { QuestionBase } from './question-base';

export class IndicatorQuestion extends QuestionBase<string> {
  controlType = 'indicator';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = (options as any)['type'] || '';
  }
}