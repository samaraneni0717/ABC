import { QuestionBase } from './question-base';

export class DatePickerQuestion extends QuestionBase<string> {
    controlType = 'date-picker';
    type: Date;

  constructor(options: {} = {}) {
    super(options);
    this.type = (options as any)['type'] || '';
  }
}
