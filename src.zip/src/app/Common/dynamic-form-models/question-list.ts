import { QuestionBase } from './question-base';

export class ListQuestion extends QuestionBase<string> {
  controlType = 'list';
  options: { key: string; value: string, parentKey: string, disableOption: boolean }[] = [];

  constructor(options: {} = {}) {
    super(options);
    this.options = (options as any)['options'] || [];
  }
}
