export class QuestionBase<T> {
    value?: T;
    section?: string;
    key: string;
    label: string;
    required: boolean;
    order: number;
    controlType: string;
    showWhen: ControlCondition;
    template: string;
    searchable: boolean;
    disabled: boolean;
    defaultOption: string;
    parent: ParentCondition;
    isTooltipPresent?: boolean;
    typeOfTooltip?: string;
    tooltipText?: string;
    relation: DynamicFormControlRelationGroup[];
    mandatory?: boolean;
    displayNone?: boolean;
    api?: string;
    filterCriteria?: string;
    rowGroupBy?: string;
    col: number;
    css?: string;
    hasTime?: boolean;
    selectionChange?: boolean;
    placeholder: string;
    constructor(options: {
        value?: T,
        section?: string;
        key?: string,
        label?: string,
        required?: boolean,
        order?: number,
        controlType?: string,
        showWhen?: ControlCondition,
        relation?: DynamicFormControlRelationGroup[],
        template?: string,
        searchable?: boolean,
        disabled?: boolean,
        defaultOption?: string,
        parent?: ParentCondition,
        isTooltipPresent?: boolean,
        typeOfTooltip?: string,
        tooltipText?: string,
        mandatory?: boolean,
        displayNone?: boolean,
        api?: string,
        filterCriteria?: string,
        rowGroupBy?: string,
        col?: number,
        css?: string,
        hasTime?: boolean,
        selectionChange?: boolean,
        placeholder?: string
      } = {}) {
      this.value = options.value;
      this.section =  options.section;
      this.key = options.key || '';
      this.label = options.label || '';
      this.required = !!options.required;
      this.showWhen = options.showWhen || new ControlCondition();
      this.order = options.order === undefined ? 1 : options.order;
      this.controlType = options.controlType || '';
      this.template = options.template;
      this.searchable = !!options.searchable;
      this.disabled = !!options.disabled;
      this.defaultOption = options.defaultOption;
      this.parent = options.parent || new ParentCondition();
      this.isTooltipPresent = options.isTooltipPresent;
      this.typeOfTooltip = options.typeOfTooltip;
      this.tooltipText = options.tooltipText;
      this.relation = Array.isArray(options.relation) ? options.relation : [];
      this.mandatory = !!options.mandatory;
      this.displayNone = !!options.displayNone;
      this.api = options.api || '';
      this.filterCriteria = options.filterCriteria || '';
      this.rowGroupBy = options.rowGroupBy || '';
      this.col = options.col === undefined ? 3 : options.col;
      this.css = options.css || '';
      this.hasTime = !!options.hasTime;
      this.selectionChange = !!options.selectionChange;
      this.placeholder = options.placeholder
    }
  }

  export class ControlCondition {
    key: string;
    value: string;
}

export class ParentCondition {
    key: string;
    value: string;
}

export const DYNAMIC_FORM_CONTROL_ACTION_DISABLE = "DISABLE";
export const DYNAMIC_FORM_CONTROL_ACTION_ENABLE = "ENABLE";
export const DYNAMIC_FORM_CONTROL_ACTION_VISIBLE = "VISIBLE";
export const DYNAMIC_FORM_CONTROL_ACTION_HIDDEN = "HIDDEN";
export const DYNAMIC_FORM_CONTROL_ACTION_REQUIRED = "REQUIRED";

export const DYNAMIC_FORM_CONTROL_CONNECTIVE_AND = "AND";
export const DYNAMIC_FORM_CONTROL_CONNECTIVE_OR = "OR";

export interface DynamicFormControlRelation {

    id: string;
    status?: string;
    value?: any;
    operator?: string; //==, ===, !=, !==,>, <, <=,>=
}

export interface DynamicFormControlRelationGroup {

    action: string;
    connective?: string;
    when: DynamicFormControlRelation[];    
}

export const COMPARE_OPERATOR = {
    "==": function(a, b) {
      var aArray = Array.isArray(a);
      var bArray = Array.isArray(b);

      //Runs a check for any empty values and compares them
      var aEmpty = (a == null)
      var bEmpty = (b == null)
      if (aEmpty != bEmpty) {
        return false
      }

      //If b is not an array, check if b is included in a
      if (aArray && !bArray) return a.includes(b);
      //If a is not an array, check if a is included in b
      if (bArray && !aArray) return b.includes(a);

      return a == b
    },
    "===": function(a, b) {
      return a === b
    },
    "!=": function(a, b) {
      var aArray = Array.isArray(a);
      var bArray = Array.isArray(b);

      //Runs a check for any empty values and compares them
      var aEmpty = (a == null)
      var bEmpty = (b == null)
      if (aEmpty != bEmpty) {
        return false
      }

      //If b is not an array, check if b is included in a
      if (aArray && !bArray) return !(a.includes(b));
      //If a is not an array, check if a is included in b
      if (bArray && !aArray) return !(b.includes(a));


      return a != b
    },
    "!==": function(a, b) {
      return a !== b
    },
    ">": function(a, b) {
      return a > b
    },
    "<": function(a, b) {
      return a < b
    },
    ">=": function(a, b) {
      return a >= b
    },
    "<=": function(a, b) {
      return a <= b
    }
  }