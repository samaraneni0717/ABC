import { QuestionBase } from './question-base';

export class MultiselectQuestion extends QuestionBase<string> {
  controlType = 'multiselect';
  options: { key: string; value: string, parentKey: string, disableOption: boolean }[] = [];

  constructor(options: {} = {}) {
    super(options);
    this.options = (options as any)['options'] || [];
  }
}
