import {
  Component,
  Input,
  EventEmitter,
  Output,
  ViewEncapsulation,
  OnInit
} from '@angular/core';

export interface TableHeader {
  headerName: string;
  apiColumnName: string;
  colSpan: number;
}
export interface TableCell {
  value: string | number;
}
export type TableRow = TableCell[];

@Component({
  selector: `app-dy-table`,
  templateUrl: './dynamic-table.component.html',
  styleUrls: ['./dynamic-table.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DynamicTableComponent implements OnInit {
  @Input() headers: TableHeader[];
  @Input() columnCount: number;
  @Input() width: string;
  @Input() dataset: TableRow[];
  @Output() rowClicked = new EventEmitter<void>();
  @Output() selectRow: EventEmitter<any> = new EventEmitter();

  ngOnInit() {}
  bindSearchOutput(item) {
    this.selectRow.emit(item);
  }
}
