import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppDynamicSearchComponent } from './app-dynamic-search.component';

describe('AppDynamicSearchComponent', () => {
  let component: AppDynamicSearchComponent;
  let fixture: ComponentFixture<AppDynamicSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDynamicSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDynamicSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
