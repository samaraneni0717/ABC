import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation
} from '@angular/core';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { DetailRequestService } from 'src/app/maintenance-requests/shared/services/mt-detail-request.service';
import { DetailTableHeaderService } from 'src/app/maintenance-requests/shared/services/mt-detail-table-header.service';
import { QuestionBase } from '../dynamic-form-models/question-base';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-app-dynamic-search',
  templateUrl: './app-dynamic-search.component.html',
  styleUrls: ['./app-dynamic-search.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppDynamicSearchComponent implements OnInit {
  isSave = false;
  @Input() searchTitle: string;
  @Input() wireBAID: string;
  @Input() legalId: number;
  @Output() selectRowData: EventEmitter<any> = new EventEmitter<any>();
  searchData: any[];
  SearchComplete = false;
  searchFormFields: QuestionBase<any>[] = [];
  searchForm: FormGroup;
  searchFormFields1: QuestionBase<any>[] = [];
  searchForm1: FormGroup;
  payLoad = '';
  searchBtnName = '';
  searchStatus = '';
  displayedColumns: any[];
  maintenanceTableData: any;
  isSearchLoading = false;
  showGridList = false;
  showStatusMsg = false;
  searchButtonType = '';
  headerColumnCount: any;
  width: string;

  constructor(
    private qcs: QuestionControlService,
    private detailRequestService: DetailRequestService,
    private dths: DetailTableHeaderService
  ) {}

  ngOnInit() {
    switch (this.searchTitle) {
      case 'Business Account':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.SearchComplete = false;
        this.searchBtnName = 'Search Account in POQ';
        this.searchButtonType = 'POQ';
        this.width = '165';
        break;
      case 'MIFID Business Account':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.SearchComplete = false;
        this.searchBtnName = 'Search Account in POQ';
        this.searchButtonType = 'POQ';
        this.width = '165';
        break;
      case 'Legal':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        Object.keys(this.searchForm.controls).forEach(control => {
          if (control === 'searchLimit') {
            this.searchForm.controls[control].setValue(25);
          }
        });
        this.searchBtnName = 'Search';
        this.searchFormFields1 = this.detailRequestService.buildBASearchFields(
          'AddLegal'
        );
        this.searchForm1 = this.qcs.toFormGroup(this.searchFormFields1);
        this.searchButtonType = 'LE';
        this.width = '165';
        break;
      case 'SPOQLegal':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        Object.keys(this.searchForm.controls).forEach(control => {
          if (control === 'searchLimit') {
            this.searchForm.controls[control].setValue(25);
          }
        });
        this.searchBtnName = 'Search';
        this.searchButtonType = 'SPOQLegal';
        this.width = '165';
        break;
      case 'Marketer':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search ';
        this.searchButtonType = 'MR';
        this.width = '165';
        break;
      case 'Salesperson/Trader':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search ';
        this.searchButtonType = 'SPTR';
        this.width = '100';
        break;
      case 'Wire':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search ';
        this.searchButtonType = 'Wire';
        this.searchForm.controls['baId'].setValue(this.wireBAID);
        this.onSearchSubmit('Wire');
        this.width = '165';
        break;
      case 'Expense Code':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search ';
        this.searchButtonType = 'ExpenseCode';
        this.width = '100';
        break;
      case 'Primary SIC':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search ';
        this.searchButtonType = 'PrimarySIC';
        this.width = '100';
        break;
      case 'Marketer Associate/Analyst':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search ';
        this.searchButtonType = 'MR';
        this.width = '165';
        break;
      case 'Relationship Manager':
      case 'Relationship Associate':
      case 'Credit Officer/Underwriter':
      case 'Cross Sell Referral':
      case 'Treasury Management Sales Consultant':
      case 'OLS Specialist':
      case 'ITM':
      case 'DoCO-CPMG Contact':
        this.searchFormFields = this.detailRequestService.buildBASearchFields(
          this.searchTitle
        );
        this.searchForm = this.qcs.toFormGroup(this.searchFormFields);
        this.searchBtnName = 'Search';
        this.searchButtonType = this.searchTitle;
        this.width = '165';
        break;
      default:
    }
  }
  selectRow(value: any) {
    this.selectRowData.emit(value);
  }

  onSearchSubmit(buttonType: any) {
    this.payLoad = JSON.parse(JSON.stringify(this.searchForm.value));
    console.warn('PayLoad' + this.payLoad);
    //debugger
    if(this.searchTitle === 'Relationship Manager' || this.searchTitle === 'Relationship Associate'
        || this.searchTitle === 'Credit Officer/Underwriter' || this.searchTitle === 'Cross Sell Referral'
        || this.searchTitle === 'Treasury Management Sales Consultant' || this.searchTitle === 'OLS Specialist'
        || this.searchTitle === 'ITM' || this.searchTitle === 'DoCO-CPMG Contact'){
      this.isSearchLoading = true;
      this.detailRequestService
        .GetEmployees(this.payLoad)
        .subscribe(data => {
          if (data) {
            this.SearchComplete = true;
            this.isSearchLoading = false;
            this.showGridList = true;
            this.displayedColumns = this.dths.getTableHeaders(buttonType);
            this.maintenanceTableData = data.results;
            this.showStatusMsg = true;
            this.headerColumnCount = this.displayedColumns.length * 2;
            this.searchStatus = 'Status : Done ';
          }
        });
    }
    else if(this.searchTitle === 'Marketer Associate/Analyst'){
      this.isSearchLoading = true;
      this.detailRequestService
        .GetMarketerAnalyst(this.payLoad)
        .subscribe(data => {
          if (data) {
            this.SearchComplete = true;
            this.isSearchLoading = false;
            this.showGridList = true;
            this.displayedColumns = this.dths.getTableHeaders(buttonType);
            this.maintenanceTableData = data.results;
            this.showStatusMsg = true;
            this.headerColumnCount = this.displayedColumns.length * 2;
            this.searchStatus = 'Status : Done ';
          }
        });
    }
    else if (!(this.searchTitle === 'Marketer')) {
      Object.keys(this.searchForm.controls).forEach(control => {
        if (control !== 'limitRow' && control !== 'srchAction') {
          if (this.searchForm.get(control).value) {
            // show the gridList
            this.showGridList = true;
          }
        }
      });
      if (!this.showGridList) {
        return; // No Need for backend call
      }

      switch (buttonType) {
        case 'POQ':
          this.isSearchLoading = true;
          this.detailRequestService
            .getCIDBusinessAccounts(this.payLoad)
            .subscribe(data => {
              if (data) {
                this.SearchComplete = true;
                this.isSearchLoading = false;
                this.showGridList = true;
                this.displayedColumns = this.dths.getTableHeaders(buttonType);
                this.maintenanceTableData = data.businessAccountList;
                this.headerColumnCount = this.displayedColumns.length * 2;
                this.showStatusMsg = true;
                this.searchStatus = 'Status : Search Complete';
              }
            });
          break;

        case 'LE':
        case 'SPOQLegal':
          this.isSearchLoading = true;
          this.detailRequestService
            .SearchLegalFromCCR(this.payLoad)
            .subscribe(data => {
              if (data) {
                this.SearchComplete = true;
                this.isSearchLoading = false;
                this.displayedColumns = this.dths.getTableHeaders(buttonType);
                this.maintenanceTableData = data.legalSearchResults;
                this.showStatusMsg = true;
                this.headerColumnCount = this.displayedColumns.length * 2;
                this.searchStatus = 'Status : Search ';
              }
            });
          break;
        case 'WCIS':
          this.payLoad = JSON.parse(JSON.stringify(this.searchForm1.value));
          this.isSearchLoading = true;
          this.detailRequestService
            .GetCommonCounterpartyList(this.payLoad)
            .subscribe(data => {
              if (data) {
                this.SearchComplete = true;
                this.isSearchLoading = false;
                this.showGridList = true;
                this.displayedColumns = this.dths.getTableHeaders(buttonType);
                this.maintenanceTableData = data.legalSearchResults;
                this.showStatusMsg = true;
                this.headerColumnCount = this.displayedColumns.length * 2;
                this.searchStatus = 'Status : Done ';
              }
            });
          break;
        case 'SPTR':
          this.isSearchLoading = true;
          this.detailRequestService
            .getSalesGroupLookup(this.payLoad)
            .subscribe(data => {
              if (data) {
                this.SearchComplete = true;
                this.isSearchLoading = false;
                this.showGridList = true;
                this.displayedColumns = this.dths.getTableHeaders(buttonType);
                this.maintenanceTableData = data.results;
                this.headerColumnCount = this.displayedColumns.length * 2;
                this.showStatusMsg = true;
                this.searchStatus = 'Status : Search Complete';
              }
            });
          break;
        case 'Wire':
          this.isSearchLoading = true;
          this.detailRequestService
            .getPaymentList(this.payLoad)
            .subscribe(data => {
              if (data) {
                this.SearchComplete = true;
                this.isSearchLoading = false;
                this.showGridList = true;
                this.displayedColumns = this.dths.getTableHeaders(buttonType);
                this.maintenanceTableData = data.lstPayments;
                this.headerColumnCount = this.displayedColumns.length * 2;
                this.showStatusMsg = true;
                this.searchStatus = 'Status : Search Complete';
              }
            });
          break;
        case 'ExpenseCode':
        case 'PrimarySIC':
          this.isSearchLoading = true;
          this.detailRequestService
            .getCOBAMLookup(this.payLoad)
            .subscribe(data => {
              if (data) {
                this.SearchComplete = true;
                this.isSearchLoading = false;
                this.showGridList = true;
                this.displayedColumns = this.dths.getTableHeaders(buttonType);
                this.maintenanceTableData = data.cobamLookupOutputList;
                this.headerColumnCount = this.displayedColumns.length * 2;
                this.showStatusMsg = true;
                this.searchStatus = 'Status : Search Complete';
              }
            });
          break;
        default:
      }
    } else {
      this.isSearchLoading = true;
      this.detailRequestService
        .GetSPOQMarketer(this.payLoad)
        .subscribe(data => {
          if (data) {
            this.SearchComplete = true;
            this.isSearchLoading = false;
            this.showGridList = true;
            this.displayedColumns = this.dths.getTableHeaders(buttonType);
            this.maintenanceTableData = data.results;
            this.showStatusMsg = true;
            this.headerColumnCount = this.displayedColumns.length * 2;
            this.searchStatus = 'Status : Done ';
          }
        });
    }
  }
}
