import { Injectable } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatSnackBar,  MatSnackBarConfig,  MatSnackBarHorizontalPosition,  MatSnackBarVerticalPosition} from '@angular/material';
@Injectable({
  providedIn: 'root'
})
export class SnackBarService {
  setAutoHide = true;
  autoHide = 1000;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(private snackBar: MatSnackBar) { }
  openSnackBar(message: string, action: string) {
    const config = this._createConfig();
    this.snackBar.open(message, action, config);
  }
  private _createConfig() {
    const config = new MatSnackBarConfig();
    config.verticalPosition = this.verticalPosition;
    config.horizontalPosition = this.horizontalPosition;
    config.duration = this.setAutoHide ? this.autoHide : 0;
    return config;
  }
}

