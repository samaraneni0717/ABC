import { TestBed, inject } from '@angular/core/testing';
import { SnackBarService } from './snack-bar.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('SnackBarService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [SnackBarService]
    });
  });

  it('should be created', inject([SnackBarService], (service: SnackBarService) => {
    expect(service).toBeTruthy();
  }));
});
