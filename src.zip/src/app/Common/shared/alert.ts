import { AlertType } from './alert-type.enum';

export class Alert {
    type: AlertType;
    message: string;
}
