import { XMLNodesPipe } from './xmlnodes.pipe';

describe('XMLNodesPipe', () => {
  it('create an instance', () => {
    const pipe = new XMLNodesPipe();
    expect(pipe).toBeTruthy();
  });
});
