export enum AlertType {
    Success,
    Error,
    Info,
    Warning
}
