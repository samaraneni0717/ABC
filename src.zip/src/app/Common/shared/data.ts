import { Injectable } from '@angular/core';

@Injectable()
export class Data {

    public requestDetails: any;

    public constructor() { }

}
