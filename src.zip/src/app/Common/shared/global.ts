export class Global {
  // public static SalesforceUrl = 'https://test.salesforce.com/apex/skuid__Social?id=';
  // public static SalesforceUrl = 'https://skuid.cs47.visual.force.com/apex/';
  // public static PoqUrl = 'https://webapp-dev.customer.wellsfargo.com/POQ';
  // "https://wfs.my.salesforce.com/apex/skuid__Social?id="
}
