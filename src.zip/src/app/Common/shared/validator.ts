export interface Validator {
    name: string;
    validator: any;
    message: string;
}
