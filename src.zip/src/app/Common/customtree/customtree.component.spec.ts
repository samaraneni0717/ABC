import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomtreeComponent } from './customtree.component';

describe('CustomtreeComponent', () => {
  let component: CustomtreeComponent;
  let fixture: ComponentFixture<CustomtreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomtreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomtreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
