import { Component, Input, EventEmitter, Output, ViewChild, OnInit } from '@angular/core';
@Component({
    selector: 'app-customtree',
    templateUrl: './customtree.component.html',
    styleUrls: ['./customtree.component.css']
})
export class CustomtreeComponent implements OnInit {
    @Input() Querystringindicator;
    @Input() TreeNodeFilter = [];
    @Input() Id = '';
    @Output() treeFilterchanged: EventEmitter<number[]> = new EventEmitter();
    isExpanded = false;
    CustomTreeDict = new Map<string, boolean>();
    @ViewChild('parentchkbox') parentchkbox;
    constructor() {
    }
    ngOnInit() {
        //debugger;
        //if (this.Querystringindicator === true) {
        //this.parentchkbox.nativeElement.indeterminate = true;
        //this.parentchkbox.nativeElement.checked = false;
        //this.UpdateParentNode();
        //}
    }
    Toggle(Id, Expanded) {
        this.CustomTreeDict.set(Id, Expanded);
        this.isExpanded = Expanded;
    }
    ParentCheckChanged() {
        this.TreeNodeFilter.forEach(element => {
            if (this.parentchkbox.nativeElement.checked) {
                element.IsSelected = true;
            } else {
                element.IsSelected = false;
            }
        });
        this.treeFilterchanged.emit();
        this.UpdateParentNode();
    }
    CheckChanged(selectednode) {
        //debugger;
        selectednode.IsSelected = !selectednode.IsSelected;
        this.treeFilterchanged.emit();
        this.UpdateParentNode();
    }
    UpdateParentNode() {
        //debugger;
        const selectedFilter = this.TreeNodeFilter.filter(f => f.IsSelected === true);
        if (selectedFilter && selectedFilter.length > 0) {
            if (selectedFilter.length === this.TreeNodeFilter.length) {
                this.parentchkbox.nativeElement.indeterminate = false;
                this.parentchkbox.nativeElement.checked = true;
            } else {
                this.parentchkbox.nativeElement.indeterminate = true;
                this.parentchkbox.nativeElement.checked = false;
            }
        } else {
            this.parentchkbox.nativeElement.indeterminate = false;
            this.parentchkbox.nativeElement.checked = false;
        }
    }
}
