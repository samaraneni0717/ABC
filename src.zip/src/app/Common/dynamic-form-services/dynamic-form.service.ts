import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map, tap} from 'rxjs/operators';
import { environment } from 'src/environments/environment';
//import {User, IUserResponse} from './user.class';

export class LookupOption {
    constructor(
      public Id: string, 
      public Desc: string
      ) {}
  }
  
  
  export interface ILookupResponse {
    options: LookupOption[];
  }

  export class User {
    constructor(
      public Id: string, 
      public Name: string
      ) {}
  }
  
  
  export interface IUserResponse {
    Count: number;
    userDetails: User[];
  }

  @Injectable({
    providedIn: 'root'
  })
export class DynamicFormService {
  private Count: number;

  constructor(private http: HttpClient) {}
  

  search(filter: {name: string, api: string, filterCriteria: string} = {name: '', api: '', filterCriteria: ''}, page = 1): Observable<any> {
      return this.http.get<IUserResponse>(
          environment.BASEURL + filter.api + '?filterCriteria=' + filter.filterCriteria
        )
        
      
  }

//   search(filter: {name: string} = {name: ''}, page = 1): Observable<any> {
//     return this.http.get(
//         'http://localhost:22842/Maintenance/users'
//     )
//     .pipe(
//         tap((response: ILookupResponse) => {          
//             response.options = response.options
//             //.map(x => new LookupOption(x.Id, x.Desc))
//             .filter(x => x.Desc.startsWith(filter.name))
//             return response;
//         })
//     );
//     }
}

