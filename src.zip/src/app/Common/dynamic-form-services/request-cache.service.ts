import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse } from '@angular/common/http';
import { CacheEntry } from '../cache/cache-entry';

const maxAge = 300000;
@Injectable()
export class RequestCache  {
  
  //cache = new Map();
  cacheMap = new Map<string, CacheEntry>();
  
  get(req: HttpRequest<any>): HttpResponse<any> | null {
    
    const entry = this.cacheMap.get(req.urlWithParams);
    if (!entry) {
        return null;
    }
    else{
      console.log(entry);
    }
    const isExpired = (Date.now() - entry.entryTime) > maxAge;
    return isExpired ? null : entry.response;
}

put(req: HttpRequest<any>, res: HttpResponse<any>): void {
  //debugger
  const entry: CacheEntry = { url: req.urlWithParams, response: res, entryTime: Date.now() };
  if(entry.url.indexOf('currentUser') > 0 || entry.url.indexOf('/users') > 0 || entry.url.indexOf('Lookup/RecordTypes') > 0 || entry.url.indexOf('Onboarding//getEntityInformationColumnDefinations') > 0) {
      this.cacheMap.set(req.urlWithParams, entry);
  }
  this.deleteExpiredCache();
}
private deleteExpiredCache() {
  this.cacheMap.forEach(entry => {
      if ((Date.now() - entry.entryTime) > maxAge) {
          this.cacheMap.delete(entry.url);
      }
  })
}

  // get(req: HttpRequest<any>): HttpResponse<any> | undefined {
  //   debugger
  //   const url = req.urlWithParams;
  //   const cached = this.cacheMap.get(url);

  //   if (!cached) {
  //     return undefined;
  //   }

  //   const isExpired = cached.lastRead < (Date.now() - maxAge);
  //   const expired = isExpired ? 'expired ' : '';
  //   return cached.response;
  // }

  // put(req: HttpRequest<any>, response: HttpResponse<any>): void {
  //   debugger
  //   const url = req.url;
  //   const entry = { url, response, lastRead: Date.now() };
  //   if(url.indexOf('currentUser') > 0 || url.indexOf('/users') > 0){
  //      this.cacheMap.set(url, entry);
  //   }

  //   const expired = Date.now() - maxAge;
  //   this.cacheMap.forEach(expiredEntry => {
  //     if (expiredEntry.lastRead < expired) {
  //       this.cacheMap.delete(expiredEntry.url);
  //     }
  //   });
  // }
}