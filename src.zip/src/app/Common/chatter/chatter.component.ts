import { Component, Input, PipeTransform, Pipe, OnInit, Renderer2, ElementRef, HostListener, AfterViewInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from 'src/environments/environment';
import { AuthService } from '../Auth/auth-service.service';

@Pipe({ name: 'safe' })
export class SafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}


@Component({
  selector: 'app-chatter',
  templateUrl: './chatter.component.html',
  styleUrls: ['./chatter.component.css']
})
export class ChatterComponent implements OnInit {
  @Input() Id: any;
  url: string;
  // url: string = Global.SalesforceUrl + 'skuid__Social?id=' + this.Id;
  constructor(private renderer: Renderer2, private elRef: ElementRef, private authService: AuthService) {
  }

  ngOnInit() {
    // console.log('The querystring in chatter is', this.Id);
    //this.url = environment.SALESFORCEURL + 'skuid__Social?id=' + this.Id;
    this.url = this.authService.configuration.SALESFORCEURL + 'skuid__Social?id=' + this.Id;
    // console.log('The URL in chatter is', this.url);
  }

  // ngAfterViewInit(): void {
  // const doc = (<HTMLIFrameElement>iframe).contentWindow.document;
  // const iframe = document.getElementById('requestChatter');
  // const iframe = document.getElementsByClassName('iframeClass');
  // (<HTMLIFrameElement>iframe).contentWindow.postMessage('Message', '*');
  // const doc = (<HTMLIFrameElement>iframe).contentWindow.document;
  // const fileElem = doc.getElementById('publisherAttachContentPost');
  // const pollElem = doc.getElementById('publisherAttachPollPost');
  // this.renderer.setStyle(fileElem, 'display', 'none');
  // this.renderer.setStyle(pollElem, 'display', 'none');
  // const doc = (<HTMLIFrameElement>iframe).contentWindow.document;
  // // const iframe = document.getElementById('requestChatter').;
  // (<HTMLIFrameElement>iframe).contentWindow.postMessage('Message', '*');

  // const fileElem = doc.getElementById('publisherAttachContentPost');
  // const pollElem = doc.getElementById('publisherAttachPollPost');
  // this.renderer.setStyle(fileElem, 'display', 'none');
  // this.renderer.setStyle(pollElem, 'display', 'none');

  //  }
  // uploadDone() {
  //   console.log('document', document.getElementById('requestChatter'));
  //   const iframe = document.getElementById('requestChatter');
  //   (<HTMLIFrameElement>iframe).contentWindow.postMessage('Message', '*');
  //   const doc = (<HTMLIFrameElement>iframe).contentWindow.document;
  //   // const fileElem = doc.getElementById('publisherAttachContentPost');
  //   // const pollElem = doc.getElementById('publisherAttachPollPost');
  // }
}

