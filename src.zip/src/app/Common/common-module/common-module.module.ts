import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  NG_VALUE_ACCESSOR
} from '@angular/forms';
import { DynamicFormQuestionComponent } from '../dynamic-form-components/dynamic-question/dynamic-form-question.component';
import { ShellManagerComponent } from '../shell-manager/shell-manager.component';
import { ObjectValuesPipe } from '../shell-manager/object-values-pipe';
import { DropdownpipePipe } from '../dynamic-form-components/dynamic-question/dropdownpipe.pipe';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AlertComponent } from '../alert/alert.component';
import { CustomtreeComponent } from '../customtree/customtree.component';
import {
  MatIconModule,
  MatProgressSpinnerModule,
  MatInputModule,
  MatButtonModule,
  MatSelectModule,
  MatCheckboxModule,
  MatRadioModule,
  MatGridListModule,
  MatTooltipModule,
  MatCardModule,
  MatFormFieldModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatAutocompleteModule,
  MatListModule
} from '@angular/material';
import { SnackBarService } from '../snackbar/snack-bar.service';
import { XMLNodesPipe } from '../shared/xmlnodes.pipe';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DynamicFormFieldsComponent } from '../dynamic-form-mat-components/dynamic-fields/dynamic-form-fields.component';
import { MatDropdownPipe } from '../dynamic-form-mat-components/dynamic-fields/dropdownpipe.pipe';
import { MtReqAlertComponent } from '../mt-alert/mt-req-alert.component';
import { DynamicTableComponent } from '../components/dynamic-table.component';
import { AppSearchComponent } from '../app-search/app-search.component';
import { AppDynamicSearchComponent } from '../app-dynamic-search/app-dynamic-search.component';
import { ChatterComponent, SafePipe } from '../chatter/chatter.component';
import { AttachmentComponent } from '../Attachment/attachment.component';
import { RequestCache } from '../dynamic-form-services/request-cache.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { CachingInterceptor } from '../dynamic-form-services/CachingInterceptor';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { CallbackHistoryComponent } from '../callback-history/callback-history.component';
import { PropertiesPipe } from '../pipes/properties.pipe';
import { ApaccommentsHistoryComponent } from '../apaccomments-history/apaccomments-history.component';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatRadioModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatGridListModule,
    MatCardModule,
    MatListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    NgxMaterialTimepickerModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  // tslint:disable-next-line:max-line-length
  declarations: [
    DynamicFormQuestionComponent,
    DynamicFormFieldsComponent,
    MatDropdownPipe,
    ShellManagerComponent,
    ObjectValuesPipe,
    DropdownpipePipe,
    CustomtreeComponent,
    AlertComponent,
    XMLNodesPipe,
    MtReqAlertComponent,
    DynamicTableComponent,
    AppSearchComponent,
    AppDynamicSearchComponent,
    ChatterComponent,
    SafePipe,
    AttachmentComponent,
    CallbackHistoryComponent,
    PropertiesPipe,
    ApaccommentsHistoryComponent
  ],
  exports: [
    DynamicFormQuestionComponent,
    DynamicFormFieldsComponent,
    ShellManagerComponent,
    ObjectValuesPipe,
    DropdownpipePipe,
    CustomtreeComponent,
    AlertComponent,
    XMLNodesPipe,
    MtReqAlertComponent,
    DynamicTableComponent,
    AppSearchComponent,
    AppDynamicSearchComponent,
    ChatterComponent,
    SafePipe,
    AttachmentComponent,
    CallbackHistoryComponent,
    PropertiesPipe,
    ApaccommentsHistoryComponent
  ],
  providers: [
    SnackBarService,
    RequestCache,
    { provide: HTTP_INTERCEPTORS, useClass: CachingInterceptor, multi: true }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CommonModuleModule {}
