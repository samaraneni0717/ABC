import { Injectable } from '@angular/core';

import { CashRequest } from '../models/cash-request.model';

import { DropdownQuestion } from '../dynamic-form-models/question-dropdown';
import { QuestionBase } from '../dynamic-form-models/question-base';
import { TextboxQuestion } from '../dynamic-form-models/question-textbox';
import { CheckboxQuestion } from '../dynamic-form-models/question-checkbox';
import { OptionsQuestion } from '../dynamic-form-models/Question-Options';
import { MultiselectQuestion } from '../../Common/dynamic-form-models/question-multiselect';
import { CashRequestsData } from '../shared/mock.data';

@Injectable({
  providedIn: 'root'
})
export class CashRequestsService {
  constructor() {}

  getSavedRequests(): Promise<CashRequest[]> {
    return Promise.resolve(CashRequestsData);
  }

  getRequest(id: string) {
    return Promise.resolve(
      CashRequestsData.find(
        request => request.COBAMNumber === id.replace(':', '')
      )
    );
  }

  addRequest(requestObject: CashRequest) {
    const requestIndex = CashRequestsData.findIndex(
      x => x.COBAMNumber === requestObject.COBAMNumber
    );
    if (requestIndex !== -1) {
      CashRequestsData.splice(requestIndex, 1);
    }

    CashRequestsData.push(requestObject);
  }

  searchLegal(requestObject: CashRequest) {
    // tslint:disable-next-line:max-line-length
    return Promise.resolve(
      CashRequestsData.find(
        request =>
          request.LegalId.toLowerCase() ===
            requestObject.LegalId.toLowerCase() ||
          request.LegalName.toLowerCase() ===
            requestObject.LegalName.toLowerCase()
      )
    );
  }
  searchBA(requestObject: CashRequest) {
    // tslint:disable-next-line:max-line-length
    return Promise.resolve(
      CashRequestsData.find(
        request =>
          request.BusAcctId.toLowerCase() ===
            requestObject.BusAcctId.toLowerCase() ||
          request.BusinessAcctName.toLowerCase() ===
            requestObject.BusinessAcctName.toLowerCase()
      )
    );
  }

  getFieldConfig(
    buildType?: string,
    productType?: string,
    settlementType?: string,
    productSubType?: string
  ) {
    let questions: QuestionBase<any>[] = [];

    // tslint:disable-next-line:max-line-length
    if (
      buildType === 'New Legal & Bus Acc' &&
      productType === 'Fixed Income Cash' &&
      settlementType === 'Regular' &&
      productSubType === 'Cash'
    ) {
      questions = [
        new DropdownQuestion({
          key: 'BuildType',
          label: 'Build Type',
          options: [
            { key: 'New Legal & Bus Acc', value: 'New Legal & Bus Acc' },
            { key: 'New Bus Acc Only', value: 'New Bus Acc Only' }
          ],
          order: 10,
          required: true
        }),

        new TextboxQuestion({
          key: 'COBAMNumber',
          label: 'COBAM Number',
          required: true,
          order: 20,
          showWhen: {
            key: 'BuildType',
            value: 'New Bus Acc Only'
          }
        }),

        new DropdownQuestion({
          key: 'QueueStatus',
          label: 'Queue Status',
          options: [
            { key: 'Draft', value: 'Draft' },
            { key: 'Open-Unassigned', value: 'Open-Unassigned' },
            { key: 'Pending-Assigned', value: 'Pending-Assigned' },
            { key: 'Closed-Approved', value: 'Closed-Approved' },
            { key: 'Closed-Rejected', value: 'Closed-Rejected' }
          ],
          order: 25
        }),

        new DropdownQuestion({
          key: 'ProductType',
          label: 'Product Type',
          options: [
            { key: 'Fixed Income Cash', value: 'Fixed Income Cash' },
            { key: 'Equities', value: 'Equities' },
            { key: 'CTS', value: 'CTS' },
            { key: 'Agency', value: 'Agency' },
            { key: 'Loan Sales', value: 'Loan Sales' }
          ],
          order: 30
        }),

        new DropdownQuestion({
          key: 'SettlementType',
          label: 'Settlement Type',
          options: [
            { key: 'Regular', value: 'Regular' },
            { key: 'Extended', value: 'Extended' }
          ],
          order: 40
        }),

        new DropdownQuestion({
          key: 'ProductSettlementType',
          label: 'Product Settlement Type',
          options: [
            {
              key: 'Fixed Income CashExtended',
              value: 'Fixed Income CashExtended'
            },
            { key: 'CTSExtended', value: 'CTSExtended' },
            { key: 'Loan SalesExtended', value: 'Loan SalesExtended' },
            {
              key: 'Fixed Income CashRegular',
              value: 'Fixed Income CashRegular'
            },
            { key: 'EquitiesRegular', value: 'EquitiesRegular' },
            { key: 'CTSRegular', value: 'CTSRegular' },
            { key: 'CTS', value: 'CTS' },
            { key: 'AgencyExtended', value: 'AgencyExtended' }
          ],
          order: 50
        }),

        new DropdownQuestion({
          key: 'ProductSubType',
          label: 'Product Sub Type',
          options: [
            { key: 'Cash', value: 'Cash' },
            { key: 'TBA', value: 'TBA' },
            { key: 'Repo', value: 'Repo' },
            { key: 'Rev Repo', value: 'Rev Repo' },
            { key: 'Tri-Party Repo', value: 'Tri-Party Repo' },
            { key: 'Repo (Overnight)', value: 'Repo (Overnight)' },
            { key: 'Prime - PB', value: 'Prime - PB' },
            { key: 'Prime - DVP', value: 'Prime - DVP' },
            { key: 'Prime - Margin Roll Up', value: 'Prime - Margin Roll Up' },
            { key: 'FCM - Futures', value: 'FCM - Futures' },
            {
              key: 'FCM - Interest Rate Swap',
              value: 'FCM - Interest Rate Swap'
            },
            {
              key: 'FCM - Credit Default Swap',
              value: 'FCM - Credit Default Swap'
            }
          ],
          order: 60
        }),

        new TextboxQuestion({
          key: 'LegalName',
          label: 'Legal Name',
          // required: true,
          order: 70,
          searchable: true,
          template: 'Legal'
        }),

        new TextboxQuestion({
          key: 'LegalId',
          label: 'Legal Id',
          // required: true,
          showWhen: {
            key: 'BuildType',
            value: 'New Bus Acc Only'
          },
          order: 80
        }),

        new TextboxQuestion({
          key: 'BusinessAcctName',
          label: 'Business Acct / Fund Name',
          // type: 'email',
          order: 90,
          searchable: true,
          template: 'BA',
          disabled: true
        }),
        new TextboxQuestion({
          key: 'WCIS',
          label: 'WCIS Name',
          order: 95,
          searchable: true,
          template: 'WCIS'
        }),
        new TextboxQuestion({
          key: 'BusAcctId',
          label: 'Bus Acct Id',
          // required: true,
          order: 100
        }),

        new MultiselectQuestion({
          key: 'WFSEntity',
          label: 'WFS Entity',
          defaultOption: '--Please Select--',
          options: [
            { key: 'Regular', value: 'Regular' },
            { key: 'Extended', value: 'Extended' },
            { key: 'Prime', value: 'Prime' },
            { key: 'Cash', value: 'Cash' },
            { key: 'Repo', value: 'Repo' },
            { key: 'FCM', value: 'FCM' }
          ],
          settings: {
            singleSelection: false,
            idField: 'key',
            textField: 'value',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true
          },
          order: 21
        })
      ];
    } else {
      questions = [
        new DropdownQuestion({
          key: 'BuildType',
          label: 'Build Type',
          options: [
            { key: 'New Legal & Bus Acc', value: 'New Legal & Bus Acc' },
            { key: 'New Bus Acc Only', value: 'New Bus Acc Only' }
          ],
          order: 10,
          required: true
        }),

        new TextboxQuestion({
          key: 'COBAMNumber',
          label: 'COBAM Number',
          required: true,
          order: 20,
          showWhen: {
            key: 'BuildType',
            value: 'New Bus Acc Only'
          }
        }),

        new DropdownQuestion({
          key: 'QueueStatus',
          label: 'Queue Status',
          options: [
            { key: 'Draft', value: 'Draft' },
            { key: 'Open-Unassigned', value: 'Open-Unassigned' },
            { key: 'Pending-Assigned', value: 'Pending-Assigned' },
            { key: 'Closed-Approved', value: 'Closed-Approved' },
            { key: 'Closed-Rejected', value: 'Closed-Rejected' }
          ],
          order: 25
        }),

        new DropdownQuestion({
          key: 'ProductType',
          label: 'Product Type',
          options: [
            { key: 'Fixed Income Cash', value: 'Fixed Income Cash' },
            { key: 'Equities', value: 'Equities' },
            { key: 'CTS', value: 'CTS' },
            { key: 'Agency', value: 'Agency' },
            { key: 'Loan Sales', value: 'Loan Sales' }
          ],
          order: 30
        }),

        new DropdownQuestion({
          key: 'SettlementType',
          label: 'Settlement Type',
          options: [
            { key: 'Regular', value: 'Regular' },
            { key: 'Extended', value: 'Extended' }
          ],
          order: 40
        }),

        new DropdownQuestion({
          key: 'ProductSettlementType',
          label: 'Product Settlement Type',
          options: [
            {
              key: 'Fixed Income CashExtended',
              value: 'Fixed Income CashExtended'
            },
            { key: 'CTSExtended', value: 'CTSExtended' },
            { key: 'Loan SalesExtended', value: 'Loan SalesExtended' },
            {
              key: 'Fixed Income CashRegular',
              value: 'Fixed Income CashRegular'
            },
            { key: 'EquitiesRegular', value: 'EquitiesRegular' },
            { key: 'CTSRegular', value: 'CTSRegular' },
            { key: 'CTS', value: 'CTS' },
            { key: 'AgencyExtended', value: 'AgencyExtended' }
          ],
          order: 50
        }),

        new DropdownQuestion({
          key: 'ProductSubType',
          label: 'Product Sub Type',
          options: [
            { key: 'Cash', value: 'Cash' },
            { key: 'TBA', value: 'TBA' },
            { key: 'Repo', value: 'Repo' },
            { key: 'Rev Repo', value: 'Rev Repo' },
            { key: 'Tri-Party Repo', value: 'Tri-Party Repo' },
            { key: 'Repo (Overnight)', value: 'Repo (Overnight)' },
            { key: 'Prime - PB', value: 'Prime - PB' },
            { key: 'Prime - DVP', value: 'Prime - DVP' },
            { key: 'Prime - Margin Roll Up', value: 'Prime - Margin Roll Up' },
            { key: 'FCM - Futures', value: 'FCM - Futures' },
            {
              key: 'FCM - Interest Rate Swap',
              value: 'FCM - Interest Rate Swap'
            },
            {
              key: 'FCM - Credit Default Swap',
              value: 'FCM - Credit Default Swap'
            }
          ],
          order: 60
        }),

        new OptionsQuestion({
          key: 'IsThisAPrimeAccount',
          label: 'Is this a Prime Account?',
          options: [{ key: 'Yes', value: 'Yes' }, { key: 'No', value: 'No' }],
          order: 65,
          required: true,
          defaultOption: 'Yes'
        }),

        new TextboxQuestion({
          key: 'LegalName',
          label: 'Legal Name',
          // required: true,
          order: 70,
          searchable: true,
          template: 'Legal'
        }),

        new TextboxQuestion({
          key: 'LegalId',
          label: 'Legal Id',
          // required: true,
          order: 80
        }),

        new TextboxQuestion({
          key: 'BusinessAcctName',
          label: 'Business Acct / Fund Name',
          // type: 'email',
          order: 90,
          searchable: true,
          template: 'BA',
          disabled: true
        }),
        new TextboxQuestion({
          key: 'WCIS',
          label: 'WCIS Name',
          order: 95,
          searchable: true,
          template: 'WCIS'
        }),
        new TextboxQuestion({
          key: 'BusAcctId',
          label: 'Bus Acct Id',
          // required: true,
          order: 100
        }),

        new TextboxQuestion({
          key: 'BusinessAcctShortName',
          label: 'Business Acct Short Name',
          // type: 'email',
          order: 110
        }),

        new TextboxQuestion({
          key: 'AddressLine1',
          label: 'Address Line1',
          // required: true,
          order: 130
        }),

        new TextboxQuestion({
          key: 'AddressLine2',
          label: 'Address Line2',
          // required: true,
          order: 140
        }),

        new TextboxQuestion({
          key: 'AddressLine3',
          label: 'Address Line3',
          // required: true,
          order: 150
        }),

        new TextboxQuestion({
          key: 'City',
          label: 'City',
          // required: true,
          order: 160
        }),

        new TextboxQuestion({
          key: 'Country',
          label: 'Country',
          // required: true,
          order: 170
        }),

        new TextboxQuestion({
          key: 'State',
          label: 'State',
          // required: true,
          order: 180
        }),
        new TextboxQuestion({
          key: 'AMLCaseManager',
          label: 'AML Case Manager',
          // required: true,
          order: 190
        }),

        new TextboxQuestion({
          key: 'PrimaryFacilitator',
          label: 'Primary Facilitator',
          // required: true,
          order: 200
        }),

        new TextboxQuestion({
          key: 'SecondaryFacilitator',
          label: 'Secondary Facilitator',
          // required: true,
          order: 210
        }),

        new DropdownQuestion({
          key: 'AMLDocStatus',
          label: 'AML Doc Status',
          options: [
            { key: 'N/A', value: 'N/A' },
            { key: 'PENDING', value: 'PENDING' },
            { key: 'COMPLETE', value: 'COMPLETE' }
          ],
          order: 230
        }),

        new DropdownQuestion({
          key: 'AMLStatus',
          label: 'AML Status',
          options: [
            { key: 'Ready In CSTN/CRMS', value: 'Ready In CSTN/CRMS' },
            { key: 'EDD Required', value: 'EDD Required' },
            { key: 'Approved in CSTN/CRMS', value: 'Approved in CSTN/CRMS' },
            { key: 'Memo in Progress', value: 'Memo in Progress' },
            {
              key: 'Memo Pending RM Approval',
              value: 'Memo Pending RM Approval'
            },
            {
              key: 'Memo Pending WFCRC Approval',
              value: 'Memo Pending WFCRC Approval'
            },
            {
              key: 'CSTN down � AML rejected',
              value: 'CSTN down � AML rejected'
            },
            {
              key: 'CSTN down � AML Approved',
              value: 'CSTN down � AML Approved'
            },
            { key: 'Rejected in CSTN/CRMS', value: 'Rejected in CSTN/CRMS' }
          ],
          order: 240
        }),

        new OptionsQuestion({
          key: 'Can_the_client_be_contacted',
          label: 'Can the client be contacted?',
          options: [{ key: 'Yes', value: 'Yes' }, { key: 'No', value: 'No' }],
          order: 250
        }),
        new CheckboxQuestion({
          key: 'FXSpecificProducts',
          label: 'FX Specific Products',
          options: [
            { key: 'FX EYD', value: 'FX EYD' },
            { key: 'FX Forward*', value: 'FX Forward*' },
            { key: 'FX NDF*', value: 'FX NDF*' },
            { key: 'FX Option**', value: 'FX Option**' },
            { key: 'FX SWAP*', value: 'FX SWAP*' },
            { key: 'FX Window Forward*', value: 'FX Window Forward*' }
          ],
          order: 255,
          required: true
        }),

        new TextboxQuestion({
          key: 'Client_Contact_Name',
          label: 'Client Contact Name',
          // required: true,
          order: 260
        }),

        new TextboxQuestion({
          key: 'Client_Contact_Email',
          label: 'Client Contact Email',
          // required: true,
          order: 270
        }),

        new TextboxQuestion({
          key: 'Client_Contact_Phone',
          label: 'Client Contact Phone',
          // required: true,
          order: 280
        }),

        new DropdownQuestion({
          key: 'CDD_Type',
          label: 'CDD Type',
          options: [
            // tslint:disable-next-line:max-line-length
            {
              key: 'Individuals, Joint Account holders, IRAs, Custodian',
              value: 'Individuals, Joint Account holders, IRAs, Custodian'
            },
            // tslint:disable-next-line:max-line-length
            {
              key:
                'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)',
              // tslint:disable-next-line:max-line-length
              value:
                'Operating (Private Companies and Companies Quoted on Unrecognized Exchange including Inc. , Ltd. Corp. LLC and Funds)'
            },
            { key: 'General Partnerships', value: 'General Partnerships' },
            // tslint:disable-next-line:max-line-length
            {
              key:
                'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)',
              value:
                'Limited Partnerships or Limited Liability Partnerships (including Hedge Funds, Private Equity Funds, etc.)'
            },
            {
              key: 'Trusts with Regulated Trustees',
              value: 'Trusts with Regulated Trustees'
            },
            {
              key: 'Trusts with Unregulated Trustees',
              value: 'Trusts with Unregulated Trustees'
            },
            { key: 'Pension Plans', value: 'Pension Plans' }
          ],
          order: 290
        }),

        new DropdownQuestion({
          key: 'CDD_Sub_Type',
          label: 'CDD Sub Type',
          options: [
            { key: 'Operating', value: 'Operating' },
            {
              key: 'Unregistered Investment Advisor',
              value: 'Unregistered Investment Advisor'
            },
            { key: 'Fund', value: 'Fund' },
            {
              key: 'Operating Limited Partnership or LLP',
              value: 'Operating Limited Partnership or LLP'
            },
            {
              key: 'Unregistered Investment Manager / Advisor',
              value: 'Unregistered Investment Manager / Advisor'
            },
            {
              key: 'Companies on Approved Exchange',
              value: 'Companies on Approved Exchange'
            },
            {
              key: 'Subsidiary of Listed Parent (>50% Ownership)',
              value: 'Subsidiary of Listed Parent (>50% Ownership)'
            },
            // tslint:disable-next-line:max-line-length
            {
              key: 'Non-US Regulated Credit or Financial Institutions: Banks',
              value: 'Non-US Regulated Credit or Financial Institutions: Banks'
            },
            { key: 'ERISA', value: 'ERISA' },
            { key: 'Non ERISA', value: 'Non ERISA' },
            {
              key: 'State, Municipal, or Government Pension Plan',
              value: 'State, Municipal, or Government Pension Plan'
            },
            // tslint:disable-next-line:max-line-length
            {
              key: 'Foreign Government and Public Authorities: Consulates',
              value: 'Foreign Government and Public Authorities: Consulates'
            }
          ],
          order: 300,
          defaultOption: '-- Please Select --'
        }),

        new DropdownQuestion({
          key: 'CIP_CDD_Verified',
          label: 'CIP/CDD Verified',
          options: [{ key: 'Yes', value: 'Yes' }, { key: 'No', value: 'No' }],
          order: 310
        }),

        new TextboxQuestion({
          key: 'Credit_limit',
          label: 'Credit Limit',
          // required: true,
          order: 320
        }),
        new MultiselectQuestion({
          key: 'WFSEntity',
          label: 'WFS Entity',
          defaultOption: '--Please Select--',
          options: [
            { key: 'Regular', value: 'Regular' },
            { key: 'Extended', value: 'Extended' },
            { key: 'Prime', value: 'Prime' },
            { key: 'Cash', value: 'Cash' },
            { key: 'Repo', value: 'Repo' },
            { key: 'FCM', value: 'FCM' }
          ],
          settings: {
            singleSelection: false,
            idField: 'key',
            textField: 'value',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true
          },
          order: 21,
          required: true
        })
      ];
    }
    return questions.sort((a, b) => a.order - b.order);
  }

  getFieldConfigForSeachLookUp(templateType?: string) {
    let questions: QuestionBase<any>[] = [];

    if (templateType === 'Legal') {
      questions = [
        new TextboxQuestion({
          key: 'LegalName',
          label: 'Legal Name',
          order: 10
        }),

        new TextboxQuestion({
          key: 'LegalId',
          label: 'Legal Id',
          order: 20
        })
      ];
    } else if (templateType === 'BA') {
      questions = [
        new TextboxQuestion({
          key: 'BusinessAcctName',
          label: 'Business Acct / Fund Name',
          order: 10
        }),

        new TextboxQuestion({
          key: 'BusAcctId',
          label: 'Bus Acct Id',
          order: 20
        }),

        new OptionsQuestion({
          key: 'SC',
          label: 'Search',
          options: [
            { key: 'Starts With', value: 'Starts With' },
            { key: 'Contains', value: 'Contains' }
          ],
          order: 65,
          defaultOption: 'Starts With'
        })
      ];
    } else if (templateType === 'WCIS') {
      questions = [
        new TextboxQuestion({
          key: 'LegalName',
          label: 'Legal Name',
          order: 10
        }),

        new TextboxQuestion({
          key: 'LegalId',
          label: 'Legal Id',
          order: 20
        })
      ];
    }
    return questions.sort((a, b) => a.order - b.order);
  }
}
