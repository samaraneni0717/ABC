import { TestBed, inject } from '@angular/core/testing';

import { CashRequestsService } from './client-build-request.service';

describe('ClientBuildRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CashRequestsService]
    });
  });

  it('should be created', inject([CashRequestsService], (service: CashRequestsService) => {
    expect(service).toBeTruthy();
  }));
});
