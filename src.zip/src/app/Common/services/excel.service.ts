import * as core from '@angular/core';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { WorkItemReportHeaderDtls, WorkItemToExport } from '../../workitem/workitem-queue/shared/Models/work-itemReport-Headers';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@core.Injectable({
  providedIn: 'root'
})
export class ExcelService {
  wi = 0;
  headerWorkItemReportHeaderDtls = new WorkItemReportHeaderDtls();
  constructor() { }
  public exportAsExcelFile(json: any[], excelFileName: string): void {
    Object.keys(WorkItemToExport).forEach(key => console.log(key));
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const ExcelRange = worksheet['!ref'].split(':');
    const a = [], j = ExcelRange[1].replace(/[0-9]/g, '').charCodeAt(0);
    let i = ExcelRange[0].replace(/[0-9]/g, '').charCodeAt(0);
    for (; i <= j; ++i) {
      a.push(String.fromCharCode(i));
    }
    for (; this.wi < a.length; ++this.wi) {
      const ColumnName = worksheet[a[this.wi] + '1'].v;
      worksheet[a[this.wi] + '1'].v = this.headerWorkItemReportHeaderDtls.lstHeaderDetails.filter
      (h => h.ColumnName === ColumnName)[0].ColumnHeader;
    }
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }
}
