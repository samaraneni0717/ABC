import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { throwError, Observable } from 'rxjs'
import { catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})

export class ApiService {
    
    constructor(private httpClient: HttpClient) {}
  
    Get<T>(url:string, httpParams: HttpParams = null, httpHeaders: HttpHeaders = null): Observable<T> {
        const options = {
            httpHeaders: httpHeaders,
            params: httpParams,
            withCredentials: true
        };
        return this.httpClient.get<T>(url, options)
        .pipe(
            catchError(this.errorHandler)
        );
    }

    Post<T>(url: string, body: any, httpParams: HttpParams = null, httpHeaders: HttpHeaders = null): Observable<T> {
        const options = {
            httpHeaders: httpHeaders,
            params: httpParams,
            withCredentials: true
        };
        return this.httpClient.post<T>(url, body, options)
            .pipe(
                catchError(this.errorHandler)
            );
    }

    Put<T>(url: string, body: any, httpParams: HttpParams = null, httpHeaders: HttpHeaders = null): Observable<T> {
        const options = {
            httpHeaders: httpHeaders,
            params: httpParams,
            withCredentials: true
        };
        return this.httpClient.put<T>(url, options)
            .pipe(
                catchError(this.errorHandler)
            );
    }

    Delete<T>(url: string, httpParams: HttpParams = null, httpHeaders: HttpHeaders = null): Observable<T> {
        const options = {
            httpHeaders: httpHeaders,
            params: httpParams,
            withCredentials: true
        };
        return this.httpClient.delete<T>(url, options)
            .pipe(
                catchError(this.errorHandler)
            );
    }

    errorHandler(error: Response) {
        console.log(error);
        return throwError(error);
    }
}