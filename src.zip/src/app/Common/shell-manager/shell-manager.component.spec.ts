import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShellManagerComponent } from './shell-manager.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('ShellManagerComponent', () => {
  let component: ShellManagerComponent;
  let fixture: ComponentFixture<ShellManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ ShellManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShellManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
