import { OnInit } from '@angular/core';
export abstract class BaseManagerComponent implements OnInit {

    protected title: string;
    protected columns: any[] = [];
    protected searchData: any[] = [];

    constructor() { }

    ngOnInit(): void {

    }

}
