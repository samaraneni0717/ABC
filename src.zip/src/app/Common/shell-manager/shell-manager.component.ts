import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-shell-manager',
  templateUrl: './shell-manager.component.html',
  styleUrls: ['./shell-manager.component.css']
})
export class ShellManagerComponent implements OnInit {
    @Input() columnHeadings: any[] = [];
    @Input() data: any[] = [];
    @Input() title: string;
    @Output() selectRow: EventEmitter<any> = new EventEmitter();
    isCollapsed = false;
    message: string;

    constructor(private route: ActivatedRoute) {

    }

    ngOnInit() {
    }


    bindSearchOutput(item) {
        this.selectRow.emit(item);
    }
}
