import { Component, Input, Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'objectValues'
})
export class ObjectValuesPipe implements PipeTransform {
    transform(obj: any) {
        const result = [];
        // tslint:disable-next-line:no-debugger
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                result.push(obj[key]);
            }
        }
        return result;
    }
}
