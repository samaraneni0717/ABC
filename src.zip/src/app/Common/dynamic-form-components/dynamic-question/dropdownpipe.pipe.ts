import { Component, Input, Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dropdownpipe'
})
export class DropdownpipePipe implements PipeTransform {

    transform(options: any, parentVKey?: string): any {
        const result = [];
        for (const opt of options) {
            if (!opt.parentKey || (opt.parentKey && opt.parentKey === parentVKey)) {
                result.push(opt);
            }
        }

        return result;
  }

}



