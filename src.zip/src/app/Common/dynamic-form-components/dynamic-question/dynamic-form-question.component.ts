import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { QuestionBase } from '../../dynamic-form-models/question-base';

@Component({
  selector: 'app-question',
  templateUrl: './dynamic-form-question.component.html',
  styleUrls: ['./dynamic-form-question.component.css']
})
export class DynamicFormQuestionComponent {
  @Input() question: QuestionBase<any>;
  @Input() form: FormGroup;
  @Output() searchIconClick: EventEmitter<any> = new EventEmitter<any>();
  // tslint:disable-next-line:no-output-on-prefix
  @Output() onItemSelectEvent: EventEmitter<any> = new EventEmitter<any>();
  // tslint:disable-next-line:no-output-on-prefix
  @Output() onSelectAllEvent: EventEmitter<any> = new EventEmitter<any>();

  control: FormControl;
  hidden: boolean;
  subscription: Subscription;
  cascadingSubscription: Subscription;

  get isValid() {
    return this.form.controls[this.question.key].valid;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnInit() {
    this.control = this.form.get(this.question.key) as FormControl;
    this.setUpConditions();
    this.cascadingConditions();
  }

  cascadingConditions() {
    if (!this.question.parent || !this.question.parent.key) {
      return;
    }

    const relatedControl = this.form.get(this.question.parent.key);
    if (!relatedControl) {
      return;
    }

    this.updateChild();
    this.cascadingSubscription = relatedControl.valueChanges.subscribe(x =>
      this.updateChild()
    );
  }

  updateChild(): void {
    // tslint:disable-next-line:no-debugger
    const relatedControl: any = this.form.get(this.question.parent.key);
    if (relatedControl.value !== this.question.parent.value) {
      this.question.parent.value = relatedControl.value;
      this.question.defaultOption = '-- Please Select --';
    }
  }

  setUpConditions() {
    if (!this.question.showWhen || !this.question.showWhen.key) {
      return;
    }

    const relatedControl = this.form.get(this.question.showWhen.key);
    if (!relatedControl) {
      return;
    }

    this.updateHidden();
    this.subscription = relatedControl.valueChanges.subscribe(x =>
      this.updateHidden()
    );
  }

  updateHidden(): void {
    const relatedControl: any = this.form.get(this.question.showWhen.key);
    this.hidden = relatedControl.value !== this.question.showWhen.value;

    this.hidden ? this.control.disable() : this.control.enable();
    // this.question.display = this.hidden;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    if (this.cascadingSubscription) {
      this.cascadingSubscription.unsubscribe();
    }
  }
  openSearchModal(legaltemplate) {
    this.searchIconClick.emit(legaltemplate);
  }

  onItemSelect(item: any) {
    this.onItemSelectEvent.emit(item);
  }
  onSelectAll(items: any) {
    this.onSelectAllEvent.emit(items);
  }
}
