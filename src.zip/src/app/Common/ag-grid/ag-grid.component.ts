import { Component, Input, EventEmitter, Output, ViewChild, OnInit } from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material';

import { AgGridLoadingOverlay } from "./ag-grid-loading-overlay.component";
import { AgGridNoRowsOverlay } from "./ag-grid-no-rows-overlay.component";
import { AuthService } from '../Auth/auth-service.service';

//import { RowTemplateRenderer } from '../../workitem/templates/row-template.component';

@Component({
    selector: 'app-grid',
    templateUrl: './ag-grid.component.html',
    styleUrls: ['./ag-grid.component.css']
})

export class AgGridComponent implements OnInit {
    @Input() columnDefs;
    @Input() rowData;
    @Input() height: string | null;
    @Input() width: string | null;
    @Input() rowSelection;
    @Input() rowClassRules;
    @Input() components;
    @Input() floatingFilter: boolean;
    @Input() enableSorting: boolean;
    @Input() enableColResize: boolean;
    @Input() pagination: boolean;
    @Input() paginationPageSize: number;
    @Input() objectContainer;
    @Input() isRowSelectable;
    @Input() fullWidthCellRenderer;
    @Input() isFullWidthCell;
    @Input() getRowHeight;
    @Input() defaultColDef;
   
    
    @Output() gridReady: EventEmitter<any> = new EventEmitter();
    @Output() selectionChanged: EventEmitter<any> = new EventEmitter();
    @Output() rowDoubleClicked: EventEmitter<any> = new EventEmitter();

    gridApi;
    multiSortKey = "ctrl";

    loadingOverlayComponent = "agGridLoadingOverlay";
    loadingOverlayComponentParams = { loadingMessage: "Loading..." };
    noRowsOverlayComponent = "agGridNoRowsOverlay";
    noRowsOverlayComponentParams = {
        noRowsMessageFunc: function () {
            return "";
        }
    };

    frameworkComponents = {
        agGridLoadingOverlay: AgGridLoadingOverlay,
        agGridNoRowsOverlay: AgGridNoRowsOverlay
    };

    modalRef: NgbModalRef;

    constructor(public authService: AuthService, public dialog: MatDialog) {}

    ngOnInit() {
        this.height = this.height ? this.height : '100%';
        this.width = this.width ? this.width : '100%';
    }

    onGridReady(params) {
        this.gridApi = params.api;
        this.gridReady.emit(params.api);
    }

    onSelectionChanged(params) {
        this.selectionChanged.emit(params);
    }

    onRowDoubleClicked(params) {
        this.rowDoubleClicked.emit(params);
    }

    // openModal(modalId: string, itemId: string) {
    //     this.modalService.open(modalId, itemId);
    // }

    openModal(templateId, workitemId) :void {
        const dialogRef = this.dialog.open(templateId, {
            width: '800px'
          });
    }
}
