import { environment } from 'src/environments/environment';
import { SelectEditor } from './select-editor/select-editor.component';

export namespace AgGrid {

    export function LoadColumnDefinition(column: any, filterParamsList: Array<any> = null): any[] {
        var columnDefinition = [];

        columnDefinition.push(
            {
                headerName: column.HeaderName,
                field: column.FieldName,
                width: column.ColumnWidth,
                tooltipField: column.ToolTipField,
                suppressMenu: column.SuppressMenu,
                suppressFilter: column.SuppressFilter,
                filter: (!column.SuppressFilter) ? column.FilterType : false,
                cellRenderer: (column.AddCellRenderer && column.CellRendererName != null) ? column.CellRendererName : null,
                comparator: (column.FieldName == "SystemAcctOpenDate" || column.FieldName == "SystemAcctEffectiveDate" || column.FieldName == "BusUnitEffectiveDate") ? this.DateSortComparator : null,
                valueFormatter: (column.OverrideCellValue) ? this.ValueFormatter : null,
                filterParams:
                {
                    filterOptions: column.FilterOptions.split(','),
                    textFormatter: (column.OverrideFilter) ? (column.FieldName == "SSN" || column.FieldName == "TaxID" || column.FieldName == "AlternateTaxID") ? this.TaxOrSSNTextFormatter : null : null,
                    comparator: (column.FieldName == "SystemAcctOpenDate" || column.FieldName == "SystemAcctEffectiveDate" || column.FieldName == "BusUnitEffectiveDate") ? this.DateComparator : null,

                },
                cellClass: (column.FieldName == "WorkitemStatusName") ? this.StatusCellFormatter : (column.FieldName == 'WorkitemTypeName') ? this.TypeCellFormatter : null
            });

        return columnDefinition;
    }

    export function TypeCellFormatter(params) {
        return 'ag-cell-type';
    }

    export function StatusCellFormatter(params) {
        var typeName = params.data.WorkitemTypeCode;
        var statusName = params.data.WorkitemStatusName;
        if((typeName == 'Regulatory' || typeName == 'CDD' || typeName == 'Tax' || typeName == 'Documentation' || typeName == 'Secondary Review') && statusName.indexOf('Complete') > -1)
            return 'CompleteColor';
        else if ((typeName == 'Regulatory' || typeName == 'CDD' || typeName == 'Tax' || typeName == 'Documentation' || typeName == 'Secondary Review') && statusName.indexOf('Pending') > -1)
            return 'PendingColor'
        else
            return ''; 
    }

    export function TaxOrSSNTextFormatter(r) {
        if (r == null) return null;
        r = r.replace(new RegExp('-', 'g'), "");
        return r;
    }

    export function ValueFormatter(params) {
        let output = '-';
        const fieldValue = params.value;
        const columnName = params.column.colId;

        if (columnName.indexOf("Date") > -1) {
            if (columnName.indexOf('LastModifiedDate') > -1) {
                if (fieldValue != null) {
                    output = new Date(fieldValue).toLocaleString();
                }
            } else {
                // Format => MM/DD/YYYY 
                if (fieldValue != null) {
                    output = (fieldValue.length > 0) ? fieldValue.substr(5, 2) + "/" + fieldValue.substr(8, 2) + '/' + fieldValue.substr(0, 4) : '';
                }
            }
        } 
        else if (columnName.indexOf('ModifiedOn') > -1 || columnName.indexOf('CreatedOn') > -1) {
            output = (fieldValue.length > 0) ? fieldValue.substr(5, 2) + "/" + fieldValue.substr(8, 2) + '/' + fieldValue.substr(0, 4) : '';  
        }
        else if (columnName.indexOf('Time_Submitted__c') > -1) {
            if (fieldValue != null) {
                output = new Date(fieldValue).toLocaleString();
            }
        }
        else if(columnName.indexOf('LegalID') > -1 || columnName.indexOf('AccountID') > -1 ) {
            if(Number(fieldValue) == 0)
                output = '';
            else
                output = fieldValue;
        }
        return output;
    }

    export function DateSortComparator(date1, date2) {
        if (date1 === undefined || date1 === null || date1.length !== 10 || date2 === undefined || date2 === null || date2.length !== 10) {
            return null;
        }

        //convert both the dates to yyyymmdd format
        var date1Asstring = date1.substring(6, 10) + date1.substring(0, 2) + date1.substring(3, 5);
        var date2Asstring = date2.substring(6, 10) + date2.substring(0, 2) + date2.substring(3, 5);

        return date1Asstring - date2Asstring;
    }

    export function DateComparator(filterLocalDateAtMidnight, cellValue) {
        var year = filterLocalDateAtMidnight.getFullYear().toString();

        var month = (1 + filterLocalDateAtMidnight.getMonth()).toString();
        month = month.length > 1 ? month : '0' + month;

        var day = filterLocalDateAtMidnight.getDate().toString();
        day = day.length > 1 ? day : '0' + day;

        var filterDateAsString = month + '/' + day + '/' + year;

        //convert both the dates to yyyymmdd format
        var date1Asstring = cellValue.substring(6, 10) + cellValue.substring(0, 2) + cellValue.substring(3, 5);
        var date2Asstring = year + month + day;

        if (date1Asstring == date2Asstring) {
            return 0
        }

        if (date1Asstring < date2Asstring) {
            return -1;
        }

        if (date1Asstring > date2Asstring) {
            return 1;
        }
    }
}