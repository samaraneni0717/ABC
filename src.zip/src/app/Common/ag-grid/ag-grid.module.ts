import { AgGridModule } from 'ag-grid-angular/main'
import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'

import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

import { AgGridLoadingOverlay } from "./ag-grid-loading-overlay.component";
import { AgGridNoRowsOverlay } from "./ag-grid-no-rows-overlay.component";

import { AgGridComponent } from './ag-grid.component';

import { SelectEditor } from "./select-editor/select-editor.component";

@NgModule ({
    imports: [
        CommonModule,
        AgGridModule.withComponents([AgGridComponent, SelectEditor]),
        NgMultiSelectDropDownModule.forRoot()
    ],

    declarations: [
        AgGridLoadingOverlay,
        AgGridNoRowsOverlay,
        AgGridComponent,
        SelectEditor
    ],

    exports: [
        AgGridLoadingOverlay,
        AgGridNoRowsOverlay,
        AgGridComponent 
    ],

    entryComponents: [
        AgGridLoadingOverlay,
        AgGridNoRowsOverlay,
        AgGridComponent 
    ]
})

export class CustomAgGridModule { }