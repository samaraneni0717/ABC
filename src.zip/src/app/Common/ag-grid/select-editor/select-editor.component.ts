import {AfterViewInit, Component, ViewChild, ViewContainerRef} from "@angular/core";

import {ICellEditorAngularComp} from "ag-grid-angular";

@Component({
    selector: 'select-editor',
    templateUrl: "select-editor.component.html"
})
export class SelectEditor implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: number;
    public options: any;

    @ViewChild('input', {read: ViewContainerRef}) public input;


    agInit(params: any): void {
        console.log(params.node.data.WorkitemTypeID);
        console.log(params.options);
        this.params = params;
        this.value = this.params.value;
        this.options = params.options;

    }

    getValue(): any {
        return this.value;
    }

    ngAfterViewInit() {
        window.setTimeout(() => {
            this.input.element.nativeElement.focus();
        })
    }

}