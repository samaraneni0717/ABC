import {
  Component,
  Input,
  OnInit,
  AfterViewInit,
  Output,
  EventEmitter,
  forwardRef
} from '@angular/core';
import { FormGroup, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subscription, Observable } from 'rxjs';

import { QuestionBase, COMPARE_OPERATOR } from '../../dynamic-form-models/question-base';
import {
  DynamicFormControlRelation,
  DynamicFormControlRelationGroup,
  DYNAMIC_FORM_CONTROL_ACTION_DISABLE,
  DYNAMIC_FORM_CONTROL_ACTION_ENABLE,
  DYNAMIC_FORM_CONTROL_CONNECTIVE_AND,
  DYNAMIC_FORM_CONTROL_CONNECTIVE_OR,
  DYNAMIC_FORM_CONTROL_ACTION_REQUIRED,
  DYNAMIC_FORM_CONTROL_ACTION_VISIBLE
} from '../../dynamic-form-models/question-base';
import {
  IUserResponse,
  DynamicFormService,
  User
} from '../../dynamic-form-services/dynamic-form.service';
import { debounceTime, switchMap, tap } from 'rxjs/operators';

@Component({
  selector: 'app-dynamic-fields',
  templateUrl: './dynamic-form-fields.component.html'
})
export class DynamicFormFieldsComponent {
  @Input() question: QuestionBase<any>;
  @Input() form: FormGroup;
  @Input() isSave: boolean;
  @Output() multiSelection: EventEmitter<any> = new EventEmitter<any>();
  @Output() searchIconClick: EventEmitter<any> = new EventEmitter<any>();
  // tslint:disable-next-line:no-output-on-prefix
  @Output() onItemSelectEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() onSelectAllEvent: EventEmitter<any> = new EventEmitter<any>();
  // tslint:disable-next-line:no-output-on-prefix
  @Output() onAutocompleteSelctionChange: EventEmitter<any> = new EventEmitter<
    any
  >();
  @Output() onOptionsinlineSelectionChange: EventEmitter<
    any
  > = new EventEmitter<any>();
  @Output() onOptionsDropDownSelectionChange: EventEmitter<any> = new EventEmitter<any>();
  filteredUsers: Observable<IUserResponse>;
  filteredData: any;
  filterText: '';
  control: FormControl;
  hidden: boolean;
  isDisabled: boolean;
  isRequired: boolean;
  subscription: Subscription;
  cascadingSubscription: Subscription;
  protected subscriptions: Subscription[] = [];

  constructor(private appService: DynamicFormService) { }

  get isValid() {
    return this.form.controls[this.question.key].valid;
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnInit() {
    this.control = this.form.get(this.question.key) as FormControl;
    this.setUpConditions();
    this.cascadingConditions();

    if (this.question.relation.length > 0) {
      this.setControlRelations();
    }

    if (this.question.controlType === 'AutoComplete') {
      this.filteredUsers = this.form.get(this.question.key).valueChanges.pipe(
        debounceTime(300),
        switchMap(value => {
          this.filterText = value ? (value.Name ? value.Name : value) : '';
          return this.appService.search(
            {
              name: value,
              api: this.question.api,
              filterCriteria: this.question.filterCriteria
            },
            1
          );
        })
      );
      this.filteredUsers.subscribe(data => {
        this.filterText = this.filterText ? this.filterText : '';
        this.filteredData = data.userDetails.filter(x => x.Name.toLowerCase().startsWith(this.filterText.toLowerCase()));
      }
      );
    }
  }

  cascadingConditions() {
    if (!this.question.parent || !this.question.parent.key) {
      return;
    }

    const relatedControl = this.form.get(this.question.parent.key);
    if (!relatedControl) {
      return;
    }

    this.updateChild();
    this.cascadingSubscription = relatedControl.valueChanges.subscribe(x =>
      this.updateChild()
    );
  }

  updateChild(): void {
    // tslint:disable-next-line:no-debugger
    const relatedControl: any = this.form.get(this.question.parent.key);
    if (relatedControl.value !== this.question.parent.value) {
      this.question.parent.value = relatedControl.value;
      this.question.defaultOption = '';
    }
  }

  setUpConditions() {
    if (!this.question.showWhen || !this.question.showWhen.key) {
      return;
    }

    const relatedControl = this.form.get(this.question.showWhen.key);
    if (!relatedControl) {
      return;
    }

    // if(!this.question.relation){
    //     return;
    // }

    // const relGroup = this.findRequiredRelation(this.question.relation);
    // this.isFormControlToBeDisabled(relGroup, this.form);

    this.updateHidden();
    this.subscription = relatedControl.valueChanges.subscribe(x =>
      this.updateHidden()
    );
  }

  updateHidden(): void {
    const relatedControl: any = this.form.get(this.question.showWhen.key);
    this.hidden = relatedControl.value !== this.question.showWhen.value;

    this.hidden ? this.control.disable() : this.control.enable();
    this.question.displayNone = this.hidden;
  }

  protected setControlRelations(): void {
    const relRequired = this.findRequiredRelation(this.question.relation);
    const relActivation = this.findActivationRelation(this.question.relation);
    const relVibility = this.findVisibilityRelation(this.question.relation);

    if (relRequired !== null) {
      const rel = relRequired as DynamicFormControlRelationGroup;

      this.updateModelRequired(rel);

      this.getRelatedFormControls(this.question, this.form).forEach(control => {
        this.subscriptions.push(
          control.valueChanges.subscribe(() => this.updateModelRequired(rel))
        );
        this.subscriptions.push(
          control.statusChanges.subscribe(() => this.updateModelRequired(rel))
        );
      });
    }

    if (relActivation !== null) {
      const rel = relActivation as DynamicFormControlRelationGroup;

      this.updateModelDisabled(this.question);

      this.getRelatedFormControls(this.question, this.form).forEach(control => {
        this.subscriptions.push(
          control.valueChanges.subscribe(() =>
            this.updateModelDisabled(this.question)
          )
        );
      });
    }

    if (relVibility !== null) {
      const rel = relVibility as DynamicFormControlRelationGroup;

      this.updateModelVisibility(rel);

      this.getRelatedFormControls(this.question, this.form).forEach(control => {
        this.subscriptions.push(
          control.valueChanges.subscribe(() => this.updateModelVisibility(rel))
        );
      });
    }
  }

  getRelatedFormControls(
    model: QuestionBase<any>,
    controlGroup: FormGroup
  ): FormControl[] {
    const controls: FormControl[] = [];

    model.relation.forEach(relGroup =>
      relGroup.when.forEach(rel => {
        if (model.key === rel.id) {
          throw new Error(`FormControl ${model.key} cannot depend on itself`);
        }

        const control = controlGroup.get(rel.id) as FormControl;

        if (
          control &&
          !controls.some(controlElement => controlElement === control)
        ) {
          controls.push(control);
        }
      })
    );

    return controls;
  }

  updateModelRequired(relation: DynamicFormControlRelationGroup): void {
    this.isRequired = this.isFormControlToBeRequired(relation, this.form);
    this.question.mandatory = this.isRequired;
  }

  updateModelDisabled(question: QuestionBase<any>): void {
    //this.isDisabled = !this.isFormControlToBeDisabled(relation, this.form);
    this.isDisabled = !this.isFormControlToBeDisabled(
      this.findActivationRelation(question.relation),
      this.form
    );
    this.question.disabled = this.isDisabled;
    if (question.controlType === 'AutoComplete' || question.controlType === 'date-picker') {
      if (this.isDisabled) {
        this.form.get(question.key).disable();
      } else {
        this.form.get(question.key).enable();
      }
    }
  }

  updateModelVisibility(relation: DynamicFormControlRelationGroup): void {
    this.hidden = !this.isFormControlToBeVisible(relation, this.form);
    this.question.displayNone = this.hidden;
  }

  findRequiredRelation(
    relGroups: DynamicFormControlRelationGroup[]
  ): DynamicFormControlRelationGroup | null {
    const rel = relGroups.find(rel => {
      return rel.action === DYNAMIC_FORM_CONTROL_ACTION_REQUIRED;
    });

    return rel !== undefined ? rel : null;
  }

  findActivationRelation(
    relGroups: DynamicFormControlRelationGroup[]
  ): DynamicFormControlRelationGroup | null {
    const rel = relGroups.find(rel => {
      return (
        rel.action === DYNAMIC_FORM_CONTROL_ACTION_DISABLE ||
        rel.action === DYNAMIC_FORM_CONTROL_ACTION_ENABLE
      );
    });

    return rel !== undefined ? rel : null;
  }

  findVisibilityRelation(
    relGroups: DynamicFormControlRelationGroup[]
  ): DynamicFormControlRelationGroup | null {
    const rel = relGroups.find(rel => {
      return rel.action === DYNAMIC_FORM_CONTROL_ACTION_VISIBLE;
    });

    return rel !== undefined ? rel : null;
  }

  isFormControlToBeRequired(
    relGroup: DynamicFormControlRelationGroup,
    _formGroup: FormGroup
  ): boolean {
    const formGroup: FormGroup = _formGroup;

    return relGroup.when.reduce(
      (
        toBeRequired: boolean,
        rel: DynamicFormControlRelation,
        index: number
      ) => {
        const control = formGroup.get(rel.id);

        if (
          control &&
          relGroup.action === DYNAMIC_FORM_CONTROL_ACTION_REQUIRED
        ) {
          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_AND &&
            !toBeRequired
          ) {
            return false;
          }

          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_OR &&
            toBeRequired
          ) {
            return true;
          }

          //return rel.value === control.value || rel.status === control.status;
          return this.runOperation(rel.operator || "===", control.value, rel.value) || false
        }

        return false;
      },
      false
    );
  }

  isFormControlToBeDisabled(
    relGroup: DynamicFormControlRelationGroup,
    _formGroup: FormGroup
  ): boolean {
    const formGroup: FormGroup = _formGroup;

    return relGroup.when.reduce(
      (
        toBeDisabled: boolean,
        rel: DynamicFormControlRelation,
        index: number
      ) => {
        const control = formGroup.get(rel.id);

        if (
          control &&
          relGroup.action === DYNAMIC_FORM_CONTROL_ACTION_DISABLE
        ) {
          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_AND &&
            !toBeDisabled
          ) {
            return false;
          }

          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_OR &&
            toBeDisabled
          ) {
            return true;
          }

          //return !(rel.value === control.value || rel.status === control.status);
          return !this.runOperation(rel.operator || "===", control.value, rel.value) || false

        }

        if (control && relGroup.action === DYNAMIC_FORM_CONTROL_ACTION_ENABLE) {
          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_AND &&
            !toBeDisabled
          ) {
            return true;
          }

          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_OR &&
            toBeDisabled
          ) {
            return false;
          }

          //return rel.value === control.value || rel.status === control.status;
          return this.runOperation(rel.operator || "===", control.value, rel.value) || false
        }

        return false;
      },
      false
    );
  }

  isFormControlToBeVisible(
    relGroup: DynamicFormControlRelationGroup,
    _formGroup: FormGroup
  ): boolean {
    const formGroup: FormGroup = _formGroup;

    return relGroup.when.reduce(
      (
        toBeVisible: boolean,
        rel: DynamicFormControlRelation,
        index: number
      ) => {
        const control = formGroup.get(rel.id);

        if (
          control &&
          relGroup.action === DYNAMIC_FORM_CONTROL_ACTION_VISIBLE
        ) {
          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_AND &&
            !toBeVisible
          ) {
            return false;
          }

          if (
            index > 0 &&
            relGroup.connective === DYNAMIC_FORM_CONTROL_CONNECTIVE_OR &&
            toBeVisible
          ) {
            return true;
          }

          //return rel.value === control.value || rel.status === control.status;
          return this.runOperation(rel.operator || "===", control.value, rel.value) || false
        }

        return false;
      },
      false
    );
  }

  runOperation(_operator: string, _valueA: any, _valueB: any): boolean {
    var valueA = _valueA
    var valueB = _valueB

    var operator = _operator || "==="
    var operation = COMPARE_OPERATOR[operator] ? COMPARE_OPERATOR[operator] : operation = COMPARE_OPERATOR["==="]

    if (valueA == "null") valueA = null;
    if (valueB == "null") valueB = null;
    let results = operation(valueA, valueB)
    return results
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    if (this.cascadingSubscription) {
      this.cascadingSubscription.unsubscribe();
    }

    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.subscriptions = [];
  }
  openSearchModal(legaltemplate) {
    this.searchIconClick.emit(legaltemplate);
  }

  onItemSelect(item: any) {
    this.onItemSelectEvent.emit(item);
  }
  onSelectAll(items: any) {
    this.onSelectAllEvent.emit(items);
  }

  onAutocompleteOptionSelected(controlName, selctedValue, item: any) {
    this.onAutocompleteSelctionChange.emit(controlName);
  }

  onOptionsinlineChange(controlName) {
    this.onOptionsinlineSelectionChange.emit(controlName);
  }
  onOptionsDropDownChange(controlName) {
    this.onOptionsDropDownSelectionChange.emit(controlName);
  }

  onSelectedCheckbox(event, controlName) {
    event['controlName'] = controlName;
    this.multiSelection.emit(event);
  }
  displayFn(user?: User): string | undefined {
    return user ? user.Name : undefined;
  }
}
