export class CashRequest {
    COBAMNumber: string;
    BuildType: string;
    WFSEntity: any[];
    Desk: string;
    CreatedDate: string;
    LastModifiedDate: string;
    TimeSubmitted: string;
    BusinessAcctName: string;
    LegalName: string;
    SalesPersonTrader: string;
    ProductType: string;
    QueueStatus: string;
    Notes: string;
    PrimaryFacilitator: string;
    SecondaryFacilitator: string;
    SettlementType: string;
    ProductSettlementType: string;
    ProductSubType: string;
    IsThisAPrimeAccount: string;
    LegalId: string;
    BusAcctId: string;
    BusinessAcctShortName: string;
    AddressLine1: string;
    AddressLine2: string;
    AddressLine3: string;
    City: string;
    Country: String;
    State: string;
    AMLCaseManager: string;
    AMLDocStatus: string;
    AMLStatus: string;
    Can_the_client_be_contacted: string;
    Client_Contact_Name: string;
    Client_Contact_Email: string;
    Client_Contact_Phone: string;
    CDD_Type: string;
    CDD_Sub_Type: string;
    CIP_CDD_Verified: string;
    Credit_limit: string;
}


