
export class UserRole {
    SalesPerson: boolean;
    SalesManager: boolean;
    ManagerDelegate: boolean;
 }