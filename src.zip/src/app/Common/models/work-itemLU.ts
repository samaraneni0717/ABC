export class WorkItemLU {
    Id: number;
    Code: string;
    ItemCode: string;
    Description: string;
    DisplayText: string;
    LUIndex: number;
    DistributionList: string;
    IsActive: boolean;
}
