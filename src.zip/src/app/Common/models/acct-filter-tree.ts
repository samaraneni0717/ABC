import {TreeNode} from './tree-node';
export class AcctFilterTree {
    treeNode: TreeNode[];
    id: number;
    description: string;
    tooltip: string;
    module_Name: string;
    component_Name: string;
}
