
export class User {
    FullName: string;
    UNumber: string;
    EmployeeId: string;
    UserId: string;
    DistributionList: string;
    Workitem_Type: number;
    HasCIDBrowserAccess: boolean;
    HasRequesterMaintenanceAccess: boolean;
    IsAMTDashboardSuperUser: boolean;
}

export class Configuration {
    POQURL: string;
    SALESFORCEURL: string;
    CIDURL: string;
    SKUtilityURL: string;
    COBAMURL: string;
    eCatchURL: string;
}