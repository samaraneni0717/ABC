export class SalesforceUser {
    FullName: string;
    Id: string;
    A_Number__c: string;
    COBAM_Role__c: string;
    Username: string;
    LastName: string;
    FirstName: string;
    Email: string;
    EmployeeNumber: string;
    Employee_Id__c: string;
    Name: string;
    Desk__c: string;
}