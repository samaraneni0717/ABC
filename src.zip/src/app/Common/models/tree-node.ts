export class TreeNode {
    children: Array<TreeNode> = [] ;
    id: number;
    level: number;
    value: any;
    name: string;
    description: string;
    displayText: string;
    isActive: boolean;
    isChecked: Boolean;
    imageOnexpand: string;
    imageOncollapse: string;
    backgroundColor: string;
    tooltip: string;
    isExpanded: boolean;
    indeterminate: string;
}
