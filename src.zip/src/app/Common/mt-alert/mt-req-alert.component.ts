import { Component, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-mt-alert',
  templateUrl: './mt-req-alert.component.html',
  styleUrls: ['./mt-req-alert.component.css']
})
export class MtReqAlertComponent implements OnChanges {
  @Input() alertText: string;
  @Input() alertType: string;

  ngOnChanges() {
    console.log('The error type is', this.alertType);
  }
}
