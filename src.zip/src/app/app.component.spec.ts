import { Component, NO_ERRORS_SCHEMA } from "@angular/core";
import { TestBed, async, ComponentFixture } from "@angular/core/testing";
import { RouterTestingModule } from '@angular/router/testing';

// Services
import { EnvironmentVariables } from "./core/services/envionment.service";
import { Login } from '../app/core/services/login.service'

// Components and Interfaces
import { AppComponent } from './app.component';
import { HttpClient, HttpHandler } from "@angular/common/http";

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  // Creating and declaring stub versions of nested components and directives.
  @Component({ selector: "router-outlet", template: "" })

  @Component({selector: 'navbar', template:''})
  class NavbarComponent {}

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
      ],
      declarations: [
        AppComponent,
        NavbarComponent
      ],
      providers: [
        EnvironmentVariables,
        HttpClient,
        HttpHandler,
        Login
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;           
    fixture.detectChanges();
  });

  it("should be created", () => {
    expect(component).toBeTruthy();
  });
});
