import {TotalEnergy} from '../../interfaces/totalEnergy.interface';
import {MpiActionCreator} from '../mpiActionCreator.service';
import { MpiAction } from '../mpiAction.interface';

export function totalMonthlyEnergyReducer(state: any = {}, action: MpiAction): TotalEnergy {
        
    switch(action.type) {

        case MpiActionCreator.GOT_TOTAL_MONTHLY_ENERGY:

            return action.payload;

        default:

            return state;
    }

}
