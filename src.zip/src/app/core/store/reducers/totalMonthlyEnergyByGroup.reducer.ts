import {TotalEnergy} from '../../interfaces/totalEnergy.interface';
import {MpiActionCreator} from '../mpiActionCreator.service';
import { MpiAction } from '../mpiAction.interface';

export function totalMonthlyEnergyByGroupReducer(state: any = {}, action: MpiAction): TotalEnergy {
        
    switch(action.type) {

        case MpiActionCreator.GOT_TOTAL_MONTHLY_ENERGY_BY_GROUP:

            return action.payload;

        default:

            return state;
    }

}
