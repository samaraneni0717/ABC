import {Breaker} from '../../interfaces/breaker.interface';
import {MpiActionCreator} from '../mpiActionCreator.service';
import { MpiAction } from '../mpiAction.interface';

export function breakersReducer(state: any = [], action: MpiAction): Array<Breaker> {

        switch(action.type) {

            case MpiActionCreator.GOT_BREAKERS:
                
                return action.payload;

            case MpiActionCreator.MADE_CHANGES:

                return state.devices.map(breaker => {
                    return breaker = breaker.breakerID === action.payload.breakerID ? Object.assign(breaker, {value: action.payload}) : breaker;
                });

            default:

                return state;
        }
    }

