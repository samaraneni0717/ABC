import { Group } from '../../interfaces/group.interface'
import { MpiAction } from "../mpiAction.interface";

import { MpiActionCreator } from '../mpiActionCreator.service';

export function groupsReducer(state: any = [], action: MpiAction): Array<Group> {

    let groups: Array<Group> = [];

        switch(action.type) {

            case MpiActionCreator.GOT_BREAKERS:

                action.payload.devices.forEach(device => {
                    groups.indexOf(device.group) == -1 ? groups.push(device.group) : null;
                });
                
                return groups;
                
            default:

                return state;
        }
    }

