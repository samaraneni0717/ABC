import {TwentyFourHourHistory} from '../../interfaces/twentyFourHourHistory.interface';
import {MpiActionCreator} from '../mpiActionCreator.service';
import { MpiAction } from '../mpiAction.interface';

export function twentyFourHourHistoryByGroupReducer(state: any = {}, action: MpiAction): TwentyFourHourHistory {

    switch(action.type) {

        case MpiActionCreator.GOT_TWENTY_FOUR_HOUR_HISTORY_BY_GROUP:
            
            return action.payload;

        default:

            return state;
    }
}