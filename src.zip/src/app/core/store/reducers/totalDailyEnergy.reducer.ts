import {TotalEnergy} from '../../interfaces/totalEnergy.interface';
import {MpiActionCreator} from '../mpiActionCreator.service';
import { MpiAction } from '../mpiAction.interface';

export function totalDailyEnergyReducer(state: any = {}, action: MpiAction): TotalEnergy {
        
    switch(action.type) {

        case MpiActionCreator.GOT_TOTAL_DAILY_ENERGY:
            
            return action.payload;

        default:

            return state;
    }

}
