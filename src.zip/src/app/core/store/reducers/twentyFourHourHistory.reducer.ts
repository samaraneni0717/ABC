import {TwentyFourHourHistory} from '../../interfaces/twentyFourHourHistory.interface';
import {MpiActionCreator} from '../mpiActionCreator.service';
import { MpiAction } from '../mpiAction.interface';

export function twentyFourHourHistoryReducer(state: any = {}, action: MpiAction): TwentyFourHourHistory {

    switch(action.type) {

        case MpiActionCreator.GOT_TWENTY_FOUR_HOUR_HISTORY:
            
            return action.payload;

        default:

            return state;
    }
}




