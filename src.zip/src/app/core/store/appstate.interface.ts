import { Devices } from "../interfaces/devices.interface";
import { Group } from "../interfaces/group.interface";
import { TwentyFourHourHistory } from "../interfaces/twentyFourHourHistory.interface";
import { TotalEnergy } from "../interfaces/totalEnergy.interface";

export interface AppState {
    breakers: Devices;
    groups: Array<Group>;
    twentyFourHourHistory: TwentyFourHourHistory;
    twentyFourHourHistoryByGroup: TwentyFourHourHistory;
    totalDailyEnergy: TotalEnergy;
    totalWeeklyEnergy: TotalEnergy;
    totalMonthlyEnergy: TotalEnergy;
    totalDailyEnergyByGroup: TotalEnergy;
    totalWeeklyEnergyByGroup: TotalEnergy;
    totalMonthlyEnergyByGroup: TotalEnergy;
    
}