import {Injectable} from '@angular/core';

import { Breaker } from "../interfaces/breaker.interface";
import { MpiAction } from './mpiAction.interface';

import { BreakerDetailParam } from '../classes/breakerDetailParam.class';
import { BreakerGroupParam } from '../classes/breakerGroupParam.class';

@Injectable()
export class MpiActionCreator {

    static GET_BREAKERS = 'Get Breakers';

    getBreakers(): MpiAction {

        return {

            type: MpiActionCreator.GET_BREAKERS,
            payload:null
        }
    }

    static GOT_BREAKERS = 'Got Breakers';

    gotBreakers(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_BREAKERS,
            payload: p
        }
    }

    static SAVE_CHANGES = 'Save Changes';

    saveChanges(breaker: Breaker): MpiAction {

        return {

            type: MpiActionCreator.SAVE_CHANGES,
            payload: breaker
        }
    }

    static MADE_CHANGES = 'Made Changes';

    madeChanges(p: any): MpiAction {

        return {

            type: MpiActionCreator.MADE_CHANGES,
            payload: p
        }
    }

    static GET_TWENTY_FOUR_HOUR_HISTORY = 'Get Twenty Four Hour History';

    getTwentyFourHourHistory(id: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerDetailParam(id, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TWENTY_FOUR_HOUR_HISTORY,
            payload:p
        }
    }

    static GOT_TWENTY_FOUR_HOUR_HISTORY = 'Got Twenty Four Hour History';

    gotTwentyFourHourHistory(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TWENTY_FOUR_HOUR_HISTORY,
            payload: p
        }
    }

    static GET_TWENTY_FOUR_HOUR_HISTORY_BY_GROUP = 'Get Twenty Four Hour History By Group';

    getTwentyFourHourHistoryByGroup(groups: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerGroupParam(groups, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TWENTY_FOUR_HOUR_HISTORY_BY_GROUP,
            payload:p
        }
    }

    static GOT_TWENTY_FOUR_HOUR_HISTORY_BY_GROUP = 'Got Twenty Four Hour History By Group';

    gotTwentyFourHourHistoryByGroup(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TWENTY_FOUR_HOUR_HISTORY_BY_GROUP,
            payload: p
        }
    }

    static GET_TOTAL_DAILY_ENERGY = 'Get Total Daily Energy';

    getTotalDailyEnergy(id: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerDetailParam(id, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TOTAL_DAILY_ENERGY,
            payload: p
        }
    }

    static GOT_TOTAL_DAILY_ENERGY = 'Got Total Daily Energy';

    gotTotalDailyEnergy(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TOTAL_DAILY_ENERGY,
            payload: p
        }
    }

    static GET_TOTAL_WEEKLY_ENERGY = 'Get Total Weekly Energy';

    getTotalWeeklyEnergy(id: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerDetailParam(id, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TOTAL_WEEKLY_ENERGY,
            payload: p
        }
    }

    static GOT_TOTAL_WEEKLY_ENERGY = 'Got Total Weekly Energy';

    gotTotalWeeklyEnergy(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TOTAL_WEEKLY_ENERGY,
            payload: p
        }
    }

    static GET_TOTAL_MONTHLY_ENERGY = 'Get Total Monthly Energy';

    getTotalMonthlyEnergy(id: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerDetailParam(id, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TOTAL_MONTHLY_ENERGY,
            payload: p
        }
    }

    static GOT_TOTAL_MONTHLY_ENERGY = 'Got Total Monthly Energy';

    gotTotalMonthlyEnergy(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TOTAL_MONTHLY_ENERGY,
            payload: p
        }
    }

    //TOTAL ENERGY BY GROUP

    static GET_TOTAL_DAILY_ENERGY_BY_GROUP = 'Get Total Daily Energy By Group';

    getTotalDailyEnergyByGroup(groups: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerGroupParam(groups, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TOTAL_DAILY_ENERGY_BY_GROUP,
            payload: p
        }
    }

    static GOT_TOTAL_DAILY_ENERGY_BY_GROUP = 'Got Total Daily Energy By Group';

    gotTotalDailyEnergyByGroup(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TOTAL_DAILY_ENERGY_BY_GROUP,
            payload: p
        }
    }

    static GET_TOTAL_WEEKLY_ENERGY_BY_GROUP = 'Get Total Weekly Energy By Group';

    getTotalWeeklyEnergyByGroup(groups: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerGroupParam(groups, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TOTAL_WEEKLY_ENERGY_BY_GROUP,
            payload: p
        }
    }

    static GOT_TOTAL_WEEKLY_ENERGY_BY_GROUP = 'Got Total Weekly Energy By Group';

    gotTotalWeeklyEnergyByGroup(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TOTAL_WEEKLY_ENERGY_BY_GROUP,
            payload: p
        }
    }

    static GET_TOTAL_MONTHLY_ENERGY_BY_GROUP = 'Get Total Monthly Energy By Group';

    getTotalMonthlyEnergyByGroup(groups: string, startDate: string, endDate: string, interval: string): MpiAction {

        let p = new BreakerGroupParam(groups, startDate, endDate, interval);

        return {

            type: MpiActionCreator.GET_TOTAL_MONTHLY_ENERGY_BY_GROUP,
            payload: p
        }
    }

    static GOT_TOTAL_MONTHLY_ENERGY_BY_GROUP = 'Got Total Monthly Energy By Group';

    gotTotalMonthlyEnergyByGroup(p: any): MpiAction {

        return {

            type: MpiActionCreator.GOT_TOTAL_MONTHLY_ENERGY_BY_GROUP,
            payload: p
        }
    }


}