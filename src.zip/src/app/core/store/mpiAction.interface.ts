import { Action } from "@ngrx/store";

export interface MpiAction extends Action {

    type: string;
    payload?: any;
    
}