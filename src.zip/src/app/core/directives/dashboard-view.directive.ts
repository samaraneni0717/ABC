import { Directive } from "@angular/core";

@Directive({
  selector: "[dashboard]"
})
export class DashboardDirective {}
