import { Directive } from '@angular/core';

@Directive({
    selector: '[breaker-view]'
})

export class BreakerViewDirective { }