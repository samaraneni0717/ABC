import { ChartPoint } from './chartPoint.interface';

export interface TwentyFourHourHistory {
    
    breakerId?: string;
    startDateTime: string;
    endDateTime: string;
    power: Array<ChartPoint>;
    voltageLLAB: Array<ChartPoint>;
    voltageLNAN: Array<ChartPoint>;
    voltageLNBN: Array<ChartPoint>;
    current: Array<ChartPoint>;

  }



