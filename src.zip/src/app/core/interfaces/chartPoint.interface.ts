export interface ChartPoint {

    intervalStart: string;
    intervalEnd: string;
    value: number;

}