export interface Location {
  id: string; 
  city: string;
  state: string;
  addressLine1: string;
  addressLine2: string;
  postalCode: string;
}
