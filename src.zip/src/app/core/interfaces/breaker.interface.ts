import { CurrentUsage } from "../interfaces/currentUsage.interface";
import { Location } from '../interfaces/location.interface';

export interface Breaker {
  
  breakerID: string;
  breakerType: string;
  recentUsage: CurrentUsage;
  deviceName: string;
  group: string;
  lastUpdate: Date;
  loadType: string;
  location: Location;
  status: string;
  cloudAgentId: string;
  commissionedDate: string;
  id: number;
  
}


