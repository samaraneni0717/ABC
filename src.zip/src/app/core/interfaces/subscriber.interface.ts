export interface Subscriber {
  id: number;
  userSubscriptionId: string;
  name: string;
  alias: string;
  address: Location

}