export interface Login {
  access_token: string;
  client_id: string;
  email: string;
  expires_in: string;
  issued_at: string;
  refresh_count: string;
  refresh_token: string;
  refresh_token_expires_in: string;
  refresh_token_issued_at: string;
  refresh_token_status: string;
  scope: string;
  token_name: string;
  unique_name: string;
}
