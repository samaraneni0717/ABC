export interface Group {
    group: string;
}