import { Breaker } from "../interfaces/breaker.interface";

export interface Devices {
  devices: Array<Breaker>
}
