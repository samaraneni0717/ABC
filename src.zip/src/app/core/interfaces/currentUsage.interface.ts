export interface CurrentUsage {
  current: {
    unit: string;
    value: number;
  };
  power: {
    unit: string;
    value: number;
  };
  voltage: {
    unit: string;
    value: number;
  };
}
