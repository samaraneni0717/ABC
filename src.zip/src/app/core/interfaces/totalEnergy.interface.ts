import { ChartPoint } from './chartPoint.interface';

export interface TotalEnergy {
    
    breakerId?: string;
    startDateTime: string;
    endDateTime: string;
    values: Array<ChartPoint>

  }
