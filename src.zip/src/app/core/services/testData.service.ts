import { Injectable } from "@angular/core";

// RXJS
import { Observable } from "rxjs/Observable";

// Interfaces
import { Devices } from "../interfaces/devices.interface"
import { TwentyFourHourHistory } from "../interfaces/twentyFourHourHistory.interface";
import { TotalEnergy } from "../interfaces/totalEnergy.interface";

// Classes
import { BreakerDetailParam } from "../classes/breakerDetailParam.class";

@Injectable()
export class DataAccess {

    constructor() { } 
    
    getTestBreakers() : Observable<Devices>{
        return Observable.create(function(observer){

            observer.next({
              devices: [
                {
                  breakerID: "30000c2a690c70b9",
                  deviceName: "Sunroom",
                  group: "Left-A",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 1.5582822211111111,
                      unit: "KW"
                    },
                    voltage: { value: 119.624, unit: "V" },
                    current: { value: 8, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c70c2",
                  deviceName: "Microwave",
                  group: "Left-A",
                  loadType: "Appliance",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 21.13699965888889, unit: "KW" },
                    voltage: { value: 119.297, unit: "V" },
                    current: { value: 21, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c70cd",
                  deviceName: "Kitchen Lights",
                  group: "Left-A",
                  loadType: "Lights",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 38.81610153333333, unit: "KW" },
                    voltage: { value: 118.342, unit: "V" },
                    current: { value: 9, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c70ea",
                  deviceName: "Bedroom 4",
                  group: "Left-B",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 32.00870544777778, unit: "KW" },
                    voltage: { value: 118.34, unit: "V" },
                    current: { value: 49, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c72e6",
                  deviceName: "Disposal",
                  group: "Left-B",
                  loadType: "Appliance",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 35.571895232222225,
                      unit: "KW"
                    },
                    voltage: { value: 118.609, unit: "V" },
                    current: { value: 46, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c771a",
                  deviceName: "Disposal",
                  group: "Left-B",
                  loadType: "Appliance",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 35.571895232222225,
                      unit: "KW"
                    },
                    voltage: { value: 118.609, unit: "V" },
                    current: { value: 46, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c773b",
                  deviceName: "Basement Lights",
                  group: "Left-A",
                  loadType: "Lights",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 88.27932893666667, unit: "KW" },
                    voltage: { value: 119.117, unit: "V" },
                    current: { value: 7, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                { breakerID: "30000c2a690c5977" },
                {
                  breakerID: "30000c2a690c7317",
                  deviceName: "Basement Outlets/Clothes Washer",
                  group: "Left-A",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 0.13950053222222222,
                      unit: "KW"
                    },
                    voltage: { value: 119.869, unit: "V" },
                    current: { value: 11, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c736e",
                  deviceName: "Compressor",
                  group: "Right-A",
                  loadType: "HVAC",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "2/40",
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c740b",
                  deviceName: "Bedroom 4",
                  group: "Left-B",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 33.793497702222226,
                      unit: "KW"
                    },
                    voltage: { value: 118.986, unit: "V" },
                    current: { value: 10, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c756f",
                  deviceName: "Clothes Dryer",
                  group: "Right-A",
                  loadType: "Appliance",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "2/30",
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c759b",
                  deviceName: "Smoke Detectors",
                  group: "Left-B",
                  loadType: "Sensor",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 32.50282724111111, unit: "KW" },
                    voltage: { value: 117.886, unit: "V" },
                    current: { value: 529, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c765c",
                  deviceName: "Bedroom 2",
                  group: "Left-B",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 0.4122051611111111,
                      unit: "KW"
                    },
                    voltage: { value: 118.481, unit: "V" },
                    current: { value: 7, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c73ef",
                  deviceName: "Heat Pump WH",
                  group: "Right-B",
                  loadType: "Water Heater",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "2/30",
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c592d",
                  deviceName: "Downstairs Bath",
                  group: "Left-A",
                  loadType: "Lights",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 11.75423264111111, unit: "KW" },
                    voltage: { value: 119.257, unit: "V" },
                    current: { value: 239, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c730e",
                  deviceName: "Refrigerator",
                  group: "Left-A",
                  loadType: "Appliance",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 162.6655975011111, unit: "KW" },
                    voltage: { value: 119.195, unit: "V" },
                    current: { value: 51, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c735d",
                  deviceName: "Dining Room",
                  group: "Left-B",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 393.89844824444447,
                      unit: "KW"
                    },
                    voltage: { value: 117.881, unit: "V" },
                    current: { value: 2306, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c7755",
                  deviceName: "Garage Lights and Plugs",
                  group: "Left-A",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 17.08688422, unit: "KW" },
                    voltage: { value: 118.577, unit: "V" },
                    current: { value: 52, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c7713",
                  deviceName: "Kitchen GFI Outlet",
                  group: "Left-B",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 38.12369437444445, unit: "KW" },
                    voltage: { value: 118.733, unit: "V" },
                    current: { value: 10, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c7716",
                  deviceName: "Living Room",
                  group: "Left-A",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 10.080734884444444,
                      unit: "KW"
                    },
                    voltage: { value: 119.299, unit: "V" },
                    current: { value: 10, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c7718",
                  deviceName: "Dishwasher",
                  group: "Left-B",
                  loadType: "Appliance",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 66.63863275111112, unit: "KW" },
                    voltage: { value: 118.543, unit: "V" },
                    current: { value: 12, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c7724",
                  deviceName: "Bedroom 1",
                  group: "Left-B",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: {
                      value: 23.599372315555556,
                      unit: "KW"
                    },
                    voltage: { value: 117.882, unit: "V" },
                    current: { value: 29, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                },
                {
                  breakerID: "30000c2a690c7375",
                  deviceName: "Downstairs Bath",
                  group: "Left-A",
                  loadType: "Plug Load",
                  location: {
                    addressLine2: "541",
                    city: "West Lafayette",
                    state: "IN",
                    postalCode: "47906"
                  },
                  breakerType: "1/20",
                  recentUsage: {
                    power: { value: 2.653791924444444, unit: "KW" },
                    voltage: { value: 119.13, unit: "V" },
                    current: { value: 9, unit: "A" }
                  },
                  status: "On",
                  lastUpdate: "2018-03-07T10:40:52-05:00"
                }
              ]
            });
        });
    }
    
    getTwentyFourHourHistoryTest(paramObj: BreakerDetailParam): Observable<TwentyFourHourHistory> {

        return Observable.create(function(observer){

            observer.next(
                
                {
                    breakerId: '124273434',
                    startDateTime: 'Monday, Jan 08, 2018 00:00:00',
                    endDateTime: 'Tuesday, Jan 09, 2018 00:00:00',

                    power: [
                        {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 00:30:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 00:45:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 01:00:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 01:15:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 01:30:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 01:45:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 02:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 02:15:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 02:30:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 02:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 03:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 03:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 03:30:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 03:45:00', value: 41 },
                        {dateTime: 'Monday, Jan 08, 2018 04:00:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 04:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 04:30:00', value: 40.92 },
                        {dateTime: 'Monday, Jan 08, 2018 04:45:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 05:00:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 05:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 05:30:00', value: 40.91 },
                        {dateTime: 'Monday, Jan 08, 2018 05:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 06:00:00', value: 40.93 }, 
                        {dateTime: 'Monday, Jan 08, 2018 06:15:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 06:30:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 06:45:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 07:00:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 07:15:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 07:30:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 07:45:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 08:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 08:15:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 08:30:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 08:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 09:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 09:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 09:30:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 09:45:00', value: 41 },
                        {dateTime: 'Monday, Jan 08, 2018 10:00:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 10:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 10:30:00', value: 40.92 },
                        {dateTime: 'Monday, Jan 08, 2018 10:45:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 11:00:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 11:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 11:30:00', value: 40.91 },
                        {dateTime: 'Monday, Jan 08, 2018 11:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 12:00:00', value: 40.93 },
                        {dateTime: 'Monday, Jan 08, 2018 12:15:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 12:30:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 12:45:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 13:00:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 13:15:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 13:30:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 13:45:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 14:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 14:15:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 14:30:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 14:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 15:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 15:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 15:30:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 15:45:00', value: 41 },
                        {dateTime: 'Monday, Jan 08, 2018 16:00:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 16:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 16:30:00', value: 40.92 },
                        {dateTime: 'Monday, Jan 08, 2018 16:45:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 17:00:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 17:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 17:30:00', value: 40.91 },
                        {dateTime: 'Monday, Jan 08, 2018 17:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 18:00:00', value: 40.93 },
                        {dateTime: 'Monday, Jan 08, 2018 18:15:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 18:30:00', value: 40.95 }, 
                        {dateTime: 'Monday, Jan 08, 2018 18:45:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 19:00:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 19:15:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 19:30:00', value: 41 }, 
                        {dateTime: 'Monday, Jan 08, 2018 19:45:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 20:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 20:15:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 20:30:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 20:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 08, 2018 21:00:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 21:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 21:30:00', value: 40.96 },
                        {dateTime: 'Monday, Jan 08, 2018 21:45:00', value: 41 },
                        {dateTime: 'Monday, Jan 08, 2018 22:00:00', value: 40.96 }, 
                        {dateTime: 'Monday, Jan 08, 2018 22:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 22:30:00', value: 40.92 },
                        {dateTime: 'Monday, Jan 08, 2018 22:45:00', value: 40.95 },
                        {dateTime: 'Monday, Jan 08, 2018 23:00:00', value: 40.92 }, 
                        {dateTime: 'Monday, Jan 08, 2018 23:15:00', value: 40.9 }, 
                        {dateTime: 'Monday, Jan 08, 2018 23:30:00', value: 40.91 },
                        {dateTime: 'Monday, Jan 08, 2018 23:45:00', value: 40.94 },
                        {dateTime: 'Monday, Jan 09, 2018 00:00:00', value: 40.93 },
                    ],

                    voltage: {

                        LN_AN: [
                            {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:30:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:45:00', value: 135 }, 
                            {dateTime: 'Monday, Jan 08, 2018 01:00:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 01:15:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 01:30:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 01:45:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 02:15:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:30:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 02:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 03:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 03:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 03:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 03:45:00', value: 87 },
                            {dateTime: 'Monday, Jan 08, 2018 04:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 04:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 04:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 04:45:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 05:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 05:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 05:30:00', value: 115 },
                            {dateTime: 'Monday, Jan 08, 2018 05:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 06:00:00', value: 80 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:15:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:30:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:45:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:00:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:15:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 07:30:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:45:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 08:15:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:30:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 08:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 09:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 09:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 09:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 09:45:00', value: 87 },
                            {dateTime: 'Monday, Jan 08, 2018 10:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 10:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 10:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 10:45:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 11:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 11:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 11:30:00', value: 115 },
                            {dateTime: 'Monday, Jan 08, 2018 11:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 12:00:00', value: 80 },
                            {dateTime: 'Monday, Jan 08, 2018 12:15:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 12:30:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 12:45:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:00:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:15:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 13:30:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:45:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 14:15:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:30:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 14:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 15:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 15:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 15:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 15:45:00', value: 87 },
                            {dateTime: 'Monday, Jan 08, 2018 16:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 16:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 16:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 16:45:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 17:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 17:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 17:30:00', value: 115 },
                            {dateTime: 'Monday, Jan 08, 2018 17:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 18:00:00', value: 80 },
                            {dateTime: 'Monday, Jan 08, 2018 18:15:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 18:30:00', value: 75 }, 
                            {dateTime: 'Monday, Jan 08, 2018 18:45:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:00:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:15:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 19:30:00', value: 87 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:45:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 20:15:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:30:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 20:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 08, 2018 21:00:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 21:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 21:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 21:45:00', value: 87 },
                            {dateTime: 'Monday, Jan 08, 2018 22:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 22:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 22:30:00', value: 100 },
                            {dateTime: 'Monday, Jan 08, 2018 22:45:00', value: 75 },
                            {dateTime: 'Monday, Jan 08, 2018 23:00:00', value: 100 }, 
                            {dateTime: 'Monday, Jan 08, 2018 23:15:00', value: 120}, 
                            {dateTime: 'Monday, Jan 08, 2018 23:30:00', value: 115 },
                            {dateTime: 'Monday, Jan 08, 2018 23:45:00', value: 90 },
                            {dateTime: 'Monday, Jan 09, 2018 00:00:00', value: 80 }
                        ],

                        LL_AB: [
                            {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:30:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:45:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 01:00:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 01:15:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 01:30:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 01:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 02:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 02:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 03:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 03:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 03:30:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 03:45:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 04:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 04:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 04:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 04:45:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 05:00:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 05:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 05:30:00', value: 145 },
                            {dateTime: 'Monday, Jan 08, 2018 05:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 06:00:00', value: 145 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:30:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:45:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:15:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 07:30:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 08:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 08:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 09:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 09:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 09:30:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 09:45:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 10:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 10:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 10:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 10:45:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 11:00:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 11:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 11:30:00', value: 144 },
                            {dateTime: 'Monday, Jan 08, 2018 11:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 12:00:00', value: 148 },
                            {dateTime: 'Monday, Jan 08, 2018 12:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 12:30:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 12:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:15:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 13:30:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 14:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 14:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 15:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 15:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 15:30:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 15:45:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 16:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 16:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 16:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 16:45:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 17:00:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 17:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 17:30:00', value: 146 },
                            {dateTime: 'Monday, Jan 08, 2018 17:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 18:00:00', value: 148 },
                            {dateTime: 'Monday, Jan 08, 2018 18:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 18:30:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 18:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:15:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 19:30:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 20:15:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 20:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 08, 2018 21:00:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 21:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 21:30:00', value: 175 },
                            {dateTime: 'Monday, Jan 08, 2018 21:45:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 22:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 22:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 22:30:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 22:45:00', value: 150 },
                            {dateTime: 'Monday, Jan 08, 2018 23:00:00', value: 150 }, 
                            {dateTime: 'Monday, Jan 08, 2018 23:15:00', value: 145}, 
                            {dateTime: 'Monday, Jan 08, 2018 23:30:00', value: 146 },
                            {dateTime: 'Monday, Jan 08, 2018 23:45:00', value: 147 },
                            {dateTime: 'Monday, Jan 09, 2018 00:00:00', value: 143 }
                        ],

                        LN_BN: [
                            {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:30:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 00:45:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 01:00:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 01:15:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 01:30:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 01:45:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:15:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 02:30:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 02:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 03:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 03:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 03:30:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 03:45:00', value: 250 },
                            {dateTime: 'Monday, Jan 08, 2018 04:00:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 04:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 04:30:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 04:45:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 05:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 05:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 05:30:00', value: 190 },
                            {dateTime: 'Monday, Jan 08, 2018 05:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 06:00:00', value: 230 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:15:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:30:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 06:45:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:00:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:15:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 07:30:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 07:45:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:15:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 08:30:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 08:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 09:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 09:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 09:30:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 09:45:00', value: 250 },
                            {dateTime: 'Monday, Jan 08, 2018 10:00:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 10:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 10:30:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 10:45:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 11:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 11:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 11:30:00', value: 190 },
                            {dateTime: 'Monday, Jan 08, 2018 11:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 12:00:00', value: 230 },
                            {dateTime: 'Monday, Jan 08, 2018 12:15:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 12:30:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 12:45:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:00:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:15:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 13:30:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 13:45:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:15:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 14:30:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 14:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 15:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 15:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 15:30:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 15:45:00', value: 250 },
                            {dateTime: 'Monday, Jan 08, 2018 16:00:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 16:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 16:30:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 16:45:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 17:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 17:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 17:30:00', value: 190 },
                            {dateTime: 'Monday, Jan 08, 2018 17:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 18:00:00', value: 230 },
                            {dateTime: 'Monday, Jan 08, 2018 18:15:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 18:30:00', value: 210 }, 
                            {dateTime: 'Monday, Jan 08, 2018 18:45:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:00:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:15:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 19:30:00', value: 250 }, 
                            {dateTime: 'Monday, Jan 08, 2018 19:45:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:15:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 20:30:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 20:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 08, 2018 21:00:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 21:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 21:30:00', value: 195 },
                            {dateTime: 'Monday, Jan 08, 2018 21:45:00', value: 250 },
                            {dateTime: 'Monday, Jan 08, 2018 22:00:00', value: 195 }, 
                            {dateTime: 'Monday, Jan 08, 2018 22:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 22:30:00', value: 200 },
                            {dateTime: 'Monday, Jan 08, 2018 22:45:00', value: 210 },
                            {dateTime: 'Monday, Jan 08, 2018 23:00:00', value: 200 }, 
                            {dateTime: 'Monday, Jan 08, 2018 23:15:00', value: 175 }, 
                            {dateTime: 'Monday, Jan 08, 2018 23:30:00', value: 190 },
                            {dateTime: 'Monday, Jan 08, 2018 23:45:00', value: 220 },
                            {dateTime: 'Monday, Jan 09, 2018 00:00:00', value: 230 }
                        ]
                    },

                    current: [
                        {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 00:30:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 00:45:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 01:00:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 01:15:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 01:30:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 01:45:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 02:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 02:15:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 02:30:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 02:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 03:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 03:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 03:30:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 03:45:00', value: 27.3 },
                        {dateTime: 'Monday, Jan 08, 2018 04:00:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 04:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 04:30:00', value: 27.31 },
                        {dateTime: 'Monday, Jan 08, 2018 04:45:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 05:00:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 05:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 05:30:00', value: 27.91 },
                        {dateTime: 'Monday, Jan 08, 2018 05:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 06:00:00', value: 27.93 }, 
                        {dateTime: 'Monday, Jan 08, 2018 06:15:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 06:30:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 06:45:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 07:00:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 07:15:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 07:30:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 07:45:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 08:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 08:15:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 08:30:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 08:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 09:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 09:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 09:30:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 09:45:00', value: 27.3 },
                        {dateTime: 'Monday, Jan 08, 2018 10:00:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 10:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 10:30:00', value: 27.31 },
                        {dateTime: 'Monday, Jan 08, 2018 10:45:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 11:00:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 11:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 11:30:00', value: 27.91 },
                        {dateTime: 'Monday, Jan 08, 2018 11:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 12:00:00', value: 27.93 },
                        {dateTime: 'Monday, Jan 08, 2018 12:15:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 12:30:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 12:45:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 13:00:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 13:15:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 13:30:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 13:45:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 14:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 14:15:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 14:30:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 14:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 15:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 15:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 15:30:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 15:45:00', value: 27.3 },
                        {dateTime: 'Monday, Jan 08, 2018 16:00:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 16:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 16:30:00', value: 27.31 },
                        {dateTime: 'Monday, Jan 08, 2018 16:45:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 17:00:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 17:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 17:30:00', value: 27.21 },
                        {dateTime: 'Monday, Jan 08, 2018 17:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 18:00:00', value: 27.23 },
                        {dateTime: 'Monday, Jan 08, 2018 18:15:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 18:30:00', value: 27.25 }, 
                        {dateTime: 'Monday, Jan 08, 2018 18:45:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 19:00:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 19:15:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 19:30:00', value: 27.3 }, 
                        {dateTime: 'Monday, Jan 08, 2018 19:45:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 20:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 20:15:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 20:30:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 20:45:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 21:00:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 21:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 21:30:00', value: 27.26 },
                        {dateTime: 'Monday, Jan 08, 2018 21:45:00', value: 27.3 },
                        {dateTime: 'Monday, Jan 08, 2018 22:00:00', value: 27.26 }, 
                        {dateTime: 'Monday, Jan 08, 2018 22:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 22:30:00', value: 27.31 },
                        {dateTime: 'Monday, Jan 08, 2018 22:45:00', value: 27.25 },
                        {dateTime: 'Monday, Jan 08, 2018 23:00:00', value: 27.31 }, 
                        {dateTime: 'Monday, Jan 08, 2018 23:15:00', value: 27.23 }, 
                        {dateTime: 'Monday, Jan 08, 2018 23:30:00', value: 27.24 },
                        {dateTime: 'Monday, Jan 08, 2018 23:45:00', value: 27.28 },
                        {dateTime: 'Monday, Jan 09, 2018 00:00:00', value: 27.3 },
                    ]
                    
                }
                
            );

        });
    
    }


    getTotalEnergyTest(): Observable<TotalEnergy> {

        //THE DATA BEING RETURNED MAY HAVE CHANGED SOME NOW THAT API IS BEING CALLED BUT
        //THIS IS WHAT WE USED INITIALLY

        return Observable.create(function (observer) {

            observer.next(

                {
                    breakerId: '124273434',
                    startDateTime: 'Monday, Jan 08, 2018 04:21:05',
                    endDateTime: 'Sunday, Jan 14, 2018 04:21:05',
                    values: [
                        {dateTime: 'Monday, Jan 08, 2018 04:21:05', value: 120 }, 
                        {dateTime: 'Tuesday, Jan 09, 2018 04:21:05', value: 100 }, 
                        {dateTime: 'Wednesday, Jan 10, 2018 04:21:05', value: 90 }, 
                        {dateTime: 'Thursday, Jan 11, 2018 04:21:05', value: 90 }, 
                        {dateTime: 'Friday, Jan 12, 2018 04:21:05', value: 75 },
                        {dateTime: 'Saturday, Jan 13, 2018 04:21:05', value: 120 },
                        {dateTime: 'Sunday, Jan 14, 2018 04:21:05', value: 140 }
                    ]
                }

            );

        });


    }
}