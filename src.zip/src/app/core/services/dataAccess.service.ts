import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from "@angular/common/http";

// RXJS 
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/empty';

// Interfaces
import { Breaker } from '../interfaces/breaker.interface';
import { Devices } from "../interfaces/devices.interface";
import { TwentyFourHourHistory } from "../interfaces/twentyFourHourHistory.interface";
import { TotalEnergy } from "../interfaces/totalEnergy.interface";
import { Subscriber } from "../interfaces/subscriber.interface";

//  Service
import { Login } from './login.service';

// Classes
import { BreakerDetailParam } from '../classes/breakerDetailParam.class';
import { BreakerGroupParam } from '../classes/breakerGroupParam.class';
import { ChartPointImpl } from '../classes/ChartPointImpl.class';
import { TotalEnergyImpl } from '../classes/totalEnergyImpl.class';
import { TwentyFourHourHistoryImpl } from '../classes/twentyFourHourHistoryImpl.class';
import { PendingRequest } from '../classes/pendingRequest.class';
import { BreakerImpl } from '../classes/breakerImpl.class';

@Injectable()
export class DataAccess {

    private queue: Array<PendingRequest> = new Array<PendingRequest>();
    
    constructor(private http: HttpClient, private loginService: Login) { }

    //**************************************
    //***** HTTP REQUEST QUEUE METHODS *****
    //**************************************

    private submit(pr: PendingRequest){

        if (pr.method === "GET"){
            this.http.get<any>(pr.url, { headers: pr.headers, params: pr.params })
                .catch(err => {

                    switch (err.status) {

                        case 401: {

                            return this.handle401ErrorRefresh(pr.url, pr.method, pr.headers, pr.params);

                        }
                        case 500: {

                            return this.handle500Error();

                        }
                        default: {

                            return this.handleOtherError();

                        }

                    }

                })
                .subscribe(res => {

                    pr.subject.next(res);
                    this.queue.shift();
                    this.submitNextRequest();

                })
        } else if (pr.method === "PUT"){
            this.http.put<Breaker>(pr.url, pr.payload, { headers: pr.headers, params: pr.params })
                .catch(err => {

                    switch (err.status) {

                        case 401: {

                            return this.handle401ErrorRefresh(pr.url, pr.method, pr.headers, pr.params, pr.payload);

                        }
                        case 500: {

                            return this.handle500Error();

                        }
                        default: {

                            return this.handleOtherError();

                        }

                    }

                })
                .subscribe(res => {

                    pr.subject.next(res);
                    this.queue.shift();
                    this.submitNextRequest();

                })
        }  

    }

    private submitNextRequest(){

        if (this.queue.length > 0) this.submit(this.queue[0]);

    }

    private addRequest(url: string, method: string, headers: HttpHeaders, params?: HttpParams, payload?: any){

        const sub = new Subject<any>();

        const req = new PendingRequest(url, method, headers, sub, params, payload);

        this.queue.push(req);

        if (this.queue.length === 1) this.submitNextRequest();

        return sub;

    }

    //*******************************************
    //***** APPLICATION REQUESTS FOR DATA *******
    //*******************************************

    editBreaker(breaker: Breaker):Observable<Breaker>{

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env"));

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let agentUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/devices/${breaker.id}/agents?active=true`;
        let agentHeaders: HttpHeaders = new HttpHeaders();
        let agentParams: HttpParams = new HttpParams();

        agentHeaders = agentHeaders.append('Content-Type', 'application/json');
        agentHeaders = agentHeaders.append('Authorization', `Bearer ${token}`);

        return this.addRequest(agentUrl, 'GET', agentHeaders, agentParams).switchMap(r => {
            
            let updateUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/agents/${r[0].id}`;
            let updateHeaders: HttpHeaders = new HttpHeaders();
            let updateParams: HttpParams = new HttpParams();

            updateHeaders = updateHeaders.append('Content-Type', 'application/json');
            updateHeaders = updateHeaders.append('Authorization', `Bearer ${token}`);

            let updatePayload = {

                name: breaker.deviceName,
                group: breaker.group,
                loadType: breaker.loadType

            };

            return this.addRequest(updateUrl, 'PUT', updateHeaders, updateParams, updatePayload).switchMap(a => {

                let breaker = new BreakerImpl();

                breaker.breakerID = a.hardwareDeviceId;
                breaker.breakerType = a.breakerType;
                breaker.cloudAgentId = a.cloudAgentId;
                breaker.commissionedDate = a.commissionedDate;
                breaker.deviceName = a.name;
                breaker.group = a.group;
                breaker.id = a.id;
                breaker.lastUpdate = a.lastUpdate;
                breaker.location = a.location;
                breaker.loadType = a.loadType;
                breaker.recentUsage = a.recentUsage;
                breaker.status = a.status;

                return Observable.of(breaker);

            }
            )
        }
        );
    }

    getSubscriptions(): Observable<Array<Subscriber>> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env"));

        let subUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions`;
        let subHeaders: HttpHeaders = new HttpHeaders();
        
        subHeaders = subHeaders.append('Content-Type', 'application/json');
        subHeaders = subHeaders.append('Authorization',`Bearer ${token}`);

        let subParams: HttpParams = new HttpParams();
        
        return this.addRequest(subUrl, 'GET', subHeaders, subParams).map(data => { return <Subscriber[]>data }); 
        
    }

    getBreakers(): Observable<Devices> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env"));

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let brUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/devices/summary`;
        let brHeaders: HttpHeaders = new HttpHeaders();
        
        brHeaders = brHeaders.append('Content-Type', 'application/json');
        brHeaders = brHeaders.append('Authorization',`Bearer ${token}`);

        let brParams: HttpParams = new HttpParams();

        return this.addRequest(brUrl, 'GET', brHeaders, brParams).switchMap(brks => { 
            
            let breakers = new Array<BreakerImpl>();
            
            for(let i=0; i<brks.length; i++){

                let breaker = new BreakerImpl();

                breaker.breakerID = brks[i].hardwareDeviceId;
                breaker.breakerType = brks[i].breakerType;
                breaker.cloudAgentId = brks[i].cloudAgentId;
                breaker.commissionedDate = brks[i].commissionedDate;
                breaker.deviceName = brks[i].name;
                breaker.group = brks[i].group;
                breaker.id = brks[i].id;
                breaker.lastUpdate = brks[i].lastUpdate;
                breaker.location = brks[i].location;
                breaker.loadType = brks[i].loadType;
                breaker.recentUsage = brks[i].recentUsage;
                breaker.status = brks[i].status;

                breakers[i] = breaker;

            }

            return Observable.of({devices: breakers});
            
        });

    }

    getTwentyFourHourHistory(paramObj: BreakerDetailParam): Observable<TwentyFourHourHistory> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env"));

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let tfhUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/devices/${paramObj.id}/intervals`;
        let tfhHeaders: HttpHeaders = new HttpHeaders();
        let tfhParams: HttpParams = new HttpParams();
        
        tfhHeaders = tfhHeaders.append('Content-Type', 'application/json');
        tfhHeaders = tfhHeaders.append('Authorization',`Bearer ${token}`);
        
        tfhParams = tfhParams.set('startdate', paramObj.startDate);
        tfhParams = tfhParams.set("enddate", paramObj.endDate);
        tfhParams = tfhParams.set('interval', paramObj.interval);

        return this.addRequest(tfhUrl, 'GET', tfhHeaders, tfhParams)
            .switchMap(r => {
                let tfhh: TwentyFourHourHistoryImpl = new TwentyFourHourHistoryImpl();

                tfhh.breakerId = paramObj.id
                tfhh.startDateTime = paramObj.startDate;
                tfhh.endDateTime = paramObj.endDate;

                r.forEach(item => {
                    //SET POWER
                    tfhh.power.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.realPower.value));

                    //SET CURRENT
                    tfhh.current.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.current.a.value));

                    //SET LL_AB VOLTAGE
                    tfhh.voltageLLAB.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.voltage.LL_AB.value));

                    //SET LL_AB VOLTAGE
                    tfhh.voltageLNAN.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.voltage.LN_AN.value));

                    //SET LL_AB VOLTAGE
                    tfhh.voltageLNBN.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.voltage.LN_BN.value));
                });

                return Observable.of(tfhh);

            })
            
    }

    getTwentyFourHourHistoryByGroup(paramObj: BreakerGroupParam): Observable<TwentyFourHourHistory> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env")); 

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let tfhhgUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/groups/intervals`;
        let tfhhgHeaders: HttpHeaders = new HttpHeaders();
        let tfhhgParams: HttpParams = new HttpParams();
        
        tfhhgHeaders = tfhhgHeaders.append('Content-Type', 'application/json');
        tfhhgHeaders = tfhhgHeaders.append('Authorization',`Bearer ${token}`);
         
        tfhhgParams = tfhhgParams.set('startdate', paramObj.startDate);
        tfhhgParams = tfhhgParams.set('enddate', paramObj.endDate);
        tfhhgParams = tfhhgParams.set("interval", paramObj.interval); 
        
        if(paramObj.groups.trim() != '*'){
            tfhhgParams = tfhhgParams.set("groupNames", paramObj.groups);
        }
                
        return this.addRequest(tfhhgUrl, 'GET', tfhhgHeaders, tfhhgParams)
            .switchMap(r => {

                let tfhhg: TwentyFourHourHistoryImpl = new TwentyFourHourHistoryImpl();
                tfhhg.startDateTime = paramObj.startDate;
                tfhhg.endDateTime = paramObj.endDate;

                r.forEach(item => {
                    //SET POWER
                    tfhhg.power.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.realPower.value));

                    //SET CURRENT
                    tfhhg.current.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.current.a.value));

                    //SET LL_AB VOLTAGE
                    tfhhg.voltageLLAB.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.voltage.LL_AB.value));

                    //SET LL_AB VOLTAGE
                    tfhhg.voltageLNAN.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.voltage.LN_AN.value));

                    //SET LL_AB VOLTAGE
                    tfhhg.voltageLNBN.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.voltage.LN_BN.value));
                });


                return Observable.of(tfhhg);

            })
            
    }

    getTotalEnergy(paramObj: BreakerDetailParam): Observable<TotalEnergy> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env")); 

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let teUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/devices/${paramObj.id}/intervals`;
        let teHeaders: HttpHeaders = new HttpHeaders();
        let teParams: HttpParams = new HttpParams();
        
        teHeaders = teHeaders.append('Content-Type', 'application/json');
        teHeaders = teHeaders.append('Authorization',`Bearer ${token}`);
        
        teParams = teParams.set('startdate', paramObj.startDate);
        teParams = teParams.set('enddate', paramObj.endDate);
        teParams = teParams.set("interval", paramObj.interval);        
        
        return this.addRequest(teUrl, 'GET', teHeaders, teParams)
            .switchMap(r => {

                let te: TotalEnergyImpl = new TotalEnergyImpl();
                te.breakerId = paramObj.id;
                te.startDateTime = paramObj.startDate;
                te.endDateTime = paramObj.endDate;

                r.forEach(item => te.values.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.realEnergy.value)));

                return Observable.of(te);

            })     

    }

    getTotalEnergyByGroup(paramObj: BreakerGroupParam): Observable<TotalEnergy> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env")); 

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let tegUrl: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/groups/intervals`;
        let tegHeaders: HttpHeaders = new HttpHeaders();
        let tegParams: HttpParams = new HttpParams();
        
        tegHeaders = tegHeaders.append('Content-Type', 'application/json');
        tegHeaders = tegHeaders.append('Authorization',`Bearer ${token}`);
         
        tegParams = tegParams.set('startdate', paramObj.startDate);
        tegParams = tegParams.set('enddate', paramObj.endDate);
        tegParams = tegParams.set("interval", paramObj.interval); 
        
        if(paramObj.groups.trim() != '*'){
            tegParams = tegParams.set("groupNames", paramObj.groups);
        }
        
        return this.addRequest(tegUrl, 'GET', tegHeaders, tegParams)
            .switchMap(r => {

                let teg: TotalEnergyImpl = new TotalEnergyImpl();
                teg.startDateTime = paramObj.startDate;
                teg.endDateTime = paramObj.endDate;

                r.forEach(item =>  teg.values.push(new ChartPointImpl(item.intervalStart, item.intervalEnd, item.realEnergy.value)));

                return Observable.of(teg);

            })    

    }

    getExportData(ids: string, startDate: string, endDate: string): Observable<any> {

        let token = JSON.parse(sessionStorage.getItem("user")).access_token;
        let environment = JSON.parse(sessionStorage.getItem("env"));

        let subscriberId = JSON.parse(sessionStorage.getItem("subscriber")).id;

        let exportURL: string = `${environment.apigeeUrl}/ulms/v1/subscriptions/${subscriberId}/devices/intervals`;
        let exportHeaders: HttpHeaders = new HttpHeaders();
        let exportParams: HttpParams = new HttpParams();

        exportHeaders = exportHeaders.append('Content-Type', 'application/json');
        exportHeaders = exportHeaders.append('Authorization', `Bearer ${token}`);

        exportParams = exportParams.set('startdate', startDate);
        exportParams = exportParams.set("enddate", endDate);
        exportParams = exportParams.set("deviceIds", ids);
        exportParams = exportParams.set('interval', 'min15');

        return this.addRequest(exportURL, 'GET', exportHeaders, exportParams).switchMap(brksExp => {

            return Observable.of(brksExp);
        });


    }

    //************************************
    //***** ERROR HANDLING METHODS *******
    //************************************

    handle401ErrorRefresh(url: string, method: string, header: HttpHeaders, params?: HttpParams, payload?: any): Observable<any> {

        let errorObservable: Observable<Array<any>> = Observable.of(new Array<any>());

        return errorObservable
            .switchMap((empty) => {

                return this.removeRefreshToken();

            }).switchMap((refTok) => {

                return this.loginService.refresh(refTok);

            }).switchMap((refRes) => {

                if (refRes == true) {

                    let newToken: string = JSON.parse(sessionStorage.getItem("user")).access_token;
                    let environment = JSON.parse(sessionStorage.getItem("env"));

                    //SET HEADERS IN ALL PENDING REQUESTS TO USE NEW TOKEN INSTEAD OF OLD TOKEN
                    this.queue.forEach(pr => {
                        pr.headers = null;
                        pr.headers = new HttpHeaders();
                        pr.headers = pr.headers.append('Content-Type', 'application/json');
                        pr.headers = pr.headers.append('Authorization',`Bearer ${newToken}`);
                    })

                    //HEADERS BEING PASSED IN BECAUSE WE MAY NEED SOME INFO BUT REBUILD HEADERS HERE DUE TO NEW TOKEN
                    header = null;
                    header = new HttpHeaders();
                    header = header.append('Content-Type', 'application/json');
                    header = header.append('Authorization', `Bearer ${newToken}`);

                    if (method === "GET"){
                        return this.http.get<any>(url, { headers: header, params: params })
                            .catch(err => {

                                return <Observable<any>>this.handleError(err);

                            })
                    } else if (method === "PUT"){
                        return this.http.put<any>(url, payload, { headers: header, params: params })
                            .catch(err => {

                                return <Observable<any>>this.handleError(err);

                            })

                    }

                } else {

                    this.loginService.redirect();
                    return Observable.empty<any>();

                }

            })

    }

    removeRefreshToken(): Observable<string>{

        let refreshToken: string = JSON.parse(sessionStorage.getItem("user")).refresh_token;
        let rt: Observable<string> = Observable.of(refreshToken);

        sessionStorage.removeItem("user");
        return rt;
    }

    handleError<T>(err: HttpErrorResponse): Observable<T> {

        switch (err.status) {

            case 401: {

                return this.handle401Error();

            }
            case 500: {

                return this.handle500Error();

            }
            default: {

                return this.handleOtherError();

            }

        }
    }

    handle401Error<T>(): Observable<T> {

        this.loginService.redirect();
        return Observable.empty<T>();

    }

    handle500Error<T>(): Observable<T> {

        //THIS METHOD IS A TEMPORARY PLACEHOLDER ... CURRENTLY ONLY HAVE HANDLER FOR 401 ERROR WITH REFRESH
        return Observable.empty<T>();

    }

    handleOtherError<T>(): Observable<T> {

        //THIS METHOD IS A TEMPORARY PLACEHOLDER ... CURRENTLY ONLY HAVE HANDLER FOR 401 ERROR WITH REFRESH
        return Observable.empty<T>();

    }

    

}
