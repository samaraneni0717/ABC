import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { environment } from "../../../environments/environment";

import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/map";

@Injectable()
export class EnvironmentVariables {
  constructor(private http: HttpClient) {}

  getEnvVars(): Observable<any> {

    return this.http.get(environment.environmentApi)
      .map(res => res);
  }

}
