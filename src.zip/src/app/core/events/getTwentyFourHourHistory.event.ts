export class GetTwentyFourHourHistoryEvent {

    constructor(public subscriberId: string, public breakerId: string, public startDate: string, public endDate: string){}

}