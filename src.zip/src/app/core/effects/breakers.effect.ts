import {Injectable} from '@angular/core';

import {Action} from '@ngrx/store';
import { Actions, Effect } from "@ngrx/effects";
import { Observable } from "rxjs/Rx"; 
import { switchMap } from "rxjs/operators";

import { MpiAction } from '../store/mpiAction.interface';
import { MpiActionCreator } from '../store/mpiActionCreator.service';

import { DataAccess } from '../services/dataAccess.service';

@Injectable()
export class BreakerEffects {

    constructor(private mpiActionCreator: MpiActionCreator, private actions$: Actions, private dataService: DataAccess){    }

    @Effect()
    getBreakers$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_BREAKERS)
        .switchMap(() => this.dataService.getBreakers()
        .map(data => this.mpiActionCreator.gotBreakers(data))) //action automatically dispatched to store with data

    @Effect()
    editBreakers$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.SAVE_CHANGES)
        .switchMap(action => this.dataService.editBreaker((<MpiAction>action).payload.breaker)
        .map(data => this.mpiActionCreator.madeChanges(data)))
}