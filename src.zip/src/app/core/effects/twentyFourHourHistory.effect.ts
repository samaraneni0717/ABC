import {Injectable} from '@angular/core';

import {Action} from '@ngrx/store';
import { Actions, Effect } from "@ngrx/effects";
import { Observable } from "rxjs/Rx"; 
import { switchMap } from "rxjs/operators";

import { MpiAction } from '../store/mpiAction.interface';
import { MpiActionCreator } from '../store/mpiActionCreator.service';

import { DataAccess } from '../services/dataAccess.service';

@Injectable()
export class TwentyFourHourHistoryEffects {

    constructor(private mpiActionCreator: MpiActionCreator, private actions$: Actions, private dataService: DataAccess){    }

    @Effect()
    getTwentyFourHourHistory$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TWENTY_FOUR_HOUR_HISTORY)
        .switchMap((action) => { return this.dataService.getTwentyFourHourHistory((<MpiAction>action).payload) })
        .map(data => this.mpiActionCreator.gotTwentyFourHourHistory(data)); //action automatically dispatched to store with data

    @Effect()
    getTwentyFourHourHistoryByGroup$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TWENTY_FOUR_HOUR_HISTORY_BY_GROUP)
        .switchMap((action) => { return this.dataService.getTwentyFourHourHistoryByGroup((<MpiAction>action).payload) })
        .map(data => this.mpiActionCreator.gotTwentyFourHourHistoryByGroup(data)); //action automatically dispatched to store with data

        
}