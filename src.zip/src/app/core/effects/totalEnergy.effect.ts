import {Injectable} from '@angular/core';

import {Action} from '@ngrx/store';
import { Actions, Effect } from "@ngrx/effects";
import { Observable } from "rxjs/Rx"; 
import { switchMap } from "rxjs/operators";

import { MpiAction } from '../store/mpiAction.interface';
import { MpiActionCreator } from '../store/mpiActionCreator.service';

import { DataAccess } from '../services/dataAccess.service';

@Injectable()
export class TotalEnergyEffects {

    constructor(private mpiActionCreator: MpiActionCreator, private actions$: Actions, private dataService: DataAccess){    }

    @Effect()
    getTotalDailyEnergy$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TOTAL_DAILY_ENERGY)
        .switchMap(action => this.dataService.getTotalEnergy((<MpiAction>action).payload))
        .map(data => this.mpiActionCreator.gotTotalDailyEnergy(data)); //action automatically dispatched to store with data

    @Effect()
    getTotalWeeklyEnergy$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TOTAL_WEEKLY_ENERGY)
        .switchMap(action => this.dataService.getTotalEnergy((<MpiAction>action).payload))
        .map(data => this.mpiActionCreator.gotTotalWeeklyEnergy(data)); //action automatically dispatched to store with data

    @Effect()
    getTotalMonthlyEnergy$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TOTAL_MONTHLY_ENERGY)
        .switchMap(action => this.dataService.getTotalEnergy((<MpiAction>action).payload))
        .map(data => this.mpiActionCreator.gotTotalMonthlyEnergy(data)); //action automatically dispatched to store with data

    @Effect()
    getTotalDailyEnergyByGroup$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TOTAL_DAILY_ENERGY_BY_GROUP)
        .switchMap(action => this.dataService.getTotalEnergyByGroup((<MpiAction>action).payload))
        .map(data => this.mpiActionCreator.gotTotalDailyEnergyByGroup(data)); //action automatically dispatched to store with data

    @Effect()
    getTotalWeeklyEnergyByGroup$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TOTAL_WEEKLY_ENERGY_BY_GROUP)
        .switchMap(action => this.dataService.getTotalEnergyByGroup((<MpiAction>action).payload))
        .map(data => this.mpiActionCreator.gotTotalWeeklyEnergyByGroup(data)); //action automatically dispatched to store with data

    @Effect()
    getTotalMonthlyEnergyByGroup$: Observable<Action> = this.actions$
        .ofType(MpiActionCreator.GET_TOTAL_MONTHLY_ENERGY_BY_GROUP)
        .switchMap(action => this.dataService.getTotalEnergyByGroup((<MpiAction>action).payload))
        .map(data => this.mpiActionCreator.gotTotalMonthlyEnergyByGroup(data)); //action automatically dispatched to store with data


}