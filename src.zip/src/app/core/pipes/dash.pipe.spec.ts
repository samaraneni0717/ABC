import { nullToDash } from "./dash.pipe";

describe("nullToDash", () => {
  // This pipe is a pure, stateless function so no need for BeforeEach
  let pipe = new nullToDash();

  it('Keeps "Test" as "Test"', () => {
    expect(pipe.transform("Test")).toBe("Test");
  });

  it('transforms "null" to "--"', () => {
    expect(pipe.transform(null)).toBe("--");
  });

  it('transforms "undefined" to "--"', () => {
    expect(pipe.transform(undefined)).toBe("--");
  });

  it('transforms "" to "--"', () => {
    expect(pipe.transform("")).toBe("--");
  });
});
