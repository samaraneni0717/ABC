import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: "statusChange" })
export class statusChange implements PipeTransform {
  transform(value: string): string {
    let status = value;
    let newStatus;
    switch (status){
      case "On":
        return newStatus = "On";
      case "Off":
        return newStatus = "Off";
      default:
        return newStatus = "Tripped";
    }
  }
}