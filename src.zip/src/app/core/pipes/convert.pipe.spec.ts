import { convert } from './convert.pipe';

describe("convert", () => {
  // This pipe is a pure, stateless function so no need for BeforeEach
    let pipe = new convert();

    it('transforms "188888" to "189"', () => {
        expect(pipe.transform(188888)).toBe(189);
    });

    it('transforms "123456" to "123"', () => {
        expect(pipe.transform(123456)).toBe(124);
    });

    it('transforms "123456789" to "123456.789"', () => {
    expect(pipe.transform(123456789)).toBe(123457);
    });
});