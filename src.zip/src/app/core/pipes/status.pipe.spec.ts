import { statusChange } from "./status.pipe";

describe("statusChange", () => {
  // This pipe is a pure, stateless function so no need for BeforeEach
  let pipe = new statusChange();

  it('transforms "On" to "On"', () => {
    expect(pipe.transform("On")).toBe("On");
  });

  it('transforms "Off" to "Off"', () => {
    expect(pipe.transform("Off")).toBe("Off");
  });

  it('transforms "null" to "Tripped"', () => {
    expect(pipe.transform(null)).toBe("Tripped");
  });

  it('transforms "undefined" to "Tripped"', () => {
    expect(pipe.transform(undefined)).toBe("Tripped");
  });
  
});
