import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: "nullToDash" })
export class nullToDash implements PipeTransform {
  transform(value: any): string {
    let newValue;
    switch (value) {
        case null:
            return (newValue = "--");
        case undefined:
            return (newValue = "--");
        case "":
            return (newValue = "--");
        default:
            return value;
    }
  }
}
