import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: "convert" })

export class convert implements PipeTransform {
  transform(value: number): number {
    return Math.ceil(value / 1000);
  }
}
