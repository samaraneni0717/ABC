import { ChartPoint } from '../interfaces/chartPoint.interface';

export class ChartPointImpl implements ChartPoint {

    constructor(public intervalStart: string, public intervalEnd: string, public value: number){ }

}