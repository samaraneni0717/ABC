import { Breaker } from '../../core/interfaces/breaker.interface';
import { CurrentUsage } from '../../core/interfaces/currentUsage.interface';
import { Location } from '../../core/interfaces/location.interface';

export class BreakerImpl implements Breaker {
    
    breakerID: string;
    breakerType: string;
    recentUsage: CurrentUsage;
    deviceName: string;
    group: string;
    lastUpdate: Date;
    loadType: string;
    location: Location;
    status: string;
    cloudAgentId: string;
    commissionedDate: string;
    id: number;
  
}