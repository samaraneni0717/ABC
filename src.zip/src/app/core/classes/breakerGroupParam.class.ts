export class BreakerGroupParam{

    constructor(public groups: string, public startDate: string, public endDate: string, public interval: string){ }

}

