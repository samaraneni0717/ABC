export class BreakerDetailParam{

    constructor(public id: string, public startDate: string, public endDate: string, public interval: string){ }

}

