import { Breaker } from "../interfaces/breaker.interface";

export class BreakerEdit {

    constructor(public breaker: Breaker) { }

}