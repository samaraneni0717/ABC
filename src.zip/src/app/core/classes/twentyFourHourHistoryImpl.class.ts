import { ChartPoint } from '../../core/interfaces/chartPoint.interface';
import { TwentyFourHourHistory } from '../../core/interfaces/twentyFourHourHistory.interface';

export class TwentyFourHourHistoryImpl implements TwentyFourHourHistory {
    
    breakerId?: string;
    startDateTime: string;
    endDateTime: string;
    power: Array<ChartPoint>;
    voltageLLAB: Array<ChartPoint>;
    voltageLNAN: Array<ChartPoint>;
    voltageLNBN: Array<ChartPoint>;
    current: Array<ChartPoint>;

    constructor(){

        this.power = new Array<ChartPoint>();
        this.current = new Array<ChartPoint>();
        this.voltageLLAB = new Array<ChartPoint>();
        this.voltageLNAN = new Array<ChartPoint>();
        this.voltageLNBN = new Array<ChartPoint>();

    }

  }