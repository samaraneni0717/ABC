import { ChartPoint } from '../interfaces/chartPoint.interface';
import { TotalEnergy } from '../interfaces/totalEnergy.interface';

export class TotalEnergyImpl implements TotalEnergy {
    
    breakerId?: string;
    startDateTime: string;
    endDateTime: string;
    values: Array<ChartPoint>;

    constructor(){

      this.values = new Array<ChartPoint>();

    }

  }