import {HttpHeaders, HttpParams } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';

export class PendingRequest{

    constructor(public url: string, public method: string, public headers: HttpHeaders, public subject: Subject<any>, public params?: HttpParams, public payload?: any){ }

}