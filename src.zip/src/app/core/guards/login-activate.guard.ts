import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AppState } from '../../core/store/appstate.interface';
import { Store } from '@ngrx/store';
import { Login } from '../interfaces/login.interface';
import { Login as LoginService } from '../services/login.service';
import { EnvironmentVariables } from '../services/envionment.service';

@Injectable()
export class LoginActivateGuard implements CanActivate {

  constructor(private loginService: LoginService, private env: EnvironmentVariables) { } 

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    return this.loginService.userLoginStatus()
      .switchMap(ls => {
        if (ls == true) {
          return Observable.of(true);
        }
        else {
          
          this.loginService.redirect();
          return Observable.of(false);
        }

      });

  }

}

