import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from "@angular/router";

import { LoginActivateGuard } from './login-activate.guard';

//Services
import { Login as LoginService } from "../services/login.service";
import { EnvironmentVariables } from '../services/envionment.service';

describe('LoginActivateGuard', () => {
  // let httpMock: HttpTestingController;
  // let loginService: LoginService;
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        EnvironmentVariables,
        LoginActivateGuard,
        LoginService,
        { provide: Router, useValue: { params: "" } }
      ]
    });
  });

  it('should ...', inject([LoginActivateGuard], (guard: LoginActivateGuard) => {
    expect(guard).toBeTruthy();
  }));

});