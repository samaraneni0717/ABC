import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { Router } from '@angular/router';


@Component({
  
  selector: 'subscribers-choose-modal',
  templateUrl: './subscribers-choose-modal.component.html',
  styleUrls: ['./subscribers-choose-modal.component.scss']
  
})
export class SubscribersChooseModalComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) private subData: any, public dialogRef: MatDialogRef<SubscribersChooseModalComponent>, private router: Router) { }

  ngOnInit() {
  }

  onSelect($event){

    sessionStorage.setItem("subscriber", JSON.stringify($event));

    this.dialogRef.close();

    this.router.navigate(['dashboard']);
    

  }

  onCloseClick(): void{

    this.dialogRef.close();

  }

  

}
