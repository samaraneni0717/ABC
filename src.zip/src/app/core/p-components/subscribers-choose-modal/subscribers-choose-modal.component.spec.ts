import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscribersChooseModalComponent } from './subscribers-choose-modal.component';

describe('SubscribersModalComponent', () => {
  let component: SubscribersChooseModalComponent;
  let fixture: ComponentFixture<SubscribersChooseModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubscribersChooseModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscribersChooseModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
