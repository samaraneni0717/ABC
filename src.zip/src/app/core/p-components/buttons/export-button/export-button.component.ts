import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from "@angular/material/dialog";

import { Breaker } from '../../../interfaces/breaker.interface';
import { ModalComponent } from '../../modal/modal.component';

@Component({
  selector: "export-button",
  templateUrl: "./export-button.component.html"
})
export class ExportButtonComponent implements OnInit {
  private dialogRef: any;
  @Input() className: string;
  @Input() data: Array<Breaker> = [];
  @Input() id: number;
  @Input() text: string;
  newData = [];

  constructor(public dialog: MatDialog) {}

  ngOnInit() {}

  ngOnChanges() {
    // Catch errors coming from changing data.
    if (this.data != this.data) {
      this.data = this.data;
    }

    this.newData = this.data;
  }

  openDialog(): void {
    this.dialogRef = this.dialog.open(ModalComponent, {
      height: "300px",
      width: "500px",
      data: this.newData
    });
  }
}
