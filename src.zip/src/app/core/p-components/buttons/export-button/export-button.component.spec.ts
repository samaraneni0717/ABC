import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from "@angular/core";

// Components
import { BreakerTableComponent } from "../../breaker-table/breaker-table.component";
import { ExportButtonComponent } from "./export-button.component";
import { ModalComponent } from "../../modal/modal.component";

// Material Import
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatTableModule, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

// Pipes
import { convert } from "../../../pipes/convert.pipe";
import { nullToDash } from "../../../pipes/dash.pipe";
import { statusChange } from "../../../pipes/status.pipe";

// Mock Class for MatDialog
import { MatDialogMock } from "../../../../../testing/dialog-stub";

describe('ExportButtonComponent', () => {
  let component: BreakerTableComponent;
  let fixture: ComponentFixture<BreakerTableComponent>;
  let buttonComponent: ExportButtonComponent;
  let buttonFixture: ComponentFixture<ExportButtonComponent>;
  let exportButton;
  let mockText: string = "Export";
  let mockClass: string = "dark export-button";

  // Mock Data
  let mockBreakers: any[] = [
    {
        breakerId: 124273434,
        deviceName: 'Backflush Pump',
        group: 3,
        loadType: 'Pump',
        location: {city: 'Columbus', state: 'OH', zipCode: '43001'},
        breakerType: '2 Poll 20 amps',
        currentUsage: 220,
        status: true,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 123456722,
        deviceName: '80 Gallon WH',
        group: 2,
        loadType: 'Water Heater',
        location: {city: 'Charlotte', state: 'NC', zipCode: '28117'},  
        breakerType: '1 Poll 30 amps',
        currentUsage: 7200,
        status: true,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 726494671,
        deviceName: "Car Charger Parking Space #10",
        group: 1,
        loadType: "EVSE",
        location: {city: "Charlotte", state: 'NC', zipCode: '28117'},
        breakerType: "EVSE 30 amps",
        currentUsage: 4000,
        status: true,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 844784938,
        deviceName: "220w LED light",
        group: 1,
        loadType: "Light",
        location: {city: "Raleigh", state: "NC", zipCode: "27511"},
        breakerType: "2 Poll 50 amps",
        currentUsage: 0,
        status: false,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        convert,
        BreakerTableComponent,
        ExportButtonComponent,
        ModalComponent,
        nullToDash,
        statusChange
      ],
      imports: [MatCheckboxModule, MatTableModule], 
      providers: [
        {provide: MatDialog, useClass: MatDialogMock},
        {provide: MAT_DIALOG_DATA, useValue: {data: mockBreakers}},
        {provide: MatDialogRef, useValue: {}},
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreakerTableComponent);
    component = fixture.componentInstance;
    // Creating an instance for the testing button clicking instances.
    buttonFixture = TestBed.createComponent(ExportButtonComponent);
    buttonComponent = buttonFixture.componentInstance;
    component.breaker = mockBreakers;
    exportButton = fixture.nativeElement.querySelector('export-button');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should display input text", () => {
    expect(exportButton.textContent.trim()).toEqual(mockText);
  });

  it("should display class name", () => {
    expect(exportButton.attributes.getNamedItem('ng-reflect-class-name').value).toContain(mockClass);
  });

  it("should contain data passed from breaker table", () => {
    exportButton.attributes.getNamedItem("ng-reflect-data").value = component.breaker;
    expect(exportButton.attributes.getNamedItem("ng-reflect-data").value).toContain(mockBreakers);    
  });

  it("should raise selected event when clicked", () => {
    spyOn(buttonComponent, "openDialog");

    let button = buttonFixture.debugElement.nativeElement.querySelector("button");
    button.click();

    buttonFixture.whenStable().then(() => {
      expect(buttonComponent.openDialog).toHaveBeenCalled();
    });
  });
});
