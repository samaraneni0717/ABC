import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from "@angular/core";

// Components
import { BreakerPanelComponent } from "../../breaker-panel/breaker-panel.component";
import { EditButtonComponent } from "./edit-button.component";

// Pipes
import { nullToDash } from "../../../pipes/dash.pipe";
import { statusChange } from "../../../pipes/status.pipe";

describe('EditButtonComponent', () => {
  let component: BreakerPanelComponent;
  let fixture: ComponentFixture<BreakerPanelComponent>;
  
  let buttonComponent: EditButtonComponent;
  let buttonFixture: ComponentFixture<EditButtonComponent>;
  
  let editButton;
  let mockClass: string = "breaker-panel-edit";

  // Mock Data
  let mockBreaker =
    {
      breakerID: "30000c2a690c70b9",
      deviceName: "Sunroom",
      group: "Left-A",
      loadType: "Plug Load",
      location: {
        addressLine1: "541 Sesame Street",
        addressLine2: null,
        city: "West Lafayette",
        state: "IN",
        postalCode: "47906"
      },
      breakerType: "1/20",
      recentUsage: {
        power: { value: 1.5582822211111111, unit: "KW" },
        voltage: { value: 119.624, unit: "V" },
        current: { value: 8, unit: "A" }
      },
      status: "On",
      lastUpdate: new Date()
    };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        BreakerPanelComponent,
        EditButtonComponent,
        nullToDash,
        statusChange
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreakerPanelComponent);
    component = fixture.componentInstance;
    component.mode = "breakerView";
    // Gives mock input a value
    component.breakers = mockBreaker; 
    // Gives mock value to breaker (after input value has been filtered)  
    component.breaker = mockBreaker;    
    // Creating an instance for the testing button clicking instances.
    buttonFixture = TestBed.createComponent(EditButtonComponent);
    buttonComponent = buttonFixture.componentInstance;
    fixture.detectChanges();   
    editButton = fixture.nativeElement.querySelector("edit-button");      
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should display class name", () => {
    expect(editButton.attributes.getNamedItem('ng-reflect-class-name').value).toContain(mockClass);
  });

  it("should contain data passed from breaker table", () => {
    editButton.attributes.getNamedItem("ng-reflect-breaker").value = component.breaker;
    expect(editButton.attributes.getNamedItem("ng-reflect-breaker").value).toContain(mockBreaker);    
  });

  it("should raise selected event when clicked", () => {
    spyOn(buttonComponent, "editFields");

    let button = buttonFixture.debugElement.nativeElement.querySelector("button");
    button.click();

    buttonFixture.whenStable().then(() => {
      expect(buttonComponent.editFields).toHaveBeenCalled();
    });
  });
});
