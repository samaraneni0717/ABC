import { Component, EventEmitter, OnInit, Input, Output } from '@angular/core';

import { Breaker } from '../../../interfaces/breaker.interface';

@Component({
  selector: "edit-button",
  templateUrl: "./edit-button.component.html"
})
export class EditButtonComponent implements OnInit {
  @Input() className: string;
  @Input() breaker: Breaker;

  @Output() breakerEdits = new EventEmitter();
  @Output() edits = new EventEmitter();

  edit: boolean = false;

  constructor() {}

  ngOnInit() {}

  editFields() {
    this.edit = this.edit ? false : true;
    this.edits.emit(this.edit);

    if (!this.edit) {
      this.saveChanges();
    }
  }

  saveChanges() {
    this.breakerEdits.emit({ breaker: this.breaker });
  }
}
