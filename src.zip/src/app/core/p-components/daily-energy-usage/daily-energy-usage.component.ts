import { Component, EventEmitter, Input, OnInit, OnChanges, Output } from '@angular/core';
import { FormControl } from '@angular/forms';

import * as Chartist from "chartist";
import "chartist-plugin-tooltips";

@Component({
  selector: "daily-energy-usage",
  templateUrl: "./daily-energy-usage.component.html"
})
export class DailyEnergyUsageComponent implements OnInit, OnChanges {
  @Input() twentyFourHourHistory;
  @Input() selectedValue;

  // Identifies tab group as 24 hour chart tabs for styling
  tabType: string = "24Hour";
  
  dates = [];
  currentValues = [];
  powerValues = [];
  voltageABValues = [];
  voltageANValues = [];
  voltageBNValues = [];

  constructor() {}

  ngOnInit() {
    
  }

  getDates(array) {
    array.forEach((value, index) => {
      if (index % 4 === 0) {
        let date = new Date(value.intervalEnd).getHours();
        let amPm = date >= 12 ? "PM" : "AM";

        date = date === 0 ? 12 : date > 12 ? date - 12 : date;

        if (date % 4 != 0) date = null;

        date != null ? this.dates.push(`${date} ${amPm}`) : this.dates.push(" ");
      }
    });
  }

  getUsage(array, type){

    if (type === "current") this.getDates(array);

    array.forEach((value, index) => {
      if (index % 4 === 0 && value.value) {
        let usage = parseFloat(value.value);

        if (type === "power"){
          this.powerValues.push(usage.toFixed(3));
        } else if (type === "current"){
          this.currentValues.push(usage.toFixed(3));          
        } else if (type === "voltageAB"){
          this.voltageABValues.push(usage.toFixed(3));          
        } else if (type === "voltageBN") {
          this.voltageBNValues.push(usage.toFixed(3));
        } else {
          this.voltageANValues.push(usage.toFixed(3));
        }
      }
    });
  }

  ngOnChanges() {

    this.dates = [];
    this.currentValues = [];
    this.powerValues = [];
    this.voltageABValues = [];
    this.voltageANValues = [];
    this.voltageBNValues = [];

    if (this.twentyFourHourHistory.current && this.twentyFourHourHistory.power &&
      this.twentyFourHourHistory.voltageLLAB && this.twentyFourHourHistory.voltageLNAN &&
      this.twentyFourHourHistory.voltageLNBN
    ) {
      this.getUsage(this.twentyFourHourHistory.current, "current");
      this.getUsage(this.twentyFourHourHistory.power, "power");
      this.getUsage(this.twentyFourHourHistory.voltageLLAB, "voltageAB");
      this.getUsage(this.twentyFourHourHistory.voltageLNAN, "voltageAN");
      this.getUsage(this.twentyFourHourHistory.voltageLNBN, "voltageBN");

      new Chartist.Line(
        ".power-line",
        {
          labels: this.dates,
          series: [this.powerValues]
        },
        {
          fullWidth: true,
          chartPadding: { right: 40 },
          axisX: { offset: 60 },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function (value) {
              return value.toFixed(4) + " kW";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );

      new Chartist.Line(
        ".voltage-line",
        {
          labels: this.dates,
          series: [this.voltageABValues, this.voltageANValues, this.voltageBNValues]
        },
        {
          fullWidth: true,
          chartPadding: { right: 40 },
          axisX: { offset: 60 },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function (value) {
              return value + " V";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );

      new Chartist.Line(
        ".current-line",
        {
          labels: this.dates,
          series: [this.currentValues]
        },
        {
          fullWidth: true,
          chartPadding: { right: 40 },
          axisX: { offset: 60 },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function (value) {
              return value + " A";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );
    }
  }
}
