import { NO_ERRORS_SCHEMA } from "@angular/core";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// Components
import { DailyEnergyUsageByGroupComponent } from './daily-energy-usage-by-group.component';
import { TabGroupComponent } from "../../p-components/tab-group/tab-group.component";
import { IndividualTabComponent } from "../../p-components/tab-group/individual-tab/individual-tab.component";

// Material Imports
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

describe('DailyEnergyUsageComponent', () => {
  let component: DailyEnergyUsageByGroupComponent;
  let fixture: ComponentFixture<DailyEnergyUsageByGroupComponent>;

  let mockData =    
  {
    breakerId: '124273434',
    startDateTime: 'Monday, Jan 08, 2018 00:00:00',
    endDateTime: 'Tuesday, Jan 09, 2018 00:00:00',
    power: [
        {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 40.95 }, 
        {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 40.95 }
    ],
    voltage: {

        LN_AN: [
            {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 75 }, 
            {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 75 }
        ],

        LL_AB: [
            {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 150 }, 
            {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 150 }
        ],

        LN_BN: [
            {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 210 }, 
            {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 210 }
        ]
    },
    current: [
        {dateTime: 'Monday, Jan 08, 2018 00:00:00', value: 27.25 }, 
        {dateTime: 'Monday, Jan 08, 2018 00:15:00', value: 27.25 }
    ] 
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DailyEnergyUsageByGroupComponent,
        IndividualTabComponent,
        TabGroupComponent
      ],
      imports: [BrowserAnimationsModule],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyEnergyUsageByGroupComponent);
    component = fixture.componentInstance;
    component.twentyFourHourHistory = mockData;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("it should contain 24 hour data", () => {
    expect(component.twentyFourHourHistory).toEqual(mockData);
  });
});
