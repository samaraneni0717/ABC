import { Component, EventEmitter, Input, OnInit, OnChanges, Output } from '@angular/core';
import { FormControl } from '@angular/forms';

import * as Chartist from "chartist";
import "chartist-plugin-tooltips";

@Component({
  selector: "daily-energy-usage-by-group",
  templateUrl: "./daily-energy-usage-by-group.component.html"
})
export class DailyEnergyUsageByGroupComponent implements OnInit, OnChanges {
  @Input() breakerGroups;
  @Input() mode;
  @Input() twentyFourHourHistory;
  @Input() selectedValue;

  // Passing back an event when groups are selected
  @Output() fetchGroupData = new EventEmitter();

  // Identifies tab group as 24 hour chart tabs for styling
  tabType: string = "24Hour";
  
  dates = [];
  currentValues = [];
  powerValues = [];
  voltageABValues = [];
  voltageANValues = [];
  voltageBNValues = [];

  groups = new FormControl();
  groupList = ['All Groups'];

  constructor() {}

  ngOnInit() {
    this.selectedValue = this.groupList;
  }

  getDates(array) {
    array.forEach((value, index) => {
      if (index % 4 === 0) {
        let date = new Date(value.intervalEnd).getHours();
        let amPm = date >= 12 ? "PM" : "AM";

        date = date === 0 ? 12 : date > 12 ? date - 12 : date;

        if (date % 4 != 0) date = null;

        date != null ? this.dates.push(`${date} ${amPm}`) : this.dates.push(" ");
      }
    });
  }

  getUsage(array, type){

    if (type === "current") this.getDates(array);

    array.forEach((value, index) => {
      if (index % 4 === 0 && value.value) {
        let usage = parseFloat(value.value);

        if (type === "power"){
          this.powerValues.push(usage.toFixed(3));
        } else if (type === "current"){
          this.currentValues.push(usage.toFixed(3));          
        } else if (type === "voltageAB"){
          this.voltageABValues.push(usage.toFixed(3));          
        } else if (type === "voltageBN") {
          this.voltageBNValues.push(usage.toFixed(3));
        } else {
          this.voltageANValues.push(usage.toFixed(3));
        }
      }
    });
  }

  groupSelected(){
    if (this.selectedValue.length < this.groupList.length && this.selectedValue[0] === "All Groups") this.selectedValue = this.selectedValue.filter(item => item != "All Groups");

    // This value is going to be passed back to the dashboard components when groups are selected
    if (this.selectedValue.length) this.fetchGroupData.emit({ groups: this.selectedValue, chart: "24 hour", interval: "min15" });
  }

  selectAll(){
    let allGroups = this.selectedValue.filter(item => item === 'All Groups').pop();
   
    if (allGroups != undefined){
      this.selectedValue = this.groupList;
      let groups = this.selectedValue.filter(item => item != "All Groups");
      this.fetchGroupData.emit({ groups: groups, chart: "24 hour", interval: "min15" }); 
    } else {
      // Empties out selected value if all groups option is unselected.
      this.selectedValue = [];
    }
  }

  ngOnChanges() {

    this.dates = [];
    this.currentValues = [];
    this.powerValues = [];
    this.voltageABValues = [];
    this.voltageANValues = [];
    this.voltageBNValues = [];

    this.breakerGroups && this.breakerGroups.length && this.groupList.length < 2 ? 
      this.breakerGroups.forEach(group => this.groupList.push(group)) : null;
    
    if (this.twentyFourHourHistory.current && this.twentyFourHourHistory.power &&
      this.twentyFourHourHistory.voltageLLAB && this.twentyFourHourHistory.voltageLNAN &&
      this.twentyFourHourHistory.voltageLNBN
    ) {
      this.getUsage(this.twentyFourHourHistory.current, "current");  
      this.getUsage(this.twentyFourHourHistory.power, "power");
      this.getUsage(this.twentyFourHourHistory.voltageLLAB, "voltageAB");
      this.getUsage(this.twentyFourHourHistory.voltageLNAN, "voltageAN");
      this.getUsage(this.twentyFourHourHistory.voltageLNBN, "voltageBN");

      new Chartist.Line(
        ".power-line",
        { 
          labels: this.dates, 
          series: [this.powerValues] 
        },
        {
          fullWidth: true,
          chartPadding: { right: 40 },
          axisX: { offset: 60 },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function(value) {
              return value.toFixed(4) + " kW";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );

      new Chartist.Line(
        ".current-line",
        { 
          labels: this.dates, 
          series: [this.currentValues] 
        },
        {
          fullWidth: true,
          chartPadding: { right: 40 },
          axisX: { offset: 60 },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function(value) {
              return value + " A";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );
    }
  }
}
