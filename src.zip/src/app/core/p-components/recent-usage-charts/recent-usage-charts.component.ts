import { Component, OnInit, OnChanges, Input } from '@angular/core';

import { Breaker } from "../../interfaces/breaker.interface";

import * as Chartist from "chartist";

@Component({
  selector: 'recent-usage-charts',
  templateUrl: './recent-usage-charts.component.html'
})
export class RecentUsageChartsComponent implements OnChanges {
  @Input() breakerData: any;
  @Input() id: any;
  
  breaker: Breaker;
  currentUsage: number;
  maxVoltageUsage: number;
  maxCurrentUsage: number;
  voltageUsage: number;

  // calcMax: number;
  // maxPowerUsage: number;
  // powerUsage: number;

  constructor() { }

  ngOnChanges() {
    if(this.breakerData != undefined && this.breakerData.devices.length){
      this.breaker = this.breakerData.devices.filter(breaker => breaker.id == this.id).pop();
      if (this.breaker.recentUsage && this.breaker.recentUsage.voltage.value != null && this.breaker.recentUsage.current.value != null) {
        
        // this.powerUsage = parseFloat(this.breaker.recentUsage.power.value.toFixed(3));
        this.currentUsage = this.breaker.recentUsage.current.value;
        this.voltageUsage = this.breaker.recentUsage.voltage.value; 

        switch (this.breaker.breakerType) {
          case "1/15": {
            // this.calcMax = 125 * 15 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 125;
            this.maxCurrentUsage = 15;
            break;
          }
          case "1/20": {
            // this.calcMax = 125 * 20 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 125;
            this.maxCurrentUsage = 20;
            break;
          }
          case "2/15": {
            // this.calcMax = 250 * 15 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 250;
            this.maxCurrentUsage = 15;
            break;
          }
          case "2/20": {
            // this.calcMax = 250 * 20 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 250;
            this.maxCurrentUsage = 20;
            break;
          }
          case "2/30": {
            // this.calcMax = 250 * 30 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 250;
            this.maxCurrentUsage = 30;
            break;
          }
          case "2/40": {
            // this.calcMax = 250 * 40 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 250;
            this.maxCurrentUsage = 40;
            break;
          }
          case "2/50": {
            // this.calcMax = 250 * 50 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 250;
            this.maxCurrentUsage = 50;
            break;
          }
          case "EV/40": {
            // this.calcMax = 250 * 40 / 1000;
            // this.maxPowerUsage = parseFloat(this.calcMax.toFixed(2));
            this.maxVoltageUsage = 250;
            this.maxCurrentUsage = 40;
            break;
          }
        }

        // Power Usage
        // new Chartist.Pie(".power", { 
        //   series: [{ 
        //     value: this.powerUsage, 
        //     className: "power-chart" 
        //   }] }, 
        //     { donut: true, 
        //       donutWidth: 10, 
        //       donutSolid: true, 
        //       startAngle: 270, 
        //       total: 2.5, 
        //       showLabel: true 
        //     });

        // Current Usage
        new Chartist.Pie(".current", { 
          series: [{ 
            value: this.currentUsage, 
            className: "current-chart" 
          }] }, 
          { donut: true, 
            donutWidth: 10, 
            donutSolid: true, 
            startAngle: 270, 
            total: this.maxCurrentUsage, 
            showLabel: true 
          });

        // Voltage Usage
        new Chartist.Pie(".voltage", { 
          series: [{ 
            value: this.voltageUsage, 
            className: "voltage-chart" 
          }] }, 
          { donut: true, 
            donutWidth: 10, 
            donutSolid: true, 
            startAngle: 270, 
            total: this.maxVoltageUsage, 
            showLabel: true 
          });
      }
    }
  }

}
