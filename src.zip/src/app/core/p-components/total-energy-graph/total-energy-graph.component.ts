import { Component, EventEmitter, Input, OnInit, OnChanges, Output} from '@angular/core';
import { FormControl } from '@angular/forms';

import { MatDatepickerInputEvent } from '@angular/material/datepicker';

import * as Chartist from "chartist";
import "chartist-plugin-tooltips";

@Component({
  selector: "total-energy-graph",
  templateUrl: "./total-energy-graph.component.html",
})
export class TotalEnergyGraphComponent implements OnInit, OnChanges {
// Passed from the breaker view component
  @Input() totalDailyEnergy;
  @Input() totalWeeklyEnergy;
  @Input() totalMonthlyEnergy;

// Passed to determine if dashboard view is passed
  @Input() mode;

// Calendar dates passed from total energy html
  @Input() breakerGroups;
  @Input() groupStartDate;
  @Input() groupEndDate;

  // Passing back an event when groups are selected
  @Output() fetchGroupData = new EventEmitter();

  // Passing back an event when groups are selected
  @Output() fetchTabData = new EventEmitter(); 

  // Passing back an event when dates are selected
  @Output() fetchTotalEnergy = new EventEmitter();  

  dailyDates = [];
  dailyValues = [];

  weeklyDates = [];
  weeklyValues = [];

  monthlyDates = [];
  monthlyValues = [];

  groups = new FormControl();
  groupList = ['All Groups'];
  selectedGroups;
  @Input() selectedValue;

  // Passing tabType allows tab classes to change based on which chart the tabs are being used in.
  // Changing class allows the tabs appearance to change when being used on the total energy chart.
  tabType: string = "totalEnergy";
  tabName: string = "Day";

  dailyLoading: boolean = false;
  weeklyLoading: boolean = false;
  monthlyLoading: boolean = false;

  constructor() {}

  ngOnInit() { 
    this.selectedValue = this.groupList; 
    this.selectedGroups = this.selectedValue;   
  }

  getDatesAndValues(array, interval){
    array.values.forEach((value, index) => {
    
      if(interval === "daily"){
        let month = new Date(value.intervalEnd).getMonth() + 1;
        let day = new Date(value.intervalEnd).getUTCDate();

        this.dailyDates.indexOf(`${month}/${day}`) == -1 ? this.dailyDates.push(`${month}/${day}`) : null;
        this.dailyValues.length < this.totalDailyEnergy.values.length ? this.dailyValues.push(value.value.toFixed(3)) : null;
      
      } else if (interval === "weekly"){
        let startDate = value.intervalStart ? `${new Date(value.intervalStart).getMonth() + 1}/${new Date(value.intervalStart).getUTCDate()} `: null;
        let endDate = value.intervalEnd ? `${new Date(value.intervalEnd).getMonth() + 1}/${new Date(value.intervalEnd).getUTCDate()}` : null;

        startDate != null ?
          this.weeklyDates.indexOf(`${startDate}-${endDate}`) == -1 ? this.weeklyDates.push(`${startDate}- ${endDate}`) : null
        : this.weeklyDates.push(endDate);

        this.weeklyValues.length < this.totalWeeklyEnergy.values.length ? this.weeklyValues.push(value.value.toFixed(3)) : null;
      
      } else {   
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        let monthString = monthNames[new Date(value.intervalEnd).getMonth()];      
             
        this.monthlyDates.indexOf(monthString) == -1 ? this.monthlyDates.push(monthString) : null;
        this.monthlyValues.length < this.totalMonthlyEnergy.values.length ? this.monthlyValues.push(value.value.toFixed(3)) : null;
      }
    });
  }

  // Selected groups will contain any checked options. 
  // If 'all groups' is selected, the reflected data will contain all available groups (minus the 'all groups' option)
  groupSelected(){
    
    if(this.selectedValue.length === this.groupList.length) this.selectedGroups = this.selectedValue.filter(item => item != "All Groups"); 
    
    // Deselects 'all groups' when an individual group is unchecked
    if (this.selectedValue.length < this.groupList.length && this.selectedValue[0] === "All Groups") this.selectedValue = this.selectedValue.filter(item => item != "All Groups");
    this.selectedGroups = this.selectedValue.filter(item => item != "All Groups");    
  }

  // Selects all options when 'all groups' is checked and deselects all when 'all groups' option is unchecked.
  selectAll(){
    let allGroups = this.selectedValue.filter(item => item === 'All Groups').pop();
   
    if (allGroups != undefined){
      this.selectedValue = this.groupList;
      this.groupSelected();
    } else {
      // Empties out selected value if all groups option is unselected.
      this.selectedValue = [];
      this.selectedGroups = this.selectedValue;
    }
  }

  // Allows the tab group component to know which tab has been selected.
  selectedTab(tab){
    this.tabName = tab;
    
    // Implement if you want lazy loading for the tabs
    // if (this.tabName === "Week" && !this.totalWeeklyEnergy) this.fetchTabData.emit({ groups: "*", chart: "total energy", tab: "weekly" });
    // if (this.tabName === "Month" && !this.totalMonthlyEnergy) this.fetchTabData.emit({groups: "*", chart: "total energy", tab: "monthly"});
  }
  
  updateData(){

  // Communicates request for changes to the store to the breaker-view component (action makes new API call)
    if (this.mode === 'breakerView' && this.groupStartDate && this.groupEndDate){
      if (this.tabName === "Day") this.fetchTotalEnergy.emit({ startDate: new Date(this.groupStartDate).toISOString(), endDate: new Date(this.groupEndDate).toISOString(), interval: "daily" });
      if (this.tabName === "Week") this.fetchTotalEnergy.emit({ startDate: new Date(this.groupStartDate).toISOString(), endDate: new Date(this.groupEndDate).toISOString(), interval: "weekly" });
      if (this.tabName === "Month") this.fetchTotalEnergy.emit({ startDate: new Date(this.groupStartDate).toISOString(), endDate: new Date(this.groupEndDate).toISOString(), interval: "monthly" });

    } else if (this.mode === 'dashboard' && this.groupStartDate && this.groupEndDate && this.selectedGroups != undefined && this.selectedGroups.length != 0 ) {
  // Used to update emitter when groups are selected only when the startDate and endDate are selected.        
      if (this.tabName === "Day") this.fetchGroupData.emit({ groups: this.selectedGroups, chart: "total energy", startDate: new Date(this.groupStartDate).toISOString(), endDate: new Date(this.groupEndDate).toISOString(), interval: "daily" });
      if (this.tabName === "Week") this.fetchGroupData.emit({ groups: this.selectedGroups, chart: "total energy", startDate: new Date(this.groupStartDate).toISOString(), endDate: new Date(this.groupEndDate).toISOString(), interval: "weekly" });
      if (this.tabName === "Month") this.fetchGroupData.emit({ groups: this.selectedGroups, chart: "total energy", startDate: new Date(this.groupStartDate).toISOString(), endDate: new Date(this.groupEndDate).toISOString(), interval: "monthly" });
    }
    
  }

  updateDate(type: string, event: MatDatepickerInputEvent<Date>){
    type === "startDate" ? this.groupStartDate = event.value : this.groupEndDate = event.value;
    
    this.groupStartDate && this.groupEndDate ? this.groupSelected() : null;
  }

  ngOnChanges() {
    
    this.breakerGroups && this.breakerGroups.length  && this.groupList.length < 2 ? 
      this.breakerGroups.forEach(group => this.breakerGroups.indexOf(group) == -1 ? null : this.groupList.push(group)) 
    : null;
  // Building out bar graphs for daily, weekly and monthly view on total energy chart
    if (this.totalDailyEnergy.values) {
      this.dailyDates = [];
      this.dailyValues = [];
      // For getting the dates and values pulled out of the data
      this.getDatesAndValues(this.totalDailyEnergy, "daily");
      this.dailyLoading = true;

      new Chartist.Bar(".day-view",
        {
          labels: this.dailyDates,
          series: [this.dailyValues]
        },
        {
          seriesBarDistance: 10,
          axisX: {
            offset: 50
          },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function(value) {
              return value + " kWh";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );
    }

    if (this.totalWeeklyEnergy && this.totalWeeklyEnergy.values) {
      this.weeklyDates = [];
      this.weeklyValues = [];
      // For getting the dates and values pulled out of the data
      this.getDatesAndValues(this.totalWeeklyEnergy, "weekly");
      this.weeklyLoading = true;

      new Chartist.Bar(".week-view",
        {
          labels: this.weeklyDates,
          series: [this.weeklyValues]
        },
        {
          seriesBarDistance: 10,
          axisX: {
            offset: 50
          },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function (value) {
              return value + " kWh";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );
    }

    if (this.totalMonthlyEnergy && this.totalMonthlyEnergy.values) {
      this.monthlyDates = [];
      this.monthlyValues = [];
      // For getting the dates and values pulled out of the data
      this.getDatesAndValues(this.totalMonthlyEnergy, "monthly");
      this.monthlyLoading = true; 

      new Chartist.Bar(".month-view",
        {
          labels: this.monthlyDates,
          series: [this.monthlyValues]
        },
        {
          seriesBarDistance: 10,
          axisX: {
            offset: 50
          },
          axisY: {
            offset: 80,
            labelInterpolationFnc: function (value) {
              return value + " kWh";
            },
            scaleMinSpace: 15
          },
          plugins: [
            Chartist.plugins.tooltip(),
          ]
        }
      );
    }
  }
}
