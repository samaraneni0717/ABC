import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from "@angular/core";

import { TotalEnergyGraphComponent } from './total-energy-graph.component';

describe('TotalEnergyGraphComponent', () => {
  let component: TotalEnergyGraphComponent;
  let fixture: ComponentFixture<TotalEnergyGraphComponent>;
  let updateButton;

  let mockData =                 
  {
    breakerId: '124273434',
    startDateTime: 'Monday, Jan 08, 2018 04:21:05',
    endDateTime: 'Sunday, Jan 14, 2018 04:21:05',
    values: [
        {dateTime: 'Monday, Jan 08, 2018 04:21:05', value: 120 }, 
        {dateTime: 'Tuesday, Jan 09, 2018 04:21:05', value: 100 }, 
        {dateTime: 'Wednesday, Jan 10, 2018 04:21:05', value: 90 }, 
        {dateTime: 'Thursday, Jan 11, 2018 04:21:05', value: 90 }, 
        {dateTime: 'Friday, Jan 12, 2018 04:21:05', value: 75 },
        {dateTime: 'Saturday, Jan 13, 2018 04:21:05', value: 120 },
        {dateTime: 'Sunday, Jan 14, 2018 04:21:05', value: 140 }
    ]
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotalEnergyGraphComponent ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalEnergyGraphComponent);
    component = fixture.componentInstance;
    component.totalDailyEnergy = mockData;
    fixture.detectChanges();
    updateButton = fixture.nativeElement.querySelector("button"); 
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("it should contain daily data", () => {
    expect(component.totalDailyEnergy).toEqual(mockData);
  });

  it("Button should raise updateData event when clicked", () => {
    spyOn(component, "updateData");
    updateButton.click();
    expect(component.updateData).toHaveBeenCalled();
  });
});
