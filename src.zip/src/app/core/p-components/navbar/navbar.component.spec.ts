import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavbarComponent } from './navbar.component';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;

  let email: string = "bob@gmail.com";
  let show: boolean = false;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    component.email = email;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should contain the user email address", () => {
    expect(component.email).toEqual(email);
  });

  it("should show options when email is clicked", () => {
    spyOn(component, "openOptions");
    
    let button = fixture.nativeElement.querySelector("button"); 
    let options = fixture.debugElement.children[0].children[0].children[4].nativeElement;

    button.click();
    
    fixture.whenStable().then(() => {
      expect(component.openOptions).toHaveBeenCalled();
      component.show = true;
      fixture.detectChanges();      
      expect(component.show).toEqual(true);
      expect(options.classList.value).toEqual("breaker-panel user-nav show")
    });

  });

  it("should hide options when close button is clicked", () => {
    spyOn(component, "closeOptions");
    component.show = true;
    
    let closeButton = fixture.nativeElement.querySelector(".close-button");
    let options = fixture.debugElement.children[0].children[0].children[4].nativeElement;

    closeButton.click();

    fixture.whenStable().then(() => {
      expect(component.closeOptions).toHaveBeenCalled();
      component.show = false;
      fixture.detectChanges();
      expect(component.show).toEqual(false);
      expect(options.classList.value).toEqual("breaker-panel user-nav hide")
    });

  });
});
