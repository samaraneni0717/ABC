import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: "navbar",
  templateUrl: "./navbar.component.html"
})
export class NavbarComponent implements OnInit {
  @Input() email: string;
  @Output() logoutUser = new EventEmitter();

  @Output() userLoggedOutEvent = new EventEmitter();

  show: boolean = false;

  constructor() {}

  ngOnInit() {}

  openOptions() {
    this.show = true;
  }

  closeOptions() {
    this.show = false;
  }

  logout(){

    this.userLoggedOutEvent.emit({ logoutUser: true });

  }
}
