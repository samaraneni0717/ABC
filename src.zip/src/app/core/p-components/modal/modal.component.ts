import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

import { DataAccess } from "../../services/dataAccess.service";

import { ISubscription } from 'rxjs/Subscription';

import { DOCUMENT } from '@angular/common';

@Component({
  selector: "modal",
  templateUrl: "./modal.component.html"
})
export class ModalComponent implements OnInit, OnDestroy {
  startDate: string;
  endDate: string;
  encodedUri: Blob;
  errorMessage: string;
  exporting: boolean = false;
  selectedBreakers = [];

  // Store Current, Frequency and Voltage Keys with better labeling
  keys: Array<string>;
  currentValues = [];
  voltageValues = [];
  frequencyValues = [];

  // Needed for Lottie animation
  // Used from https://github.com/chenqingspring/ng-lottie
  public lottieConfig: Object;
  private animation: any;
  private animationSpeed: number = 1;

  //Subscriptions
  exportDataSubscription: ISubscription;

  constructor(
    private service: DataAccess,
    public dialogRef: MatDialogRef<ModalComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
    @Inject(DOCUMENT) private doc: Document
  ) {
    this.lottieConfig = {
      path: '../../../../assets/lottie-json-files/download-icon.json',
      autoplay: true,
      loop: false
    };
  }

  ngOnInit() {
    
    this.data.forEach(breaker => this.selectedBreakers.push(breaker.id));
    
  }

  ngOnDestroy(){

    if (this.startDate && this.endDate) this.exportDataSubscription.unsubscribe();

  }

  handleAnimation(anim: any) {
    this.animation = anim;
  }

  buildHeaders(array, unit){
    let arrayName: Array<string>;
    let title = this.keys.indexOf(unit.toLowerCase());

    if (unit === "Current"){
      arrayName = this.currentValues;
    } else if (unit === "Voltage"){
      arrayName = this.voltageValues;
    } else {
      arrayName = this.frequencyValues;
    }

    if (unit === "Current" || unit === "Voltage"){
      Object.keys(array).forEach(type => {
        Object.keys(array[type])
          ? Object.keys(array[type]).forEach(key => arrayName.push(`${unit} ${type} (${key})`))
          : (arrayName = [
              `${unit} ${type} (value)`,
              `${unit} ${type} (unit)`,
              `${unit} ${type} (avg)`,
              `${unit} ${type} (max)`,
              `${unit} ${type} (min)`
            ]);
      });
    } else {
      Object.keys(array).forEach(key => {
        key ? arrayName.push(`${unit} (${key})`)
          : (arrayName = [
            `${unit} (value)`,
            `${unit} (unit)`,
            `${unit} (avg)`,
            `${unit} (min)`,
            `${unit} (max)`
          ]);
      });
    }

    if (title !== -1) this.keys[title] = arrayName.join(",");
  }

  exportData() {
    if (this.startDate && this.endDate){
      
      this.exporting = true;

      let startDate = new Date(this.startDate).toISOString();
      let endDate = new Date(this.endDate).toISOString();
      
      let ids = this.selectedBreakers.join(",");

      this.exportDataSubscription = this.service.getExportData(ids, startDate, endDate).subscribe(data => {

        if(data.length === 0 || !data) this.errorMessage = "No data found for selected dates. Please select a different date range.";

        // let csvContent = "data:text/csv;charset=utf-8,";

        this.keys = Object.keys(data[0]);
        
        this.keys.forEach(title => {
          if (title === "current" || title === "voltage" || title === "frequency") {
            // Building out headers for current, voltage and frequency
            this.buildHeaders(data[0].current, "Current");
            this.buildHeaders(data[0].voltage, "Voltage"); 
            this.buildHeaders(data[0].frequency, "Frequency"); 
          } else if (title === "realPower" || title === "realEnergy"){
            if (this.keys.indexOf(title) !== -1) this.keys[this.keys.indexOf(title)] = `${title} (value),${title} (unit)`;            
          }
        })

        let titles = `${this.keys.join(",")}\n`;

        let result = titles.replace("deviceName", "Circuit Name");
        
        
        // For looping through all data when building rows
        let allKeys = Object.keys(data[0]);
        // Add the initial rows
        data.forEach(obj => {
          // Concat information
          allKeys.forEach((k, ix) => {
            if (ix) result += ",";

            if (typeof obj[k] === "object" && obj[k] != null) {
              // Getting values for further nested (location, recent usage, voltage, current, etc)
              Object.values(obj[k]).forEach((item, index) => {
                // For voltage and current
                if (typeof item === "object" && item != null) {
                  for (let value in item) {
                    result += ix ? `${item[value]},` : `${item[value]}`;
                  }
                  // For location, frequency, realPower and realEnergy
                } else {

                  result += typeof item === "number" ? `,${item},` : `${item}`;
                }
              });
            }
            // For everything else that isn't buried in an object
            else {
              result += obj[k];
              result = result.replace("/", ":");
            }
          });
          // Make a new line when through all keys
          result += "\n";
        });

        // Removing duplicate commas
        result = result.replace(/,+/g, ",");

        // Encoding csv content and built up string to open as csv file.
        this.encodedUri = new Blob([result], {type: 'text/csv;charset=utf-8;'});
        let csvURL = window.URL.createObjectURL(this.encodedUri);
        
        let link: any = this.doc.createElement('a');

        link.href = csvURL;

        link.download = `SmartBreakerExport-${new Date(Date.now()).toLocaleString()}`;

        this.doc.body.appendChild(link);

        link.click();

        this.doc.body.removeChild(link);

      });
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
