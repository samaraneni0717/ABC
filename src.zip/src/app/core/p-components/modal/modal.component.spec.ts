import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient, HttpHandler } from "@angular/common/http";
import { NO_ERRORS_SCHEMA } from "@angular/core";

// Component
import { ModalComponent } from './modal.component';

// Material import
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

// Service
import { DataAccess } from '../../services/dataAccess.service';
import { Login } from '../../services/login.service';
import { EnvironmentVariables } from '../../services/envionment.service';

//Subscriptions
// import { ISubscription } from "rxjs/Subscription";
// import { Observable } from "rxjs/Observable";

describe('ModalComponent', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;
  // let button: HTMLButtonElement;

  //Subscriptions
  // let exportDataSubscription: ISubscription;

  // Mock Data
  let mockBreakers: any[] = [
    {
      breakerID: "30000c2a690c70b9",
      deviceName: "Sunroom",
      group: "Left-A",
      loadType: "Plug Load",
      location: {
        addressLine2: "541",
        city: "West Lafayette",
        state: "IN",
        postalCode: "47906"
      },
      breakerType: "1/20",
      recentUsage: {
        power: {
          value: 1.5582822211111111,
          unit: "KW"
        },
        voltage: { value: 119.624, unit: "V" },
        current: { value: 8, unit: "A" }
      },
      status: "On",
      lastUpdate: "2018-03-07T10:40:52-05:00"
    },
    {
      breakerID: "30000c2a690c70c2",
      deviceName: "Microwave",
      group: "Left-A",
      loadType: "Appliance",
      location: {
        addressLine2: "541",
        city: "West Lafayette",
        state: "IN",
        postalCode: "47906"
      },
      breakerType: "1/20",
      recentUsage: {
        power: { value: 21.13699965888889, unit: "KW" },
        voltage: { value: 119.297, unit: "V" },
        current: { value: 21, unit: "A" }
      },
      status: "On",
      lastUpdate: "2018-03-07T10:40:52-05:00"
    }
  ];

  beforeEach(async(() => {

    TestBed.configureTestingModule({
      declarations: [ ModalComponent ],
      // imports: [ ],
      providers: [
        DataAccess,
        EnvironmentVariables,
        HttpClient,
        HttpHandler,
        Login,
        {
          provide: MatDialogRef,
          useValue: ModalComponent
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockBreakers
        }
      ],
      schemas: [ NO_ERRORS_SCHEMA ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;

    component.startDate = new Date().toISOString();
    component.endDate = new Date().toISOString();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should contain data passed from breaker table", () => {
    let selectedBreakerID = [];
    mockBreakers.forEach(breaker => selectedBreakerID.push(breaker.breakerID));    
    expect(component.selectedBreakers).toEqual(selectedBreakerID);    
  });

  it("button should be disabled if dates are not selected", () => {
    component.startDate = null;
    component.endDate = null;
    fixture.detectChanges();
    
    let button = fixture.debugElement.children[0].nativeElement.children[1].children[0].lastElementChild.children[0];

    fixture.whenStable().then(() => {
      expect(button.classList.value).toEqual("dark button modal disabled");
    });

  });

  it("button should be enabled if dates are selected", () => {
    let button = fixture.debugElement.children[0].nativeElement.children[1].children[0].lastElementChild.children[0];
    
    fixture.whenStable().then(() => {
      expect(button.classList.value).toEqual("dark button modal enabled");
    });

  });

  it("should raise export when clicked", () => {
    spyOn(component, "exportData");

    let button = fixture.debugElement.children[0].nativeElement.children[1].children[0].lastElementChild.children[0];
    button.click();

    fixture.whenStable().then(() => {
      expect(component.exportData).toHaveBeenCalled();
    });

  });

  it("should unsubscribe data when component is destroyed", () => {
    let dataAccess = fixture.debugElement.injector.get(DataAccess);
    spyOn(dataAccess, 'getExportData').and.returnValue( {subscribe: () => {mockBreakers} });
    fixture.componentInstance.exportData();
    expect(dataAccess.getExportData).toHaveBeenCalled();
  });

});
