import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabGroupComponent } from './tab-group.component';
import { IndividualTabComponent } from './individual-tab/individual-tab.component';

describe('TabGroupComponent', () => {
  let component: TabGroupComponent;
  let fixture: ComponentFixture<TabGroupComponent>;

  let mockTab: IndividualTabComponent = {
    active: true,
    title: "Test",
    ngOnInit(){ }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        IndividualTabComponent,
        TabGroupComponent 
      ],
      providers: [TabGroupComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabGroupComponent);
    component = fixture.componentInstance;
    component.addTab(mockTab);
    component.tabType = "total-energy";        
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should contain test individual tab", () => {
    expect(component.tabs).toContain(mockTab);
  });

  it("should change tab group class based on tab type input", () => {
    const tabGroupSection = fixture.nativeElement.children[0];
    const tabGroupDiv = fixture.nativeElement.children[0].children[0];

    expect(tabGroupSection.attributes.getNamedItem("ng-reflect-ng-class").value).toContain("tab-group-container total-ener");        
    expect(tabGroupDiv.attributes.getNamedItem("ng-reflect-ng-class").value).toContain("tab-group total-energy");
  });

  it("should raise selected event when clicked", () => {
    spyOn(component, "selectTab");
    let button = fixture.debugElement.nativeElement.children[0].children[0].children[0];
    button.click();

    fixture.whenStable().then(() => {
      expect(component.selectTab).toHaveBeenCalled();
    });
  });
  
});
