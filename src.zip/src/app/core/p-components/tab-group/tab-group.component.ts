import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { IndividualTabComponent } from './individual-tab/individual-tab.component';

@Component({
  selector: "tab-group",
  templateUrl: "./tab-group.component.html"
})
export class TabGroupComponent implements OnInit {
  @Input() tabType: string;

  @Output() tabName = new EventEmitter();
  
  selectedTab : IndividualTabComponent;
  tabs: IndividualTabComponent[] = [];

  constructor() {}

  ngOnInit() {
    this.isSelected();
  }

  addTab(tab: IndividualTabComponent) {
    if (this.tabs.length === 0) tab.active = true;
    this.tabs.push(tab);
  }

  isSelected(){
    return this.tabs.filter(tab => tab.active ? this.selectedTab = tab : null).pop();
  }

  selectTab(tab: IndividualTabComponent) {
    this.tabs.forEach(tab => {
      tab.active = false;
    });

    tab.active = true;
    this.selectedTab = tab;
    this.tabName.emit(this.selectedTab.title);
  }
}
