import { Component, OnInit, Input } from '@angular/core';

import { Breaker } from '../../../interfaces/breaker.interface'
import { TabGroupComponent } from '../tab-group.component';

@Component({
  selector: "individual-tab",
  templateUrl: "./individual-tab.component.html"
})
export class IndividualTabComponent implements OnInit {
  active: boolean;
  @Input() title: string;

  constructor(tabs: TabGroupComponent) {
    tabs.addTab(this);    
  }

  ngOnInit() {}

}
