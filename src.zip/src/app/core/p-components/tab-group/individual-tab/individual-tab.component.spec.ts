import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabGroupComponent } from "../tab-group.component";
import { IndividualTabComponent } from './individual-tab.component';

describe('IndividualTabComponent', () => {
  let component: IndividualTabComponent;
  let fixture: ComponentFixture<IndividualTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndividualTabComponent ],
      providers: [TabGroupComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should contain title passed by tab group", () => {
    let title = "Test Tab";
    component.title = title;
    expect(component.title).toEqual(title);
  });

});
