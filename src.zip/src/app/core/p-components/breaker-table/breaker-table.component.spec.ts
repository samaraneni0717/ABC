import { Component, NO_ERRORS_SCHEMA } from "@angular/core";
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// Components
import { BreakerTableComponent } from './breaker-table.component';

// Material Import
import { MatTableModule } from "@angular/material";

// Pipes
import { convert } from "../../pipes/convert.pipe";
import { nullToDash } from "../../pipes/dash.pipe";
import { statusChange } from '../../pipes/status.pipe';

describe('BreakerTableComponent', () => {
  let component: BreakerTableComponent;
  let fixture: ComponentFixture<BreakerTableComponent>;

  // Mock Data
  let mockBreakers: any[] = [
    {
        breakerId: 124273434,
        deviceName: 'Backflush Pump',
        group: 3,
        loadType: 'Pump',
        location: {city: 'Columbus', state: 'OH', zipCode: '43001'},
        breakerType: '2 Poll 20 amps',
        currentUsage: 220,
        status: "On",
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 123456722,
        deviceName: '80 Gallon WH',
        group: 2,
        loadType: 'Water Heater',
        location: {city: 'Charlotte', state: 'NC', zipCode: '28117'},  
        breakerType: '1 Poll 30 amps',
        currentUsage: 7200,
        status: "Off",
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 726494671,
        deviceName: "Car Charger Parking Space #10",
        group: 1,
        loadType: "EVSE",
        location: {city: "Charlotte", state: 'NC', zipCode: '28117'},
        breakerType: "EVSE 30 amps",
        currentUsage: 4000,
        status: null,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 844784938,
        deviceName: "220w LED light",
        group: 1,
        loadType: "Light",
        location: {city: "Raleigh", state: "NC", zipCode: "27511"},
        breakerType: "2 Poll 50 amps",
        currentUsage: 0,
        status: "On",
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    }
  ];

  // Creating and declaring stub version of export-button.
  @Component({ selector: "export-button", template: "" })
  class ExportButtonComponent {}

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        BreakerTableComponent,
        convert,
        ExportButtonComponent,
        nullToDash,
        statusChange
      ],
      imports: [MatTableModule],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreakerTableComponent);
    component = fixture.componentInstance;
    component.breaker = mockBreakers;
    fixture.detectChanges();
  });

  it("should be created", () => {
    expect(component).toBeTruthy();
  });

  it("breaker table component should contain breakers component data", () => {
    expect(component.breaker).toEqual(mockBreakers);
  });

  it("nullToDash pipe returns dashes when necessary", () => {
    component.breaker.forEach(breaker => {
      for (let item in breaker) {
        if (breaker[item] === null) {
          breaker[item] = "--";
          expect(breaker[item]).toMatch("--");
        }

        if (typeof breaker[item] === "object") {
          Object.values(breaker[item]).forEach(item => {
            if (item === null) {
              item = "--";
              expect(item).toMatch("--");
            }
          });
        }
      }
    });
  });

  it("statusChange pipe returns 'On, Off, or Tripped' when necessary", () => {
    component.breaker.forEach(breaker => {
      for (let item in breaker) {
        
        switch (breaker[item]){
          case "On":
            return "On";

          case "Off":
            return "Off";

          case null: 
            return "Tripped";

          case undefined:
            return "Tripped";
        }

        if (breaker[item] === null || breaker[item] === undefined) expect(breaker[item]).toMatch("Tripped");
       
      }
    });
  });

});
