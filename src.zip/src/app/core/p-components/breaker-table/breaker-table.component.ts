import { Component, ViewChild, Input, OnChanges } from "@angular/core";
import { MatTableDataSource, MatSort } from "@angular/material";
import { SelectionModel } from "@angular/cdk/collections";

import { Breaker } from '../../interfaces/breaker.interface';

@Component({
  selector: "breaker-table",
  templateUrl: "./breaker-table.component.html"
})

export class BreakerTableComponent implements OnChanges {
  displayedColumns = ["select", "breakerID", "deviceName", "group", "loadType", "location", "breakerType", "currentUsage", "status", "lastUpdate"];
  dataSource: any;
  selection = new SelectionModel<Breaker>(true, []);
  
  @Input() breaker: any;
  @ViewChild(MatSort) sort: MatSort;

  constructor() {}

  ngOnChanges(){
    if (this.breaker != undefined && this.breaker.devices.length) {
      this.dataSource = new MatTableDataSource(this.breaker.devices);
      this.dataSource.sort = this.sort;
    }

  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

}
