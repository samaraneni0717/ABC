import { Component, OnChanges, Input, Output, EventEmitter } from '@angular/core';

// Interfaces
import { Breaker } from '../../interfaces/breaker.interface';

@Component({
  selector: "breaker-panel",
  templateUrl: "./breaker-panel.component.html"
})
export class BreakerPanelComponent implements OnChanges {
  // For breaker View
  @Input() breakers: any;
  @Input() id: number;

  // For switching between dashboard or Breaker View
  @Input() mode: string;
  @Input() dashboard: boolean;

  // Event emitters
  @Output() breakerDataEvent = new EventEmitter();
  @Output() breakerEdits = new EventEmitter();
  
  // For breaker-view
  breaker: Breaker;
  deviceName: string;
  edit: boolean = false;
  group: string;
  loadType: string;
  location: string;

  // For Dashboard View 
  active: number = 0;
  breakerTotal: number;
  inactive: number = 0;

  constructor() {}

  ngOnInit() {}

  // If this.edit is true then the edit icon turns into a check mark.
  isEditing(edit){
    this.edit = edit;
  }

  saveChanges(breaker) {
    this.breaker.deviceName = this.deviceName;
    this.breaker.group = this.group;
    this.breaker.loadType = this.loadType;
    // Emit edits to breaker view component
    this.breakerEdits.emit({ breaker: this.breaker });
  }

  ngOnChanges() {
    if (this.breakers != undefined && this.breakers.devices.length && !this.dashboard) {
      this.breaker = this.breakers.devices.filter(breaker => breaker.id == this.id).pop();
      this.deviceName = this.breaker.deviceName ? this.breaker.deviceName : null;
      this.group = this.breaker.group ? this.breaker.group : null;
      this.loadType = this.breaker.loadType ? this.breaker.loadType : null;
      this.location = this.breaker.location
        ? `${this.breaker.location.addressLine1} ${
            this.breaker.location.addressLine2
          } ${this.breaker.location.city}, ${this.breaker.location.state} ${
            this.breaker.location.postalCode
          }`
        : null;
    } 
    else if (this.breakers != undefined && this.breakers.devices.length && this.dashboard){
      this.breakerTotal = this.breakers.devices.length;
      return this.breakers.devices.map(breaker => breaker.recentUsage ? this.active++ : this.inactive++);
    } 
    else {
      this.breakerDataEvent.emit({ breakers: this.breakers });
    }
  }
}
