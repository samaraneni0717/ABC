import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { Component, NO_ERRORS_SCHEMA } from "@angular/core";
import { FormsModule } from "@angular/forms";

// Components
import { BreakerPanelComponent } from "./breaker-panel.component";

// Interfaces
import { Breaker } from "../../../core/interfaces/breaker.interface";

// Pipes
import { nullToDash } from "../../pipes/dash.pipe";
import { statusChange } from "../../pipes/status.pipe";

describe('BreakerPanelComponent', () => {
  let component: BreakerPanelComponent;
  let fixture: ComponentFixture<BreakerPanelComponent>;
  let id = "30000c2a690c70b9";
  let breaker: Breaker;

  // Mock Data
  let mockBreakers: any = [
    {
      breakerID: "30000c2a690c70b9",
      deviceName: "Sunroom",
      group: "Left-A",
      loadType: "Plug Load",
      location: {
        streetNumber: "541",
        streetName: "Sesame Street",
        city: "West Lafayette",
        state: "IN",
        postalCode: "47906"
      },
      breakerType: "1/20",
      recentUsage: {
        power: {
          value: 1.5582822211111111,
          unit: "KW"
        },
        voltage: { value: 119.624, unit: "V" },
        current: { value: 8, unit: "A" }
      },
      status: "On",
      lastUpdate: new Date()
    },
    {
      breakerID: "30000c2a690c70c2",
      deviceName: "Microwave",
      group: "Left-A",
      loadType: "Appliance",
      location: {
        streetNumber: "541",
        streetName: "Sesame Street",
        city: "West Lafayette",
        state: "IN",
        postalCode: "47906"
      },
      breakerType: "1/20",
      recentUsage: {
        power: { value: 21.13699965888889, unit: "KW" },
        voltage: { value: 119.297, unit: "V" },
        current: { value: 21, unit: "A" }
      },
      status: "On",
      lastUpdate: new Date()
    },
    {
      breakerID: "30000c2a690c70cd",
      deviceName: "Kitchen Lights",
      group: "Left-A",
      loadType: "Lights",
      location: {
        streetNumber: "541",
        streetName: "Sesame Street",
        city: "West Lafayette",
        state: "IN",
        postalCode: "47906"
      },
      breakerType: "1/20",
      recentUsage: {
        power: { value: 38.81610153333333, unit: "KW" },
        voltage: { value: 118.342, unit: "V" },
        current: { value: 9, unit: "A" }
      },
      status: "On",
      lastUpdate: new Date()
    }
  ];

  // Creating and declaring stub version of export-button.
  @Component({ selector: "edit-button", template: "" })
  class EditButtonComponent { }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        BreakerPanelComponent,
        EditButtonComponent,
        nullToDash,
        statusChange
      ],
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreakerPanelComponent);
    component = fixture.componentInstance;
    breaker = mockBreakers.filter(breaker => breaker.breakerID == id).pop();
    component.breaker = breaker; 
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("breaker table component should contain breakers component data", () => {
    expect(component.breaker).toEqual(breaker);
  });

  it("nullToDash pipe returns dashes when necessary", () => {

    for(let item in breaker){
      
      if(breaker[item] === null){
        breaker[item] = "--";                    
        expect(breaker[item]).toMatch("--");  
      }

      if(typeof breaker[item] === "object"){
        Object.values(breaker[item]).forEach(item => {
          if(item === null){
            item = "--";
            expect(item).toMatch("--");              
          } 
        }); 
      }  

    }
  });

  it("statusChange pipe returns 'On, Off, or Tripped' when necessary", () => {
    for (let item in breaker) {
      
      switch (breaker[item]){
        case "On":
          return "On";

        case "Off":
          return "Off";

        case null: 
          return "Tripped";

        case undefined:
          return "Tripped";
      }

      if (breaker[item] === null || breaker[item] === undefined) expect(breaker[item]).toMatch("Tripped");
      
    }
  });
});
