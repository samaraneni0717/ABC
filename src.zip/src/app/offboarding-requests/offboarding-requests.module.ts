import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OffboardingRequestsRoutingModule } from './offboarding-requests-routing.module';
import { CommonModuleModule } from '../Common/common-module/common-module.module';
import { OffboardingDetailRequestComponent } from './detail-request/offboarding-detail-request.component';
import { MatTabsModule, MatButtonModule, MatInputModule, MatSidenavModule, MatMenuModule, MatToolbarModule, MatTooltipModule, MatIconModule, MatCardModule, MatProgressBarModule, MatSelectModule, MatProgressSpinnerModule, MatListModule } from '@angular/material';
//import { ChatterComponent, SafePipe } from '../Common/chatter/chatter.component';
//import { AttachmentComponent } from '../Common/Attachment/attachment.component';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatTabsModule,
        OffboardingRequestsRoutingModule,
        CommonModuleModule,
        MatButtonModule,
        MatInputModule,
        MatSidenavModule,
        MatMenuModule,
        MatToolbarModule,
        MatTooltipModule,
        MatIconModule,
        MatCardModule,
        MatProgressBarModule,
        MatSelectModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatTabsModule,
        MatListModule,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    declarations: [
        OffboardingDetailRequestComponent, 
        //ChatterComponent, SafePipe,
        //AttachmentComponent
    ]
})
export class OffboardingRequestsModule { }
