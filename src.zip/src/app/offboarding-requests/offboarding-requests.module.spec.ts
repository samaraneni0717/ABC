import { OffboardingRequestsModule } from './offboarding-requests.module';

describe('OffboardingRequestsModule', () => {
  let offboardingRequestsModule: OffboardingRequestsModule;

  beforeEach(() => {
    offboardingRequestsModule = new OffboardingRequestsModule();
  });

  it('should create an instance', () => {
    expect(offboardingRequestsModule).toBeTruthy();
  });
});
