import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { QuestionControlService } from '../../Common/dynamic-form-services/question-control.service';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { CheckboxQuestion } from '../../Common/dynamic-form-models/question-checkbox';
import { MatDialog } from '@angular/material';
import { AlertService } from 'src/app/Common/services/alert.service';
import { OffboardingRequestInputService } from '../services/OffboardingRequestInputService';
import { OffboardingDetailRequestService } from '../services/OffboardingDetailRequestService';
import { OffboardingRequestParentInput } from '../Models/offboardingRequestParentInput';
import { OffboardingRequestInput } from '../Models/OffboardingRequestInput';
import { OffboardingRequestOutput } from '../Models/OffboardingRequestOutput';
import { Subscription } from 'rxjs';


@Component({
    selector: 'app-offboarding-detail-request',
    templateUrl: './offboarding-detail-request.html',
    styleUrls: ['./offboarding-detail-request.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class OffboardingDetailRequestComponent implements OnInit {
    offboardingRequestParentInput: OffboardingRequestParentInput;
    offboardingRequestInput: OffboardingRequestInput;
    offboardingRequestOutput: OffboardingRequestOutput;
    formFields: QuestionBase<any>[] = [];
    reqForm: FormGroup;
    showSaveButton = false;
    showUpdateButton = false;
    showAttachFilesTab = false;
    showChatterTab = false;
    showSubmitButton = false;
    showGridList = false;
    isSave = false;
    showAlert = false;
    showStatusMsg = false;
    isSaveLoading = true;
    isSearchLoading = false;
    cobamRole: string;
    searchTitle = '';
    userAction: string;
    payLoad: any;
    errorMessage: string;
    offboardingRequsetId = this.route.snapshot.queryParams['id'];
    private subscriptions: Subscription[] = [];

    constructor(
        private qcs: QuestionControlService,
        private offboardingDetailRequestService: OffboardingDetailRequestService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private datePipe: DatePipe,
        private offboardinginput: OffboardingRequestInputService
    ) {}

    initializeModels() {
        this.offboardingRequestParentInput = {
          OffboardingRequestInput: null,
          UserAction: ''
        };
        this.offboardingRequestInput = this.offboardinginput.offboardingRequestInput();
    }

    ngOnInit(): void {
        // this.initializeModels();

        // this.formFields = this.offboardingDetailRequestService.buildFields();
        // this.reqForm = this.qcs.toFormGroup(this.formFields);
        // this.showhidetabsbuttons();
//debugger;
        this.isSaveLoading = true;
        this.initializeModels();

        this.offboardingDetailRequestService.getCurrentUser().subscribe(data => {
            if (data) {
                this.cobamRole = data.COBAM_Role__c;
            this.BuildPage(data.COBAM_Role__c);
          }
          //this.isSaveLoading = false;
        });
    }

    BuildPage(cobamRole) {
        this.formFields = this.offboardingDetailRequestService.buildFields(cobamRole);
        this.formFields = this.offboardingDetailRequestService.buildCommonFields(
            cobamRole,
            this.formFields,
            'Draft'
        );

        this.reqForm = this.qcs.toFormGroup(this.formFields);
        this.showhidetabsbuttons();

        this.subscriptions.push(this.reqForm.get('Type_of_Account_to_Offboard__c').valueChanges.subscribe(() => this.onTypeOfAccountOffboardChange()));

        const offboardingRequsetId = this.route.snapshot.queryParams['id'];
        console.log(offboardingRequsetId);
        if (
            this.route.snapshot.queryParams['id'] != null &&
            this.route.snapshot.queryParams['id'] !== ''
        ) {
            this.showSaveButton = false;
            this.populateForm(offboardingRequsetId);
            this.isSave = true;
        }
        else{
          this.enableDisableControls(
            this.cobamRole,
            this.reqForm.get('Status__c').value
            );
          this.isSaveLoading = false;
        }
    }

    onTypeOfAccountOffboardChange(): void{
      if(this.reqForm.get('Type_of_Account_to_Offboard__c')){
        if(this.reqForm.get('Type_of_Account_to_Offboard__c').value === 'Legal Account'){
          alert('All accounts linked to the legal will be removed and cannot be retrieved');
        }
      }
    }

    populateForm(offboardingRequsetId) {
      //debugger;
      this.isSaveLoading = true;
      this.offboardingDetailRequestService.GetOffboardingRequestDetails(offboardingRequsetId).subscribe(
        data => {
          if (data) {
            data = JSON.parse(JSON.stringify(data));
            this.offboardingRequestOutput = data;
              //debugger
            this.formFields = this.offboardingDetailRequestService.buildCommonFields(
                this.cobamRole,
                this.formFields,
                this.offboardingRequestOutput.Status__c
            );

            //this.reqForm = this.qcs.toFormGroup(this.formFields);
            //this.subscriptions.push(this.reqForm.get('Type_of_Account_to_Offboard__c').valueChanges.subscribe(() => this.onTypeOfAccountOffboardChange()));
            console.log(this.reqForm.controls['Status__c']);
            for (const prop of Object.keys(this.offboardingRequestOutput)) {
              if (this.reqForm.controls[prop]) {
                if (prop === 'CreatedDate') {
                  this.reqForm.controls[prop].setValue(
                    new Date(
                      this.datePipe.transform(
                        this.offboardingRequestOutput[prop],
                        'MM/dd/yyyy h:mm a'
                      )
                    ).toLocaleString()
                  );
                } else if (prop === 'Owner') {
                  this.reqForm.controls[prop].setValue(
                    this.offboardingRequestOutput[prop].Name
                  );
                 } //else if (prop === 'RequestedBy__r') {
                //   this.reqForm.controls[prop].setValue(
                //     this.offboardingRequestOutput[prop].Desk__c
                //   );
                // } 
                else {
                  this.reqForm.controls[prop].setValue(
                    this.offboardingRequestOutput[prop]
                  );
                }
              }
            }

            this.enableDisableControls(
              this.cobamRole,
              this.offboardingRequestOutput.Status__c
            );
            this.showhidetabsbuttons();
            this.isSaveLoading = false;
            console.warn('The data is', this.reqForm);
          }
        },
        error => {
          console.error(error);
          this.isSearchLoading = false; // stop spinner
          this.alertService.clear();
          this.alertService.warn(
            'Not able to communicate with Service Please try Again'
          );
        }
      );
    }
  enableDisableControls(cobamRole?: string, currentStatus?: string): any {
    switch (currentStatus) {
      case 'Draft':
        this.reqForm.get('Status__c').disable();
        this.reqForm.get('Type_of_Account_to_Offboard__c').enable();
        this.reqForm.get('Off_Boarding_Reason__c').enable();
        this.reqForm.get('Requestor_Department__c').enable();
        break;
      case 'Closed - Pending Settlement':
      case 'Closed - Off Boarded':
      case 'Closed - Pending Approval':
        this.reqForm.get('Status__c').disable();
        this.reqForm.get('Type_of_Account_to_Offboard__c').disable();
        this.reqForm.get('Off_Boarding_Reason__c').disable();
        this.reqForm.get('Requestor_Department__c').disable();
        this.reqForm.get('Primary_Case_Manager__r').disable();
        this.reqForm.get('Secondary_Case_Manager__r').disable();
        break;
      case 'Open - Unassigned':
      case 'Re-Opened':
        if (
          cobamRole === 'Off Boarding'
        ) {
          this.reqForm.get('Status__c').enable();
          this.reqForm.get('Primary_Case_Manager__r').enable();
          this.reqForm.get('Secondary_Case_Manager__r').enable();
        } else {
          this.reqForm.get('Status__c').disable();
          this.reqForm.get('Primary_Case_Manager__r').disable();
          this.reqForm.get('Secondary_Case_Manager__r').disable();
        }
        this.reqForm.get('Type_of_Account_to_Offboard__c').disable();
        this.reqForm.get('Off_Boarding_Reason__c').disable();
        this.reqForm.get('Requestor_Department__c').disable();
        break;
      case 'Assigned':
      case 'Pending - Additional Information Required':
      case 'Pending - Additional Approval Required':
      case 'Pending - Customer Service Inputs':
        if (
          cobamRole === 'Off Boarding'
        ) {
          this.reqForm.get('Status__c').enable();
          this.reqForm.get('Primary_Case_Manager__r').disable();
          this.reqForm.get('Secondary_Case_Manager__r').enable();
        } else {
          this.reqForm.get('Status__c').disable();
          this.reqForm.get('Primary_Case_Manager__r').disable();
          this.reqForm.get('Secondary_Case_Manager__r').disable();
        }
        
        this.reqForm.get('Type_of_Account_to_Offboard__c').disable();
        this.reqForm.get('Off_Boarding_Reason__c').disable();
        this.reqForm.get('Requestor_Department__c').disable();

        break;
      default:
        this.reqForm.get('Status__c').disable();
        this.reqForm.get('Primary_Case_Manager__r').disable();
        this.reqForm.get('Secondary_Case_Manager__r').disable();
        this.reqForm.get('Type_of_Account_to_Offboard__c').disable();
        this.reqForm.get('Off_Boarding_Reason__c').disable();
        this.reqForm.get('Requestor_Department__c').disable();
        break;
    }

  }

    onAutocompleteSelctionChange(controlName: string) {
        if (controlName === 'Primary_Case_Manager__r') {
            if (this.reqForm.get('Status__c').value === 'Open - Unassigned') {
                this.reqForm.get('Status__c').setValue('Assigned');
            }
        }
    }

    openSearchModal(template, value: string): void {
    //debugger
      this.showStatusMsg = false; // hiding helptext
      if (value !== '[object Event]' && value !== '[object MouseEvent]') {
          this.searchTitle = value;
          const dialogRef = this.dialog.open(template, {
              width: '80%'
          });
      }

      console.log('The type of template is', value);
    }

    onModalClose() {
      this.showGridList = false;
      this.dialog.closeAll();
    }

    selectRowData(value: any): void {
      //debugger;
      this.isSave = false;
      this.showAlert = false;
      Object.keys(this.reqForm.controls).forEach(item => {
          switch (item) {
              case 'CID_LEID__c':
                  this.reqForm.controls[item].setValue(value.LegalId);
                  break;
              case 'BA_ID__c':
                  this.reqForm.controls[item].setValue(value.AccountId);
                  break;
              case 'Legal_Name__c':
                  this.reqForm.controls[item].setValue(value.LegalFullName);
                  break;
              case 'Business_Acct_Fund_Name__c':
                  this.reqForm.controls[item].setValue(value.AccountName);
                  break;
              case 'External_Name__c':
                  this.reqForm.controls[item].setValue(value.ExternalSystem);
                  break;
              case 'External_ID__c':
                  this.reqForm.controls[item].setValue(value.ExternalId);
                  break;
              case 'Middle_Market_Indicator__c':
                  this.reqForm.controls[item].setValue(value.middlemarket);
                  break;
              case 'MiFID_II_Risk_Reducing__c':
                  this.reqForm.controls[item].setValue(value.MiFIDII_RiskReducing);
                  break;
          }
      });
      this.onModalClose();
      this.showhidetabsbuttons();
    }

    saveDetails() {
      this.isSaveLoading = true;
      this.userAction = 'SAVE';
      
      if (this.offboardingRequsetId != null) {
        this.updateDetailsService();
      } else {
        this.saveDetailsservice();
      }
    }

    submitaccount() {
        //debugger;
        this.isSaveLoading = true;
        this.userAction = 'SUBMIT';
        if (this.offboardingRequsetId != null) {
          this.updateDetailsService();
        } else {
          this.saveDetailsservice();
        }
    }

  saveDetailsservice() {
    //debugger;
    this.setOffboardingRequestParentInputToSave();
    this.payLoad = JSON.stringify(this.offboardingRequestParentInput);
    console.log(this.payLoad);
    this.offboardingDetailRequestService.AddOffboardingRequest(this.payLoad).subscribe(
      data => {
        if (!data.startsWith('Error')) {
          console.log('The data from backend is', data);
          this.offboardingRequsetId = data;
          this.isSave = true;
          this.populateForm(this.offboardingRequsetId);
          //this.isSaveLoading = false;
          this.showAlert = false;
        } else {
          this.isSaveLoading = false;
          this.showAlert = true;
          this.errorMessage = data.replace('Error', '');
        }
      },
      error => {
        this.isSaveLoading = false;
        console.error(error);
        this.alertService.clear();
        this.alertService.warn(
          'Not able to communicate with Service Please try Again'
        );
      }
    );
  }

  updateDetailsService() {
    this.setOffboardingRequestParentInputToSave();
    this.offboardingRequestParentInput.OffboardingRequestInput.Id = this.offboardingRequsetId;
    this.payLoad = JSON.stringify(this.offboardingRequestParentInput);
    this.offboardingDetailRequestService.UpdateOffboardingRequest(this.payLoad).subscribe(
      data => {
        if (data && !data.startsWith('Error')) {
          this.offboardingRequestOutput = data.OffboardingRequestOutput;
          this.populateForm(this.offboardingRequsetId);
          //this.isSaveLoading = false;
          this.showAlert = false;
          this.showSubmitButton = false;
          this.showSaveButton = false;
        } else {
          this.isSaveLoading = false;
          this.showAlert = true;
          this.errorMessage = data.replace('Error', '');
        }
      },
      error => {
        console.error(error);
        this.alertService.clear();
        this.alertService.warn(
          'Not able to communicate with Service Please try Again'
        );
        this.isSaveLoading = false;
      }
    );
  }

  setOffboardingRequestParentInputToSave(){
    let keysArr = [];
    keysArr = Object.keys(this.reqForm.controls);
    keysArr.forEach(key => {
      this.offboardingRequestInput[key] = this.reqForm.get(key).value;
    });
    if(this.offboardingRequestInput['Type_of_Account_to_Offboard__c'] === 'Legal Account'){
      this.offboardingRequestInput['Business_Acct_Fund_Name__c'] = '';
      this.offboardingRequestInput['BA_ID__c'] = '';
      this.offboardingRequestInput['External_Name__c'] = '';
      this.offboardingRequestInput['External_ID__c'] = '';
    }
    this.offboardingRequestParentInput.OffboardingRequestInput = this.offboardingRequestInput;
    this.offboardingRequestParentInput.UserAction = this.userAction;
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
    this.subscriptions = [];
  }

  showhidetabsbuttons() {
    //debugger
        const payLoad = JSON.parse(JSON.stringify(this.reqForm.value));
        console.log('User_Role ' + this.cobamRole);
        console.log('Name ' + this.reqForm.get('Name').value);
        console.log('Status__c ' + this.reqForm.get('Status__c').value);
        
        if(this.cobamRole === 'Requester' 
          || this.cobamRole === 'Requester NonCash' 
          || this.cobamRole === 'AML KYC'){
//this.offboardingRequestOutput
              if (
                this.reqForm.get('Status__c').value === 'Draft' &&
                this.reqForm.get('Name').value != null &&
                this.reqForm.get('Name').value !== ''
              ) {
                    this.showSaveButton = true;
                    //this.showUpdateButton = true;
                    this.showAttachFilesTab = true;
                    this.showChatterTab = true;
                    this.showSubmitButton = true;
              } else if (
                this.reqForm.get('Status__c').value === 'Draft' &&
                (this.reqForm.get('Name').value == null || this.reqForm.get('Name').value === '')
              ) {
                    this.showSaveButton = true;
                    this.showSubmitButton = false;
                    this.showAttachFilesTab = false;
                    this.showChatterTab = false;
              } else {
                    this.showSaveButton = false;
                    //this.showUpdateButton = false;
                    this.showSubmitButton = false;
                    this.showAttachFilesTab = true;
                    this.showChatterTab = true;
              }

        }
        else if(this.cobamRole === 'Off Boarding'){
          if ((this.reqForm.get('Name').value != null && this.reqForm.get('Name').value !== '') 
            && 
               ((this.reqForm.get('Status__c').value !== null && this.reqForm.get('Status__c').value !== '') && this.reqForm.get('Status__c').value !== 'Draft' 
               && this.reqForm.get('Status__c').value !== 'Closed - Pending Settlement'
               && this.reqForm.get('Status__c').value !== 'Closed - Pending Approval'
               && this.reqForm.get('Status__c').value !== 'Closed - Off Boarded')
          ){
                this.showSaveButton = true;
                //this.showUpdateButton = false;
                this.showSubmitButton = false;
                this.showAttachFilesTab = true;
                this.showChatterTab = true;
          }
          if((this.reqForm.get('Status__c').value !== null && this.reqForm.get('Status__c').value !== '') && this.reqForm.get('Status__c').value !== 'Draft' ){
                this.showAttachFilesTab = true;
                this.showChatterTab = true;
          }
        }
        
  }
}
