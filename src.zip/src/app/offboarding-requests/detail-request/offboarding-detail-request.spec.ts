import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OffboardingDetailRequestComponent } from './offboarding-detail-request.component';


describe('OffboardingDetailRequestComponent', () => {
  let component: OffboardingDetailRequestComponent;
  let fixture: ComponentFixture<OffboardingDetailRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OffboardingDetailRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OffboardingDetailRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
