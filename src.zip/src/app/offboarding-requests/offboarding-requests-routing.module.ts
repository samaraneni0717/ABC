import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OffboardingDetailRequestComponent } from './detail-request/offboarding-detail-request.component';


const routes: Routes = [
    {
        path: 'detail',
        component: OffboardingDetailRequestComponent
    },
    {
        path: 'detail/:id',
        component: OffboardingDetailRequestComponent
    },
    {
        path: '',
        component: OffboardingDetailRequestComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class OffboardingRequestsRoutingModule { }
