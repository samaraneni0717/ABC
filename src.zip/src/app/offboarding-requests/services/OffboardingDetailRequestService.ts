import { Injectable } from '@angular/core';
import { TextboxQuestion } from '../../Common/dynamic-form-models/question-textbox';
import { QuestionBase } from '../../Common/dynamic-form-models/question-base';
import { OptionsQuestion } from '../../Common/dynamic-form-models/Question-Options';
import { DropdownQuestion } from '../../Common/dynamic-form-models/question-dropdown';
import { TextAreaQuestion } from '../../Common/dynamic-form-models/question-textarea';
import { AutoCompleteQuestion } from '../../Common/dynamic-form-models/question-autocomplete';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs/Observable';
import { SingleCheckboxQuestion } from '../../Common/dynamic-form-models/question-single-checkbox';
import { LabelQuestion } from '../../Common/dynamic-form-models/question-label';
import { OptionsInlineQuestion } from '../../Common/dynamic-form-models/Question-OptionsInline';
import { DatePickerQuestion } from '../../Common/dynamic-form-models/question-date-picker';
import { tap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class OffboardingDetailRequestService {
    constructor(private httpClient: HttpClient) {
      console.log('Service instantiated');
    }

    getCurrentUser(): Observable<any> {
        return this.httpClient.get(
            environment.BASEURL + 'Maintenance/currentUser'
          );
    }

    buildFields(cobamRole?:string): QuestionBase<any>[] {
        let questions: QuestionBase<any>[] = [];
        questions = [
            new DropdownQuestion({
                key: 'Type_of_Account_to_Offboard__c',
                label: 'Type of Account to Offboard',
                order: 100,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Business Account', value: 'Business Account' },
                    { key: 'External Account', value: 'External Account' },
                    { key: 'Legal Account', value: 'Legal Account' },
                ],
                defaultOption: '',
                mandatory: true,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    }
                ]
            }),
            new TextAreaQuestion({
                key: 'Legal_Name__c',
                label: 'Legal Name',
                order: 110,
                disabled: true,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: 'Full legal name of the counterparty'
            }),
            new LabelQuestion({
                key: 'CID_LEID__c',
                label: 'CID LEID',
                order: 120,
                disabled: true,
                isTooltipPresent: true,
                typeOfTooltip: 'help',
                tooltipText: `A CID LEID is assigned to all new accounts on a legal/parent level. A CID
                    LEID must be entered by the Facilitator in order to close any new legal account build request.`
            }),
            new TextAreaQuestion({
                key: 'CreatedDate',
                label: 'Created Date',
                order: 130,
                disabled: true
            }),
            new DropdownQuestion({
                key: 'Off_Boarding_Reason__c',
                label: 'Off Boarding Reason',
                order: 200,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'Business raising the Off boarding Request', value: 'Business raising the Off boarding Request' },
                    { key: 'AML/Compliance/Legal Reason', value: 'AML/Compliance/Legal Reason' },
                    { key: 'Entity Ceases to Exist', value: 'Entity Ceases to Exist' },
                    { key: 'Client Decision', value: 'Client Decision' },
                    { key: 'Client Documentation', value: 'Client Documentation' },
                    { key: 'Client Account Inactivity', value: 'Client Account Inactivity' },
                    { key: 'Client Profitability', value: 'Client Profitability' },
                    { key: 'Counterparty Distress (including Default)', value: 'Counterparty Distress (including Default)' },
                    { key: 'Negative News', value: 'Negative News' },
                    { key: 'Regulatory Issues & Internal Audit', value: 'Regulatory Issues & Internal Audit' },
                    { key: 'Exit Recommendation', value: 'Exit Recommendation' },
                    { key: 'Other', value: 'Other' }
                ],
                defaultOption: '',
                mandatory: true,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    }
                ]
            }),
            new TextAreaQuestion({
                key: 'Business_Acct_Fund_Name__c',
                label: 'Bus Account Name',
                order: 210,
                disabled: true,
                relation: [
                    {
                      action: 'VISIBLE',
                      connective: 'OR',
                      when: [
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: ''
                        },
                        {
                          id: 'Type_of_Account_to_Offboard__c',
                          value: 'Business Account'
                        },
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: 'External Account'
                        }
                      ]
                    }
                  ]
            }),
            new LabelQuestion({
                key: 'BA_ID__c',
                label: 'BA ID',
                order: 220,
                isTooltipPresent: true,
                disabled: true,
                typeOfTooltip: 'help',
                tooltipText: `Similar to the CID LEID, the BA ID acts as an internal WFS tracking number on a business account level.
                      A BA ID must be entered by the Facilitator in order to close any new business account request.`,
                relation: [
                    {
                        action: 'VISIBLE',
                        connective: 'OR',
                        when: [
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: ''
                        },
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: 'Business Account'
                        },
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: 'External Account'
                        }
                        ]
                    }
                ]
            }),
            new LabelQuestion({
              key: 'Name',
              label: 'Off-Boarding Request number',
              order: 230,
              disabled: true
            }),


            new LabelQuestion({
                key: 'BASearch',
                label: 'Bus Acct Search',
                order: 300,
                searchable: true,
                template: 'Business Account',
                relation: [
                    {
                      action: 'VISIBLE',
                      connective: 'OR',
                      when: [
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: ''
                        },
                        {
                          id: 'Type_of_Account_to_Offboard__c',
                          value: 'Business Account'
                        },
                        {
                            id: 'Type_of_Account_to_Offboard__c',
                            value: 'External Account'
                        }
                      ]
                    },
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    }
                  ]
              }),
            
              new TextAreaQuestion({
              key: 'External_Name__c',
              label: 'External Name',
              order: 310,
              disabled: true,
              relation: [
                {
                  action: 'VISIBLE',
                  connective: 'OR',
                  when: [
                    {
                        id: 'Type_of_Account_to_Offboard__c',
                        value: ''
                    },
                    {
                      id: 'Type_of_Account_to_Offboard__c',
                      value: 'Business Account'
                    },
                    {
                        id: 'Type_of_Account_to_Offboard__c',
                        value: 'External Account'
                    }
                  ]
                }
              ]
            }),
            new TextAreaQuestion({
              key: 'External_ID__c',
              label: 'External ID',
              order: 320,
              disabled: true,
              relation: [
                {
                  action: 'VISIBLE',
                  connective: 'OR',
                  when: [
                    {
                        id: 'Type_of_Account_to_Offboard__c',
                        value: ''
                    },
                    {
                      id: 'Type_of_Account_to_Offboard__c',
                      value: 'Business Account'
                    },
                    {
                        id: 'Type_of_Account_to_Offboard__c',
                        value: 'External Account'
                    }
                  ]
                }
              ]
            }),
            new LabelQuestion({
                key: 'Requestor_Name__c',
                label: 'Requestor Name',
                order: 330,
                disabled: true
            }),
            new LabelQuestion({
                key: 'LegalSearch',
                label: 'Legal Search',
                order: 400,
                searchable: true,
                template: 'Legal',
                relation: [
                  {
                    action: 'VISIBLE',
                    connective: 'OR',
                    when: [
                      {
                        id: 'Type_of_Account_to_Offboard__c',
                        value: 'Legal Account'
                      }
                    ]
                  },
                  {
                      action: 'ENABLE',
                      when: [
                          {
                              id: 'Status__c',
                              value: 'Draft'
                          }
                      ]
                  }
                ]
            }),
            new TextAreaQuestion({
               key: 'Test',
               label: '',
               order: 410,
               disabled: true,
               relation: [
                   {
                       action: "VISIBLE",
                       connective: "OR",
                       when: [
                           {
                           id: "Status__c",
                           value: ""
                           },
                       ]
                   }
               ]
            }),
            new DropdownQuestion({
                key: 'Requestor_Department__c',
                label: 'Requestor Department',
                order: 420,
                disabled: false,
                options: [
                    { key: '', value: '--None--' },
                    { key: 'AML', value: 'AML' },
                    { key: 'Compliance', value: 'Compliance' },
                    { key: 'Front Office', value: 'Front Office' },
                    { key: 'Credit', value: 'Credit' },
                    { key: 'Other', value: 'Other' }
                ],
                defaultOption: '',
                mandatory: true,
                relation: [
                    {
                        action: 'ENABLE',
                        when: [
                            {
                                id: 'Status__c',
                                value: 'Draft'
                            }
                        ]
                    }
                  ],
            }),
            
            
            new LabelQuestion({
                key: 'User_Role',
                label: 'User Role',
                value: cobamRole,
                order: 520,
                displayNone: true,
                relation: [
                   {
                       action: "VISIBLE",
                       connective: "OR",
                       when: [
                           {
                           id: "Status__c",
                           value: ""
                           },
                       ]
                   }
                ]
            }),
            new TextAreaQuestion({
                key: 'Test',
                label: '',
                order: 530,
                disabled: true,
                relation: [
                    {
                        action: "VISIBLE",
                        connective: "OR",
                        when: [
                            {
                            id: "Status__c",
                            value: ""
                            },
                        ]
                    }
                ]
            }),
            new TextAreaQuestion({
                key: 'Notes__c',
                label: 'Notes',
                order: 600,
                disabled: false
            })
          ];
          return questions.sort((a, b) => a.order - b.order);
    }

    buildCommonFields(cobamRole?: string,
        formFields?: QuestionBase<any>[], requestStatus?: string): QuestionBase<any>[] {
        let statusOrder: number = 0;
        let options: any = [];
        switch (requestStatus) {
            case 'Draft':
                options = [{ key: 'Draft', value: 'Draft' }];
                break;
            case 'Open - Unassigned':
                options =
                    [
                        { key: 'Open - Unassigned', value: 'Open - Unassigned' },
                        { key: 'Assigned', value: 'Assigned' }
                    ];
                break;
            case 'Assigned':
                options =
                    [
                        { key: 'Assigned', value: 'Assigned' },
                        { key: 'Pending - Additional Information Required', value: 'Pending - Additional Information Required' },
                        { key: 'Pending - Additional Approval Required', value: 'Pending - Additional Approval Required' },
                        { key: 'Pending - Customer Service Inputs', value: 'Pending - Customer Service Inputs' },
                        { key: 'Closed - Pending Settlement', value: 'Closed - Pending Settlement' },
                        { key: 'Closed - Off Boarded', value: 'Closed - Off Boarded' },
                        { key: 'Closed - Pending Approval', value: 'Closed - Pending Approval' }
                    ];
                break;
            case 'Pending - Additional Information Required':
            case 'Pending - Additional Approval Required':
            case 'Pending - Customer Service Inputs':
                options =
                    [
                        { key: 'Pending - Additional Information Required', value: 'Pending - Additional Information Required' },
                        { key: 'Pending - Additional Approval Required', value: 'Pending - Additional Approval Required' },
                        { key: 'Pending - Customer Service Inputs', value: 'Pending - Customer Service Inputs' },
                        { key: 'Closed - Pending Settlement', value: 'Closed - Pending Settlement' },
                        { key: 'Closed - Off Boarded', value: 'Closed - Off Boarded' },
                        { key: 'Closed - Pending Approval', value: 'Closed - Pending Approval' }
                    ];
                break;
            case 'Re-Opened':
                options =
                    [
                        { key: 'Pending - Additional Information Required', value: 'Pending - Additional Information Required' },
                        { key: 'Pending - Additional Approval Required', value: 'Pending - Additional Approval Required' },
                        { key: 'Pending - Customer Service Inputs', value: 'Pending - Customer Service Inputs' },
                        { key: 'Closed - Pending Settlement', value: 'Closed - Pending Settlement' },
                        { key: 'Closed - Off Boarded', value: 'Closed - Off Boarded' },
                        { key: 'Closed - Pending Approval', value: 'Closed - Pending Approval' },
                        { key: 'Re-Opened', value: 'Re-Opened' }
                    ];
                break;
            case 'Closed - Pending Settlement':
                options = [{ key: 'Closed - Pending Settlement', value: 'Closed - Pending Settlement' }];
                break;
            case 'Closed - Off Boarded':
                options = [{ key: 'Closed - Off Boarded', value: 'Closed - Off Boarded' }];
                break;
            case 'Closed - Pending Approval':
                options = [{ key: 'Closed - Pending Approval', value: 'Closed - Pending Approval' }];
                break;
            default:
                options = [{ key: 'Draft', value: 'Draft' }];
                break;
        }
        
        let queueStatusQuestion = new DropdownQuestion({
            key: 'Status__c',
            label: 'Queue Status',
            value: requestStatus,
            order: 430,
            disabled: false,
            options: options,
            relation: [
                {
                    action: 'DISABLE',
                    connective: 'AND',
                    when: [
                        {
                            id: 'User_Role',
                            value: 'Requester'
                        },
                        {
                            id: 'User_Role',
                            value: 'Requester NonCash'
                        },
                        {
                            id: 'User_Role',
                            value: 'AML KYC'
                        },
                    ]
                }
            ]
        });

        let primaryCaseManagerQuestion = new AutoCompleteQuestion({
            key: 'Primary_Case_Manager__r',
            label: 'Primary Case Manager',
            value: '',
            order: 500,
            api: 'Maintenance/users/',
            filterCriteria: 'Off Boarding',
            disabled: false,
            mandatory: true,
            relation: [
                {
                    action: "VISIBLE",
                    connective: "OR",
                    when: [
                        {
                            id: "Status__c",
                            value: "Open - Unassigned"
                        },
                        {
                            id: "Status__c",
                            value: "Assigned"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Additional Information Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Additional Approval Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Customer Service Inputs"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Pending Settlement"
                        },
                        {
                            id: "Status__c",
                            value: "Re-Opened"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Off Boarded"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Pending Approval"
                        }
                    ]
                },
                //{
                //    action: 'ENABLE',
                //    connective: 'AND',
                //    when: [
                //        {
                //            id: 'User_Role',
                //            value: 'Off Boarding'
                //        }
                //    ]
                //},
                {
                    action: 'REQUIRED',
                    connective: 'OR',
                    when: [
                        {
                            id: "Status__c",
                            value: "Pending - Inprogress"
                        },
                        {
                            id: "Status__c",
                            value: "Assigned"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Additional Information Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Additional Approval Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Customer Service Inputs"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Pending Settlement"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Pending Approval"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Off Boarded"
                        },
                        {
                            id: "Status__c",
                            value: "Re-Opened"
                        }
                    ]
                }
            ],
        });

        let secondaryCaseManagerQuestion = new AutoCompleteQuestion({
            key: 'Secondary_Case_Manager__r',
            label: 'Secondary Case Manager',
            value: '',
            order: 510,
            disabled: true,
            mandatory: false,
            api: 'Maintenance/users/',
            filterCriteria: 'Off Boarding',
            relation: [
                {
                    action: "VISIBLE",
                    connective: "OR",
                    when: [
                        {
                            id: "Status__c",
                            value: "Open - Unassigned"
                        },
                        {
                            id: "Status__c",
                            value: "Assigned"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Additional Information Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Additional Approval Required"
                        },
                        {
                            id: "Status__c",
                            value: "Pending - Customer Service Inputs"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Pending Settlement"
                        },
                        {
                            id: "Status__c",
                            value: "Re-Opened"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Off Boarded"
                        },
                        {
                            id: "Status__c",
                            value: "Closed - Pending Approval"
                        }
                    ]
                },
                //{
                //    action: 'ENABLE',
                //    connective: 'AND',
                //    when: [
                //        {
                //            id: 'User_Role',
                //            value: 'Off Boarding'
                //        }
                //    ]
                //}

            ],
        });



        formFields = formFields.filter(question => question.key !== 'Status__c' && question.key !== 'Primary_Case_Manager__r'
            && question.key !== 'Secondary_Case_Manager__r'
            && question.key !== 'Current_Status');
        formFields.push(queueStatusQuestion,
            primaryCaseManagerQuestion,
            secondaryCaseManagerQuestion,
            );
        return formFields.sort((a, b) => a.order - b.order);
    }

    GetOffboardingRequestDetails(offboardingRequsetId: string): Observable<any> {
        console.log('GetOffboardingRequestDetails ' + offboardingRequsetId);
        return this.httpClient.get(
          environment.BASEURL +
          'Offboarding/GetOffboardingRequest/?id=' +
          offboardingRequsetId
        );
    }

    AddOffboardingRequest(paramObj: any): Observable<any> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers };
        const body = JSON.stringify({ OffboardingRequest: paramObj });

        return this.httpClient.post(
            environment.BASEURL + 'Offboarding/AddOffboardingRequest/'
            , body
            , options
        );
    }

    UpdateOffboardingRequest(paramObj: any): Observable<any> {

        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const options = { headers: headers };
        const body = JSON.stringify({ OffboardingRequest: paramObj });
  
        return this.httpClient.put(
            environment.BASEURL + 'Offboarding/UpdateOffboardingRequest/'
            , body
            , options
        );
  
    }
}