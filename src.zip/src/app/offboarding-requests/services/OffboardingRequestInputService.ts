import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class OffboardingRequestInputService {
  offboardingRequestInput(): any {
    return {
        Id: '',
        Name: '',
        Off_Boarding_Reason__c: '',
        Type_of_Account_to_Offboard__c: '',
        Legal_Name__c: '',
        Business_Acct_Fund_Name__c: '',
        CID_LEID__c: '',
        BA_ID__c: '',
        Status__c: '',
        Notes__c: '',
        External_Name__c: '',
        External_ID__c: '',
        Requestor_Name__c: '',
        Time_Submitted__c: null,
        CreatedDate: null,
        OwnerId: '',
        RequestedBy__c: '',
        UpdatedBy__c: '',
        Requestor_Department__c: '',
        Primary_Case_Manager__c: '',
        Secondary_Case_Manager__c: '',
        Primary_Case_Manager__r: null,
        Secondary_Case_Manager__r: null
    };
  }
}
