import { User } from "src/app/Common/dynamic-form-services/dynamic-form.service";

export interface OffboardingRequestInput {
    Id: string;
    Name: string;
    Off_Boarding_Reason__c: string;
    Type_of_Account_to_Offboard__c: string;
    Legal_Name__c: string;
    Business_Acct_Fund_Name__c: string;
    CID_LEID__c: string;
    BA_ID__c: string;
    Status__c: string;
    Notes__c: string;
    External_Name__c: string;
    External_ID__c: string;
    Requestor_Name__c: string;
    Time_Submitted__c: Date;
    OwnerId: string;
    RequestedBy__c: string;
    UpdatedBy__c: string;
    Requestor_Department__c: string;
    Primary_Case_Manager__c: string;
    Secondary_Case_Manager__c: string;
    Primary_Case_Manager__r: User;
    Secondary_Case_Manager__r: User;
    CreatedDate: Date;
}