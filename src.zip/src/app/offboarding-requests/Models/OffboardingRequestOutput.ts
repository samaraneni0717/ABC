import { User } from "src/app/Common/models/User";

export class OffboardingRequestOutput {
    Id: string;
    Name: string;
    Off_Boarding_Reason__c: string;
    Type_of_Account_to_Offboard__c: string;
    Legal_Name__c: string;
    Business_Acct_Fund_Name__c: string;
    CID_LEID__c: string;
    BA_ID__c: string;
    Status__c: string;
    Notes__c: string;
    External_Name__c: string;
    External_ID__c: string;
    Requestor_Name__c: string;
    Time_Submitted__c: Date;
    OwnerId: string;
    RequestedBy__c: string;
    UpdatedBy__c: string;
    Requestor_Department__c: string;
    Primary_Case_Manager__c: string;
    Secondary_Case_Manager__c: string;
    Primary_Case_Manager__r: User;
    Secondary_Case_Manager__r: User;
    CreatedDate: Date;

    constructor() {
        (this.Id = ''),
        (this.Name =  ''),
        (this.Off_Boarding_Reason__c =  ''),
        (this.Type_of_Account_to_Offboard__c = ''),
        (this.Legal_Name__c = ''),
        (this.Business_Acct_Fund_Name__c = ''),
        (this.CID_LEID__c = ''),
        (this.BA_ID__c = ''),
        (this.Status__c = ''),
        (this.Notes__c = ''),
        (this.External_Name__c = ''),
        (this.External_ID__c = ''),
        (this.Requestor_Name__c = ''),
        (this.Time_Submitted__c = null),
        (this.OwnerId = ''),
        (this.RequestedBy__c = ''),
        (this.UpdatedBy__c = ''),
        (this.Requestor_Department__c = ''),
        (this.Primary_Case_Manager__c = ''),
        (this.Secondary_Case_Manager__c = ''),
        (this.Primary_Case_Manager__c = null),
        (this.Secondary_Case_Manager__c = null),
        (this.CreatedDate = null);
    }
}