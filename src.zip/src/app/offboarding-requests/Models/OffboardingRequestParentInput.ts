import { OffboardingRequestInput } from "./OffboardingRequestInput";

export interface OffboardingRequestParentInput {
  OffboardingRequestInput: OffboardingRequestInput;
  UserAction: string;
}
