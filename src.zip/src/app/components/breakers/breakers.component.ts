import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import { MpiActionCreator } from '../../core/store/mpiActionCreator.service';
import { AppState } from '../../core/store/appstate.interface';

import "rxjs/add/operator/filter";

@Component({
  selector: 'breakers',
  templateUrl: './breakers.component.html'
})

export class BreakersComponent implements OnInit {
  
  constructor(private mpiActionCreator: MpiActionCreator, public store: Store<AppState>){ }

  breakers: any;
  
  ngOnInit(){
    //set the value in the store
    this.store.dispatch(this.mpiActionCreator.getBreakers());
    
    //retrieve the value from the store and assigning to this.breakers 
    // to pass to breakers table component.
    this.breakers = this.store.select(state => state.breakers)
    .filter(items => items && items.devices != undefined && items.devices.length > 0);
      
  }

}
