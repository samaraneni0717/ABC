import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { Location } from "@angular/common";
import { Store } from "@ngrx/store";

// RxJS
import "rxjs/add/operator/filter";
import { Observable } from "rxjs";

// Interfaces
import { AppState } from "../../core/store/appstate.interface";
import { Devices } from '../../core/interfaces/devices.interface';
import { TotalEnergy } from '../../core/interfaces/totalEnergy.interface';
import { TwentyFourHourHistory } from '../../core/interfaces/twentyFourHourHistory.interface';

// Services
import { MpiActionCreator } from "../../core/store/mpiActionCreator.service";

@Component({
  selector: "breaker-view",
  templateUrl: "./breaker-view.component.html"
})
export class BreakerViewComponent implements OnInit {
  breakers: Observable<Devices>;
  id: string;

  // Dates for the total energy and daily evergy usage charts  
  date: Date = new Date();
  today: string = new Date(this.date.setDate(this.date.getDate())).toISOString();
  yesterday: string = new Date(this.date.setDate(this.date.getDate() - 1)).toISOString();
  daysAgo: string = new Date(this.date.setDate(this.date.getDate() - 7)).toISOString();
  weeksAgo: string = new Date(this.date.setDate(this.date.getDate() - 30)).toISOString();
  monthsAgo: string = new Date(this.date.setDate(this.date.getDate()-60)).toISOString();

  // Pass breakerView to presentational components to enable specific views or functionality
  dashboard: boolean = false;
  mode: string = 'breakerView';

  // Observables passed to presentational components
  twentyFourHourHistory: Observable<TwentyFourHourHistory>;
  dailyEnergy: Observable<TotalEnergy>;
  weeklyEnergy: Observable<TotalEnergy>;
  monthlyEnergy: Observable<TotalEnergy>;

  constructor(
    private route: ActivatedRoute,
    private location: Location,
    private mpiActionCreator: MpiActionCreator,
    public store: Store<AppState>
  ) {}

  ngOnInit() {
    // route.snapshot gets the static route information
    this.id = this.route.snapshot.params.id;

    // Send breaker data from store
    this.breakers = this.store.select(state => state.breakers)
      .filter(breakers => breakers && breakers.devices != undefined && breakers.devices.length > 0);

    // Get 24 hour history
    this.store.dispatch(this.mpiActionCreator.getTwentyFourHourHistory(this.id, this.yesterday, this.today, "min15"));
    this.twentyFourHourHistory = this.store.select(state => state.twentyFourHourHistory);

    // Get total energy (day view)
    this.store.dispatch(this.mpiActionCreator.getTotalDailyEnergy(this.id, this.daysAgo, this.today, "daily"));
    this.dailyEnergy = this.store.select(state => state.totalDailyEnergy);

    // Get total energy (week view)
    this.store.dispatch(this.mpiActionCreator.getTotalWeeklyEnergy(this.id, this.weeksAgo, this.today, "weekly"));
    this.weeklyEnergy = this.store.select(state => state.totalWeeklyEnergy);

    // Get total energy (month view)
    this.store.dispatch(this.mpiActionCreator.getTotalMonthlyEnergy(this.id, this.monthsAgo, this.today, "monthly"));
    this.monthlyEnergy = this.store.select(state => state.totalMonthlyEnergy);
  }

  // Used to check if this.breakers is null within the breaker panel component
  handleNullBreakers(data) {
    // IF event is null get breakers
    if (data.breakers === null) {
      this.store.dispatch(this.mpiActionCreator.getBreakers());

      this.breakers = this.store.select(state => state.breakers)
        .filter(breakers => breakers && breakers.devices != undefined && breakers.devices.length > 0);
    }
  }

  // Dispatch new breaker data to store from event of changes to breaker information coming from the breaker panel
  handleBreakerEdits(breaker) {
    this.store.dispatch(this.mpiActionCreator.saveChanges(breaker));

    this.breakers = this.store.select(state => state.breakers)
      .filter(breakers => breakers && breakers.devices != undefined && breakers.devices.length > 0);
  }

  // Dispatch new breaker data to store based on event emitted from total energy chart.
  handleNewDates(data) {
    if (data.interval === "daily"){
      // Get total energy (day view)
      this.store.dispatch(this.mpiActionCreator.getTotalDailyEnergy(this.id, data.startDate, data.endDate, "daily"));
      this.dailyEnergy = this.store.select(state => state.totalDailyEnergy);
    } else if (data.interval === "weekly"){
      // Get total energy (week view)
      this.store.dispatch(this.mpiActionCreator.getTotalWeeklyEnergy(this.id, data.startDate, data.endDate, "weekly"));
      this.weeklyEnergy = this.store.select(state => state.totalWeeklyEnergy);
    } else {
      // Get total energy (month view)
      this.store.dispatch(this.mpiActionCreator.getTotalMonthlyEnergy(this.id, data.startDate, data.endDate, "monthly"));
      this.monthlyEnergy = this.store.select(state => state.totalMonthlyEnergy);
    }
  }
}
