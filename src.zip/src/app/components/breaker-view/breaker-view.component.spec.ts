import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, NO_ERRORS_SCHEMA } from "@angular/core";
import { Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF } from "@angular/common";
import { ActivatedRoute } from "@angular/router";

import { Store, StoreModule } from "@ngrx/store";
import { Observable } from "rxjs";

import { MockStore } from "../../core/store/mock-store";

//Data, Effects, Services and Reducers 
import { breakersReducer } from "../../core/store/reducers/breakers.reducer";
import { MpiActionCreator } from "../../core/store/mpiActionCreator.service";

// Components and Interfaces
import { BreakerViewComponent } from "./breaker-view.component";

describe('BreakerViewComponent', () => {
  let component: BreakerViewComponent;
  let fixture: ComponentFixture<BreakerViewComponent>;
  let section: HTMLElement;
  // let service: MpiActionCreator;
  let store: any;

// Mock Data
  let mockBreakers: any = {
    devices: [{
        breakerId: 124273434,
        deviceName: 'Backflush Pump',
        group: 3,
        loadType: 'Pump',
        location: {city: 'Columbus', state: 'OH', zipCode: '43001'},
        breakerType: '2 Poll 20 amps',
        currentUsage: 220,
        status: true,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 123456722,
        deviceName: '80 Gallon WH',
        group: 2,
        loadType: 'Water Heater',
        location: {city: 'Charlotte', state: 'NC', zipCode: '28117'},  
        breakerType: '1 Poll 30 amps',
        currentUsage: 7200,
        status: true,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 726494671,
        deviceName: "Car Charger Parking Space #10",
        group: 1,
        loadType: "EVSE",
        location: {city: "Charlotte", state: 'NC', zipCode: '28117'},
        breakerType: "EVSE 30 amps",
        currentUsage: 4000,
        status: true,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    },
    {
        breakerId: 844784938,
        deviceName: "220w LED light",
        group: 1,
        loadType: "Light",
        location: {city: "Raleigh", state: "NC", zipCode: "27511"},
        breakerType: "2 Poll 50 amps",
        currentUsage: 0,
        status: false,
        lastUpdate: "Monday, January 08, 2017 07:23:08 AM"
    }
  ]};

  // Creating and declaring stub version of breaker-panel.
  @Component({ selector: "breaker-panel", template: "" })
  class BreakerPanelComponent {}

    // Creating and declaring stub version of recent-usage-charts.
  @Component({ selector: "recent-usage-charts", template: "" })
  class RecentUsageChartsComponent {}

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        BreakerViewComponent,
        BreakerPanelComponent,
        RecentUsageChartsComponent 
      ],
      imports: [
        StoreModule.forRoot({ reducer: breakersReducer })      
      ],
      providers: [
        { provide: ActivatedRoute, 
          useValue: {
            snapshot: {params: Observable.of({breakerID: "123445567"})}
          }
        },
        { provide: APP_BASE_HREF, useValue: '/'},        
        Location,
        { provide: LocationStrategy, useClass: PathLocationStrategy },
        MpiActionCreator,
        { provide: Store, 
          useValue: new MockStore({mockBreakers: []})
        },
      ],
      schemas: [NO_ERRORS_SCHEMA]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreakerViewComponent);
    section = fixture.nativeElement.querySelector('section');
    store = fixture.debugElement.injector.get(Store);
    component = fixture.componentInstance;        
    store.dispatch({type: MpiActionCreator.GET_BREAKERS, payload: null });
    fixture.detectChanges();
  });

  it("should be created", () => {
    expect(component).toBeTruthy();
  });

  it("store to be defined", async(() => {
    expect(store).toBeDefined();
  }));

  it("data is in component", async(() => {
    store.next({ mockBreakers: mockBreakers.devices });
    fixture.detectChanges();
    component.breakers = mockBreakers.devices;
    expect(component.breakers).toEqual(mockBreakers.devices);
  }));

});
