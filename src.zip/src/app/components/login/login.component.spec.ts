import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, NO_ERRORS_SCHEMA } from "@angular/core";
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router, ActivatedRoute } from "@angular/router";
import { RouterTestingModule } from "@angular/router/testing";

import { Observable } from "rxjs";

import { EnvironmentVariables } from "../../core/services/envionment.service";
import { Login } from "../../core/services/login.service";

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  
  // let env: EnvironmentVariables;  
  let httpMock: HttpTestingController;
  // let initialCode: string; 
  
  let service;

  class MockAuthService extends Login {
    mockProcess(){

      let mockLogin: any = {
        access_token: 'bjfd8re4tnm4t',
        client_id: '984tbnek',
        email: 'billybob@gmail.com',
        expires_in: '100000',
        issued_at: '546456345634',
        refresh_count: '1',
        refresh_token: '43bn334ui4tne8ddf89fb897vbcbb',
        refresh_token_expires_in: '90000',
        refresh_token_issued_at: '4353543429072843',
        refresh_token_status: '0',
        scope: '',
        token_name: '83434b34bj34bjk43hiu',
        unique_name: 'test'
      };

      return mockLogin;

    }

  }

  // Creating and declaring stub version of breaker-panel.
  @Component({ selector: "breakers", template: "" })
  class BreakersComponent {}

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BreakersComponent, LoginComponent],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([
          { path: "login", component: LoginComponent },
          { path: "breakers", component: BreakersComponent }
        ])
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: Observable.of({ code: "1da41e81-df88-47b2-b894-b10baae2c249" })
          }
        },
        EnvironmentVariables,
        Login,
        MockAuthService,
        {
          provide: Router,
          userValue: "login"
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    httpMock = TestBed.get(HttpTestingController);
    component = fixture.componentInstance;
    service = fixture.debugElement.injector.get(MockAuthService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should return expected login", () => {
    spyOn(service, 'mockProcess').and.returnValue(true);
  });
});