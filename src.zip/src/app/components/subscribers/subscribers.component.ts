import { Component, OnInit } from '@angular/core';
import { MatDialog } from "@angular/material/dialog";
import { DataAccess } from '../../core/services/dataAccess.service'

import { Subscriber } from '../../core/interfaces/subscriber.interface';
import { SubscribersChooseModalComponent } from '../../core/p-components/subscribers-choose-modal/subscribers-choose-modal.component';

import { Router } from "@angular/router";

@Component({
  selector: "subscribers",
  templateUrl: "./subscribers.component.html"
})
export class SubscribersComponent implements OnInit {
  private dialogRef: any;
  
  constructor(public dialog: MatDialog, private da: DataAccess, private router: Router){}

  ngOnInit() {

    this.da.getSubscriptions().map(s => 
      {
        if(s.length == 1){
          
          sessionStorage.setItem("subscriber", JSON.stringify(s[0]));
          this.router.navigate(['dashboard']);

        }
        else{

          this.openDialog(s);

        }
        
      }
    )
    .subscribe();  

  }

  openDialog(subData: Array<Subscriber>): void {

    this.dialogRef = this.dialog.open(SubscribersChooseModalComponent, {
      width: "350px",
      data: subData,
      disableClose: true
    });
  }
}

