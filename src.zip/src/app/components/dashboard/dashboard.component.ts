import { Component, OnInit } from "@angular/core";
import { Store } from "@ngrx/store";

// RxJS
import "rxjs/add/operator/filter";
import { Observable } from "rxjs";

// Interfaces
import { AppState } from "../../core/store/appstate.interface";
import { Devices } from "../../core/interfaces/devices.interface";
import { Group } from "../../core/interfaces/group.interface";
import { TotalEnergy } from "../../core/interfaces/totalEnergy.interface";
import { TwentyFourHourHistory } from "../../core/interfaces/twentyFourHourHistory.interface";

// Services
import { MpiActionCreator } from "../../core/store/mpiActionCreator.service";

import "rxjs/add/operator/filter";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  breakers: Observable<Devices>;
  dashboard: boolean = true;
  mode: string = 'dashboard';

  // Dates for the total energy and daily evergy usage charts  
  date: Date = new Date();
  today = new Date(this.date.setDate(this.date.getDate())).toISOString();
  yesterday = new Date(this.date.setDate(this.date.getDate() - 1)).toISOString();
  daysAgo = new Date(this.date.setDate(this.date.getDate() - 7)).toISOString();
  weeksAgo = new Date(this.date.setDate(this.date.getDate() - 30)).toISOString();
  monthsAgo = new Date(this.date.setDate(this.date.getDate() - 60)).toISOString();

  groups: Observable<Array<Group>>;
  twentyFourHourHistory: Observable<TwentyFourHourHistory>;
  dailyEnergy: Observable<TotalEnergy>;
  weeklyEnergy: Observable<TotalEnergy>;
  monthlyEnergy: Observable<TotalEnergy>;

  constructor(private mpiActionCreator: MpiActionCreator, public store: Store<AppState>) { }

  ngOnInit() {    
    this.breakers = this.store.select(state => state.breakers)
      .filter(breakers => breakers && breakers.devices != undefined && breakers.devices.length > 0);

    this.groups = this.store.select(state=> state.groups);

    // Get 24 hour history
    // this.store.dispatch(this.mpiActionCreator.getTwentyFourHourHistoryByGroup('*', "2018-04-18T00:00:00-04:00", "2018-04-19T00:00:00-04:00", "min15"));
    this.store.dispatch(this.mpiActionCreator.getTwentyFourHourHistoryByGroup("*", this.yesterday, this.today, "min15"));
    this.twentyFourHourHistory = this.store.select(state => state.twentyFourHourHistoryByGroup);

    // Get total energy (day view)
    // this.store.dispatch(this.mpiActionCreator.getTotalDailyEnergyByGroup('*', "2018-04-18T00:00:00-04:00", "2018-04-24T00:00:00-04:00", "daily"));
    this.store.dispatch(this.mpiActionCreator.getTotalDailyEnergyByGroup("*", this.daysAgo, this.today, "daily"));
    this.dailyEnergy = this.store.select(state => state.totalDailyEnergyByGroup);

    // Get total energy (week view)
    // this.store.dispatch(this.mpiActionCreator.getTotalWeeklyEnergyByGroup('*', "2018-04-18T00:00:00-04:00", "2018-04-25T00:00:00-04:00", "weekly"));
    this.store.dispatch(this.mpiActionCreator.getTotalWeeklyEnergyByGroup("*", this.weeksAgo, this.today, "weekly"));
    this.weeklyEnergy = this.store.select(state => state.totalWeeklyEnergyByGroup);

    // Get total energy (month view)
    // this.store.dispatch(this.mpiActionCreator.getTotalMonthlyEnergyByGroup('*', "2018-03-22T00:00:00-04:00", "2018-05-18T00:00:00-04:00", "monthly"));
    this.store.dispatch(this.mpiActionCreator.getTotalMonthlyEnergyByGroup('*', this.monthsAgo, this.today, "monthly"));
    this.monthlyEnergy = this.store.select(state => state.totalMonthlyEnergyByGroup);
  }

  // Used to check if this.breakers is null within the breaker-panel presentational component
  handleNullBreakers(data) {
    // IF event is null get breakers
    if (data.breakers === null) {
      this.store.dispatch(this.mpiActionCreator.getBreakers());

      this.breakers = this.store.select(state => state.breakers)
        .filter(breakers => breakers && breakers.devices != undefined && breakers.devices.length > 0);

      this.groups = this.store.select(state => state.groups);
    }
  }

  handleSelectedGroups(groups){
    let groupString = groups.groups.join(",");

    if (groups.chart === "24 hour"){      
      // Get 24 hour history
      this.store.dispatch(this.mpiActionCreator.getTwentyFourHourHistoryByGroup(groupString, this.yesterday, this.today, "min15"));
      this.twentyFourHourHistory = this.store.select(state => state.twentyFourHourHistoryByGroup);
    } else {
      if (groups.interval === "daily") {
        // Get total energy (day view)
        this.store.dispatch(this.mpiActionCreator.getTotalDailyEnergyByGroup(groupString, groups.startDate, groups.endDate, "daily"));
        this.dailyEnergy = this.store.select(state => state.totalDailyEnergyByGroup);
      } else if (groups.interval === "weekly") {
        // Get total energy (week view)
        this.store.dispatch(this.mpiActionCreator.getTotalWeeklyEnergyByGroup(groupString, groups.startDate, groups.endDate, "weekly"));
        this.weeklyEnergy = this.store.select(state => state.totalWeeklyEnergyByGroup);
      } else {
        // Get total energy (month view)
        this.store.dispatch(this.mpiActionCreator.getTotalMonthlyEnergyByGroup(groupString, groups.startDate, groups.endDate, "monthly"));
        this.monthlyEnergy = this.store.select(state => state.totalMonthlyEnergyByGroup);
      }
    }
  }

  // Use if you implement lazy loading for total energy tabs
  // handleSelectedTab(tabInfo){
  //   if (tabInfo.tab === "weekly") {
  //     // Get total energy (week view)
  //     this.store.dispatch(this.mpiActionCreator.getTotalWeeklyEnergyByGroup(tabInfo.groups, this.weeksAgo, this.today, tabInfo.tab));
  //     this.weeklyEnergy = this.store.select(state => state.totalWeeklyEnergyByGroup);
  //   } else {
  //     // Get total energy (month view)
  //     this.store.dispatch(this.mpiActionCreator.getTotalMonthlyEnergyByGroup(tabInfo.groups, this.monthsAgo, this.today, tabInfo.tab));
  //     this.monthlyEnergy = this.store.select(state => state.totalMonthlyEnergyByGroup);
  //   }
  // }

}
