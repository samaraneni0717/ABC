export const environment = {
  production: true,
  environmentApi: 'app/config'
};
